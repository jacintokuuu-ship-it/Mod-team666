#!/bin/bash
set -euo pipefail
PROJECT_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APP_NAME="${APP_NAME:-Fryzz}"
APP="$PROJECT_ROOT/.theos/obj/${APP_NAME}.app"
SOURCE_APP="$PROJECT_ROOT/layout/Applications/${APP_NAME}.app"
OUT="$PROJECT_ROOT/trollstore-out"
STAGE="$PROJECT_ROOT/trollstore-stage"
test -d "$APP"
test -f "$APP/$APP_NAME"
rm -rf "$STAGE" "$OUT"
mkdir -p "$STAGE/Payload" "$OUT"
ditto "$APP" "$STAGE/Payload/$APP_NAME.app"
test -f "$SOURCE_APP/Info.plist"
cp -f "$SOURCE_APP/Info.plist" "$STAGE/Payload/$APP_NAME.app/Info.plist"
test -f "$STAGE/Payload/$APP_NAME.app/Info.plist"
test -f "$STAGE/Payload/$APP_NAME.app/$APP_NAME"
/usr/bin/plutil -lint "$STAGE/Payload/$APP_NAME.app/Info.plist"
python3 - "$STAGE/Payload/$APP_NAME.app/Info.plist" <<'PY2'
import plistlib,sys
with open(sys.argv[1],"rb") as f:x=plistlib.load(f)
assert x.get("CFBundleExecutable")=="Fryzz"
assert x.get("CFBundlePackageType")=="APPL"
print("Info.plist OK")
PY2
(cd "$STAGE" && COPYFILE_DISABLE=1 zip -qry "../trollstore-out/Fryzz-TrollStore.tipa" Payload)
echo "Created: $OUT/Fryzz-TrollStore.tipa"
