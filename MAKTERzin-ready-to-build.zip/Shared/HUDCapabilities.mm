#import "HUDCapabilities.h"
#import <UIKit/UIKit.h>
#include <sys/utsname.h>

@implementation HUDCapabilitySnapshot

+ (instancetype)currentSnapshot {
    HUDCapabilitySnapshot *s = [HUDCapabilitySnapshot new];
    s.osVersion = UIDevice.currentDevice.systemVersion;
    s.deviceModel = UIDevice.currentDevice.model;

    struct utsname u;
    s.architecture = @"unknown";
    if (uname(&u) == 0) {
        s.architecture = [NSString stringWithUTF8String:u.machine] ?: @"unknown";
    }

    s.rootlessPathPresent = [[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"];
    s.executionMode = s.rootlessPathPresent ? @"Rootless hints detected" : @"Standalone / sandboxed";
    return s;
}

@end
