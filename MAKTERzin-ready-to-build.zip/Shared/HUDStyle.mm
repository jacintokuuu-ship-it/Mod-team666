#import "HUDStyle.h"

UIColor *HUDBackgroundColor(void) { return [UIColor colorWithRed:0.025 green:0.055 blue:0.11 alpha:.98]; }
UIColor *HUDBorderColor(void) { return [UIColor colorWithRed:.15 green:.45 blue:.95 alpha:.35]; }
UIColor *HUDAccentColor(void) { return [UIColor colorWithRed:.10 green:.48 blue:1.0 alpha:1]; }
UIColor *HUDAccentSoftColor(void) { return [UIColor colorWithRed:.20 green:.65 blue:1.0 alpha:.18]; }
UIColor *HUDPanelColor(void) { return [UIColor colorWithRed:.04 green:.09 blue:.17 alpha:.96]; }
