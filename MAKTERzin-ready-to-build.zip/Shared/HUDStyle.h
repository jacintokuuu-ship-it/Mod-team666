#pragma once
#import <UIKit/UIKit.h>

UIColor *HUDBackgroundColor(void);
UIColor *HUDBorderColor(void);
UIColor *HUDAccentColor(void);
UIColor *HUDAccentSoftColor(void);
UIColor *HUDPanelColor(void);
