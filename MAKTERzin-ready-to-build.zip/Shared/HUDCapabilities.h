#import <Foundation/Foundation.h>

@interface HUDCapabilitySnapshot : NSObject
@property(nonatomic,copy) NSString *osVersion;
@property(nonatomic,copy) NSString *deviceModel;
@property(nonatomic,copy) NSString *architecture;
@property(nonatomic,copy) NSString *executionMode;
@property(nonatomic) BOOL rootlessPathPresent;
+ (instancetype)currentSnapshot;
@end
