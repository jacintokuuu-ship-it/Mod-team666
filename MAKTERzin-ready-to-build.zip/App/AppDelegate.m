#import "AppDelegate.h"
#import "Menu/Menu.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UIViewController *vc = [UIViewController new];
    vc.view.backgroundColor = [UIColor systemBackgroundColor];
    self.window.rootViewController = vc;
    [self.window makeKeyAndVisible];

    [[HUDManager sharedManager] startInView:vc.view];
    return YES;
}

@end
