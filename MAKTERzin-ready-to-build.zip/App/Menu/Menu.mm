#import "Menu.h"
#import "../Core/FeatureManager.h"
#import "../Core/Backend.h"
#import "../../Shared/HUDStyle.h"

@interface HUDMenuView ()
@property(nonatomic,strong) UISegmentedControl *segments;
@property(nonatomic,strong) UIView *content;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) UILabel *capability;
@property(nonatomic,strong) UISwitch *masterSwitch;
@property(nonatomic,strong) UISlider *intensity;
@property(nonatomic,strong) UITextField *profile;
@property(nonatomic,strong) UISwitch *haptics;
@property(nonatomic,strong) UISwitch *compact;
@property(nonatomic,strong) UIImageView *logo;
@end

@implementation HUDMenuView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (!self) return nil;

    self.backgroundColor = HUDBackgroundColor();
    self.layer.cornerRadius = 24;
    self.layer.borderWidth = 1;
    self.layer.borderColor = HUDBorderColor().CGColor;
    self.layer.shadowColor = UIColor.blackColor.CGColor;
    self.layer.shadowOpacity = .35;
    self.layer.shadowRadius = 24;
    self.layer.shadowOffset = CGSizeMake(0, 12);

    UIView *accent = [[UIView alloc] initWithFrame:CGRectMake(0,0,4,frame.size.height)];
    accent.backgroundColor = HUDAccentColor();
    accent.layer.cornerRadius = 2;
    accent.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    [self addSubview:accent];

    UIImage *img = [UIImage imageNamed:@"fogo"];
    _logo = [[UIImageView alloc] initWithImage:img];
    _logo.frame = CGRectMake(18,14,44,44);
    _logo.contentMode = UIViewContentModeScaleAspectFit;
    _logo.layer.cornerRadius = 12;
    _logo.clipsToBounds = YES;
    [self addSubview:_logo];

    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(72,12,180,28)];
    title.text = @"MAKTERzin";
    title.textColor = UIColor.whiteColor;
    title.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBlack];
    [self addSubview:title];

    UILabel *sub = [[UILabel alloc] initWithFrame:CGRectMake(72,38,200,20)];
    sub.text = @"MODULAR • BLUE EDITION";
    sub.textColor = HUDAccentColor();
    sub.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
    [self addSubview:sub];

    _status = [[UILabel alloc] initWithFrame:CGRectMake(frame.size.width-110,16,92,24)];
    _status.textAlignment = NSTextAlignmentRight;
    _status.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
    _status.textColor = HUDAccentColor();
    _status.text = @"READY";
    _status.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:_status];

    _segments = [[UISegmentedControl alloc] initWithItems:@[@"HOME",@"TOOLS",@"SETTINGS"]];
    _segments.frame = CGRectMake(16,70,frame.size.width-32,36);
    _segments.selectedSegmentIndex = 0;
    _segments.selectedSegmentTintColor = HUDAccentColor();
    [_segments setTitleTextAttributes:@{NSForegroundColorAttributeName:UIColor.whiteColor} forState:UIControlStateSelected];
    [_segments addTarget:self action:@selector(segmentChanged:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_segments];

    _content = [[UIView alloc] initWithFrame:CGRectMake(16,118,frame.size.width-32,frame.size.height-132)];
    _content.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_content];

    [self showHome];
    return self;
}

- (void)clearContent {
    for (UIView *v in _content.subviews) [v removeFromSuperview];
}

- (UILabel *)label:(NSString *)text frame:(CGRect)frame {
    UILabel *l = [[UILabel alloc] initWithFrame:frame];
    l.text = text;
    l.textColor = UIColor.whiteColor;
    l.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    [_content addSubview:l];
    return l;
}

- (UIButton *)button:(NSString *)title frame:(CGRect)frame {
    UIButton *b = [UIButton buttonWithType:UIButtonTypeSystem];
    b.frame = frame;
    b.backgroundColor = HUDPanelColor();
    b.layer.cornerRadius = 13;
    b.layer.borderWidth = 1;
    b.layer.borderColor = HUDBorderColor().CGColor;
    b.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:HUDAccentColor() forState:UIControlStateNormal];
    b.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    return b;
}

- (UISwitch *)toggle:(NSString *)name y:(CGFloat)y on:(BOOL)value action:(SEL)selector {
    [self label:name frame:CGRectMake(4,y,190,34)];
    UISwitch *s = [[UISwitch alloc] initWithFrame:CGRectMake(_content.bounds.size.width-58,y,51,31)];
    s.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
    s.onTintColor = HUDAccentColor();
    s.on = value;
    [s addTarget:self action:selector forControlEvents:UIControlEventValueChanged];
    [_content addSubview:s];
    return s;
}

- (void)showHome {
    [self clearContent];
    FeatureManager *fm = FeatureManager.sharedManager;

    UILabel *heading = [self label:@"CONTROL CENTER" frame:CGRectMake(4,0,220,28)];
    heading.textColor = HUDAccentColor();

    _masterSwitch = [self toggle:@"HUD enabled" y:34 on:fm.state.enabled action:@selector(masterChanged:)];

    [self label:@"Intensity" frame:CGRectMake(4,78,100,28)];
    _intensity = [[UISlider alloc] initWithFrame:CGRectMake(102,78,_content.bounds.size.width-106,28)];
    _intensity.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _intensity.minimumValue = 0; _intensity.maximumValue = 1; _intensity.value = fm.state.intensity;
    _intensity.minimumTrackTintColor = HUDAccentColor();
    [_intensity addTarget:self action:@selector(intensityChanged:) forControlEvents:UIControlEventValueChanged];
    [_content addSubview:_intensity];

    [self label:@"Profile" frame:CGRectMake(4,118,90,34)];
    _profile = [[UITextField alloc] initWithFrame:CGRectMake(92,118,_content.bounds.size.width-96,34)];
    _profile.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    _profile.backgroundColor = HUDPanelColor();
    _profile.textColor = UIColor.whiteColor;
    _profile.layer.cornerRadius = 9;
    _profile.layer.borderWidth = 1;
    _profile.layer.borderColor = HUDBorderColor().CGColor;
    _profile.leftView = [[UIView alloc] initWithFrame:CGRectMake(0,0,10,1)];
    _profile.leftViewMode = UITextFieldViewModeAlways;
    _profile.text = fm.state.profileName;
    _profile.placeholder = @"Profile name";
    [_profile addTarget:self action:@selector(profileChanged:) forControlEvents:UIControlEventEditingDidEnd|UIControlEventEditingDidEndOnExit];
    [_content addSubview:_profile];

    UIView *card = [[UIView alloc] initWithFrame:CGRectMake(4,166,_content.bounds.size.width-8,76)];
    card.autoresizingMask = UIViewAutoresizingFlexibleWidth;
    card.backgroundColor = HUDPanelColor();
    card.layer.cornerRadius = 14;
    card.layer.borderWidth = 1;
    card.layer.borderColor = HUDBorderColor().CGColor;
    [_content addSubview:card];

    UILabel *t = [[UILabel alloc] initWithFrame:CGRectMake(12,10,card.bounds.size.width-24,24)];
    t.text = @"BACKEND";
    t.textColor = HUDAccentColor();
    t.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
    [card addSubview:t];

    UILabel *v = [[UILabel alloc] initWithFrame:CGRectMake(12,32,card.bounds.size.width-24,32)];
    v.text = [HUDBackend.sharedBackend statusText];
    v.textColor = UIColor.whiteColor;
    v.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
    [card addSubview:v];
}

- (void)showTools {
    [self clearContent];

    [self label:@"DIAGNOSTICS" frame:CGRectMake(4,0,220,28)].textColor = HUDAccentColor();

    UIButton *refresh = [self button:@"Refresh environment" frame:CGRectMake(4,38,_content.bounds.size.width-8,44)];
    refresh.tag = 10;
    [refresh addTarget:self action:@selector(toolPressed:) forControlEvents:UIControlEventTouchUpInside];
    [_content addSubview:refresh];

    UIButton *reset = [self button:@"Reset local configuration" frame:CGRectMake(4,90,_content.bounds.size.width-8,44)];
    reset.tag = 11;
    [reset addTarget:self action:@selector(toolPressed:) forControlEvents:UIControlEventTouchUpInside];
    [_content addSubview:reset];

    HUDCapabilitySnapshot *c = FeatureManager.sharedManager.capabilities;
    UILabel *info = [self label:[NSString stringWithFormat:@"OS %@\nDevice %@ • %@\n%@",
        c.osVersion,c.deviceModel,c.architecture,c.executionMode]
        frame:CGRectMake(4,150,_content.bounds.size.width-8,74)];
    info.numberOfLines = 0;
    info.textColor = UIColor.lightTextColor;
    info.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
}

- (void)showSettings {
    [self clearContent];
    FeatureManager *fm = FeatureManager.sharedManager;

    [self label:@"PREFERENCES" frame:CGRectMake(4,0,220,28)].textColor = HUDAccentColor();
    _haptics = [self toggle:@"Haptic feedback" y:38 on:fm.state.haptics action:@selector(hapticsChanged:)];
    _compact = [self toggle:@"Compact layout" y:82 on:fm.state.compactMode action:@selector(compactChanged:)];

    UILabel *about = [self label:@"MAKTERzin 1.0.0\nStandalone iOS modular HUD\nLocal settings via NSUserDefaults"
        frame:CGRectMake(4,132,_content.bounds.size.width-8,70)];
    about.numberOfLines = 0;
    about.textColor = UIColor.secondaryLabelColor;
    about.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
}

- (void)segmentChanged:(UISegmentedControl *)sender {
    if (sender.selectedSegmentIndex == 0) [self showHome];
    else if (sender.selectedSegmentIndex == 1) [self showTools];
    else [self showSettings];
}

- (void)masterChanged:(UISwitch *)s {
    FeatureManager.sharedManager.state.enabled = s.isOn;
    [FeatureManager.sharedManager update];
    _status.text = s.isOn ? @"ACTIVE" : @"READY";
}

- (void)intensityChanged:(UISlider *)s {
    FeatureManager.sharedManager.state.intensity = s.value;
    [FeatureManager.sharedManager update];
}

- (void)profileChanged:(UITextField *)t {
    if (t.text.length) FeatureManager.sharedManager.state.profileName = t.text;
    [FeatureManager.sharedManager update];
}

- (void)hapticsChanged:(UISwitch *)s {
    FeatureManager.sharedManager.state.haptics = s.isOn;
    [FeatureManager.sharedManager update];
}

- (void)compactChanged:(UISwitch *)s {
    FeatureManager.sharedManager.state.compactMode = s.isOn;
    [FeatureManager.sharedManager update];
}

- (void)toolPressed:(UIButton *)b {
    if (b.tag == 10) {
        [HUDBackend.sharedBackend refresh];
        _status.text = @"SCANNED";
        [self showTools];
    } else if (b.tag == 11) {
        [FeatureManager.sharedManager reset];
        _status.text = @"RESET";
        [self showHome];
    }
}

@end

@implementation HUDManager {
    HUDMenuView *_menu;
    UIButton *_handle;
    UIView *_host;
}

+ (instancetype)sharedManager {
    static HUDManager *m; static dispatch_once_t once;
    dispatch_once(&once, ^{ m = [HUDManager new]; });
    return m;
}

- (void)startInView:(UIView *)view {
    if (_menu.superview) return;
    _host = view;

    CGFloat width = MIN(370.0, MAX(300.0, view.bounds.size.width-24));
    CGFloat height = 330.0;
    _menu = [[HUDMenuView alloc] initWithFrame:CGRectMake(12,60,width,height)];
    _menu.autoresizingMask = UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin;
    [view addSubview:_menu];

    _handle = [UIButton buttonWithType:UIButtonTypeSystem];
    _handle.frame = CGRectMake(14,404,52,52);
    _handle.autoresizingMask = UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleRightMargin;
    _handle.backgroundColor = HUDBackgroundColor();
    _handle.layer.cornerRadius = 26;
    _handle.layer.borderWidth = 1;
    _handle.layer.borderColor = HUDBorderColor().CGColor;
    [_handle setTitle:@"M" forState:UIControlStateNormal];
    [_handle setTitleColor:HUDAccentColor() forState:UIControlStateNormal];
    _handle.titleLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBlack];
    [_handle addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:_handle];
}

- (void)toggle { _menu.hidden = !_menu.hidden; }

@end
