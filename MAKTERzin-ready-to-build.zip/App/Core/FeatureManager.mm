#import "FeatureManager.h"
#import "Backend.h"

static NSString * const kConfigKey = @"MAKTERzin.configuration";

@implementation HUDFeatureState
@end

@implementation FeatureManager {
    HUDFeatureState *_state;
}

+ (instancetype)sharedManager {
    static FeatureManager *m;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ m = [FeatureManager new]; });
    return m;
}

- (instancetype)init {
    self = [super init];
    if (!self) return nil;

    _state = [HUDFeatureState new];
    _state.profileName = @"Default";
    _state.intensity = .75f;
    _state.haptics = YES;

    NSDictionary *saved = [[NSUserDefaults standardUserDefaults] objectForKey:kConfigKey];
    if ([saved isKindOfClass:NSDictionary.class]) {
        _state.enabled = [saved[@"enabled"] boolValue];
        if (saved[@"intensity"]) _state.intensity = [saved[@"intensity"] floatValue];
        if ([saved[@"profileName"] isKindOfClass:NSString.class]) _state.profileName = saved[@"profileName"];
        if (saved[@"haptics"]) _state.haptics = [saved[@"haptics"] boolValue];
        _state.compactMode = [saved[@"compactMode"] boolValue];
    }
    return self;
}

- (HUDFeatureState *)state { return _state; }
- (HUDCapabilitySnapshot *)capabilities { return [HUDCapabilitySnapshot currentSnapshot]; }

- (void)update {
    NSDictionary *d = @{
        @"enabled": @(_state.enabled),
        @"intensity": @(_state.intensity),
        @"profileName": _state.profileName ?: @"Default",
        @"haptics": @(_state.haptics),
        @"compactMode": @(_state.compactMode)
    };
    [[NSUserDefaults standardUserDefaults] setObject:d forKey:kConfigKey];
}

- (void)reset {
    _state.enabled = NO;
    _state.intensity = .75f;
    _state.profileName = @"Default";
    _state.haptics = YES;
    _state.compactMode = NO;
    [self update];
    [[HUDBackend sharedBackend] refresh];
}

@end
