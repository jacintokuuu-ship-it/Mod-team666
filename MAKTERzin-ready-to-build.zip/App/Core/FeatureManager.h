#import <Foundation/Foundation.h>
#import "../../Shared/HUDCapabilities.h"

@interface HUDFeatureState : NSObject
@property(nonatomic) BOOL enabled;
@property(nonatomic) float intensity;
@property(nonatomic,copy) NSString *profileName;
@property(nonatomic) BOOL haptics;
@property(nonatomic) BOOL compactMode;
@end

@interface FeatureManager : NSObject
@property(nonatomic,readonly) HUDFeatureState *state;
@property(nonatomic,readonly) HUDCapabilitySnapshot *capabilities;
+ (instancetype)sharedManager;
- (void)update;
- (void)reset;
@end
