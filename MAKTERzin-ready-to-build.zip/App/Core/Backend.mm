#import "Backend.h"

@implementation HUDBackend {
    BOOL _available;
    NSString *_statusText;
}

+ (instancetype)sharedBackend {
    static HUDBackend *b;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ b = [HUDBackend new]; });
    return b;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _available = YES;
        _statusText = @"Local backend ready";
    }
    return self;
}

- (BOOL)available { return _available; }
- (NSString *)statusText { return _statusText; }

- (void)refresh {
    _available = YES;
    _statusText = @"Local backend ready";
}

@end
