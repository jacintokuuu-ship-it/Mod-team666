#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HUDBackend : NSObject
@property(nonatomic,readonly) BOOL available;
@property(nonatomic,readonly) NSString *statusText;
+ (instancetype)sharedBackend;
- (void)refresh;
@end

NS_ASSUME_NONNULL_END
