# MAKTERzin — Modular iOS HUD

Uma nova base independente inspirada apenas na organização modular do projeto de referência.
O aplicativo é **standalone/userland**: não inclui injeção, leitura/escrita de memória de outros
processos, bypass de anti-cheat, evasão de detecção, exploit de kernel ou mecanismo de stealth.

## Estrutura

- `App/` — aplicativo iOS standalone.
- `App/Menu/` — interface do menu MAKTERzin.
- `App/Overlay/` — camada visual.
- `App/Core/` — estado/configuração e backend seguro.
- `Shared/` — estilo e modelos compartilhados.
- `App/Resources/Assets.xcassets/` — logo `fogo.png`.
- `.github/workflows/build.yml` — build automático da IPA.

## Atualização futura

Os pontos de integração ficam isolados em `App/Core/Backend.h/.mm`.
Para um projeto legítimo que tenha uma API própria/autorizada, substitua apenas o backend,
sem espalhar lógica específica pelo menu.

## Build

GitHub Actions usa macOS + Xcode + Theos SDK, seguindo a estrutura do workflow de referência.
O resultado é `output/MAKTERzin.ipa`.

Compatibilidade configurada: arm64, SDK iPhoneOS 15.6, deployment iOS 15.0.
