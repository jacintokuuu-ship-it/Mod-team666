# iOSModularHUD — Modular TrollStore + Rootless Project

A clean, buildable base for a TrollStore standalone app and a Theos rootless tweak.

## What is included

### Standalone `App/`
A real iOS application intended to be packaged as:
- `iOSModularHUD.ipa`
- `iOSModularHUD.tipa`

The app includes:
- modern modular HUD;
- feature page with master toggle, intensity slider and profile field;
- tools/diagnostics page;
- settings page;
- local persistence with `NSUserDefaults`;
- environment/capability snapshot;
- rootless path detection;
- safe URL scheme `iosmodularhud://`;
- no dependency on a jailbreak for launching the UI.

### Jailbreak `Tweak/`
A separate Theos rootless tweak:
- UIKit overlay;
- feature tabs;
- diagnostics;
- rootless packaging;
- SpringBoard filter;
- C++17 Objective-C++ build.

### Shared/
Shared capability inspection used by both targets.

## Kernel/jailbreak boundary

TrollStore does **not** automatically give a normal application kernel-level privileges. The project therefore does not pretend that an IPA has kernel access.

The architecture leaves a clean `FeatureManager`/backend boundary where a legitimate, separately installed and authorized helper can be integrated later. This repository does not contain a kernel exploit, privilege escalation, anti-cheat bypass, anti-ban mechanism, memory patcher, stealth/injection engine, or detection evasion.

## Build

GitHub Actions uses macOS + Xcode and builds:

1. `iOSModularHUD-rootless.deb`
2. `iOSModularHUD.ipa`
3. `iOSModularHUD.tipa`

Run:

**Actions → Build iOSModularHUD → Run workflow**

## Research basis

The UI architecture follows common open-source mod-menu patterns such as pages, toggles, sliders, text fields and modular menu items, while keeping this implementation limited to safe UI/state functionality. See examples such as Xelahot's menu base and other Theos menu templates.

TrollStore can preserve entitlements and can package powerful apps, but its own documentation also describes important limitations around platformization and process injection. A TrollStore-installed app should therefore not be represented as automatically having kernel access.

## Compatibility

The targets are configured for arm64 and iOS 15+ SDK/deployment. Actual TrollStore installation compatibility depends on the device/iOS version and TrollStore support.


## GitHub Actions IPA build

The workflow builds only the standalone IPA with iPhoneOS 15.6 SDK and arm64, using an iOS 15.0 deployment target for iOS 15.x compatibility. It installs the official Theos SDK repository directly instead of using the failing GitHub API-based SDK installer.
