#import <UIKit/UIKit.h>
#import "Menu/Menu.h"
#import "Overlay/Overlay.h"

%ctor {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[HUDManager sharedManager] start];
    });
}
