#pragma once
#import <UIKit/UIKit.h>

@interface HUDMenuView : UIView
@end

@interface HUDManager : NSObject
+ (instancetype)sharedManager;
- (void)start;
- (void)toggle;
@end
