#import "Menu.h"
#import "../Config/Settings.h"
#import "../Config/Features.h"
#import "../Config/Theme.h"
#import "../Core/FeatureManager.h"

@implementation HUDMenuView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor colorWithWhite:0.08 alpha:0.96];
        self.layer.cornerRadius = Theme.cornerRadius;

        UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(
            Theme.padding, Theme.padding, frame.size.width - Theme.padding * 2, 30
        )];
        title.text = @"iOS Modular HUD";
        title.textColor = UIColor.whiteColor;
        title.font = [UIFont boldSystemFontOfSize:20];
        [self addSubview:title];

        [self addSwitch:@"Feature A" y:58 action:^{
            Features::featureA = !Features::featureA;
        }];

        [self addSwitch:@"Feature B" y:110 action:^{
            Features::featureB = !Features::featureB;
        }];

        [self addSwitch:@"Feature C" y:162 action:^{
            Features::featureC = !Features::featureC;
        }];
    }
    return self;
}

- (void)addSwitch:(NSString *)name y:(CGFloat)y action:(void (^)(void))action {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(
        Theme.padding, y, 170, 40
    )];
    label.text = name;
    label.textColor = UIColor.whiteColor;
    [self addSubview:label];

    UISwitch *toggle = [[UISwitch alloc] initWithFrame:CGRectMake(
        self.bounds.size.width - 70, y, 50, 40
    )];
    toggle.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;

    [toggle addAction:[UIAction actionWithHandler:^(__kindof UIAction * _Nonnull act) {
        action();
    }] forControlEvents:UIControlEventValueChanged];

    [self addSubview:toggle];
}

@end

@implementation HUDManager {
    HUDMenuView *_menu;
}

+ (instancetype)sharedManager {
    static HUDManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [HUDManager new];
    });
    return manager;
}

- (void)start {
    UIWindow *window = UIApplication.sharedApplication.keyWindow;
    if (!window) {
        for (UIWindow *candidate in UIApplication.sharedApplication.windows) {
            if (candidate.isKeyWindow) {
                window = candidate;
                break;
            }
        }
    }

    if (!window || _menu.superview) return;

    CGFloat width = 300;
    CGFloat height = 235;

    _menu = [[HUDMenuView alloc] initWithFrame:CGRectMake(
        20, 80, width, height
    )];

    _menu.autoresizingMask = UIViewAutoresizingFlexibleRightMargin |
                             UIViewAutoresizingFlexibleBottomMargin;

    [window addSubview:_menu];
}

- (void)toggle {
    _menu.hidden = !_menu.hidden;
}

@end
