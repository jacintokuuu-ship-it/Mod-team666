#pragma once

struct HUDTheme {
    float cornerRadius = 12.0f;
    float padding = 12.0f;
    float rowHeight = 42.0f;
};

inline HUDTheme Theme{};
