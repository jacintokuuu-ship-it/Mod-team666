#import "FeatureManager.h"

@implementation FeatureManager

+ (instancetype)sharedManager {
    static FeatureManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [FeatureManager new];
    });
    return manager;
}

- (void)update {
    // Coloque aqui somente lógica de features do seu próprio app/HUD.
}

@end
