#import "Overlay.h"

@implementation HUDOverlay

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColor.clearColor;
        self.userInteractionEnabled = NO;
    }
    return self;
}

- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];

    // Área reservada para elementos visuais legítimos do seu próprio app.
    // Exemplo: indicadores, debug, FPS, coordenadas da interface etc.
}

@end
