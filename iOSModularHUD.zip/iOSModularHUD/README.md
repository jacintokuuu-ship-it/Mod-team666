# iOS Modular HUD

Base modular para desenvolver uma interface/HUD em iOS usando Theos.

## Estrutura

- `Config/` — configurações, opções e tema.
- `Menu/` — desenho e navegação do menu.
- `Overlay/` — camada visual independente.
- `Core/` — gerenciamento das features.
- `UI/ImGui/` — reservado para a biblioteca de UI, se você optar por adicioná-la.

## Build

No ambiente Theos:

```sh
make package
```

Para instalar:

```sh
make package install
```

O projeto usa rootless e arm64, com deployment target iOS 15.

## Onde editar

Comece por:

- `Config/Settings.h`
- `Config/Features.h`
- `Config/Theme.h`
- `Menu/Menu.mm`

Este template não contém leitura/escrita de memória de outros processos, bypass de anti-cheat ou mecanismos de cheat.
