# GitHub Actions build

1. Upload the **contents** of this project folder to the repository root (so `Makefile`, `Tweak.x`, `control`, and `.github/` are at the repository root).
2. Push to `main`/`master`, open a pull request to either branch, or run **Actions → Build OverlayIOSTOOL (Theos) → Run workflow**.
3. Open the successful run and download the `OverlayIOSTOOL-rootless-deb` artifact.

The Makefile builds the Theos tweak (`OverlayIOSTOOL`) as a dynamic library and the companion UIKit app (`OverlayIOSTOOLApp`), then packages them into a rootless `.deb`. It does not rename a Debian package to an IPA.

The workflow validates the required inputs and property lists before building. The actual iOS compilation must run on GitHub's macOS runner with Apple's SDK; a Linux-only local check cannot prove that the Objective-C/Logos build compiles.
