# iOSModularHUD

Projeto modular para iOS com duas variantes independentes:

- `Tweak/` — tweak Theos para jailbreak rootless, empacotado como `.deb`.
- `App/` — aplicativo iOS standalone, compilado como `.ipa` e disponibilizado também com extensão `.tipa` para uso com TrollStore.
- `Shared/` — pequenos componentes reutilizáveis entre variantes.

## Importante sobre TrollStore

TrollStore instala aplicativos iOS reais. Ele não transforma um tweak `.deb` em aplicativo. Por isso esta árvore mantém uma variante `App/` separada.

O aplicativo TrollStore não é um substituto para a injeção de tweak em outros processos. Ele é um aplicativo normal com seu próprio bundle e interface. A versão `App/` não implementa injeção, bypass de anti-cheat, evasão de detecção, manipulação de memória ou mecanismos de ocultação.

A extensão `.tipa` neste projeto é uma cópia do pacote IPA produzido pelo build. Ela não é uma conversão de `.deb` e não cria uma assinatura Apple inexistente. O TrollStore faz a instalação/permasigning conforme o suporte do dispositivo e da versão do iOS.

## Build pelo GitHub

1. Abra **Actions**.
2. Selecione **Build iOSModularHUD**.
3. Clique em **Run workflow**.
4. Aguarde a execução.
5. Abra o artifact **iOSModularHUD-builds**.
6. Baixe `iOSModularHUD-rootless.deb`, `iOSModularHUD.ipa` ou `iOSModularHUD.tipa`.

O workflow usa macOS porque a compilação para iOS depende do SDK/toolchain da Apple. O workflow não procura um `.app` dentro do ZIP original: ele compila as duas variantes diretamente do código-fonte.

## Theos rootless

O Makefile do tweak usa `THEOS_PACKAGE_SCHEME=rootless` e `PACKAGE_FORMAT=deb`. O pacote rootless usa arquitetura `iphoneos-arm64`.

## Limites intencionais

Este projeto é apenas uma base legítima de HUD/UI. Não há leitura/escrita de memória de outros processos, bypass de anti-cheat, anti-ban, evasão de detecção, spoofing de integridade ou mecanismos para impedir detecção.
