#import "Menu.h"
#import "../Config/Settings.h"
#import "../Config/Features.h"
#import "../Config/Theme.h"
#import "../Core/FeatureManager.h"
@interface HUDMenuView ()
@property(nonatomic, strong) UILabel *statusLabel;
@property(nonatomic, strong) UIView *card;
@end
@implementation HUDMenuView
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame]; if (!self) return nil;
    self.backgroundColor = UIColor.clearColor;
    _card = [[UIView alloc] initWithFrame:self.bounds];
    _card.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    _card.backgroundColor = [UIColor colorWithWhite:.055 alpha:.97];
    _card.layer.cornerRadius = Theme.cornerRadius;
    _card.layer.borderWidth = 1; _card.layer.borderColor = [UIColor colorWithWhite:1 alpha:.10].CGColor;
    _card.layer.shadowColor = UIColor.blackColor.CGColor; _card.layer.shadowOpacity = .25; _card.layer.shadowRadius = 18; _card.layer.shadowOffset = CGSizeMake(0,8);
    [self addSubview:_card];
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(Theme.padding, Theme.padding, frame.size.width-2*Theme.padding, 28)];
    title.text = @"iOS Modular HUD"; title.textColor = UIColor.whiteColor; title.font = [UIFont systemFontOfSize:20 weight:UIFontWeightSemibold]; [_card addSubview:title];
    UILabel *subtitle = [[UILabel alloc] initWithFrame:CGRectMake(Theme.padding, 42, frame.size.width-2*Theme.padding, 20)];
    subtitle.text = @"Modular UI • local features"; subtitle.textColor = [UIColor colorWithWhite:1 alpha:.55]; subtitle.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium]; [_card addSubview:subtitle];
    [self addSwitch:@"Feature A" y:72 key:0]; [self addSwitch:@"Feature B" y:118 key:1]; [self addSwitch:@"Feature C" y:164 key:2];
    _statusLabel = [[UILabel alloc] initWithFrame:CGRectMake(Theme.padding, 214, frame.size.width-2*Theme.padding, 20)];
    _statusLabel.textColor = [UIColor colorWithWhite:1 alpha:.45]; _statusLabel.font = [UIFont systemFontOfSize:11]; _statusLabel.text = @"Ready"; [_card addSubview:_statusLabel];
    return self;
}
- (void)addSwitch:(NSString *)name y:(CGFloat)y key:(NSInteger)key {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(Theme.padding,y,170,Theme.rowHeight)]; label.text=name; label.textColor=UIColor.whiteColor; label.font=[UIFont systemFontOfSize:15 weight:UIFontWeightMedium]; [_card addSubview:label];
    UISwitch *toggle=[[UISwitch alloc] initWithFrame:CGRectMake(_card.bounds.size.width-Theme.padding-51,y+6,51,31)]; toggle.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin; toggle.tag=key; toggle.onTintColor=[UIColor colorWithRed:.18 green:.55 blue:1 alpha:1]; [toggle addTarget:self action:@selector(switchChanged:) forControlEvents:UIControlEventValueChanged]; [_card addSubview:toggle];
}
- (void)switchChanged:(UISwitch *)sender {
    switch(sender.tag){case 0:Features::featureA=sender.isOn;break;case 1:Features::featureB=sender.isOn;break;case 2:Features::featureC=sender.isOn;break;}
    [[FeatureManager sharedManager] update]; _statusLabel.text=sender.isOn?@"Feature enabled":@"Feature disabled";
}
@end
@implementation HUDManager { HUDMenuView *_menu; UIButton *_handle; }
+ (instancetype)sharedManager { static HUDManager *m; static dispatch_once_t once; dispatch_once(&once,^{m=[HUDManager new];}); return m; }
- (UIWindow *)activeWindow { UIWindow *best=nil; for(UIWindow *w in UIApplication.sharedApplication.windows){ if(w.hidden||w.alpha<=.01||w.windowLevel!=UIWindowLevelNormal) continue; if(w.isKeyWindow)return w; if(!best)best=w;} return best; }
- (void)start { if(_menu.superview||_handle.superview)return; UIWindow *window=[self activeWindow]; if(!window)return; CGFloat width=Theme.width; _menu=[[HUDMenuView alloc] initWithFrame:CGRectMake(16,72,width,242)]; _menu.hidden=!Settings::menuVisible; [window addSubview:_menu]; _handle=[UIButton buttonWithType:UIButtonTypeSystem]; _handle.frame=CGRectMake(16,322,44,44); _handle.backgroundColor=[UIColor colorWithWhite:.05 alpha:.92]; _handle.layer.cornerRadius=22; _handle.layer.borderWidth=1; _handle.layer.borderColor=[UIColor colorWithWhite:1 alpha:.12].CGColor; [_handle setTitle:@"≡" forState:UIControlStateNormal]; _handle.titleLabel.font=[UIFont systemFontOfSize:22 weight:UIFontWeightBold]; [_handle setTitleColor:UIColor.whiteColor forState:UIControlStateNormal]; [_handle addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside]; [window addSubview:_handle]; }
- (void)toggle { if(!_menu){[self start];return;} _menu.hidden=!_menu.hidden; Settings::menuVisible=!_menu.hidden; }
@end
