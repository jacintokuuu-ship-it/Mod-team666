#import <UIKit/UIKit.h>
@interface HUDMenuView : UIView
@end
@interface HUDManager : NSObject
+ (instancetype)sharedManager;
- (void)startInView:(UIView *)view;
- (void)toggle;
@end
