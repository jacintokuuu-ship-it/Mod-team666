#import "Menu.h"
#import "../../Shared/HUDStyle.h"
#import "../Core/FeatureManager.h"
namespace { bool featureA=false, featureB=false, featureC=false; }
@interface HUDMenuView ()
@property(nonatomic,strong)UILabel *statusLabel;
@end
@implementation HUDMenuView
- (instancetype)initWithFrame:(CGRect)frame { self=[super initWithFrame:frame]; if(!self)return nil; self.backgroundColor=HUDBackgroundColor(); self.layer.cornerRadius=16; self.layer.borderWidth=1; self.layer.borderColor=HUDBorderColor().CGColor;
UILabel *title=[[UILabel alloc]initWithFrame:CGRectMake(16,14,frame.size.width-32,28)]; title.text=@"iOS Modular HUD"; title.textColor=UIColor.labelColor; title.font=[UIFont systemFontOfSize:20 weight:UIFontWeightSemibold]; [self addSubview:title];
UILabel *subtitle=[[UILabel alloc]initWithFrame:CGRectMake(16,42,frame.size.width-32,20)]; subtitle.text=@"TrollStore / standalone mode"; subtitle.textColor=UIColor.secondaryLabelColor; subtitle.font=[UIFont systemFontOfSize:12]; [self addSubview:subtitle];
[self addSwitch:@"Feature A" y:76 tag:0]; [self addSwitch:@"Feature B" y:122 tag:1]; [self addSwitch:@"Feature C" y:168 tag:2];
_statusLabel=[[UILabel alloc]initWithFrame:CGRectMake(16,214,frame.size.width-32,20)]; _statusLabel.text=@"Ready"; _statusLabel.font=[UIFont systemFontOfSize:11]; _statusLabel.textColor=UIColor.secondaryLabelColor; [self addSubview:_statusLabel]; return self; }
- (void)addSwitch:(NSString*)name y:(CGFloat)y tag:(NSInteger)tag { UILabel*l=[[UILabel alloc]initWithFrame:CGRectMake(16,y,170,36)]; l.text=name; l.font=[UIFont systemFontOfSize:15 weight:UIFontWeightMedium]; [self addSubview:l]; UISwitch*s=[[UISwitch alloc]initWithFrame:CGRectMake(self.bounds.size.width-67,y,51,31)]; s.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin; s.tag=tag; s.onTintColor=HUDAccentColor(); [s addTarget:self action:@selector(changed:) forControlEvents:UIControlEventValueChanged]; [self addSubview:s]; }
- (void)changed:(UISwitch*)s { if(s.tag==0)featureA=s.isOn; if(s.tag==1)featureB=s.isOn; if(s.tag==2)featureC=s.isOn; [[FeatureManager sharedManager] update]; _statusLabel.text=s.isOn?@"Feature enabled":@"Feature disabled"; }
@end
@implementation HUDManager { HUDMenuView *_menu; UIButton *_button; UIView *_host; }
+ (instancetype)sharedManager { static HUDManager*m; static dispatch_once_t once; dispatch_once(&once,^{m=[HUDManager new];}); return m; }
- (void)startInView:(UIView*)view { if(_menu.superview)return; _host=view; _menu=[[HUDMenuView alloc]initWithFrame:CGRectMake(16,72,320,242)]; _menu.autoresizingMask=UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin; [view addSubview:_menu]; _button=[UIButton buttonWithType:UIButtonTypeSystem]; _button.frame=CGRectMake(16,322,44,44); _button.backgroundColor=HUDBackgroundColor(); _button.layer.cornerRadius=22; [_button setTitle:@"≡" forState:UIControlStateNormal]; _button.titleLabel.font=[UIFont systemFontOfSize:22 weight:UIFontWeightBold]; [_button addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside]; [view addSubview:_button]; }
- (void)toggle { _menu.hidden=!_menu.hidden; }
@end
