#import <Foundation/Foundation.h>
@interface FeatureManager : NSObject
+ (instancetype)sharedManager;
- (void)update;
@end
