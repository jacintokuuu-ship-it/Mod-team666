#import "FeatureManager.h"

static NSString * const kHUDConfigKey = @"iOSModularHUD.configuration";

@implementation HUDFeatureState
@end

@implementation FeatureManager {
    HUDFeatureState *_state;
}
+ (instancetype)sharedManager {
    static FeatureManager *m;
    static dispatch_once_t once;
    dispatch_once(&once, ^{ m = [FeatureManager new]; });
    return m;
}
- (instancetype)init {
    self = [super init];
    if (!self) return nil;
    _state = [HUDFeatureState new];
    _state.profileName = @"Default";
    _state.intensity = .75f;
    _state.haptics = YES;
    _state.compactMode = NO;

    NSDictionary *saved = [[NSUserDefaults standardUserDefaults] objectForKey:kHUDConfigKey];
    if ([saved isKindOfClass:NSDictionary.class]) [self importConfiguration:saved];
    return self;
}
- (HUDFeatureState *)state { return _state; }
- (void)update {
    NSDictionary *config = [self exportConfiguration];
    [[NSUserDefaults standardUserDefaults] setObject:config forKey:kHUDConfigKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
}
- (void)reset {
    _state.enabled = NO;
    _state.intensity = .75f;
    _state.profileName = @"Default";
    _state.haptics = YES;
    _state.compactMode = NO;
    [self update];
}
- (NSDictionary *)exportConfiguration {
    return @{
        @"enabled": @(_state.enabled),
        @"intensity": @(_state.intensity),
        @"profileName": _state.profileName ?: @"Default",
        @"haptics": @(_state.haptics),
        @"compactMode": @(_state.compactMode)
    };
}
- (void)importConfiguration:(NSDictionary *)configuration {
    if (![configuration isKindOfClass:NSDictionary.class]) return;
    _state.enabled = [configuration[@"enabled"] boolValue];
    if (configuration[@"intensity"]) _state.intensity = [configuration[@"intensity"] floatValue];
    if ([configuration[@"profileName"] isKindOfClass:NSString.class]) _state.profileName = configuration[@"profileName"];
    _state.haptics = configuration[@"haptics"] ? [configuration[@"haptics"] boolValue] : YES;
    _state.compactMode = [configuration[@"compactMode"] boolValue];
}
- (HUDCapabilitySnapshot *)capabilities { return [HUDCapabilitySnapshot currentSnapshot]; }
@end
