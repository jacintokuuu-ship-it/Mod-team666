#import <Foundation/Foundation.h>
#import "../../Shared/HUDCapabilities.h"

NS_ASSUME_NONNULL_BEGIN

@interface HUDFeatureState : NSObject
@property(nonatomic, assign) BOOL enabled;
@property(nonatomic, assign) float intensity;
@property(nonatomic, copy) NSString *profileName;
@property(nonatomic, assign) BOOL haptics;
@property(nonatomic, assign) BOOL compactMode;
@end

@interface FeatureManager : NSObject
@property(nonatomic, strong, readonly) HUDFeatureState *state;
+ (instancetype)sharedManager;
- (void)update;
- (void)reset;
- (NSDictionary *)exportConfiguration;
- (void)importConfiguration:(NSDictionary *)configuration;
- (HUDCapabilitySnapshot *)capabilities;
@end

NS_ASSUME_NONNULL_END
