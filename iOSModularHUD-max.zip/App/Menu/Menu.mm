#import "Menu.h"
#import "../Core/FeatureManager.h"
#import "../../Shared/HUDStyle.h"

@interface HUDMenuView ()
@property(nonatomic,strong) UISegmentedControl *segments;
@property(nonatomic,strong) UIView *content;
@property(nonatomic,strong) UILabel *status;
@property(nonatomic,strong) UILabel *capability;
@property(nonatomic,strong) UISwitch *masterSwitch;
@property(nonatomic,strong) UISlider *intensity;
@property(nonatomic,strong) UITextField *profile;
@property(nonatomic,strong) UISwitch *haptics;
@property(nonatomic,strong) UISwitch *compact;
@end

@implementation HUDMenuView

- (instancetype)initWithFrame:(CGRect)frame {
    self=[super initWithFrame:frame];
    if(!self) return nil;

    self.backgroundColor=HUDBackgroundColor();
    self.layer.cornerRadius=20;
    self.layer.borderWidth=1;
    self.layer.borderColor=HUDBorderColor().CGColor;
    self.layer.shadowColor=UIColor.blackColor.CGColor;
    self.layer.shadowOpacity=.28;
    self.layer.shadowRadius=20;
    self.layer.shadowOffset=CGSizeMake(0,10);

    UILabel *title=[[UILabel alloc] initWithFrame:CGRectMake(18,14,frame.size.width-36,28)];
    title.text=@"iOS Modular HUD";
    title.textColor=UIColor.labelColor;
    title.font=[UIFont systemFontOfSize:20 weight:UIFontWeightBold];
    [self addSubview:title];

    UILabel *sub=[[UILabel alloc] initWithFrame:CGRectMake(18,42,frame.size.width-36,18)];
    sub.text=@"Standalone • modular • local state";
    sub.textColor=UIColor.secondaryLabelColor;
    sub.font=[UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    [self addSubview:sub];

    _status=[[UILabel alloc] initWithFrame:CGRectMake(frame.size.width-118,17,100,24)];
    _status.textAlignment=NSTextAlignmentRight;
    _status.font=[UIFont systemFontOfSize:11 weight:UIFontWeightSemibold];
    _status.textColor=HUDAccentColor();
    _status.text=@"READY";
    _status.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin;
    [self addSubview:_status];

    _segments=[[UISegmentedControl alloc] initWithItems:@[@"Features",@"Tools",@"Settings"]];
    _segments.frame=CGRectMake(16,70,frame.size.width-32,32);
    _segments.selectedSegmentIndex=0;
    [_segments addTarget:self action:@selector(segmentChanged:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_segments];

    _content=[[UIView alloc] initWithFrame:CGRectMake(16,112,frame.size.width-32,frame.size.height-126)];
    _content.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_content];

    [self showFeatures];
    return self;
}

- (void)clearContent {
    for (UIView *v in _content.subviews) [v removeFromSuperview];
}

- (UILabel *)label:(NSString *)text frame:(CGRect)frame {
    UILabel *l=[[UILabel alloc] initWithFrame:frame];
    l.text=text;
    l.textColor=UIColor.labelColor;
    l.font=[UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    [_content addSubview:l];
    return l;
}

- (UISwitch *)toggle:(NSString *)name y:(CGFloat)y on:(BOOL)value action:(SEL)selector {
    [self label:name frame:CGRectMake(4,y,170,34)];
    UISwitch *s=[[UISwitch alloc] initWithFrame:CGRectMake(_content.bounds.size.width-58,y,51,31)];
    s.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin;
    s.onTintColor=HUDAccentColor();
    s.on=value;
    [s addTarget:self action:selector forControlEvents:UIControlEventValueChanged];
    [_content addSubview:s];
    return s;
}

- (void)showFeatures {
    [self clearContent];
    FeatureManager *fm=FeatureManager.sharedManager;

    _masterSwitch=[self toggle:@"HUD enabled" y:4 on:fm.state.enabled action:@selector(masterChanged:)];
    [self label:@"Intensity" frame:CGRectMake(4,48,100,28)];

    _intensity=[[UISlider alloc] initWithFrame:CGRectMake(102,48,_content.bounds.size.width-106,28)];
    _intensity.autoresizingMask=UIViewAutoresizingFlexibleWidth;
    _intensity.minimumValue=0; _intensity.maximumValue=1; _intensity.value=fm.state.intensity;
    [_intensity addTarget:self action:@selector(intensityChanged:) forControlEvents:UIControlEventValueChanged];
    [_content addSubview:_intensity];

    [self label:@"Profile" frame:CGRectMake(4,88,100,34)];
    _profile=[[UITextField alloc] initWithFrame:CGRectMake(100,88,_content.bounds.size.width-104,34)];
    _profile.autoresizingMask=UIViewAutoresizingFlexibleWidth;
    _profile.borderStyle=UITextBorderStyleRoundedRect;
    _profile.text=fm.state.profileName;
    _profile.placeholder=@"Profile name";
    _profile.returnKeyType=UIReturnKeyDone;
    [_profile addTarget:self action:@selector(profileChanged:) forControlEvents:UIControlEventEditingDidEndOnExit|UIControlEventEditingDidEnd];
    [_content addSubview:_profile];

    _capability=[self label:@"" frame:CGRectMake(4,136,_content.bounds.size.width-8,52)];
    _capability.numberOfLines=2;
    [self refreshCapability];
}

- (void)showTools {
    [self clearContent];
    [self label:@"Diagnostics" frame:CGRectMake(4,4,200,28)];

    UIButton *scan=[self button:@"Refresh environment" frame:CGRectMake(4,42,_content.bounds.size.width-8,40)];
    scan.tag=10;
    [scan addTarget:self action:@selector(toolPressed:) forControlEvents:UIControlEventTouchUpInside];

    UIButton *reset=[self button:@"Reset local configuration" frame:CGRectMake(4,90,_content.bounds.size.width-8,40)];
    reset.tag=11;
    [reset addTarget:self action:@selector(toolPressed:) forControlEvents:UIControlEventTouchUpInside];

    UILabel *note=[self label:@"This build exposes only safe userland diagnostics. No memory patching, injection, anti-cheat bypass, or kernel exploit is bundled." frame:CGRectMake(4,142,_content.bounds.size.width-8,76)];
    note.numberOfLines=0;
    note.textColor=UIColor.secondaryLabelColor;
    note.font=[UIFont systemFontOfSize:11];
}

- (UIButton *)button:(NSString *)title frame:(CGRect)frame {
    UIButton *b=[UIButton buttonWithType:UIButtonTypeSystem];
    b.frame=frame;
    b.autoresizingMask=UIViewAutoresizingFlexibleWidth;
    b.backgroundColor=[UIColor colorWithWhite:.5 alpha:.10];
    b.layer.cornerRadius=12;
    [b setTitle:title forState:UIControlStateNormal];
    [b setTitleColor:HUDAccentColor() forState:UIControlStateNormal];
    return b;
}

- (void)showSettings {
    [self clearContent];
    FeatureManager *fm=FeatureManager.sharedManager;
    _haptics=[self toggle:@"Haptic feedback" y:4 on:fm.state.haptics action:@selector(hapticsChanged:)];
    _compact=[self toggle:@"Compact layout" y:48 on:fm.state.compactMode action:@selector(compactChanged:)];

    UILabel *about=[self label:@"Build" frame:CGRectMake(4,96,80,28)];
    about.font=[UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];

    UILabel *info=[self label:@"iOSModularHUD • standalone TrollStore target\nSettings are stored locally with NSUserDefaults." frame:CGRectMake(4,122,_content.bounds.size.width-8,55)];
    info.numberOfLines=0;
    info.textColor=UIColor.secondaryLabelColor;
    info.font=[UIFont systemFontOfSize:11];
}

- (void)refreshCapability {
    HUDCapabilitySnapshot *c=FeatureManager.sharedManager.capabilities;
    _capability.text=[NSString stringWithFormat:@"OS %@ • %@\n%@ • rootless path: %@",
                      c.osVersion,c.deviceModel,c.executionMode,c.rootlessPathPresent?@"present":@"not detected"];
}

- (void)segmentChanged:(UISegmentedControl *)sender {
    if(sender.selectedSegmentIndex==0) [self showFeatures];
    else if(sender.selectedSegmentIndex==1) [self showTools];
    else [self showSettings];
}
- (void)masterChanged:(UISwitch *)s { FeatureManager.sharedManager.state.enabled=s.isOn; [FeatureManager.sharedManager update]; _status.text=s.isOn?@"ACTIVE":@"READY"; }
- (void)intensityChanged:(UISlider *)s { FeatureManager.sharedManager.state.intensity=s.value; [FeatureManager.sharedManager update]; }
- (void)profileChanged:(UITextField *)t { if(t.text.length) FeatureManager.sharedManager.state.profileName=t.text; [FeatureManager.sharedManager update]; }
- (void)hapticsChanged:(UISwitch *)s { FeatureManager.sharedManager.state.haptics=s.isOn; [FeatureManager.sharedManager update]; }
- (void)compactChanged:(UISwitch *)s { FeatureManager.sharedManager.state.compactMode=s.isOn; [FeatureManager.sharedManager update]; }
- (void)toolPressed:(UIButton *)b {
    if(b.tag==10) { [self refreshCapability]; _status.text=@"SCANNED"; }
    if(b.tag==11) { [FeatureManager.sharedManager reset]; [self showFeatures]; _status.text=@"RESET"; }
}
@end

@implementation HUDManager {
    HUDMenuView *_menu;
    UIButton *_handle;
    UIView *_host;
}
+ (instancetype)sharedManager {
    static HUDManager *m; static dispatch_once_t once;
    dispatch_once(&once,^{m=[HUDManager new];});
    return m;
}
- (void)startInView:(UIView *)view {
    if(_menu.superview) return;
    _host=view;
    CGFloat width=MIN(350.0, MAX(290.0, view.bounds.size.width-24));
    CGFloat height=340;
    _menu=[[HUDMenuView alloc] initWithFrame:CGRectMake(12,70,width,height)];
    _menu.autoresizingMask=UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin;
    [view addSubview:_menu];

    _handle=[UIButton buttonWithType:UIButtonTypeSystem];
    _handle.frame=CGRectMake(14,418,48,48);
    _handle.autoresizingMask=UIViewAutoresizingFlexibleTopMargin|UIViewAutoresizingFlexibleRightMargin;
    _handle.backgroundColor=HUDBackgroundColor();
    _handle.layer.cornerRadius=24;
    _handle.layer.borderWidth=1;
    _handle.layer.borderColor=HUDBorderColor().CGColor;
    [_handle setTitle:@"≡" forState:UIControlStateNormal];
    _handle.titleLabel.font=[UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    [_handle addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:_handle];
}
- (void)toggle { _menu.hidden=!_menu.hidden; }
@end
