#import "AppDelegate.h"
#import "Menu/Menu.h"
@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    UIViewController *root = [UIViewController new];
    root.view.backgroundColor = [UIColor systemBackgroundColor];
    self.window.rootViewController = root;
    [self.window makeKeyAndVisible];
    [[HUDManager sharedManager] startInView:root.view];
    return YES;
}
@end
