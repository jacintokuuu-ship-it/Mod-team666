#pragma once
#import <UIKit/UIKit.h>

static inline UIColor *HUDBackgroundColor(void) { return [UIColor colorWithWhite:0.055 alpha:0.97]; }
static inline UIColor *HUDBorderColor(void) { return [UIColor colorWithWhite:1 alpha:0.10]; }
static inline UIColor *HUDAccentColor(void) { return [UIColor colorWithRed:.18 green:.55 blue:1 alpha:1]; }
