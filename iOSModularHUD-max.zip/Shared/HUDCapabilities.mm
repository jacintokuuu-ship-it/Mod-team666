#import "HUDCapabilities.h"
#include <sys/utsname.h>

@implementation HUDCapabilitySnapshot
+ (instancetype)currentSnapshot {
    HUDCapabilitySnapshot *s = [HUDCapabilitySnapshot new];
    s.osVersion = UIDevice.currentDevice.systemVersion;
    s.deviceModel = UIDevice.currentDevice.model;

    struct utsname u;
    if (uname(&u) == 0) {
        s.architecture = [NSString stringWithUTF8String:u.machine] ?: @"unknown";
    } else {
        s.architecture = @"unknown";
    }

    s.rootlessPathPresent = [[NSFileManager defaultManager] fileExistsAtPath:@"/var/jb"];
    s.likelyJailbroken = s.rootlessPathPresent ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Sileo.app"] ||
        [[NSFileManager defaultManager] fileExistsAtPath:@"/Applications/Zebra.app"];

    s.executionMode = s.likelyJailbroken ? @"Jailbreak / rootless hints" : @"Standalone / sandboxed";
    return s;
}
@end
