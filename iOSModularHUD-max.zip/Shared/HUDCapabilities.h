#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface HUDCapabilitySnapshot : NSObject
@property(nonatomic, copy) NSString *osVersion;
@property(nonatomic, copy) NSString *deviceModel;
@property(nonatomic, copy) NSString *architecture;
@property(nonatomic, assign) BOOL rootlessPathPresent;
@property(nonatomic, assign) BOOL likelyJailbroken;
@property(nonatomic, copy) NSString *executionMode;
+ (instancetype)currentSnapshot;
@end

NS_ASSUME_NONNULL_END
