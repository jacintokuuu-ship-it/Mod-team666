Reserved for optional Dear ImGui integration. Current HUD uses UIKit only.
