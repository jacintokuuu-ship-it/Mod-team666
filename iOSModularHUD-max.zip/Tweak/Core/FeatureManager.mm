#import "FeatureManager.h"
@implementation FeatureManager
+ (instancetype)sharedManager {
    static FeatureManager *m; static dispatch_once_t once;
    dispatch_once(&once,^{m=[FeatureManager new];});
    return m;
}
- (void)update { /* UI-only feature state hook point. */ }
- (HUDCapabilitySnapshot *)capabilities { return [HUDCapabilitySnapshot currentSnapshot]; }
@end
