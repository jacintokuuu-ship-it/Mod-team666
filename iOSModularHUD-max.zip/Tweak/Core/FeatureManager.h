#import <Foundation/Foundation.h>
#import "../../../Shared/HUDCapabilities.h"
@interface FeatureManager : NSObject
+ (instancetype)sharedManager;
- (void)update;
- (HUDCapabilitySnapshot *)capabilities;
@end
