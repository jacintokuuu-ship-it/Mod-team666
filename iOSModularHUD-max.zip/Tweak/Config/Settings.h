#pragma once
namespace Settings {
    inline bool menuVisible = true;
    inline float uiScale = 1.0f;
    inline int selectedTab = 0;
}
