#pragma once
namespace Features {
    inline bool featureA = false;
    inline bool featureB = false;
    inline bool featureC = false;
}
