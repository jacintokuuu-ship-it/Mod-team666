#pragma once
#import <UIKit/UIKit.h>
struct HUDTheme {
    CGFloat cornerRadius = 16.0;
    CGFloat padding = 14.0;
    CGFloat rowHeight = 46.0;
    CGFloat width = 320.0;
};
inline HUDTheme Theme{};
