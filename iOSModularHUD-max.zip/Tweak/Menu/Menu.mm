#import "Menu.h"
#import "../Config/Settings.h"
#import "../Config/Features.h"
#import "../Config/Theme.h"
#import "../Core/FeatureManager.h"

@interface HUDMenuView ()
@property(nonatomic,strong) UISegmentedControl *segments;
@property(nonatomic,strong) UIView *content;
@property(nonatomic,strong) UILabel *status;
@end

@implementation HUDMenuView
- (instancetype)initWithFrame:(CGRect)frame {
    self=[super initWithFrame:frame]; if(!self)return nil;
    self.backgroundColor=[UIColor colorWithWhite:.055 alpha:.98];
    self.layer.cornerRadius=20;
    self.layer.borderWidth=1;
    self.layer.borderColor=[UIColor colorWithWhite:1 alpha:.10].CGColor;
    self.layer.shadowColor=UIColor.blackColor.CGColor;
    self.layer.shadowOpacity=.28; self.layer.shadowRadius=20; self.layer.shadowOffset=CGSizeMake(0,10);

    UILabel *title=[[UILabel alloc]initWithFrame:CGRectMake(18,14,220,28)];
    title.text=@"iOS Modular HUD"; title.textColor=UIColor.whiteColor;
    title.font=[UIFont systemFontOfSize:20 weight:UIFontWeightBold]; [self addSubview:title];

    _status=[[UILabel alloc]initWithFrame:CGRectMake(frame.size.width-100,17,82,24)];
    _status.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin;
    _status.text=@"READY"; _status.textAlignment=NSTextAlignmentRight;
    _status.textColor=[UIColor colorWithRed:.18 green:.55 blue:1 alpha:1];
    _status.font=[UIFont systemFontOfSize:10 weight:UIFontWeightBold]; [self addSubview:_status];

    _segments=[[UISegmentedControl alloc]initWithItems:@[@"Features",@"Tools",@"Info"]];
    _segments.frame=CGRectMake(16,52,frame.size.width-32,32);
    _segments.selectedSegmentIndex=0;
    [_segments addTarget:self action:@selector(segmentChanged:) forControlEvents:UIControlEventValueChanged];
    [self addSubview:_segments];

    _content=[[UIView alloc]initWithFrame:CGRectMake(16,96,frame.size.width-32,frame.size.height-108)];
    _content.autoresizingMask=UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    [self addSubview:_content];
    [self showFeatures];
    return self;
}
- (UILabel *)addLabel:(NSString *)text y:(CGFloat)y {
    UILabel*l=[[UILabel alloc]initWithFrame:CGRectMake(4,y,_content.bounds.size.width-8,28)];
    l.text=text; l.textColor=UIColor.whiteColor; l.font=[UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    [_content addSubview:l]; return l;
}
- (void)clear { for(UIView*v in _content.subviews)[v removeFromSuperview]; }
- (void)showFeatures {
    [self clear];
    UILabel *hint=[self addLabel:@"Local feature controls" y:0];
    hint.textColor=[UIColor colorWithWhite:1 alpha:.5]; hint.font=[UIFont systemFontOfSize:11];

    NSArray *names=@[@"Feature A",@"Feature B",@"Feature C"];
    for(NSInteger i=0;i<names.count;i++){
        UILabel*l=[self addLabel:names[i] y:36+i*44];
        l.frame=CGRectMake(4,36+i*44,160,34);
        UISwitch*s=[[UISwitch alloc]initWithFrame:CGRectMake(_content.bounds.size.width-58,36+i*44,51,31)];
        s.autoresizingMask=UIViewAutoresizingFlexibleLeftMargin;
        s.tag=i; s.onTintColor=[UIColor colorWithRed:.18 green:.55 blue:1 alpha:1];
        [s addTarget:self action:@selector(toggle:) forControlEvents:UIControlEventValueChanged];
        [_content addSubview:s];
    }
    UISlider*slider=[[UISlider alloc]initWithFrame:CGRectMake(4,174,_content.bounds.size.width-8,28)];
    slider.autoresizingMask=UIViewAutoresizingFlexibleWidth; slider.value=.75;
    [slider addTarget:self action:@selector(slider:) forControlEvents:UIControlEventValueChanged];
    [_content addSubview:slider];
    [self addLabel:@"Intensity" y:202];
}
- (void)showTools {
    [self clear];
    [self addLabel:@"Safe diagnostics" y:0];
    UILabel*l=[self addLabel:@"" y:38]; l.numberOfLines=0;
    HUDCapabilitySnapshot*c=FeatureManager.sharedManager.capabilities;
    l.text=[NSString stringWithFormat:@"OS: %@\nArch: %@\nMode: %@\n/var/jb: %@",
            c.osVersion,c.architecture,c.executionMode,c.rootlessPathPresent?@"present":@"not detected"];
    l.textColor=[UIColor colorWithWhite:1 alpha:.65];
    UIButton*b=[UIButton buttonWithType:UIButtonTypeSystem];
    b.frame=CGRectMake(4,142,_content.bounds.size.width-8,40);
    b.autoresizingMask=UIViewAutoresizingFlexibleWidth;
    [b setTitle:@"Refresh diagnostics" forState:UIControlStateNormal];
    [b addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventTouchUpInside];
    [_content addSubview:b];
    UILabel*note=[self addLabel:@"No memory patching, injection, anti-cheat bypass, or kernel exploit is bundled." y:194];
    note.numberOfLines=0; note.textColor=[UIColor colorWithWhite:1 alpha:.4]; note.font=[UIFont systemFontOfSize:10];
}
- (void)showInfo {
    [self clear];
    UILabel*l=[self addLabel:@"Environment" y:0]; l.font=[UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    UILabel*i=[self addLabel:@"Rootless jailbreak target • UIKit overlay\nUI state only; backend hooks can be added for legitimate integrations." y:38];
    i.numberOfLines=0; i.textColor=[UIColor colorWithWhite:1 alpha:.6];
}
- (void)segmentChanged:(UISegmentedControl*)s {
    if(s.selectedSegmentIndex==0)[self showFeatures];
    else if(s.selectedSegmentIndex==1)[self showTools];
    else [self showInfo];
}
- (void)toggle:(UISwitch*)s {
    if(s.tag==0)Features::featureA=s.isOn;
    if(s.tag==1)Features::featureB=s.isOn;
    if(s.tag==2)Features::featureC=s.isOn;
    [[FeatureManager sharedManager] update];
    _status.text=s.isOn?@"ACTIVE":@"READY";
}
- (void)slider:(UISlider*)s { _status.text=[NSString stringWithFormat:@"%d%%",(int)roundf(s.value*100)]; }
- (void)refresh:(UIButton*)b { [self showTools]; _status.text=@"SCANNED"; }
@end

@implementation HUDManager { HUDMenuView *_menu; UIButton *_handle; }
+ (instancetype)sharedManager { static HUDManager*m; static dispatch_once_t once; dispatch_once(&once,^{m=[HUDManager new];}); return m; }
- (UIWindow*)activeWindow {
    UIWindow*best=nil;
    for(UIWindow*w in UIApplication.sharedApplication.windows){
        if(w.hidden||w.alpha<.01||w.windowLevel!=UIWindowLevelNormal)continue;
        if(w.isKeyWindow)return w;
        if(!best)best=w;
    }
    return best;
}
- (void)start {
    if(_menu.superview)return;
    UIWindow*w=[self activeWindow]; if(!w)return;
    CGFloat width=MIN(340.0,MAX(285.0,w.bounds.size.width-24));
    _menu=[[HUDMenuView alloc]initWithFrame:CGRectMake(12,72,width,330)];
    _menu.autoresizingMask=UIViewAutoresizingFlexibleRightMargin|UIViewAutoresizingFlexibleBottomMargin;
    [w addSubview:_menu];

    _handle=[UIButton buttonWithType:UIButtonTypeSystem];
    _handle.frame=CGRectMake(14,412,48,48);
    _handle.backgroundColor=[UIColor colorWithWhite:.05 alpha:.94];
    _handle.layer.cornerRadius=24; _handle.layer.borderWidth=1;
    _handle.layer.borderColor=[UIColor colorWithWhite:1 alpha:.12].CGColor;
    [_handle setTitle:@"≡" forState:UIControlStateNormal];
    _handle.titleLabel.font=[UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    [_handle setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    [_handle addTarget:self action:@selector(toggle) forControlEvents:UIControlEventTouchUpInside];
    [w addSubview:_handle];
}
- (void)toggle { if(!_menu){[self start];return;} _menu.hidden=!_menu.hidden; }
@end
