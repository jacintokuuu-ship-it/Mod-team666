#import <UIKit/UIKit.h>
@interface HUDMenuView : UIView
@end
@interface HUDManager : NSObject
+ (instancetype)sharedManager;
- (void)start;
@end
