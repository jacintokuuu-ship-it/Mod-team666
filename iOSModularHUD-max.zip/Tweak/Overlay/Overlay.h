#pragma once
#import <UIKit/UIKit.h>
@interface HUDOverlay : UIView
@end
