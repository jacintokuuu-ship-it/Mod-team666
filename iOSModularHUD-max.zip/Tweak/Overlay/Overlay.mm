#import "Overlay.h"
@implementation HUDOverlay
- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColor.clearColor;
        self.userInteractionEnabled = NO;
        self.accessibilityIdentifier = @"iOSModularHUD.overlay";
    }
    return self;
}
- (void)drawRect:(CGRect)rect {
    [super drawRect:rect];
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectInset(self.bounds, 1, 1) cornerRadius:14];
    [[UIColor colorWithWhite:1 alpha:.10] setStroke]; path.lineWidth = 1; [path stroke];
}
@end
