#import <UIKit/UIKit.h>
#import "Menu/Menu.h"
__attribute__((constructor)) static void iOSModularHUDInit(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        [[HUDManager sharedManager] start];
    });
}
