#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow *window;
@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    self.window.backgroundColor = [UIColor colorWithWhite:0.1 alpha:1.0];
    
    UIViewController *rootVC = [[UIViewController alloc] init];
    
    UILabel *title = [[UILabel alloc] initWithFrame:CGRectMake(50, 100, 300, 50)];
    title.text = @"XternalZ Rootless Controller";
    title.textColor = [UIColor cyanColor];
    title.font = [UIFont boldSystemFontOfSize:22];
    [rootVC.view addSubview:title];
    
    UILabel *info = [[UILabel alloc] initWithFrame:CGRectMake(50, 160, 300, 100)];
    info.text = @"O tweak (XternalZCore.dylib) já está instalado no sistema Rootless via Dopamine.\nConfigure as opções aqui.";
    info.textColor = [UIColor whiteColor];
    info.numberOfLines = 0;
    [rootVC.view addSubview:info];
    
    self.window.rootViewController = rootVC;
    [self.window makeKeyAndVisible];
    return YES;
}

@end

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
