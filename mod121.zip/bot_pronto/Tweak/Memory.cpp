#include <mach/mach.h>
#include <stdio.h>
#include <stdint.h>

// Standard Mach VM read wrapper for external/internal memory manipulation
template <typename T>
T ReadMemory(vm_address_t address) {
    T value;
    vm_size_t size = 0;
    kern_return_t kr = vm_read_overwrite(mach_task_self(), address, sizeof(T), (vm_address_t)&value, &size);
    if (kr != KERN_SUCCESS) {
        // Handle error quietly
        return T();
    }
    return value;
}

// Write memory template
template <typename T>
bool WriteMemory(vm_address_t address, T value) {
    kern_return_t kr = vm_write(mach_task_self(), address, (vm_offset_t)&value, sizeof(T));
    return (kr == KERN_SUCCESS);
}
