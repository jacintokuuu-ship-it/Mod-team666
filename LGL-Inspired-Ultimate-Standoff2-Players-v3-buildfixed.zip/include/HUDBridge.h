#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif

NS_ASSUME_NONNULL_BEGIN

void HUDSetESPEnabled(BOOL enabled);
void HUDSetTracersEnabled(BOOL enabled);
void HUDSetStealthEnabled(BOOL enabled);
void HUDSetOverlayEnabled(BOOL enabled);
void HUDHideMenu(void);

NS_ASSUME_NONNULL_END

#ifdef __cplusplus
}
#endif
