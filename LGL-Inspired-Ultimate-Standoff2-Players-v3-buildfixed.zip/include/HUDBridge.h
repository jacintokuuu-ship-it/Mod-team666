#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif

NS_ASSUME_NONNULL_BEGIN

void HUDSetESPEnabled(BOOL enabled);
void HUDSetTracersEnabled(BOOL enabled);
void HUDSetStealthEnabled(BOOL enabled);
void HUDSetOverlayEnabled(BOOL enabled);
BOOL HUDRouteTouch(CGPoint point, UITouchPhase phase, NSInteger pointerId);
void HUDHideMenu(void);
void HUDSetESPTestMode(NSInteger mode);
const char *HUDESPTestStatus(void);

NS_ASSUME_NONNULL_END

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
extern "C" {
#endif
void HUDVerifyExternal(void);
void HUDShowToast(const char *message);
#ifdef __cplusplus
}
#endif
