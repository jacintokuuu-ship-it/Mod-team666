# XternalZ — Touch/Input Fix Report

## Symptom
The HUD rendered correctly, but buttons, switches, taps and menu dragging did not respond.

## Root causes found

### 1. Hosted window was created with `attached:NO`
The HUD window used the private `UIWindow` constructor with `attached:NO`. That is different from the accessibility/global HUD model used by UIDaemon-style windows. A window can therefore have a visible CoreAnimation context while not participating correctly in the global WindowServer input route.

**Fix:** `HUDMainWindow` now uses `_initWithFrame:attached:YES` and keeps the global-window flags enabled.

### 2. The window was made the normal application key window
The previous code used `makeKeyAndVisible`. The reference global-HUD architecture orders the hosted window to the front instead of relying on ordinary application-key-window focus.

**Fix:** use `setHidden:NO` + `orderFront:nil`, then register the context with `SBSAccessibilityWindowHostingController`.

### 3. Synthetic event delivery bypassed the UIKit run-loop event path
The previous `TSEventFetcher` directly created `_touchesEvent`, populated it and called `sendEvent:` immediately. Modern UIKit has an internal event/run-loop pipeline, and mutating a `UITouch` and immediately sending a `UIEvent` from the HID callback is fragile.

**Fix:** synthetic touches are now snapshotted and delivered through a `CFRunLoopSource` on the main run loop. This follows the architecture used by TrollSpeed's `TSEventFetcher`.

### 4. The HID representation of each touch became stale
The original KIF touch helper created the HID event only once. Later move/phase updates changed the `UITouch` but did not regenerate its HID representation.

**Fix:** `setLocationInWindow:` and `setPhaseAndUpdateTimestamp:` now regenerate the touch's HID event after every state change.

### 5. Pointer IDs were not bounded
The previous dictionary accepted any positive `pathIdentity`. The new implementation clamps IDs to the practical range used by the reference implementation (1–98) so malformed input cannot create unbounded touch state.

## Preserved modules

No motor module was removed as part of this touch fix. The project still contains the original:

- `hooks/CaptainHook.h`
- `tasks/pid.mm` / `pid.h`
- `functions/Teste.mm` / `Teste.h` / `Offsets.h`
- `unity/unity.mm` / `unity.h`
- `overlay/ESPImGuiView.mm` / `.h`

One important distinction: the original ZIP contains the CaptainHook header, but the source audit did not find active `CHMethod`, `CHConstructor` or `MSHookMessageEx` call-sites outside the legacy header/unused ImGui source. This fix therefore preserves existing hook infrastructure; it does not invent hook call-sites that were absent.

## Runtime diagnostics
DEBUG builds now log the input path at three checkpoints:

1. AX HID decoding.
2. HUD window hit-testing.
3. TSEventFetcher touch state / phase.

These logs are intended to identify whether a future failure is before WindowServer routing, during hit-testing, or during UIKit delivery.

## Validation performed

- Source tree extracted and audited.
- HUD window constructor and registration path checked.
- Touch pipeline checked from `BKSHIDEventRegisterEventCallback` to `UIApplication sendEvent:`.
- Entitlement file retained unchanged.
- Existing motor directories retained.
- No iPhoneOS/Theos SDK is available in this Linux analysis environment, so a real arm64 device build was not performed here.

## SDK 15.6 compile fix

`HUDMainApplication.mm` now declares `UIWindow -orderFront:` in its local private UIKit interface. The selector is used by UIDaemon/TrollSpeed-style global HUD implementations but is absent from the public iOS 15.6 `UIWindow` declaration, so Clang correctly rejected `[self.window orderFront:nil]` when the receiver was statically typed as `UIWindow *`.

No warning-suppression flag was added for this error; the missing declaration is fixed at the source boundary.
