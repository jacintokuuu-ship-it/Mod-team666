# OFFSET_AUDIT.md

A dump estrutural não está presente no ZIP recebido. Os valores existentes em `functions/Offsets.h` foram preservados como **NÃO CONFIRMADO** nesta entrega; não foram promovidos a fato estrutural.

| Nome | Valor anterior | Valor novo | Fonte | Status |
|---|---:|---:|---|---|
| GameFacadeGetUIModelSpectatorRVA | 0x05933D60 | 0x05933D60 | `Offsets.h` existente | NÃO CONFIRMADO |
| GetLivePlayerByTeamIdAndPlayerIndexRVA | 0x048F86B8 | 0x048F86B8 | `Offsets.h` existente | NÃO CONFIRMADO |
| GetPlayerCountRVA | 0x048F8C34 | 0x048F8C34 | `Offsets.h` existente | NÃO CONFIRMADO |
| GetPlayerListFromTeamIdRVA | 0x048F85F4 | 0x048F85F4 | `Offsets.h` existente | NÃO CONFIRMADO |
| CameraGetMainRVA | 0x08CFF0B4 | 0x08CFF0B4 | `Offsets.h` existente | NÃO CONFIRMADO |
| CameraWorldToScreenPointRVA | 0x08CFE9C0 | 0x08CFE9C0 | `Offsets.h` existente | NÃO CONFIRMADO |
| PlayerGetAttackableCenterWSRVA | 0x056300E8 | 0x056300E8 | `Offsets.h` existente | NÃO CONFIRMADO |

Não foram inventados offsets de campos/estruturas.
