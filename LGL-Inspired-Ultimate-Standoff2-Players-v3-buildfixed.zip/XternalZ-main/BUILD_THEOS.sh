#!/bin/sh
set -eu

if [ -z "${THEOS:-}" ]; then
  echo "ERROR: THEOS is not set." >&2
  echo "Example: export THEOS=$HOME/theos" >&2
  exit 2
fi

SDK_VERSION="${SDKVERSION:-15.6}"

echo "==> Theos: $THEOS"
echo "==> iOS SDK: $SDK_VERSION"

echo "==> Cleaning previous build"
make clean || true

echo "==> Building Excalibur"
make all SDKVERSION="$SDK_VERSION" messages=yes

echo "==> Verifying package"
test -s packages/LGLInspired.tipa
unzip -t packages/LGLInspired.tipa >/dev/null

echo "BUILD PASS: packages/LGLInspired.tipa"
