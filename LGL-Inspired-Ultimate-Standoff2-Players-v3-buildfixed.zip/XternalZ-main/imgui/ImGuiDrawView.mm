//Require standard library
#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import <Foundation/Foundation.h>

#include <math.h>

// Import ImGui headers early so they're available for all code below
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/Honkai.h"

// Minimal forward declarations for MTKView to avoid pulling in full MetalKit headers
@class MTKView;

@protocol MTKViewDelegate <NSObject>
- (void)mtkView:(MTKView *)view drawableSizeWillChange:(CGSize)size;
- (void)drawInMTKView:(MTKView *)view;
@end

@interface MTKView : UIView
@property (nullable, nonatomic, strong) id<MTLDevice> device;
@property (nullable, nonatomic, weak) id<MTKViewDelegate> delegate;
@property (nonatomic) MTLClearColor clearColor;
@property (nullable, nonatomic, readonly) id<CAMetalDrawable> currentDrawable;
@property (nullable, nonatomic, readonly) MTLRenderPassDescriptor *currentRenderPassDescriptor;
@property (nonatomic) NSInteger preferredFramesPerSecond;
@end

// Debug variables for touch tracking (declared early so TouchableMTKView can use them)
static char debugText[256] = "Waiting for touch...";
static int touchCount = 0;
static NSUInteger gLastChangedTouches = 0;
static NSUInteger gLastAllTouches = 0;
static __weak UITouch *gPrimaryTouch = nil;
static CGPoint gUIKitPoint = {0.0, 0.0};
static BOOL gUIKitMouseDown = NO;
static BOOL gHasUIKitPoint = NO;

// Main menu ImGui context. The ESP debug overlay runs a second context, so any
// code that touches ImGui IO outside that overlay's own draw must bind to this
// one first (touch handlers, AX injection, the menu draw).
ImGuiContext *gMainImGuiContext = nullptr;
extern "C" ImGuiContext *HUDMainImGuiContext(void) { return gMainImGuiContext; }

// Rect of the actual menu window in view-local coords, updated every render. The
// menu surface only captures touches over this rect; everything else passes
// through so you can tap things that are not under the checkbox window.
static CGRect gMenuWindowRect = CGRectZero;

// Custom MTKView that forwards touch events
@interface TouchableMTKView : MTKView
@property (nonatomic, weak) id touchDelegate;
@property (nonatomic, assign) BOOL shouldCaptureTouch;
@end

@implementation TouchableMTKView

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    
    // Only capture touches that land on the actual menu window. Everything else
    // passes through (return nil) so taps reach whatever is behind the menu.
    if (self.shouldCaptureTouch && CGRectContainsPoint(gMenuWindowRect, point)) {
        return self;
    }

    return nil;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    snprintf(debugText, sizeof(debugText), "MTKView: touchesBegan called!");
    
    if ([self.touchDelegate respondsToSelector:@selector(touchesBegan:withEvent:)]) {
        [self.touchDelegate touchesBegan:touches withEvent:event];
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([self.touchDelegate respondsToSelector:@selector(touchesMoved:withEvent:)]) {
        [self.touchDelegate touchesMoved:touches withEvent:event];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    if ([self.touchDelegate respondsToSelector:@selector(touchesEnded:withEvent:)]) {
        [self.touchDelegate touchesEnded:touches withEvent:event];
    }
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([self.touchDelegate respondsToSelector:@selector(touchesCancelled:withEvent:)]) {
        [self.touchDelegate touchesCancelled:touches withEvent:event];
    }
}

@end

#import "../hooks/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "ESPImGuiView.h"
#import "../functions/Teste.h"

static bool MenDeal = true;

// The HUD receives native UITouch events directly from TouchableMTKView.
// The old HID/AX -> synthetic UITouch path was intentionally removed: using both
// paths at once caused duplicate/misaligned clicks and could feed touches to the
// wrong view.
extern "C" CGRect HUDMenuInteractiveRect(void)
{
    return gMenuWindowRect;
}

extern "C" BOOL HUDMenuIsInteractive(void)
{
    return (MenDeal && !CGRectIsEmpty(gMenuWindowRect));
}

// Bridge to HUD layer to toggle ESP overlay visibility, HUD overlay, and hide menu.
extern "C" void HUDSetESPEnabled(bool enabled);
extern "C" void HUDSetTracersEnabled(bool enabled);
extern "C" void HUDSetOverlayEnabled(bool enabled);
extern "C" void HUDSetStealthEnabled(bool enabled);
extern "C" void HUDHideMenu(void);

// Bridge to HUD layer to toggle ESP overlay visibility and hide menu.
extern "C" void HUDSetESPEnabled(bool enabled);
extern "C" void HUDHideMenu(void);

#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

// -----------------------------------------------------------------------------
// LGL Android-template visual layer, ported to iOS/ImGui.
// The menu/window lifecycle and the existing ESP/memory bridges below remain
// untouched; these helpers only reproduce the template's visual language.
// -----------------------------------------------------------------------------
static ImFont *gTemplateBodyFont = nullptr;
static ImFont *gTemplateTitleFont = nullptr;
static ImFont *gTemplateSubtitleFont = nullptr;
static bool gTemplateSettingsOpen = false;
static bool gTemplateDragging = false;
static ImVec2 gTemplateDragMouseStart = ImVec2(0, 0);
static ImVec2 gTemplateDragWindowStart = ImVec2(0, 0);

static ImU32 LGLTemplateTextColor()      { return IM_COL32(255, 255, 255, 255); }
static ImU32 LGLTemplateAccentColor()    { return IM_COL32(130, 202, 253, 255); } // #82CAFD
static ImU32 LGLTemplateMenuColor()      { return IM_COL32(28, 42, 53, 238); }  // #EE1C2A35
static ImU32 LGLTemplateFeatureColor()   { return IM_COL32(20, 28, 34, 221); }  // #DD141C22
static ImU32 LGLTemplateButtonColor()    { return IM_COL32(28, 38, 45, 255); }  // #1C262D
static ImU32 LGLTemplateCategoryColor()  { return IM_COL32(47, 61, 76, 255); }  // #2F3D4C
static ImU32 LGLTemplateToggleOn()       { return IM_COL32(128, 203, 196, 255); } // #80CBC4
static ImU32 LGLTemplateToggleOff()      { return IM_COL32(92, 99, 105, 255); }

static void LGLTemplateDrawCenteredText(ImDrawList *draw, const ImVec2 &min, const ImVec2 &max, const char *text, ImU32 color, ImFont *font, float size)
{
    if (!draw || !text) return;
    ImVec2 ts = font ? font->CalcTextSizeA(size, 100000.0f, 0.0f, text) : ImGui::CalcTextSize(text);
    ImVec2 pos((min.x + max.x - ts.x) * 0.5f, (min.y + max.y - ts.y) * 0.5f);
    draw->AddText(font, size, pos, color, text);
}

static void LGLTemplateDrawGear(ImDrawList *draw, const ImVec2 &center, ImU32 color)
{
    if (!draw) return;
    const float innerR = 5.0f;
    const float outerR = 9.0f;
    const int teeth = 8;
    for (int i = 0; i < teeth; ++i) {
        float a = (float)i * (2.0f * (float)M_PI / (float)teeth);
        ImVec2 a0(center.x + cosf(a) * innerR, center.y + sinf(a) * innerR);
        ImVec2 a1(center.x + cosf(a) * outerR, center.y + sinf(a) * outerR);
        draw->AddLine(a0, a1, color, 2.0f);
    }
    draw->AddCircle(center, 6.0f, color, 12, 2.0f);
    draw->AddCircleFilled(center, 2.2f, color);
}

static bool LGLTemplateCategory(const char *text)
{
    ImGuiStyle &style = ImGui::GetStyle();
    ImVec2 p = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    const float h = 20.0f;
    ImDrawList *draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(p, ImVec2(p.x + w, p.y + h), LGLTemplateCategoryColor());
    LGLTemplateDrawCenteredText(draw, p, ImVec2(p.x + w, p.y + h), text, LGLTemplateTextColor(), gTemplateBodyFont, 15.0f);
    ImGui::Dummy(ImVec2(w, h + style.ItemSpacing.y));
    return true;
}

static bool LGLTemplateToggleRow(const char *id, const char *label, bool *value)
{
    ImVec2 p = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    const float h = 24.0f;
    bool clicked = ImGui::InvisibleButton(id, ImVec2(w, h));
    bool hovered = ImGui::IsItemHovered();
    ImDrawList *draw = ImGui::GetWindowDrawList();

    ImU32 bg = hovered ? IM_COL32(28, 38, 45, 245) : LGLTemplateFeatureColor();
    draw->AddRectFilled(p, ImVec2(p.x + w, p.y + h), bg);
    ImVec2 textPos(p.x + 10.0f, p.y + (h - 16.0f) * 0.5f);
    draw->AddText(gTemplateBodyFont, 8.5f, textPos, LGLTemplateTextColor(), label);

    const float trackW = 24.0f;
    const float trackH = 13.0f;
    ImVec2 trackMin(p.x + w - trackW - 10.0f, p.y + (h - trackH) * 0.5f);
    ImVec2 trackMax(trackMin.x + trackW, trackMin.y + trackH);
    draw->AddRectFilled(trackMin, trackMax, *value ? LGLTemplateToggleOn() : LGLTemplateToggleOff(), trackH * 0.5f);

    float knobR = 5.0f;
    float knobX = *value ? (trackMax.x - knobR - 2.0f) : (trackMin.x + knobR + 2.0f);
    draw->AddCircleFilled(ImVec2(knobX, (trackMin.y + trackMax.y) * 0.5f), knobR, IM_COL32(245, 248, 250, 255));

    if (clicked) *value = !*value;
    ImGui::Dummy(ImVec2(w, ImGui::GetStyle().ItemSpacing.y));
    return clicked;
}

static bool LGLTemplateButtonRow(const char *id, const char *label)
{
    ImVec2 p = ImGui::GetCursorScreenPos();
    float w = ImGui::GetContentRegionAvail().x;
    const float h = 22.0f;
    bool clicked = ImGui::InvisibleButton(id, ImVec2(w, h));
    bool hovered = ImGui::IsItemHovered();
    ImDrawList *draw = ImGui::GetWindowDrawList();
    draw->AddRectFilled(p, ImVec2(p.x + w, p.y + h), hovered ? IM_COL32(36, 48, 56, 255) : LGLTemplateButtonColor());
    LGLTemplateDrawCenteredText(draw, p, ImVec2(p.x + w, p.y + h), label, LGLTemplateTextColor(), gTemplateBodyFont, 8.5f);
    ImGui::Dummy(ImVec2(w, ImGui::GetStyle().ItemSpacing.y));
    return clicked;
}

static bool LGLTemplateFooterButton(const char *id, const char *label, bool alignRight)
{
    float w = ImGui::GetWindowSize().x * 0.5f;
    const float h = 24.0f;
    ImVec2 p = ImGui::GetCursorScreenPos();
    bool clicked = ImGui::InvisibleButton(id, ImVec2(w, h));
    ImDrawList *draw = ImGui::GetWindowDrawList();
    ImVec2 ts = gTemplateBodyFont ? gTemplateBodyFont->CalcTextSizeA(8.5f, 100000.0f, 0.0f, label) : ImVec2(0, 0);
    float textX = alignRight ? (p.x + w - ts.x - 10.0f) : (p.x + 10.0f);
    draw->AddText(gTemplateBodyFont, 8.5f, ImVec2(textX, p.y + 8.0f), LGLTemplateAccentColor(), label);
    return clicked;
}

static void LGLTemplateClampWindow(const ImVec2 &displaySize)
{
    ImVec2 pos = ImGui::GetWindowPos();
    ImVec2 size = ImGui::GetWindowSize();
    const float margin = 8.0f;
    pos.x = fminf(fmaxf(pos.x, margin), fmaxf(margin, displaySize.x - size.x - margin));
    pos.y = fminf(fmaxf(pos.y, margin), fmaxf(margin, displaySize.y - size.y - margin));
    ImGui::SetWindowPos(pos, ImGuiCond_Always);
}

@implementation ImGuiDrawView

//I usually let the function for hooking in here...
void (*huy)(void *instance);
void _huy(void *instance)
{
    huy(instance);
}

static bool gTesteToggle = false;


- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];


    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) {
        abort();
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    gMainImGuiContext = ImGui::GetCurrentContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.IniFilename = NULL;

    // Android Mod Menu 5.0 visual palette/typography, ported to ImGui.
    ImGui::StyleColorsDark();

    ImGuiStyle &style = ImGui::GetStyle();
    ImFontConfig bodyCfg;
    bodyCfg.SizePixels = 15.0f;
    gTemplateBodyFont = io.Fonts->AddFontDefault(&bodyCfg);

    ImFontConfig titleCfg;
    titleCfg.SizePixels = 18.0f;
    gTemplateTitleFont = io.Fonts->AddFontDefault(&titleCfg);

    ImFontConfig subtitleCfg;
    subtitleCfg.SizePixels = 10.0f;
    gTemplateSubtitleFont = io.Fonts->AddFontDefault(&subtitleCfg);

    style.Colors[ImGuiCol_Text]            = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
    style.Colors[ImGuiCol_TextDisabled]    = ImVec4(0.51f, 0.79f, 0.99f, 1.00f);
    style.Colors[ImGuiCol_WindowBg]        = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    style.Colors[ImGuiCol_ChildBg]         = ImVec4(0.0f, 0.0f, 0.0f, 0.0f);
    style.Colors[ImGuiCol_FrameBg]         = ImVec4(0.11f, 0.15f, 0.18f, 1.00f);
    style.Colors[ImGuiCol_FrameBgHovered]  = ImVec4(0.14f, 0.19f, 0.22f, 1.00f);
    style.Colors[ImGuiCol_FrameBgActive]   = ImVec4(0.16f, 0.21f, 0.24f, 1.00f);
    style.Colors[ImGuiCol_Button]           = ImVec4(0.11f, 0.15f, 0.18f, 1.00f);
    style.Colors[ImGuiCol_ButtonHovered]    = ImVec4(0.15f, 0.20f, 0.23f, 1.00f);
    style.Colors[ImGuiCol_ButtonActive]     = ImVec4(0.18f, 0.23f, 0.27f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarBg]      = ImVec4(0.04f, 0.05f, 0.06f, 0.45f);
    style.Colors[ImGuiCol_ScrollbarGrab]    = ImVec4(0.24f, 0.30f, 0.34f, 0.90f);
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.32f, 0.39f, 0.43f, 1.00f);
    style.Colors[ImGuiCol_ScrollbarGrabActive]  = ImVec4(0.40f, 0.48f, 0.52f, 1.00f);
    style.WindowRounding     = 4.0f;
    style.ChildRounding      = 0.0f;
    style.FrameRounding      = 0.0f;
    style.GrabRounding       = 0.0f;
    style.ScrollbarRounding  = 0.0f;
    style.WindowPadding      = ImVec2(0, 0);
    style.FramePadding       = ImVec2(0, 0);
    style.ItemSpacing        = ImVec2(0, 0);
    style.ItemInnerSpacing   = ImVec2(4, 4);
    style.TouchExtraPadding  = ImVec2(3, 3);
    style.WindowBorderSize   = 0.0f;

    ImGui_ImplMetal_Init(_device);


    return self;
}

static bool gHUDMenuWasOpen = true;
// Host view used by the ImGui/Metal view lifecycle. Keep this translation-unit local.
static UIView *gImGuiHostView = nil;

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
    if (open) {
        gHUDMenuWasOpen = true;
    }
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{

    UIWindow *window = [UIApplication sharedApplication].keyWindow ?: [UIApplication sharedApplication].windows.firstObject;
    CGFloat w = window.bounds.size.width;
    CGFloat h = window.bounds.size.height;
    TouchableMTKView *mtkView = [[TouchableMTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
    mtkView.shouldCaptureTouch = NO; // Initially don't capture touches
    self.view = mtkView;
    self.view.multipleTouchEnabled = YES;
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    mtkView.touchDelegate = self;
    gImGuiHostView = self.view;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    self.view.clipsToBounds = YES;
    self.mtkView.userInteractionEnabled = YES;
    self.mtkView.multipleTouchEnabled = YES;
}



#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    UITouch *touch = gPrimaryTouch;
    if (!touch) {
        return;
    }

    CGPoint touchLocation = [touch locationInView:self.view];
    gUIKitPoint = touchLocation;
    gHasUIKitPoint = YES;

    if (gMainImGuiContext) ImGui::SetCurrentContext(gMainImGuiContext);
    ImGuiIO &io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
    io.MousePos = ImVec2(touchLocation.x, touchLocation.y);

    const BOOL active = (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled);
    io.MouseDown[0] = active;
    gUIKitMouseDown = active;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    touchCount++;
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;

    // Lock the ImGui pointer to the first touch that entered the menu.
    // Additional fingers are ignored by the menu instead of changing the pointer
    // position underneath an already-active control.
    if (!gPrimaryTouch) {
        gPrimaryTouch = touches.anyObject;
    }

    snprintf(debugText, sizeof(debugText), "UI beg ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;
    snprintf(debugText, sizeof(debugText), "UI mov ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);

    if (gPrimaryTouch) {
        [self updateIOWithTouchEvent:event];
    }
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;
    snprintf(debugText, sizeof(debugText), "UI can ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);

    if (gPrimaryTouch && [touches containsObject:gPrimaryTouch]) {
        if (gMainImGuiContext) ImGui::SetCurrentContext(gMainImGuiContext);
        ImGui::GetIO().MouseDown[0] = false;
        gUIKitMouseDown = NO;
        gPrimaryTouch = nil;
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;
    snprintf(debugText, sizeof(debugText), "UI end ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);

    if (gPrimaryTouch && [touches containsObject:gPrimaryTouch]) {
        [self updateIOWithTouchEvent:event];
        if (gMainImGuiContext) ImGui::SetCurrentContext(gMainImGuiContext);
        ImGui::GetIO().MouseDown[0] = false;
        gUIKitMouseDown = NO;
        gPrimaryTouch = nil;
    }
}

#pragma mark - MTKViewDelegate

- (void)drawInMTKView:(MTKView*)view
{
    // The ESP overlay swaps the current context during its own draw, so make
    // sure the menu always renders into the main context.
    if (gMainImGuiContext) ImGui::SetCurrentContext(gMainImGuiContext);
    ImGuiIO& io = ImGui::GetIO();

    if (gHasUIKitPoint) {
        io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
        io.MousePos = ImVec2(gUIKitPoint.x, gUIKitPoint.y);
        io.MouseDown[0] = gUIKitMouseDown;
    }

    io.DisplaySize.x = view.bounds.size.width;
    io.DisplaySize.y = view.bounds.size.height;

    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1.0f / float(view.preferredFramesPerSecond ?: 120);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];

    static bool showBoxes   = false;
    static bool showTracers = false;
    static bool showHealthBar = false;
    static bool showName    = false;
    static bool showWeapon  = false;
    static bool teamCheck   = true;
    static float colLine[3]   = {1.0f, 1.0f, 1.0f};
    static float colBox[3]    = {1.0f, 1.0f, 1.0f};
    static float colHp[3]     = {0.20f, 0.90f, 0.30f};
    static float colName[3]   = {1.0f, 1.0f, 1.0f};
    static float colWeapon[3] = {1.0f, 1.0f, 1.0f};
    static bool  chamsEnabled = false;
    static int   chamsMaterialId = 0;       // 0 = solid purple "missing material"
    static bool  stealthEnabled = false;    // hide menu + ESP from screenshots/recording

    // Update touch capture based on menu visibility
    TouchableMTKView *touchableView = (TouchableMTKView *)view;
    if ([touchableView isKindOfClass:[TouchableMTKView class]]) {
        touchableView.shouldCaptureTouch = (MenDeal && !CGRectIsEmpty(gMenuWindowRect));
    }

    if (MenDeal == true) {
        gHUDMenuWasOpen = true;
        [self.view setUserInteractionEnabled:YES];
    } else {
        if (gHUDMenuWasOpen) {
            HUDHideMenu();
            gHUDMenuWasOpen = false;
        }
        [self.view setUserInteractionEnabled:YES];
    }

    MTLRenderPassDescriptor* renderPassDescriptor = view.currentRenderPassDescriptor;
    if (!renderPassDescriptor) {
        [commandBuffer commit];
        return;
    }

    id<MTLRenderCommandEncoder> renderEncoder =
        [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
    [renderEncoder pushDebugGroup:@"LGL Mod Menu"];

    ImGui_ImplMetal_NewFrame(renderPassDescriptor);
    ImGui::NewFrame();
    
    if (MenDeal == true)
    {
        // Exact menu family from the Android Mod Menu 5.0 source: dark alpha
        // panel, centered blue title/subtitle, category strip, scrollable feature
        // area and blue footer actions. The iOS floating surface remains the same
        // MenuView/Metal surface used by the original project.
        ImGuiWindowFlags flags = ImGuiWindowFlags_NoTitleBar |
                                 ImGuiWindowFlags_NoCollapse |
                                 ImGuiWindowFlags_NoResize |
                                 ImGuiWindowFlags_NoSavedSettings;

        const float panelW = MIN(180.0f, MAX(160.0f, io.DisplaySize.x - 20.0f));
        const float panelH = MIN(205.0f, MAX(175.0f, io.DisplaySize.y - 20.0f));
        ImGui::SetNextWindowSize(ImVec2(panelW, panelH), ImGuiCond_Always);
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f),
                                ImGuiCond_FirstUseEver, ImVec2(0.5f, 0.5f));

        if (ImGui::Begin("##LGLModMenu", nullptr, flags))
        {
            ImVec2 wpos = ImGui::GetWindowPos();
            ImVec2 wsize = ImGui::GetWindowSize();
            ImVec2 content = ImGui::GetContentRegionAvail();
            ImDrawList *draw = ImGui::GetWindowDrawList();

            // Menu body. This mirrors MENU_BG_COLOR (#EE1C2A35).
            draw->AddRectFilled(wpos, ImVec2(wpos.x + wsize.x, wpos.y + wsize.y), LGLTemplateMenuColor(), 4.0f);

            const float headerH = 38.0f;
            const float footerH = 26.0f;

            // Header drag region (same floating-menu behavior, now on the
            // template-style header because there is no native ImGui title bar).
            ImVec2 headerPos = ImGui::GetCursorScreenPos();
            float dragW = MAX(1.0f, content.x - 28.0f);
            ImGui::InvisibleButton("##LGLDragHeader", ImVec2(dragW, headerH));
            if (ImGui::IsItemActive()) {
                if (!gTemplateDragging) {
                    gTemplateDragging = true;
                    gTemplateDragMouseStart = io.MousePos;
                    gTemplateDragWindowStart = ImGui::GetWindowPos();
                }
                if (io.MouseDown[0]) {
                    ImVec2 delta(io.MousePos.x - gTemplateDragMouseStart.x,
                                 io.MousePos.y - gTemplateDragMouseStart.y);
                    ImGui::SetWindowPos(ImVec2(gTemplateDragWindowStart.x + delta.x,
                                               gTemplateDragWindowStart.y + delta.y), ImGuiCond_Always);
                    LGLTemplateClampWindow(io.DisplaySize);
                }
            } else if (!io.MouseDown[0]) {
                gTemplateDragging = false;
            }

            // Settings glyph/area (same role as Android template's gear).
            ImGui::SetCursorScreenPos(ImVec2(wpos.x + wsize.x - 40.0f, wpos.y + 8.0f));
            ImGui::InvisibleButton("##LGLSettings", ImVec2(24.0f, 22.0f));
            bool settingsClicked = ImGui::IsItemClicked();
            LGLTemplateDrawGear(draw, ImVec2(wpos.x + wsize.x - 16.0f, wpos.y + 14.0f), LGLTemplateAccentColor());
            if (settingsClicked) gTemplateSettingsOpen = !gTemplateSettingsOpen;

            // Exact title/subtitle strings from the reference template.
            if (gTemplateTitleFont) {
                ImGui::PushFont(gTemplateTitleFont);
                LGLTemplateDrawCenteredText(draw, ImVec2(wpos.x, headerPos.y + 0.0f),
                                            ImVec2(wpos.x + wsize.x, headerPos.y + 20.0f),
                                            "Mod menu by LGL", LGLTemplateAccentColor(), gTemplateTitleFont, 11.0f);
                ImGui::PopFont();
            }
            if (gTemplateSubtitleFont) {
                ImGui::PushFont(gTemplateSubtitleFont);
                LGLTemplateDrawCenteredText(draw, ImVec2(wpos.x, headerPos.y + 20.0f),
                                            ImVec2(wpos.x + wsize.x, headerPos.y + 34.0f),
                                            "whatever here", LGLTemplateAccentColor(), gTemplateSubtitleFont, 7.0f);
                ImGui::PopFont();
            }

            ImGui::SetCursorScreenPos(ImVec2(wpos.x, headerPos.y + headerH));

            const float childH = MAX(90.0f, wsize.y - headerH - footerH);
            if (ImGui::BeginChild("##LGLFeatureScroll", ImVec2(wsize.x, childH), false, ImGuiWindowFlags_NoScrollbar))
            {
                LGLTemplateCategory(gTemplateSettingsOpen ? "Settings" : "Mod");

                if (!gTemplateSettingsOpen) {
                    // Existing Teste/memory-read path is called exactly as before.
                    if (LGLTemplateButtonRow("##LGLTeste", "Teste")) {
                        gTesteToggle = true;
                        MenuFuncaoTeste();
                    }

                    LGLTemplateToggleRow("##LGLShowBoxes", "Show opponents on map", &showBoxes);
                    LGLTemplateToggleRow("##LGLHealth", "Show health bar", &showHealthBar);
                    LGLTemplateToggleRow("##LGLNames", "Show names", &showName);
                    LGLTemplateToggleRow("##LGLWeapon", "Show weapons", &showWeapon);
                    LGLTemplateToggleRow("##LGLTracers", "Show lines", &showTracers);
                    LGLTemplateToggleRow("##LGLChams", "Material chams", &chamsEnabled);
                    LGLTemplateToggleRow("##LGLStealth", "Stealth overlay", &stealthEnabled);
                    LGLTemplateToggleRow("##LGLTeam", "Team check", &teamCheck);

                    if (gTesteToggle) {
                        const char *msg = TesteMensagem();
                        if (TesteMensagemVisivel() && msg && *msg) {
                            ImVec2 p = ImGui::GetCursorScreenPos();
                            float ww = ImGui::GetContentRegionAvail().x;
                            draw = ImGui::GetWindowDrawList();
                            draw->AddRectFilled(p, ImVec2(p.x + ww, p.y + 36.0f), LGLTemplateFeatureColor());
                            draw->AddText(gTemplateSubtitleFont, 10.0f, ImVec2(p.x + 10.0f, p.y + 11.0f), LGLTemplateAccentColor(), msg);
                            ImGui::Dummy(ImVec2(ww, 42.0f));
                        }
                    }
                } else {
                    // Settings page keeps the Android template's simple list style.
                    LGLTemplateToggleRow("##LGLSettingTeam", "Team check", &teamCheck);
                    LGLTemplateToggleRow("##LGLSettingStealth", "Stealth overlay", &stealthEnabled);
                    if (LGLTemplateButtonRow("##LGLBackSettings", "Back to Mod")) {
                        gTemplateSettingsOpen = false;
                    }
                }
            }
            ImGui::EndChild();

            // Android template footer: transparent area with blue left/right actions.
            ImGui::SetCursorScreenPos(ImVec2(wpos.x, wpos.y + wsize.y - footerH));
            if (LGLTemplateFooterButton("##LGLHide", "HIDE/KILL (Hold)", false)) {
                MenDeal = false;
            }
            ImGui::SameLine(0, 0);
            if (LGLTemplateFooterButton("##LGLMinimize", "MINIMIZE", true)) {
                MenDeal = false;
            }

            gMenuWindowRect = CGRectMake(wpos.x, wpos.y, wsize.x, wsize.y);
        }

        ImGui::End();

        [ESPImGuiView setLineColor:[UIColor colorWithRed:colLine[0] green:colLine[1] blue:colLine[2] alpha:1.0]];
        [ESPImGuiView setBoxColor:[UIColor colorWithRed:colBox[0] green:colBox[1] blue:colBox[2] alpha:1.0]];
        [ESPImGuiView setHpColor:[UIColor colorWithRed:colHp[0] green:colHp[1] blue:colHp[2] alpha:1.0]];
        [ESPImGuiView setNameColor:[UIColor colorWithRed:colName[0] green:colName[1] blue:colName[2] alpha:1.0]];
        [ESPImGuiView setWeaponColor:[UIColor colorWithRed:colWeapon[0] green:colWeapon[1] blue:colWeapon[2] alpha:1.0]];
        [ESPImGuiView setChamsEnabled:chamsEnabled];
        [ESPImGuiView setChamsMaterialId:chamsMaterialId];
        [ESPImGuiView setStealthEnabled:stealthEnabled];
        // Apply stealth immediately on toggle (HUD layout timer may be idle).
        static bool prevStealth = false;
        if (stealthEnabled != prevStealth) {
            prevStealth = stealthEnabled;
            HUDSetStealthEnabled(stealthEnabled);
        }

        // Drive the ESP draw loop (HUDMainApplication reads these flags).
        BOOL espOn = (showBoxes || showHealthBar || showName || showWeapon || showTracers || chamsEnabled);
        [ESPImGuiView setESPEnabled:espOn];
        [ESPImGuiView setTracersEnabled:espOn];   // master gate for the HUD ESP draw loop
        [ESPImGuiView setShowLines:showTracers];
        [ESPImGuiView setShowBox:showBoxes];
        [ESPImGuiView setShowHealthBar:showHealthBar];
        [ESPImGuiView setShowName:showName];
        [ESPImGuiView setShowWeapon:showWeapon];
        [ESPImGuiView setTeamCheck:teamCheck];

        // The HUD ESP overlay is driven by the same "any feature on" flag.
        HUDSetESPEnabled(espOn);
        HUDSetTracersEnabled(espOn);

    } else {
        gMenuWindowRect = CGRectZero;
        // Draw small indicator when menu is closed
        ImDrawList *fgDrawList = ImGui::GetForegroundDrawList();
        fgDrawList->AddCircleFilled(ImVec2(io.DisplaySize.x - 30, 30), 10, IM_COL32(0, 255, 0, 150));
    }

    ImGui::Render();
    ImDrawData* draw_data = ImGui::GetDrawData();
    ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
  
    [renderEncoder popDebugGroup];
    [renderEncoder endEncoding];

    [commandBuffer presentDrawable:view.currentDrawable];
    [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}

@end
