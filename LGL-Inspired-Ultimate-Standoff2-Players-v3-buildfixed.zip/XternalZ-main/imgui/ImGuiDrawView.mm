#include <algorithm>
#include <atomic>
#include <deque>
#include <mutex>
#include <unordered_map>
//Require standard library
#import <UIKit/UIKit.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>
#import <Foundation/Foundation.h>

// Import ImGui headers early so they're available for all code below
#import "IMGUI/imgui.h"
#import "IMGUI/imgui_impl_metal.h"
#import "IMGUI/Honkai.h"

// Minimal forward declarations for MTKView to avoid pulling in full MetalKit headers
@class MTKView;

@protocol MTKViewDelegate <NSObject>
- (void)mtkView:(MTKView *)view drawableSizeWillChange:(CGSize)size;
- (void)drawInMTKView:(MTKView *)view;
@end

@interface MTKView : UIView
@property (nullable, nonatomic, strong) id<MTLDevice> device;
@property (nullable, nonatomic, weak) id<MTKViewDelegate> delegate;
@property (nonatomic) MTLClearColor clearColor;
@property (nullable, nonatomic, readonly) id<CAMetalDrawable> currentDrawable;
@property (nullable, nonatomic, readonly) MTLRenderPassDescriptor *currentRenderPassDescriptor;
@property (nonatomic) NSInteger preferredFramesPerSecond;
@end

// Debug variables for touch tracking (declared early so TouchableMTKView can use them)
static char debugText[256] = "Waiting for touch...";
static int touchCount = 0;
static NSUInteger gLastChangedTouches = 0;
static NSUInteger gLastAllTouches = 0;
static CGPoint gInjectedPoint = {0.0, 0.0};
static BOOL gInjectedMouseDown = NO;
static BOOL gHasInjectedPoint = NO;
static __weak UIView *gImGuiHostView = nil;
static CGPoint gUIKitPoint = {0.0, 0.0};
static BOOL gUIKitMouseDown = NO;
static BOOL gHasUIKitPoint = NO;
static CFTimeInterval gLastUIKitTouchTime = 0.0;
static CFTimeInterval gLastInjectedTouchTime = 0.0;

// UIKit callbacks and the Metal render callback should not mutate ImGuiIO at the
// same time. The UIKit side only queues compact touch events; drawInMTKView:
// applies them immediately before ImGui::NewFrame(). This is compatible with the
// Dear ImGui 1.83 API bundled by this project (which predates AddMousePosEvent()).
struct NexusQueuedTouchEvent {
    CGPoint point;
    UITouchPhase phase;
};

static std::mutex gNexusTouchQueueMutex;
static std::deque<NexusQueuedTouchEvent> gNexusTouchQueue;
static constexpr size_t kNexusTouchQueueLimit = 128;

// Published in atomic scalar form because hit-testing may occur independently of
// the Metal frame callback. The cached rectangle is the actual ImGui window in
// host-view coordinates.
static std::atomic<double> gMenuRectX{0.0};
static std::atomic<double> gMenuRectY{0.0};
static std::atomic<double> gMenuRectW{0.0};
static std::atomic<double> gMenuRectH{0.0};

static void NexusPublishMenuRect(CGRect rect)
{
    gMenuRectX.store(CGRectGetMinX(rect), std::memory_order_release);
    gMenuRectY.store(CGRectGetMinY(rect), std::memory_order_release);
    gMenuRectW.store(CGRectGetWidth(rect), std::memory_order_release);
    gMenuRectH.store(CGRectGetHeight(rect), std::memory_order_release);
}

static CGRect NexusReadMenuRect()
{
    return CGRectMake(
        gMenuRectX.load(std::memory_order_acquire),
        gMenuRectY.load(std::memory_order_acquire),
        gMenuRectW.load(std::memory_order_acquire),
        gMenuRectH.load(std::memory_order_acquire));
}

static void NexusQueueTouch(CGPoint point, UITouchPhase phase)
{
    std::lock_guard<std::mutex> lock(gNexusTouchQueueMutex);

    // Coalesce consecutive move events. This bounds queue growth and keeps the
    // render callback close to the finger position at high touch sample rates.
    if (phase == UITouchPhaseMoved &&
        !gNexusTouchQueue.empty() &&
        gNexusTouchQueue.back().phase == UITouchPhaseMoved) {
        gNexusTouchQueue.back().point = point;
        return;
    }

    if (gNexusTouchQueue.size() >= kNexusTouchQueueLimit) {
        gNexusTouchQueue.pop_front();
    }

    gNexusTouchQueue.push_back({point, phase});
}

static std::deque<NexusQueuedTouchEvent> NexusDrainTouchQueue()
{
    std::lock_guard<std::mutex> lock(gNexusTouchQueueMutex);
    std::deque<NexusQueuedTouchEvent> result;
    result.swap(gNexusTouchQueue);
    return result;
}

// Main menu ImGui context. The ESP debug overlay runs a second context, so any
// code that touches ImGui IO outside that overlay's own draw must bind to this
// one first (touch handlers, AX injection, the menu draw).
ImGuiContext *gMainImGuiContext = nullptr;
extern "C" ImGuiContext *HUDMainImGuiContext(void) { return gMainImGuiContext; }

// Rect of the actual menu window in view-local coords, updated every render. The
// menu surface only captures touches over this rect; everything else passes
// through so you can tap things that are not under the checkbox window.
static CGRect gMenuWindowRect = CGRectZero;

// Custom MTKView that forwards touch events
@interface TouchableMTKView : MTKView
@property (nonatomic, weak) id touchDelegate;
@property (nonatomic, assign) BOOL shouldCaptureTouch;
@end

@implementation TouchableMTKView

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    // UIKit can ask pointInside: before hitTest:. Keep the same strict region in
    // both methods so the full-screen Metal view never acts as a touch shield.
    return self.shouldCaptureTouch &&
           !CGRectIsEmpty(gMenuWindowRect) &&
           CGRectContainsPoint(gMenuWindowRect, point);
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    // Only capture touches that land on the actual ImGui window. Everything else
    // returns nil and is therefore eligible for the lower SpringBoard/game
    // window.
    if ([self pointInside:point withEvent:event]) {
        return self;
    }

    return nil;
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    snprintf(debugText, sizeof(debugText), "MTKView: touchesBegan called!");
    
    if ([self.touchDelegate respondsToSelector:@selector(touchesBegan:withEvent:)]) {
        [self.touchDelegate touchesBegan:touches withEvent:event];
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([self.touchDelegate respondsToSelector:@selector(touchesMoved:withEvent:)]) {
        [self.touchDelegate touchesMoved:touches withEvent:event];
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    if ([self.touchDelegate respondsToSelector:@selector(touchesEnded:withEvent:)]) {
        [self.touchDelegate touchesEnded:touches withEvent:event];
    }
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if ([self.touchDelegate respondsToSelector:@selector(touchesCancelled:withEvent:)]) {
        [self.touchDelegate touchesCancelled:touches withEvent:event];
    }
}

@end

#import "../hooks/CaptainHook.h"
#import "Esp/ImGuiDrawView.h"
#import "ESPImGuiView.h"
#import "../functions/Teste.h"

static const char *HUDPhaseName(NSInteger phase)
{
    switch (phase) {
        case UITouchPhaseBegan: return "beg";
        case UITouchPhaseMoved: return "mov";
        case UITouchPhaseStationary: return "sta";
        case UITouchPhaseEnded: return "end";
        case UITouchPhaseCancelled: return "can";
        default: return "unk";
    }
}

extern "C" void HUDInjectImGuiTouchAtScreenPoint(CGPoint screenPoint, NSInteger phase)
{
    if (!gImGuiHostView) {
        return;
    }

    // The HID/AX bridge and the dedicated touch window both report screen/window
    // coordinates. Convert once into the Metal view's local coordinate system.
    // Only the render callback mutates ImGuiIO; UIKit merely queues the event.
    CGPoint localPoint = [gImGuiHostView convertPoint:screenPoint fromView:nil];
    UITouchPhase touchPhase = static_cast<UITouchPhase>(phase);
    BOOL ending = (touchPhase == UITouchPhaseEnded ||
                   touchPhase == UITouchPhaseCancelled);

    gUIKitPoint = localPoint;
    gHasUIKitPoint = YES;
    gLastUIKitTouchTime = CACurrentMediaTime();
    gUIKitMouseDown = !ending;
    if (gUIKitMouseDown) {
        gHasInjectedPoint = NO;
    }

    snprintf(debugText, sizeof(debugText), "Touch %s %.0f %.0f",
             HUDPhaseName(phase), localPoint.x, localPoint.y);

    NexusQueueTouch(localPoint, touchPhase);
}

extern "C" BOOL HUDImGuiMenuContainsScreenPoint(CGPoint screenPoint)
{
    if (!gImGuiHostView || gImGuiHostView.hidden || gImGuiHostView.alpha <= 0.01) {
        return NO;
    }

    CGRect menuRect = NexusReadMenuRect();
    if (CGRectIsNull(menuRect) || CGRectIsEmpty(menuRect)) {
        return NO;
    }

    CGPoint localPoint = [gImGuiHostView convertPoint:screenPoint fromView:nil];
    return CGRectContainsPoint(menuRect, localPoint);
}

extern "C" BOOL HUDImGuiHasRecentDirectTouch(void)
{
    CFTimeInterval now = CACurrentMediaTime();
    return gUIKitMouseDown || (gHasUIKitPoint && (now - gLastUIKitTouchTime) < 0.20);
}

// Backward-compatible bridge for older callers. New code should use the
// screen-point variant above; the separate touch window is now the source of truth.
extern "C" void HUDInjectImGuiTouchAtWindowPoint(CGPoint point, NSInteger phase, UIWindow *window)
{
    (void)window;
    HUDInjectImGuiTouchAtScreenPoint(point, phase);
}

// Bridge to HUD layer to toggle ESP overlay visibility, HUD overlay, and hide menu.
extern "C" void HUDSetESPEnabled(bool enabled);
extern "C" void HUDSetTracersEnabled(bool enabled);
extern "C" void HUDSetOverlayEnabled(bool enabled);
extern "C" void HUDSetStealthEnabled(bool enabled);
extern "C" void HUDHideMenu(void);
extern "C" void HUDSetTouchWindowFrame(CGRect screenRect, BOOL visible, BOOL hotspotMode);


#define kWidth  [UIScreen mainScreen].bounds.size.width
#define kHeight [UIScreen mainScreen].bounds.size.height
#define kScale [UIScreen mainScreen].scale

@interface ImGuiDrawView () <MTKViewDelegate>
@property (nonatomic, strong) id <MTLDevice> device;
@property (nonatomic, strong) id <MTLCommandQueue> commandQueue;
@end

@implementation ImGuiDrawView

//I usually let the function for hooking in here...
void (*huy)(void *instance);
void _huy(void *instance)
{
    huy(instance);
}

static bool MenDeal = true;


- (instancetype)initWithNibName:(nullable NSString *)nibNameOrNil bundle:(nullable NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];


    _device = MTLCreateSystemDefaultDevice();
    _commandQueue = [_device newCommandQueue];

    if (!self.device) {
        abort();
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    gMainImGuiContext = ImGui::GetCurrentContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.IniFilename = NULL;

    // Futuristic LGL-inspired dark theme. The actual switches below are custom
    // draw controls; ImGui supplies only the touch hit region.
    ImGui::StyleColorsDark();

    ImFontConfig fontCfg;
    fontCfg.SizePixels = 13.5f;
    io.Fonts->AddFontDefault(&fontCfg);

    ImGuiStyle &style = ImGui::GetStyle();
    const ImVec4 accent    = ImVec4(0.18f, 0.90f, 0.55f, 1.00f);
    const ImVec4 accentDim = ImVec4(0.18f, 0.90f, 0.55f, 0.28f);
    style.Colors[ImGuiCol_Text]             = ImVec4(0.90f, 0.95f, 0.93f, 1.00f);
    style.Colors[ImGuiCol_TextDisabled]     = ImVec4(0.42f, 0.50f, 0.53f, 1.00f);
    style.Colors[ImGuiCol_WindowBg]         = ImVec4(0.018f, 0.028f, 0.045f, 0.97f);
    style.Colors[ImGuiCol_FrameBg]          = ImVec4(0.045f, 0.065f, 0.085f, 1.00f);
    style.Colors[ImGuiCol_FrameBgHovered]   = ImVec4(0.075f, 0.12f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_FrameBgActive]   = accentDim;
    style.Colors[ImGuiCol_CheckMark]       = accent;
    style.Colors[ImGuiCol_SliderGrab]      = accent;
    style.Colors[ImGuiCol_SliderGrabActive]= ImVec4(0.35f, 1.00f, 0.68f, 1.00f);
    style.Colors[ImGuiCol_Button]          = ImVec4(0.045f, 0.065f, 0.085f, 1.00f);
    style.Colors[ImGuiCol_ButtonHovered]   = accentDim;
    style.Colors[ImGuiCol_ButtonActive]    = accent;
    style.Colors[ImGuiCol_Header]          = accentDim;
    style.Colors[ImGuiCol_HeaderHovered]   = accentDim;
    style.Colors[ImGuiCol_HeaderActive]   = accent;
    style.Colors[ImGuiCol_TitleBg]         = ImVec4(0.018f, 0.028f, 0.045f, 1.00f);
    style.Colors[ImGuiCol_TitleBgActive]   = ImVec4(0.025f, 0.055f, 0.050f, 1.00f);
    style.Colors[ImGuiCol_Separator]       = ImVec4(0.10f, 0.20f, 0.18f, 1.00f);
    style.WindowRounding   = 18.0f;
    style.FrameRounding    = 10.0f;
    style.GrabRounding     = 10.0f;
    style.WindowPadding    = ImVec2(12, 12);
    style.FramePadding     = ImVec2(9, 8);
    style.ItemSpacing      = ImVec2(8, 8);
    style.ItemInnerSpacing = ImVec2(6, 5);
    style.TouchExtraPadding = ImVec2(6, 6);
    style.WindowBorderSize = 1.0f;
    style.TabRounding      = 9.0f;

    ImGui_ImplMetal_Init(_device);


    return self;
}

static bool gHUDMenuWasOpen = true;

+ (void)showChange:(BOOL)open
{
    MenDeal = open;
    if (open) {
        gHUDMenuWasOpen = true;
    }
}

- (MTKView *)mtkView
{
    return (MTKView *)self.view;
}

- (void)loadView
{

    UIWindow *window = [UIApplication sharedApplication].keyWindow ?: [UIApplication sharedApplication].windows.firstObject;
    CGFloat w = window.bounds.size.width;
    CGFloat h = window.bounds.size.height;
    TouchableMTKView *mtkView = [[TouchableMTKView alloc] initWithFrame:CGRectMake(0, 0, w, h)];
    mtkView.shouldCaptureTouch = NO; // UIKit input is owned by the dedicated HUDTouchWindow.
    self.view = mtkView;
    self.view.multipleTouchEnabled = YES;
    self.view.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    mtkView.touchDelegate = self;
    gImGuiHostView = self.view;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.mtkView.device = self.device;
    self.mtkView.delegate = self;
    self.mtkView.clearColor = MTLClearColorMake(0, 0, 0, 0);
    self.mtkView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.mtkView.clipsToBounds = YES;
    self.view.clipsToBounds = YES;
    self.mtkView.userInteractionEnabled = NO;
    self.mtkView.multipleTouchEnabled = NO;
}



#pragma mark - Interaction

- (void)updateIOWithTouchEvent:(UIEvent *)event
{
    NSSet<UITouch *> *allTouches = event.allTouches;
    gLastAllTouches = allTouches.count;
    UITouch *anyTouch = allTouches.anyObject;
    if (!anyTouch) {
        return;
    }

    CGPoint touchLocation = [anyTouch locationInView:self.view];
    gUIKitPoint = touchLocation;
    gHasUIKitPoint = YES;
    gLastUIKitTouchTime = CACurrentMediaTime();
    if (gMainImGuiContext) ImGui::SetCurrentContext(gMainImGuiContext);
    UITouchPhase phase = anyTouch.phase;
    BOOL hasActiveTouch = NO;
    for (UITouch *touch in allTouches)
    {
        if (touch.phase != UITouchPhaseEnded && touch.phase != UITouchPhaseCancelled)
        {
            hasActiveTouch = YES;
            break;
        }
    }

    gUIKitMouseDown = hasActiveTouch;
    if (hasActiveTouch) {
        gHasInjectedPoint = NO;
    }

    NexusQueueTouch(touchLocation, phase);
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    touchCount++;
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;
    snprintf(debugText, sizeof(debugText), "UI beg ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);
    [self updateIOWithTouchEvent:event];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;
    snprintf(debugText, sizeof(debugText), "UI mov ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);
    [self updateIOWithTouchEvent:event];
}

- (void)touchesCancelled:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;
    snprintf(debugText, sizeof(debugText), "UI can ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);
    [self updateIOWithTouchEvent:event];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    gLastChangedTouches = touches.count;
    gLastAllTouches = event.allTouches.count;
    snprintf(debugText, sizeof(debugText), "UI end ch:%lu all:%lu", (unsigned long)gLastChangedTouches, (unsigned long)gLastAllTouches);
    [self updateIOWithTouchEvent:event];
}



#pragma mark - MTKViewDelegate

static bool NexusSwitch(const char *id, const char *label, bool *value, const ImVec2 &size = ImVec2(0.0f, 42.0f))
{
    ImGui::PushID(id);

    ImVec2 cursor = ImGui::GetCursorScreenPos();
    ImVec2 avail = ImGui::GetContentRegionAvail();
    float rowWidth = size.x > 0.0f ? size.x : avail.x;
    float rowHeight = size.y > 0.0f ? size.y : 42.0f;

    bool pressed = ImGui::InvisibleButton("##switch", ImVec2(rowWidth, rowHeight));
    if (pressed) {
        *value = !*value;
    }

    float dt = ImGui::GetIO().DeltaTime;
    float target = *value ? 1.0f : 0.0f;
    static std::unordered_map<ImGuiID, float> animations;
    ImGuiID animID = ImGui::GetID("##anim");
    float &t = animations[animID];
    float speed = std::clamp(dt * 12.0f, 0.0f, 1.0f);
    t += (target - t) * speed;

    ImDrawList *draw = ImGui::GetWindowDrawList();
    const float trackW = 50.0f;
    const float trackH = 26.0f;
    const float knobR = 9.0f;
    const float trackX = cursor.x + rowWidth - trackW - 2.0f;
    const float trackY = cursor.y + (rowHeight - trackH) * 0.5f;
    const float knobX = trackX + 13.0f + t * (trackW - 26.0f);
    const float knobY = trackY + trackH * 0.5f;

    ImU32 rowBg = IM_COL32(13, 19, 30, 235);
    ImU32 rowBorder = IM_COL32(43, 57, 78, 230);
    ImU32 offTrack = IM_COL32(34, 43, 57, 255);
    ImU32 onTrack = IM_COL32(24, 148, 91, 255);
    ImU32 knob = IM_COL32(235, 247, 255, 255);
    ImU32 text = IM_COL32(226, 235, 247, 255);
    ImU32 sub = IM_COL32(111, 130, 153, 255);

    draw->AddRectFilled(cursor, ImVec2(cursor.x + rowWidth, cursor.y + rowHeight),
                        rowBg, 10.0f);
    draw->AddRect(cursor, ImVec2(cursor.x + rowWidth, cursor.y + rowHeight),
                  rowBorder, 10.0f, 0, 1.0f);

    if (t > 0.001f) {
        ImU32 glow = IM_COL32(35, 230, 139, (int)(35.0f * t));
        draw->AddRectFilled(ImVec2(trackX - 3.0f, trackY - 3.0f),
                            ImVec2(trackX + trackW + 3.0f, trackY + trackH + 3.0f),
                            glow, 15.0f);
    }

    ImU32 trackColor = *value ? onTrack : offTrack;
    draw->AddRectFilled(ImVec2(trackX, trackY),
                        ImVec2(trackX + trackW, trackY + trackH),
                        trackColor, trackH * 0.5f);

    draw->AddCircleFilled(ImVec2(knobX, knobY), knobR + 2.0f,
                          IM_COL32(0, 0, 0, 75), 32);
    draw->AddCircleFilled(ImVec2(knobX, knobY), knobR, knob, 32);

    draw->AddText(ImVec2(cursor.x + 13.0f, cursor.y + 6.0f), text, label);
    const char *state = *value ? "ACTIVE" : "OFF";
    ImVec2 stateSize = ImGui::CalcTextSize(state);
    draw->AddText(ImVec2(trackX - stateSize.x - 9.0f, cursor.y + rowHeight - 15.0f),
                  *value ? IM_COL32(66, 229, 145, 255) : sub, state);

    ImGui::PopID();
    return pressed;
}

static void NexusSectionTitle(const char *title, const char *caption)
{
    ImGui::Spacing();
    ImGui::TextColored(ImVec4(0.25f, 0.86f, 0.62f, 1.0f), "%s", title);
    ImGui::SameLine();
    ImGui::TextDisabled("  %s", caption);
    ImGui::Spacing();
}

- (void)drawInMTKView:(MTKView*)view
{
    if (gMainImGuiContext) ImGui::SetCurrentContext(gMainImGuiContext);
    ImGuiIO& io = ImGui::GetIO();

    const std::deque<NexusQueuedTouchEvent> touchEvents = NexusDrainTouchQueue();
    for (const NexusQueuedTouchEvent &event : touchEvents) {
        io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
        io.MousePos = ImVec2(event.point.x, event.point.y);

        switch (event.phase) {
            case UITouchPhaseBegan:
                io.MouseDown[0] = true;
                break;
            case UITouchPhaseMoved:
            case UITouchPhaseStationary:
                // Keep the button pressed while the active touch is moving.
                io.MouseDown[0] = true;
                break;
            case UITouchPhaseEnded:
            case UITouchPhaseCancelled:
                io.MouseDown[0] = false;
                break;
            default:
                break;
        }
    }

    if (touchEvents.empty() && !gUIKitMouseDown && gHasInjectedPoint) {
        io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;
        io.MousePos = ImVec2(gInjectedPoint.x, gInjectedPoint.y);
        io.MouseDown[0] = gInjectedMouseDown;
    }

    io.DisplaySize = ImVec2(view.bounds.size.width, view.bounds.size.height);
    CGFloat framebufferScale = view.window.screen.scale ?: UIScreen.mainScreen.scale;
    io.DisplayFramebufferScale = ImVec2(framebufferScale, framebufferScale);
    io.DeltaTime = 1.0f / float(view.preferredFramesPerSecond ?: 120);

    id<MTLCommandBuffer> commandBuffer = [self.commandQueue commandBuffer];
    MTLRenderPassDescriptor *renderPassDescriptor = view.currentRenderPassDescriptor;
    if (!renderPassDescriptor) {
        [commandBuffer commit];
        return;
    }

    static bool showBoxes = false;
    static bool showTracers = false;
    static bool showHealthBar = false;
    static bool showName = false;
    static bool showWeapon = false;
    static bool teamCheck = true;
    static bool chamsEnabled = false;
    static bool stealthEnabled = false;
    static int chamsMaterialId = 0;

    ImGui_ImplMetal_NewFrame(renderPassDescriptor);
    ImGui::NewFrame();

    if (MenDeal) {
        gHUDMenuWasOpen = true;

        ImGuiWindowFlags flags =
            ImGuiWindowFlags_NoCollapse |
            ImGuiWindowFlags_NoResize |
            ImGuiWindowFlags_NoSavedSettings |
            ImGuiWindowFlags_NoTitleBar |
            ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoScrollWithMouse;

        const float panelW = 318.0f;
        ImGui::SetNextWindowSize(ImVec2(panelW, 0.0f), ImGuiCond_Always);
        ImGui::SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f,
                                       io.DisplaySize.y * 0.5f),
                                ImGuiCond_FirstUseEver,
                                ImVec2(0.5f, 0.5f));

        ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.025f, 0.035f, 0.055f, 0.97f));
        ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 18.0f);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(13.0f, 13.0f));

        if (ImGui::Begin("##NEXUS_FUTURISTIC", &MenDeal, flags)) {
            ImDrawList *draw = ImGui::GetWindowDrawList();
            ImVec2 pos = ImGui::GetWindowPos();
            ImVec2 size = ImGui::GetWindowSize();

            draw->AddRectFilled(ImVec2(pos.x, pos.y),
                                ImVec2(pos.x + size.x, pos.y + 4.0f),
                                IM_COL32(50, 232, 151, 255), 18.0f);

            ImGui::BeginChild("##TOP", ImVec2(0, 62), false,
                              ImGuiWindowFlags_NoScrollbar);
            ImGui::TextColored(ImVec4(0.28f, 0.95f, 0.66f, 1.0f), "NEXUS");
            ImGui::SameLine();
            ImGui::TextDisabled("  FUTURE HUD  /  1.1");
            ImGui::TextDisabled("External interface • touch routed");
            ImGui::EndChild();

            ImGui::Separator();
            ImGui::Spacing();

            if (ImGui::BeginTabBar("##NEXUS_TABS",
                                   ImGuiTabBarFlags_FittingPolicyScroll)) {
                if (ImGui::BeginTabItem("COMBAT")) {
                    NexusSectionTitle("VISUALS", "PLAYER OVERLAY");

                    NexusSwitch("boxes", "Player boxes", &showBoxes);
                    ImGui::Spacing();
                    NexusSwitch("tracers", "Tracers", &showTracers);
                    ImGui::Spacing();
                    NexusSwitch("health", "Health bars", &showHealthBar);
                    ImGui::Spacing();
                    NexusSwitch("names", "Player names", &showName);
                    ImGui::Spacing();
                    NexusSwitch("weapon", "Weapon labels", &showWeapon);
                    ImGui::Spacing();
                    NexusSwitch("team", "Team check", &teamCheck);

                    ImGui::Spacing();
                    NexusSectionTitle("MATERIAL", "RENDER");

                    NexusSwitch("chams", "Chams", &chamsEnabled);
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("SYSTEM")) {
                    NexusSectionTitle("ENGINE", "EXISTING BACKEND");

                    if (ImGui::Button("RUN BACKEND TEST", ImVec2(-1.0f, 44.0f))) {
                        MenuFuncaoTeste();
                    }

                    if (TesteMensagemVisivel()) {
                        ImGui::Spacing();
                        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.04f, 0.065f, 0.09f, 1.0f));
                        ImGui::BeginChild("##RESULT", ImVec2(0, 52), true,
                                          ImGuiWindowFlags_NoScrollbar);
                        ImGui::TextWrapped("%s", TesteMensagem());
                        ImGui::EndChild();
                        ImGui::PopStyleColor();
                    } else {
                        ImGui::TextDisabled("Backend path is preserved; use the test only when needed.");
                    }

                    ImGui::Spacing();
                    NexusSectionTitle("PRIVACY", "EXISTING BEHAVIOR");
                    NexusSwitch("stealth", "Secure view / stealth", &stealthEnabled);
                    ImGui::EndTabItem();
                }

                if (ImGui::BeginTabItem("STATUS")) {
                    NexusSectionTitle("ROUTING", "INPUT DIAGNOSTICS");

                    ImGui::TextColored(ImVec4(0.28f, 0.95f, 0.66f, 1.0f),
                                       "● TOUCH WINDOW ONLINE");
                    ImGui::Spacing();
                    ImGui::TextDisabled("Interactive surface follows the rendered panel.");
                    ImGui::TextDisabled("Transparent screen regions remain pass-through.");
                    ImGui::Spacing();
                    ImGui::TextDisabled("Coordinates: %.0f × %.0f",
                                        io.MousePos.x, io.MousePos.y);

                    ImGui::Spacing();
                    ImGui::Separator();
                    ImGui::TextDisabled("NEXUS / iOS / LGL-inspired controls");
                    ImGui::EndTabItem();
                }

                ImGui::EndTabBar();
            }

            ImGui::Spacing();
            ImGui::TextDisabled("ENGINE ONLINE  •  UI SEPARATED FROM BACKEND");
        }
        ImGui::End();

        ImGui::PopStyleVar(2);
        ImGui::PopStyleColor();

        ImVec2 wpos = ImGui::GetWindowPos();
        ImVec2 wsize = ImGui::GetWindowSize();
        gMenuWindowRect = CGRectMake(wpos.x, wpos.y, wsize.x, wsize.y);
        NexusPublishMenuRect(gMenuWindowRect);

        if (gImGuiHostView.window && !CGRectIsEmpty(gMenuWindowRect)) {
            CGRect screenRect = [gImGuiHostView convertRect:gMenuWindowRect toView:nil];
            HUDSetTouchWindowFrame(screenRect, YES, NO);
        }

        [ESPImGuiView setChamsEnabled:chamsEnabled];
        [ESPImGuiView setChamsMaterialId:chamsMaterialId];
        [ESPImGuiView setStealthEnabled:stealthEnabled];

        static bool prevStealth = false;
        if (stealthEnabled != prevStealth) {
            prevStealth = stealthEnabled;
            HUDSetStealthEnabled(stealthEnabled);
        }

        [ESPImGuiView setESPEnabled:(showBoxes || showHealthBar || showName ||
                                     showWeapon || showTracers || chamsEnabled)];
        [ESPImGuiView setTracersEnabled:showTracers];
        [ESPImGuiView setShowLines:showTracers];
        [ESPImGuiView setShowBox:showBoxes];
        [ESPImGuiView setShowHealthBar:showHealthBar];
        [ESPImGuiView setShowName:showName];
        [ESPImGuiView setShowWeapon:showWeapon];
        [ESPImGuiView setTeamCheck:teamCheck];

        HUDSetESPEnabled((showBoxes || showHealthBar || showName ||
                          showWeapon || showTracers || chamsEnabled));
        HUDSetTracersEnabled(showTracers);
    } else {
        gMenuWindowRect = CGRectZero;
        NexusPublishMenuRect(CGRectZero);
        HUDSetTouchWindowFrame(CGRectZero, NO, YES);

        ImDrawList *fg = ImGui::GetForegroundDrawList();
        ImVec2 orb(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f);
        fg->AddCircleFilled(orb, 25.0f, IM_COL32(7, 14, 24, 245), 48);
        fg->AddCircle(orb, 25.0f, IM_COL32(50, 232, 151, 235), 48, 2.0f);
        fg->AddCircleFilled(orb, 15.0f, IM_COL32(24, 128, 88, 220), 48);
        ImVec2 textSize = ImGui::CalcTextSize("N");
        fg->AddText(ImVec2(orb.x - textSize.x * 0.5f,
                           orb.y - textSize.y * 0.5f - 1.0f),
                    IM_COL32(240, 255, 248, 255), "N");
        if (gHUDMenuWasOpen) {
            HUDHideMenu();
            gHUDMenuWasOpen = false;
        }
    }

    ImGui::Render();
    ImDrawData *draw_data = ImGui::GetDrawData();

    id<MTLRenderCommandEncoder> renderEncoder =
        [commandBuffer renderCommandEncoderWithDescriptor:renderPassDescriptor];
    [renderEncoder pushDebugGroup:@"NEXUS FUTURISTIC UI"];
    ImGui_ImplMetal_RenderDrawData(draw_data, commandBuffer, renderEncoder);
    [renderEncoder popDebugGroup];
    [renderEncoder endEncoding];

    [commandBuffer presentDrawable:view.currentDrawable];
    [commandBuffer commit];
}

- (void)mtkView:(MTKView*)view drawableSizeWillChange:(CGSize)size
{
    
}

@end
