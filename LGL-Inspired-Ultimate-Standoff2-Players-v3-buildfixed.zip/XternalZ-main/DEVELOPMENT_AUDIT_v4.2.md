# LGL Inspired v4.2 — development audit

## Objective

Stabilize the HUD input pipeline so the Metal/ImGui menu receives touches only
inside its interactive rectangle while touches outside remain pass-through.

## Root-cause model

The source contained a fullscreen visual window, a second input window, a proxy
view, and a global HID fallback. The interactive window was configured with
`_usesWindowServerHitTesting = NO`, the fallback rediscovered that window through
`UIApplication.windows`, and the render loop scheduled an update to the window
frame on the main queue once per frame. These three details made event ownership
fragile.

A second, independent timing defect existed: a very short tap could produce
`touchesBegan` and `touchesEnded` between two ImGui frames. Because ImGui 1.83 in
this tree consumes `io.MouseDown` once per frame, the click transition could be
lost entirely.

## v4.2 design

1. `HUDMainWindow` remains visual-only and returns no hit target.
2. `HUDTouchWindow` is the only interactive window and uses window-server hit
   testing.
3. `HUDTouchProxyView` owns the UIKit touch lifecycle.
4. The global HID path remains a guarded fallback only. It reads the exact live
   hosted input-window geometry through a C bridge instead of enumerating
   `UIApplication.windows`.
5. Screen coordinates are converted once into the ImGui host view.
6. The touch window geometry is updated synchronously on the main thread and only
   when the rectangle/state actually changes.
7. The ImGui backend keeps a one-frame press latch so very fast taps create a
   deterministic down/up transition.
8. The 3-finger gesture installer ignores both the visual window and the input
   window, reducing gesture arbitration in the touch surface.

## Communication graph

```
physical touch
    -> UIKit hosted input window
    -> HUDTouchProxyView
    -> HUDInjectImGuiTouchAtScreenPoint()
    -> ImGuiIO.MousePos / MouseDown
    -> ImGui frame
    -> Button / Checkbox / drag header

fallback path:
physical HID event
    -> AXEventRepresentation
    -> exact HUDTouchWindow screen rect bridge
    -> inside-rect gate
    -> same HUDInjectImGuiTouchAtScreenPoint()
```

## Validation performed in the workspace

- Whole archive inventory: 86 files.
- Production source graph cross-checked against Makefile.
- Touch symbols cross-referenced between Objective-C++ translation units.
- ImGui version/API checked; this tree is ImGui 1.83 WIP, so the implementation
  intentionally keeps the legacy `io.MousePos` / `io.MouseDown` interface.
- No `ImVec2 + ImVec2` dependency reintroduced.
- Legacy synthetic KIF/TSEventFetcher sources remain excluded from the production
  target.
- Theos package staging contract remains unchanged.

## Remaining device-level validation

A real arm64 iOS build and on-device test still require macOS/Xcode/Theos. The
workspace cannot truthfully claim an arm64 compile was executed here.

### Regression hardening pass

A cancelled touch is treated differently from a completed tap: any pending press latch is discarded immediately, so an interruption cannot synthesize a click. The Metal error path also commits the command buffer only once, and UIKit-to-screen conversion now uses the view's coordinate conversion API directly.

## Release test matrix

| Case | Expected result | Verification mode |
|---|---|---|
| Tap button | ImGui registers click | Device UI test |
| Toggle checkbox | Value changes and stays changed | Device UI test |
| Drag header | Panel follows finger | Device UI test |
| Tap outside panel | Underlying app receives touch | Device UI test |
| Fast tap | One click, never zero/missed | Device UI test |
| Touch cancellation | No synthetic click | Device UI test |
| Hidden/minimized hotspot | Hotspot alone receives touch | Device UI test |
| Restore from hotspot | Full menu becomes interactive | Device UI test |
| Orientation change | Input rectangle follows panel | Device UI test |
| Background/foreground | Touch state does not remain stuck | Device UI test |
