#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p "$ROOT/.theos/obj/debug"
test -d "$ROOT/.theos"
test -d "$ROOT/.theos/obj/debug"
mkdir -p "$ROOT/.theos/obj/debug/Excalibur.app"
test -d "$ROOT/.theos/obj/debug/Excalibur.app"

# Keep the same invariant as the Makefile: both non-arch and
# architecture-specific object paths must exist before Theos starts
# generating .stamp files and compiler object files.
SOURCE_DIRS=(
  functions
  imgui
  imgui/IMGUI
  menu
  objc_base
  overlay
  tasks
  unity
)

ARCHS_VALUE="$(sed -n 's/^ARCHS[[:space:]]*[:?+]*=[[:space:]]*//p' "$ROOT/Makefile" | head -n 1)"
test -n "$ARCHS_VALUE"

for source_dir in "${SOURCE_DIRS[@]}"; do
  mkdir -p "$ROOT/.theos/obj/debug/$source_dir"
  test -d "$ROOT/.theos/obj/debug/$source_dir"
done

for arch in $ARCHS_VALUE; do
  mkdir -p "$ROOT/.theos/obj/debug/$arch"
  test -d "$ROOT/.theos/obj/debug/$arch"

  for source_dir in "${SOURCE_DIRS[@]}"; do
    mkdir -p "$ROOT/.theos/obj/debug/$arch/$source_dir"
    test -d "$ROOT/.theos/obj/debug/$arch/$source_dir"
  done

  mkdir -p "$ROOT/.theos/obj/debug/$arch/Excalibur.app"
  test -d "$ROOT/.theos/obj/debug/$arch/Excalibur.app"
done
test -f "$ROOT/Makefile"
echo "PASS: Theos build directory bootstrapped"
