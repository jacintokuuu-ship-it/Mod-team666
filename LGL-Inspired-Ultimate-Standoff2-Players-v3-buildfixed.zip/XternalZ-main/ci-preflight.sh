#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p "$ROOT/.theos"
test -d "$ROOT/.theos"
test -f "$ROOT/Makefile"
echo "PASS: Theos build directory bootstrapped"
