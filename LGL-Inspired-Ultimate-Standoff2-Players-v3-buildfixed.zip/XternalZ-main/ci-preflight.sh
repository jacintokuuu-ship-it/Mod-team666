#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p "$ROOT/.theos/obj/debug"
test -d "$ROOT/.theos"
test -d "$ROOT/.theos/obj/debug"

# Keep the same invariant as the Makefile: every declared source-directory
# object path must exist before Theos starts generating .stamp files.
for source_dir in functions imgui/IMGUI objc_base overlay tasks unity menu; do
  mkdir -p "$ROOT/.theos/obj/debug/$source_dir"
  test -d "$ROOT/.theos/obj/debug/$source_dir"
done
test -f "$ROOT/Makefile"
echo "PASS: Theos build directory bootstrapped"
