#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
mkdir -p "$ROOT/.theos"
test -d "$ROOT/.theos"

ensure_dir() {
  local path="$1"
  if [ -e "$path" ] && [ ! -d "$path" ]; then
    rm -f "$path"
  fi
  mkdir -p "$path"
  test -d "$path"
}

ensure_dir "$ROOT/.theos/obj/debug"
ensure_dir "$ROOT/.theos/obj/debug/arm64"

# Keep the same invariant as the Makefile: every declared source-directory
# object path and both app object roots must exist before Theos starts
# generating .stamp files.
for source_dir in functions imgui/IMGUI objc_base overlay tasks unity menu; do
  ensure_dir "$ROOT/.theos/obj/debug/$source_dir"
  ensure_dir "$ROOT/.theos/obj/debug/arm64/$source_dir"
done
ensure_dir "$ROOT/.theos/obj/debug/Excalibur.app"
ensure_dir "$ROOT/.theos/obj/debug/arm64/Excalibur.app"
test -f "$ROOT/Makefile"
echo "PASS: Theos build directory bootstrapped"
