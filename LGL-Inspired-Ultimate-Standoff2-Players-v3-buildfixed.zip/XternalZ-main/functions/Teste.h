#pragma once

#ifdef __cplusplus
extern "C" {
#endif

// Scans the currently running Standoff 2 process and shows the
// detected room/player count using the same memory path as the existing ESP.
void MenuFuncaoTeste(void);

const char *TesteMensagem(void);
bool TesteMensagemVisivel(void);

#ifdef __cplusplus
}
#endif
