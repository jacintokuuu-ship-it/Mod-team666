#import "Teste.h"
#import "Offsets.h"
// This feature is intentionally read-only: it reads the game process and only
// renders the resulting count in the HUD. No game state is modified.
#import "../tasks/pid.h"

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <QuartzCore/QuartzCore.h>
#include <cstdio>
#include <cstdint>
#include <cstring>

#ifndef BYTE_SIZE
#define BYTE_SIZE 8ULL
#endif

static char gTesteMessage[192] = "";
static CFTimeInterval gTesteMessageUntil = 0.0;

static bool ValidPtr(mach_vm_address_t p) {
    return p >= 0x1000000;
}

static int ReadPlayerTeam(mach_vm_address_t player, task_t task) {
    if (!ValidPtr(player)) return -1;

    mach_vm_address_t photon =
        Read<mach_vm_address_t>(player + SO2Offsets::PlayerPhotonOffset, task);
    if (!ValidPtr(photon)) return -1;

    mach_vm_address_t props =
        Read<mach_vm_address_t>(photon + SO2Offsets::PhotonCustomPropertiesOffset, task);
    if (!ValidPtr(props)) return -1;

    int size = Read<int>(props + SO2Offsets::PropertiesSizeOffset, task);
    if (size <= 0 || size > 64) return -1;

    mach_vm_address_t entries =
        Read<mach_vm_address_t>(props + SO2Offsets::PropertiesEntriesOffset, task);
    if (!ValidPtr(entries)) return -1;

    for (int j = 0; j < size && j < 64; ++j) {
        const uintptr_t entry = SO2Offsets::PropertyKeyStart +
                                SO2Offsets::PropertyStride * (uintptr_t)j;

        mach_vm_address_t key =
            Read<mach_vm_address_t>(entries + entry, task);
        if (!ValidPtr(key)) continue;

        int keyLen =
            Read<int>(key + SO2Offsets::PropertyKeyLengthOffset, task);

        if (keyLen != 4) continue;

        uint64_t keyChars =
            Read<uint64_t>(key + SO2Offsets::PropertyKeyStringOffset, task);

        // UTF-16 little-endian "team".
        if (keyChars != 0x006D006100650074ULL) continue;

        mach_vm_address_t value =
            Read<mach_vm_address_t>(
                entries + SO2Offsets::PropertyValueObjectOffset +
                SO2Offsets::PropertyStride * (uintptr_t)j, task);

        if (!ValidPtr(value)) continue;
        return Read<int>(value + SO2Offsets::PropertyIntValueOffset, task);
    }

    return -1;
}

static bool ScanStandoff2(int *outPlayers, int *outEnemies) {
    if (!outPlayers || !outEnemies) return false;

    *outPlayers = 0;
    *outEnemies = -1;

    pid_t pid = get_pid_by_name("Standoff2");
    if (pid <= 0) return false;

    task_t task = get_task_by_pid(pid);
    if (!task) return false;

    mach_vm_address_t base = get_image_base_address(task, "UnityFramework");
    if (!base) return false;

    mach_vm_address_t typeInfo =
        base + SO2Offsets::PlayerManagerTypeInfoRVA;

    mach_vm_address_t parentTypeInfo =
        Read<mach_vm_address_t>(
            typeInfo + SO2Offsets::TypeInfoParentOffset, task);
    if (!ValidPtr(parentTypeInfo)) return false;

    mach_vm_address_t staticFields =
        Read<mach_vm_address_t>(
            parentTypeInfo + SO2Offsets::StaticFieldsOffsetPrimary, task);

    if (!ValidPtr(staticFields)) {
        staticFields =
            Read<mach_vm_address_t>(
                parentTypeInfo + SO2Offsets::StaticFieldsOffsetFallback, task);
    }
    if (!ValidPtr(staticFields)) return false;

    mach_vm_address_t playerManager =
        Read<mach_vm_address_t>(
            staticFields + SO2Offsets::PlayerManagerStaticFieldOffset, task);
    if (!ValidPtr(playerManager)) return false;

    mach_vm_address_t playersDict =
        Read<mach_vm_address_t>(
            playerManager + SO2Offsets::PlayersDictionaryOffset, task);
    if (!ValidPtr(playersDict)) return false;

    int c20 = Read<int>(
        playersDict + SO2Offsets::DictionaryCountA, task);
    int c40 = Read<int>(
        playersDict + SO2Offsets::DictionaryCountB, task);
    int c18 = Read<int>(
        playersDict + SO2Offsets::DictionaryCountC, task);

    int playersCount = 0;
    if (c20 > 0 && c20 <= 32) playersCount = c20;
    else if (c40 > 0 && c40 <= 32) playersCount = c40;
    else if (c18 > 0 && c18 <= 32) playersCount = c18;

    if (playersCount <= 0 || playersCount > 32) return false;
    *outPlayers = playersCount;

    mach_vm_address_t localPlayer =
        Read<mach_vm_address_t>(
            playerManager + SO2Offsets::LocalPlayerOffsetPrimary, task);

    if (!ValidPtr(localPlayer)) {
        localPlayer =
            Read<mach_vm_address_t>(
                playerManager + SO2Offsets::LocalPlayerOffsetFallback, task);
    }

    int localTeam = -1;
    if (ValidPtr(localPlayer)) {
        localTeam = ReadPlayerTeam(localPlayer, task);
    }

    // Count other live dictionary entries. If the local team is available,
    // count only players with a different known team as enemies.
    mach_vm_address_t entries =
        Read<mach_vm_address_t>(
            playersDict + SO2Offsets::DictionaryEntriesOffset, task);
    if (!ValidPtr(entries)) return true;

    int capacity = Read<int>(
        entries + 0x18, task);
    if (capacity < 0) capacity = 0;
    if (capacity > 100) capacity = 100;

    int enemies = 0;
    bool canDetermineEnemies = (localTeam >= 0);

    for (int i = 0; i < capacity; ++i) {
        mach_vm_address_t player =
            Read<mach_vm_address_t>(
                entries + SO2Offsets::DictionaryEntryStart +
                SO2Offsets::DictionaryEntryStride * (uintptr_t)i +
                SO2Offsets::DictionaryEntryValueOffset, task);

        if (!ValidPtr(player) || player == localPlayer) continue;

        int team = ReadPlayerTeam(player, task);

        if (localTeam >= 0 && team >= 0) {
            if (team != localTeam) enemies++;
        } else {
            canDetermineEnemies = false;
        }
    }

    *outEnemies = canDetermineEnemies ? enemies : -1;
    return true;
}

extern "C" void TesteDefinirMensagem(const char *message) {
    if (!message) message = "";
    std::snprintf(gTesteMessage, sizeof(gTesteMessage), "%s", message);
    gTesteMessageUntil = CACurrentMediaTime() + 4.0;
}

extern "C" void MenuFuncaoTeste(void) {
    int players = 0;
    int enemies = -1;

    if (!ScanStandoff2(&players, &enemies)) {
        TesteDefinirMensagem("Standoff 2: partida/estrutura ainda nao encontrada");
        return;
    }

    if (enemies >= 0) {
        std::snprintf(
            gTesteMessage, sizeof(gTesteMessage),
            "Jogadores: %d  |  Inimigos: %d", players, enemies);
    } else {
        std::snprintf(
            gTesteMessage, sizeof(gTesteMessage),
            "Jogadores: %d  |  Inimigos: ?", players);
    }

    gTesteMessageUntil = CACurrentMediaTime() + 4.0;
}

extern "C" const char *TesteMensagem(void) {
    return gTesteMessage;
}

extern "C" bool TesteMensagemVisivel(void) {
    return gTesteMessage[0] != '\0' &&
           CACurrentMediaTime() < gTesteMessageUntil;
}
