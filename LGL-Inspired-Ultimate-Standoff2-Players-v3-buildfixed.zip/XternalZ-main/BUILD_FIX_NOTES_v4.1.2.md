# v4.1.2 — ImGui compile fix

## Root cause
`ImGui::GetWindowPos()` and `ImGuiIO::MouseDelta` both return `ImVec2`. Dear ImGui does not enable the public `ImVec2` arithmetic operators by default, so `operator+` in `imgui/ImGuiDrawView.mm` failed under the project's compiler configuration.

## Fix
The custom menu source now performs the addition explicitly through `x`/`y` components. This avoids depending on `IMGUI_DEFINE_MATH_OPERATORS` in an application translation unit.

## Regression guard
`verify_build_contract.sh` now rejects the previous `ImVec2 + ImVec2` expression so the same build failure cannot silently return.

## Source-graph hardening
The production Makefile now lists the four required Dear ImGui core translation units explicitly instead of using a wildcard. `imgui_demo.cpp` is intentionally excluded because the application does not call the demo API.

## NEXUS v5.1 build correction

- Fixed the custom-source `ImClamp` compilation error by using `std::clamp` from `<algorithm>`.
- Kept Dear ImGui 1.83 private headers out of application code.
- Added explicit `<atomic>`/queue support for safe publication of the menu rectangle and touch samples.


## Deterministic Theos pre-flight
The Makefile now creates `.theos/obj/debug` and every production source
subdirectory with `$(shell mkdir -p ...)` before including Theos' common build
rules. Source validation no longer uses `$(wildcard ...)`; each declared file
is checked with a literal `test -f`.
