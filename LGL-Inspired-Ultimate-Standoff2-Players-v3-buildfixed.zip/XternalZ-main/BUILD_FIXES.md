# PROJETINpai build fixes

## Fixed
1. `ld: framework 'BackBoardServices' not found`
   - Removed `Excalibur_PRIVATE_FRAMEWORKS` from the Makefile.
   - The CI build uses Apple's public iOS 15.6 SDK, which does not ship the
     private framework bundle.

2. Future private-symbol linker failures
   - SpringBoard and legacy HUD initialization symbols are now looked up with
     `dlsym(RTLD_DEFAULT, ...)` instead of being hard-linked.

3. UIKit private selectors
   - `_accessibilityInit` and `__completeAndRunAsPlugin` remain local Objective-C
     declarations so the compiler accepts the selectors.
   - The plugin-completion call is guarded with `respondsToSelector:`.

## Intentionally preserved
- Existing source tree and feature files.
- arm64 / iOS 15 target.
- UIKit touch pass-through architecture.
- Existing Excalibur executable target (the display name is PROJETINpai).

## CI note
The definitive test is the GitHub Actions build. If the linker reports another
missing symbol after this change, that means another private framework dependency
is still being hard-linked; it should be converted to the same lazy-resolution
pattern rather than adding an unavailable SDK framework.
