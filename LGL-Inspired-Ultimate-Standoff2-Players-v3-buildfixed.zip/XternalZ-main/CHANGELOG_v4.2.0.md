# v4.2.1 — Touch-stable buildfix

## Input architecture

- `HUDTouchWindow` is now the dedicated interactive window.
- `HUDMainWindow` remains render-only and continues to pass through touches.
- The touch window participates in window-server hit testing and is physically resized to the active ImGui panel/hotspot.
- The HID fallback reads the live touch-window geometry through a direct bridge instead of enumerating `UIApplication.windows` by class name.

## ImGui input reliability

- UIKit touch events are converted from screen space to the ImGui host view exactly once.
- A one-frame press latch prevents fast taps from disappearing between render callbacks.
- Cancelled touches clear the latch and cannot synthesize a click.
- The project keeps the legacy `MousePos`/`MouseDown` API because the vendored Dear ImGui version is 1.83 WIP and does not contain the newer event helpers.

## Runtime/build hygiene

- Touch-window geometry is applied immediately on the main thread and skipped when unchanged, instead of queuing a main-thread block on every render frame.
- ImGui-to-HUD bridge setters execute immediately when already on the main thread and dispatch only when needed.
- Removed the duplicate Metal command-buffer commit in the no-render-pass path.
- Theos production source inventory remains explicit; legacy synthetic touch sources are excluded from the release graph.
- `REPOSITORY_BUILD_CONTRACT.md` now documents the actual checked-in GitHub Actions workflow rather than an obsolete ZIP extraction workflow.

## Validation performed in this environment

- Static build contract: PASS.
- Info/entitlement plist parse: PASS.
- Dear ImGui host C++ syntax check: PASS.
- Theos Makefile dry-run with a minimal makefile stub: PASS.
- Production source inventory: 15 files, all present.

## Device/build limitation

A real arm64 iOS compile/package was not executed in this Linux runtime because Xcode and the iOS SDK are not available here. The checked-in CI workflow performs the authoritative macOS/Theos build using the iOS 15.6 SDK.
