# Build fix for Build LGL-Inspired #81

Fixed the `menu/menu.m:266:1: error: duplicate declaration of method 'hitTest:withEvent:'` error.

The file now contains exactly one `MenuView` `hitTest:withEvent:` implementation. The retained implementation is the pass-through version that only allows interaction inside `HUDMenuInteractiveRect()` and delegates to the ImGui view.

No hooks, memory/task/unity/functions source files were removed or rewritten as part of this fix.
