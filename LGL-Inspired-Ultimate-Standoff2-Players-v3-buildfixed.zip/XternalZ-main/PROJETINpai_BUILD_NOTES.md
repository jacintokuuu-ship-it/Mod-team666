# PROJETINpai — iOS 15 touch rebuild

Base: LGL-Inspired-Ultimate-Standoff2-Players-v3-buildfixed

## Changes
- Fixed the iOS 15 SDK compile errors in `objc_base/HUDApp.mm` by declaring the two
  private UIApplication selectors locally.
- Kept the existing UIKit-only touch architecture: no `TSEventFetcher.mm` is added
  to the Makefile and no synthetic UITouch replay is used by the HUD.
- Kept the HUD window non-key and frontmost-monitor based visibility behavior.
- Kept the three-finger global recognizer disabled; the HUD does not install gestures
  into other application windows.
- Removed the duplicate `MenuView hitTest:` implementation.
- Rebranded visible bundle metadata/package output to `PROJETINpai`.
- Target remains iOS 15.0+ / arm64 and the existing game/process integration is retained.

## Important
This archive is source-only. It has not been compiled here because an Apple/Xcode/Theos
iOS SDK build environment is not available in this runtime. The GitHub Actions build
should be used to produce the installable package and to catch any environment-specific
compiler/linker issues.
