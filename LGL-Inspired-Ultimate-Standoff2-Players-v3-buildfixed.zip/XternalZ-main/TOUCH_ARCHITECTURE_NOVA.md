# XternalZ NOVA — touch architecture

## Design
- One overlay window.
- UIKit hit-testing only.
- The menu surface is visually fullscreen but only the actual ImGui window rectangle is interactive.
- ESP/debug layers are non-interactive.
- No synthetic UITouch objects.
- No AXEventRepresentation replay.
- No `_enqueueHIDEvent` interception.
- No gesture recognizers are installed on other applications' windows.
- HUD visibility follows the frontmost Standoff 2 bundle (`com.axlebolt.standoff2`).
- HUD window is non-key and is hidden when the HUD app resigns active/backgrounds.

## Expected routing
| Area | Receiver |
|---|---|
| Inside NOVA menu | NOVA |
| Outside menu | Standoff 2 / underlying app |
| ESP | Underlying app |
| Home/app switcher | System |
| Leaving Standoff 2 | HUD hidden |
