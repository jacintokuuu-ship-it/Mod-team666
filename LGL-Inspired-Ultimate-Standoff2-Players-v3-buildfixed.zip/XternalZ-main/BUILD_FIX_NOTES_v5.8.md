v5.8 BUILD FIX — non-architecture Excalibur.app bootstrap

The CI log showed that the architecture-specific object tree now exists, but
Theos still failed when creating:
  .theos/obj/debug/Excalibur.app/Excalibur.<hash>.unsigned

In v5.7 the Makefile created only the architecture-specific
`.theos/obj/debug/arm64/Excalibur.app` directory. The application-variables
stage also uses the non-architecture `.theos/obj/debug/Excalibur.app` path.

v5.8 therefore bootstraps BOTH:
  .theos/obj/debug/Excalibur.app/
  .theos/obj/debug/<arch>/Excalibur.app/

The same invariant is checked by ci-preflight.sh. No production source file
was changed.
