#import <cstddef>
#import <cstring>
#import <cstdlib>
#import <dlfcn.h>
#import <spawn.h>
#import <unistd.h>
#import <sys/param.h>
#import <sys/sysctl.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <os/log.h>
#import <signal.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


#pragma mark -

static NSString *_cachesDirectoryPath = nil;
static NSString *_hudPIDFilePath = nil;
static NSString *GetPIDFilePath(void)
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _cachesDirectoryPath = 
        [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
        _hudPIDFilePath = [_cachesDirectoryPath stringByAppendingPathComponent:@"hud.pid"];
    });
    return _hudPIDFilePath;
}


#pragma mark -

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT, "launched argc %{public}d, argv[1] %{public}s", argc, argc > 1 ? argv[1] : "NULL");
#endif

        if (argc <= 1)
            return UIApplicationMain(argc, argv, @"MainApplication", @"MainApplicationDelegate");
        
        if (strcmp(argv[1], "-hud") == 0)
        {
            NSString *pidString = [NSString stringWithFormat:@"%d", getpid()];
            [pidString writeToFile:GetPIDFilePath()
                        atomically:YES
                          encoding:NSUTF8StringEncoding
                             error:nil];
            
            [UIScreen initialize];
            CFRunLoopGetCurrent();

            // Private bootstrap entry points are resolved at runtime. This keeps
            // HUDApp.mm compilable with the public SDK headers used by Theos.
            typedef void (*VoidFn)(void);
            typedef void (*InstantiateFn)(Class);
            typedef void (*PushRunLoopModeFn)(CFStringRef);

            auto resolveVoid = [](const char *name) -> VoidFn {
                return reinterpret_cast<VoidFn>(dlsym(RTLD_DEFAULT, name));
            };

            VoidFn gsInitialize = resolveVoid("GSInitialize");
            VoidFn bksDisplayServicesStart = resolveVoid("BKSDisplayServicesStart");
            VoidFn uiApplicationInitialize = resolveVoid("UIApplicationInitialize");

            if (gsInitialize) gsInitialize();
            if (bksDisplayServicesStart) bksDisplayServicesStart();
            if (uiApplicationInitialize) uiApplicationInitialize();

            InstantiateFn instantiateSingleton =
                reinterpret_cast<InstantiateFn>(
                    dlsym(RTLD_DEFAULT, "UIApplicationInstantiateSingleton"));
            if (instantiateSingleton) {
                instantiateSingleton(objc_getClass("HUDMainApplication"));
            }

            static id<UIApplicationDelegate> appDelegate =
                [[objc_getClass("HUDMainApplicationDelegate") alloc] init];
            UIApplication *application = UIApplication.sharedApplication;
            [application setDelegate:appDelegate];

            SEL accessibilityInitSEL = sel_registerName("_accessibilityInit");
            if ([application respondsToSelector:accessibilityInitSEL]) {
                ((void (*)(id, SEL))objc_msgSend)(application, accessibilityInitSEL);
            }

            [NSRunLoop currentRunLoop];

            if (@available(iOS 15.0, *)) {
                typedef void (*GSEventInitializeFn)(uint32_t);
                GSEventInitializeFn gsEventInitialize =
                    reinterpret_cast<GSEventInitializeFn>(
                        dlsym(RTLD_DEFAULT, "GSEventInitialize"));
                PushRunLoopModeFn gsEventPushRunLoopMode =
                    reinterpret_cast<PushRunLoopModeFn>(
                        dlsym(RTLD_DEFAULT, "GSEventPushRunLoopMode"));

                if (gsEventInitialize) gsEventInitialize(0);
                if (gsEventPushRunLoopMode) {
                    gsEventPushRunLoopMode(kCFRunLoopDefaultMode);
                }
            }

            SEL completeAndRunSEL = sel_registerName("__completeAndRunAsPlugin");
            if ([application respondsToSelector:completeAndRunSEL]) {
                ((void (*)(id, SEL))objc_msgSend)(application, completeAndRunSEL);
            }

            CFRunLoopRun();
            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-exit") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                kill(pid, SIGKILL);
                unlink(GetPIDFilePath().UTF8String);
            }

            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-check") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                int killed = kill(pid, 0);
                return (killed == 0 ? EXIT_FAILURE : EXIT_SUCCESS);
            }
            else return EXIT_SUCCESS;  // No PID file, so HUD is not running
        }
    }
}