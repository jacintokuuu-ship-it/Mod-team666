#import <cstddef>
#import <cstring>
#import <cstdlib>
#import <dlfcn.h>
#import <spawn.h>
#import <unistd.h>
#import <sys/param.h>
#import <sys/sysctl.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

// These are private UIKit entry points used only by the standalone HUD process.
// The declarations are intentionally local so the iOS 15 SDK compiler knows the
// selectors exist; the implementation remains provided by UIKit at runtime.
@interface UIApplication (PROJETINpaiPrivate)
- (void)_accessibilityInit;
- (void)__completeAndRunAsPlugin;
@end


#pragma mark -

typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDNotification *IOHIDNotificationRef;
typedef struct __IOHIDService *IOHIDServiceRef;
typedef struct __GSEvent *GSEventRef;

// Private framework entry points are deliberately NOT linked against the SDK.
// Resolve them lazily so the project can link with the public iOS 15 SDK used by
// CI. Missing optional symbols are treated as unavailable at runtime.
typedef void (*PROJETINpaiVoidFn)(void);
typedef void (*PROJETINpaiUIApplicationInstantiateFn)(id);
typedef void (*PROJETINpaiGSEventInitFn)(Boolean);
typedef void (*PROJETINpaiGSEventRunLoopFn)(CFStringRef);
typedef void (*PROJETINpaiGSEventCallbackFn)(void (*)(GSEventRef));
typedef void *(*PROJETINpaiBKSHIDRegisterFn)(void (*)(void *, void *, IOHIDServiceRef, IOHIDEventRef));

static void *PROJETINpaiResolve(const char *name)
{
    return dlsym(RTLD_DEFAULT, name);
}

static void PROJETINpaiCallVoid(const char *name)
{
    PROJETINpaiVoidFn fn = (PROJETINpaiVoidFn)PROJETINpaiResolve(name);
    if (fn) fn();
}


#pragma mark -

// Touch architecture: UIKit-only. No synthetic UITouch objects, no AX/HID replay,
// and no _enqueueHIDEvent interception. This keeps the HUD transparent outside
// the menu hit region and prevents it from owning touches belonging to other apps.

#pragma mark -

static NSString *_cachesDirectoryPath = nil;
static NSString *_hudPIDFilePath = nil;
static NSString *GetPIDFilePath(void)
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _cachesDirectoryPath = 
        [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
        _hudPIDFilePath = [_cachesDirectoryPath stringByAppendingPathComponent:@"hud.pid"];
    });
    return _hudPIDFilePath;
}


#pragma mark -

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT, "launched argc %{public}d, argv[1] %{public}s", argc, argc > 1 ? argv[1] : "NULL");
#endif

        if (argc <= 1)
            return UIApplicationMain(argc, argv, @"MainApplication", @"MainApplicationDelegate");
        
        if (strcmp(argv[1], "-hud") == 0)
        {
            NSString *pidString = [NSString stringWithFormat:@"%d", getpid()];
            [pidString writeToFile:GetPIDFilePath()
                        atomically:YES
                          encoding:NSUTF8StringEncoding
                             error:nil];
            
            [UIScreen initialize];
            CFRunLoopGetCurrent();

            PROJETINpaiCallVoid("GSInitialize");
            PROJETINpaiCallVoid("BKSDisplayServicesStart");
            PROJETINpaiCallVoid("UIApplicationInitialize");

            PROJETINpaiUIApplicationInstantiateFn instantiate =
                (PROJETINpaiUIApplicationInstantiateFn)PROJETINpaiResolve("UIApplicationInstantiateSingleton");
            if (instantiate) {
                instantiate(objc_getClass("HUDMainApplication"));
            }
            static id<UIApplicationDelegate> appDelegate = [[objc_getClass("HUDMainApplicationDelegate") alloc] init];
            [UIApplication.sharedApplication setDelegate:appDelegate];
            if ([UIApplication.sharedApplication respondsToSelector:@selector(_accessibilityInit)]) {
                [UIApplication.sharedApplication _accessibilityInit];
            }

            [NSRunLoop currentRunLoop];
            // Intentionally no global HID callback. Touches are handled only by UIKit hit-testing.

            // GSEvent initialization was part of the old private event path.
            // The rebuilt touch architecture is UIKit-only, so do not call or
            // reference these private symbols here. This also keeps the source
            // compatible with the public iOS 15 SDK used by CI.
            
            if ([UIApplication.sharedApplication respondsToSelector:@selector(__completeAndRunAsPlugin)]) {
                [UIApplication.sharedApplication __completeAndRunAsPlugin];
            }
            
            CFRunLoopRun();
            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-exit") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                kill(pid, SIGKILL);
                unlink(GetPIDFilePath().UTF8String);
            }

            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-check") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                int killed = kill(pid, 0);
                return (killed == 0 ? EXIT_FAILURE : EXIT_SUCCESS);
            }
            else return EXIT_SUCCESS;  // No PID file, so HUD is not running
        }
    }
}