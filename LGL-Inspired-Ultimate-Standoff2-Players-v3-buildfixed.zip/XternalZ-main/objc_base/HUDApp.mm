#import <cstddef>
#import <cstring>
#import <cstdlib>
#import <dlfcn.h>
#import <spawn.h>
#import <unistd.h>
#import <sys/param.h>
#import <sys/sysctl.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


#pragma mark -

typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDNotification *IOHIDNotificationRef;
typedef struct __IOHIDService *IOHIDServiceRef;
typedef struct __GSEvent *GSEventRef;

#if __cplusplus
extern "C" {
#endif
void *BKSHIDEventRegisterEventCallback(void (*)(void *, void *, IOHIDServiceRef, IOHIDEventRef));
void UIApplicationInstantiateSingleton(id aclass);
void UIApplicationInitialize();
void BKSDisplayServicesStart();
void GSInitialize();
void GSEventInitialize(Boolean registerPurple);
void GSEventPopRunLoopMode(CFStringRef mode);
void GSEventPushRunLoopMode(CFStringRef mode);
void GSEventRegisterEventCallBack(void (*)(GSEventRef));
#if __cplusplus
}
#endif


#pragma mark -

@interface UIApplication (Private)
- (id)_systemAnimationFenceExemptQueue;
- (void)_accessibilityInit;
- (void)_enqueueHIDEvent:(IOHIDEventRef)event;
- (void)__completeAndRunAsPlugin;
@end

@interface UIEventFetcher : NSObject
- (void)_receiveHIDEvent:(IOHIDEventRef)arg1;
@end

@interface AXEventPathInfoRepresentation : NSObject
@property (assign, nonatomic) unsigned char pathIdentity;
@end

@interface AXEventHandInfoRepresentation : NSObject
- (NSArray <AXEventPathInfoRepresentation *> *)paths;
@end

@interface AXEventRepresentation : NSObject
@property (nonatomic, readonly) BOOL isTouchDown; 
@property (nonatomic, readonly) BOOL isMove; 
@property (nonatomic, readonly) BOOL isChordChange; 
@property (nonatomic, readonly) BOOL isLift; 
@property (nonatomic, readonly) BOOL isInRange; 
@property (nonatomic, readonly) BOOL isInRangeLift; 
@property (nonatomic, readonly) BOOL isCancel; 
+ (instancetype)representationWithHIDEvent:(IOHIDEventRef)event hidStreamIdentifier:(NSString *)identifier;
- (AXEventHandInfoRepresentation *)handInfo;
- (CGPoint)location;
@end


#pragma mark -

// The HUD has a dedicated, small input window. Keep its public surface here
// limited to the state that the global HID bridge actually needs.
@interface HUDTouchWindow : UIWindow
@property (nonatomic, assign) BOOL hotspotMode;
@end

extern "C" void HUDInjectImGuiTouchAtWindowPoint(CGPoint point, NSInteger phase, UIWindow *window);
extern "C" void HUDOpenMenuFromTouchProxy(void);

static UIWindow *HUDActiveWindow(UIApplication *app)
{
    // Prefer the dedicated small touch window. The fullscreen render window is
    // visual-only and intentionally ignores all hit testing.
    for (UIWindow *window in app.windows.reverseObjectEnumerator) {
        if ([NSStringFromClass([window class]) isEqualToString:@"HUDTouchWindow"] &&
            !window.hidden && window.alpha > 0.01 && !CGRectIsEmpty(window.bounds)) {
            return window;
        }
    }
    return nil;
}


static __used void _HUDEventCallback(void *target, void *refcon, IOHIDServiceRef service, IOHIDEventRef event)
{
    static Class AXEventRepresentationCls = nil;
    static BOOL menuTouchActive = NO;
    static BOOL hotspotTouchActive = NO;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[NSBundle bundleWithPath:@"/System/Library/PrivateFrameworks/AccessibilityUtilities.framework"] load];
        AXEventRepresentationCls = objc_getClass("AXEventRepresentation");
    });

    if (!AXEventRepresentationCls) {
        return;
    }

    AXEventRepresentation *rep = [AXEventRepresentationCls representationWithHIDEvent:event hidStreamIdentifier:@"UIApplicationEvents"];
    if (!rep) {
        return;
    }

    UITouchPhase phase = UITouchPhaseEnded;
    if ([rep isTouchDown])
        phase = UITouchPhaseBegan;
    else if ([rep isMove] || [rep isChordChange])
        phase = UITouchPhaseMoved;
    else if ([rep isCancel])
        phase = UITouchPhaseCancelled;
    else if ([rep isLift] || [rep isInRange] || [rep isInRangeLift])
        phase = UITouchPhaseEnded;

    CGPoint globalPoint = [rep location];
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *hudWindow = HUDActiveWindow([UIApplication sharedApplication]);
        if (!hudWindow) {
            menuTouchActive = NO;
            hotspotTouchActive = NO;
            return;
        }

        // The HID callback is global. It fires for touches destined for SpringBoard
        // and other apps too, so we must explicitly test the physical touch window.
        // Without this gate, the previous version injected *every* background
        // touch into ImGui even though HUDTouchWindow itself was only a small rect.
        CGPoint localPoint = [hudWindow convertPoint:globalPoint fromWindow:nil];
        BOOL insideTouchWindow = CGRectContainsPoint(hudWindow.bounds, localPoint);
        BOOL hotspotMode = [(HUDTouchWindow *)hudWindow hotspotMode];

        if (phase == UITouchPhaseBegan) {
            menuTouchActive = NO;
            hotspotTouchActive = NO;

            if (!insideTouchWindow) {
                return;
            }

            if (hotspotMode) {
                hotspotTouchActive = YES;
                return;
            }

            menuTouchActive = YES;
            HUDInjectImGuiTouchAtWindowPoint(globalPoint, phase, hudWindow);
            return;
        }

        // Once a touch begins on the menu, keep routing its move/end sequence to
        // ImGui even if the finger leaves the menu rectangle. UIKit likewise keeps
        // a touch associated with its original window/view for the sequence.
        if (menuTouchActive) {
            HUDInjectImGuiTouchAtWindowPoint(globalPoint, phase, hudWindow);
            if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
                menuTouchActive = NO;
            }
            return;
        }

        if (hotspotTouchActive) {
            if (phase == UITouchPhaseEnded) {
                HUDOpenMenuFromTouchProxy();
            }
            if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
                hotspotTouchActive = NO;
            }
            return;
        }

        // No HUD touch sequence is active. Crucially, do nothing here: the original
        // HID event remains available to the underlying SpringBoard/game instead of
        // being enqueued into this HUD application's UIKit event queue.
    });
}



#pragma mark -

static NSString *_cachesDirectoryPath = nil;
static NSString *_hudPIDFilePath = nil;
static NSString *GetPIDFilePath(void)
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _cachesDirectoryPath = 
        [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
        _hudPIDFilePath = [_cachesDirectoryPath stringByAppendingPathComponent:@"hud.pid"];
    });
    return _hudPIDFilePath;
}


#pragma mark -

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT, "launched argc %{public}d, argv[1] %{public}s", argc, argc > 1 ? argv[1] : "NULL");
#endif

        if (argc <= 1)
            return UIApplicationMain(argc, argv, @"MainApplication", @"MainApplicationDelegate");
        
        if (strcmp(argv[1], "-hud") == 0)
        {
            NSString *pidString = [NSString stringWithFormat:@"%d", getpid()];
            [pidString writeToFile:GetPIDFilePath()
                        atomically:YES
                          encoding:NSUTF8StringEncoding
                             error:nil];
            
            [UIScreen initialize];
            CFRunLoopGetCurrent();

            GSInitialize();
            BKSDisplayServicesStart();
            UIApplicationInitialize();

            UIApplicationInstantiateSingleton(objc_getClass("HUDMainApplication"));
            static id<UIApplicationDelegate> appDelegate = [[objc_getClass("HUDMainApplicationDelegate") alloc] init];
            [UIApplication.sharedApplication setDelegate:appDelegate];
            [UIApplication.sharedApplication _accessibilityInit];

            [NSRunLoop currentRunLoop];
            BKSHIDEventRegisterEventCallback(_HUDEventCallback);

            if (@available(iOS 15.0, *)) {
                GSEventInitialize(0);
                GSEventPushRunLoopMode(kCFRunLoopDefaultMode);
            }
            
            [UIApplication.sharedApplication __completeAndRunAsPlugin];
            
            CFRunLoopRun();
            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-exit") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                kill(pid, SIGKILL);
                unlink(GetPIDFilePath().UTF8String);
            }

            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-check") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                int killed = kill(pid, 0);
                return (killed == 0 ? EXIT_FAILURE : EXIT_SUCCESS);
            }
            else return EXIT_SUCCESS;  // No PID file, so HUD is not running
        }
    }
}