#import <cstddef>
#import <cstring>
#import <cstdlib>
#import <dlfcn.h>
#import <spawn.h>
#import <unistd.h>
#import <sys/param.h>
#import <sys/sysctl.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <objc/message.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


#pragma mark -

typedef void (*HUDVoidFunction)(void);
typedef void (*HUDInitializeEventFunction)(int);
typedef void (*HUDInstantiateFunction)(Class);
typedef void (*HUDPushRunLoopModeFunction)(CFStringRef);

static HUDVoidFunction HUDResolveVoidFunction(const char *name)
{
    return (HUDVoidFunction)dlsym(RTLD_DEFAULT, name);
}

static HUDInitializeEventFunction HUDResolveInitializeEventFunction(const char *name)
{
    return (HUDInitializeEventFunction)dlsym(RTLD_DEFAULT, name);
}

static HUDInstantiateFunction HUDResolveInstantiateFunction(const char *name)
{
    return (HUDInstantiateFunction)dlsym(RTLD_DEFAULT, name);
}

static HUDPushRunLoopModeFunction HUDResolvePushRunLoopModeFunction(const char *name)
{
    return (HUDPushRunLoopModeFunction)dlsym(RTLD_DEFAULT, name);
}

static NSString *_cachesDirectoryPath = nil;
static NSString *_hudPIDFilePath = nil;
static NSString *GetPIDFilePath(void)
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _cachesDirectoryPath = 
        [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
        _hudPIDFilePath = [_cachesDirectoryPath stringByAppendingPathComponent:@"hud.pid"];
    });
    return _hudPIDFilePath;
}


#pragma mark -

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT, "launched argc %{public}d, argv[1] %{public}s", argc, argc > 1 ? argv[1] : "NULL");
#endif

        if (argc <= 1)
            return UIApplicationMain(argc, argv, @"MainApplication", @"MainApplicationDelegate");
        
        if (strcmp(argv[1], "-hud") == 0)
        {
            NSString *pidString = [NSString stringWithFormat:@"%d", getpid()];
            [pidString writeToFile:GetPIDFilePath()
                        atomically:YES
                          encoding:NSUTF8StringEncoding
                             error:nil];
            
            [UIScreen initialize];
            CFRunLoopGetCurrent();

            /*
             * These entry points are private/UIKit-internal and are not declared by
             * the public iPhoneOS SDK. Resolve them at runtime so this source remains
             * compatible with the SDK used by the Theos build.
             */
            HUDVoidFunction gsInitialize = HUDResolveVoidFunction("GSInitialize");
            if (gsInitialize)
                gsInitialize();

            HUDVoidFunction bkStart = HUDResolveVoidFunction("BKSDisplayServicesStart");
            if (bkStart)
                bkStart();

            HUDVoidFunction uiInitialize = HUDResolveVoidFunction("UIApplicationInitialize");
            if (uiInitialize)
                uiInitialize();

            HUDInstantiateFunction instantiateSingleton = HUDResolveInstantiateFunction("UIApplicationInstantiateSingleton");
            Class hudApplicationClass = objc_getClass("HUDMainApplication");
            if (instantiateSingleton && hudApplicationClass)
                instantiateSingleton(hudApplicationClass);

            UIApplication *application = [UIApplication sharedApplication];
            Class delegateClass = objc_getClass("HUDMainApplicationDelegate");
            if (application && delegateClass)
            {
                id<UIApplicationDelegate> appDelegate = [[delegateClass alloc] init];
                [application setDelegate:appDelegate];
            }

            SEL accessibilityInitSelector = sel_registerName("_accessibilityInit");
            if (application && [application respondsToSelector:accessibilityInitSelector])
            {
                ((void (*)(id, SEL))objc_msgSend)(application, accessibilityInitSelector);
            }

            [NSRunLoop currentRunLoop];

            if (@available(iOS 15.0, *))
            {
                HUDInitializeEventFunction eventInitialize = HUDResolveInitializeEventFunction("GSEventInitialize");
                if (eventInitialize)
                    eventInitialize(0);

                HUDPushRunLoopModeFunction pushRunLoopMode = HUDResolvePushRunLoopModeFunction("GSEventPushRunLoopMode");
                if (pushRunLoopMode)
                    pushRunLoopMode(kCFRunLoopDefaultMode);
            }

            SEL completeAndRunSelector = sel_registerName("__completeAndRunAsPlugin");
            if (application && [application respondsToSelector:completeAndRunSelector])
            {
                ((void (*)(id, SEL))objc_msgSend)(application, completeAndRunSelector);
            }
            
            CFRunLoopRun();
            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-exit") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                kill(pid, SIGKILL);
                unlink(GetPIDFilePath().UTF8String);
            }

            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-check") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                int killed = kill(pid, 0);
                return (killed == 0 ? EXIT_FAILURE : EXIT_SUCCESS);
            }
            else return EXIT_SUCCESS;  // No PID file, so HUD is not running
        }
    }
}