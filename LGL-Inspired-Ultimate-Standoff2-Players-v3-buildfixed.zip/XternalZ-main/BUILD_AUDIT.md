# XternalZ build audit

This package was reviewed for deterministic source-level build breakers in the supplied v11 EXTERNAL-FLOAT tree.

## Applied fixes

- Consolidated `menu/menu.m` to one `hitTest:withEvent:` implementation.
- Reworked the private HUD bootstrap in `objc_base/HUDApp.mm` so private C entry points are resolved at runtime instead of being parsed/linked as undeclared SDK symbols.
- Reworked `_accessibilityInit` and `__completeAndRunAsPlugin` calls to runtime selector dispatch.
- Added the required Objective-C runtime/message, logging, and signal headers.
- Defined the missing `BYTE_SIZE` fallback used by the network-speed code and explicitly imported QuartzCore for `CACurrentMediaTime`.
- Removed `UILaunchStoryboardName` from the two application Info.plists because no `LaunchScreen` storyboard/resource exists in this source tree.
- Added `tools/preflight.sh` for repeatable checks of the known deterministic failure modes.

## Environment limitation

The supplied environment does not contain the GitHub Actions Xcode/iPhoneOS 15.6 SDK/Theos installation, so a real Theos/Xcode compile cannot be executed here. The package therefore does not claim a full remote build; the checks above are source-level/static checks against the supplied tree.
