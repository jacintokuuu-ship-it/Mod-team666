#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

fail=0
check_file() { [ -f "$1" ] || { echo "FAIL: missing $1"; fail=1; }; }
check_file Makefile
check_file hud-prefix.pch
check_file imgui/ImGuiDrawView.mm
check_file objc_base/HUDMainApplication.mm
check_file menu/menu.m

# Catch the exact regression that previously stopped the arm64 build.
if grep -RIn --include='*.m' --include='*.mm' --include='*.h' -E '\bending\b' imgui objc_base menu overlay functions unity tasks 2>/dev/null | grep -v 'ending zero' >/tmp/hud_bad_identifiers.$$ 2>/dev/null; then
  echo "FAIL: stale identifier 'ending' found"
  cat /tmp/hud_bad_identifiers.$$
  fail=1
fi
rm -f /tmp/hud_bad_identifiers.$$

# Ensure the production graph does not accidentally reintroduce legacy event synthesis.
for forbidden in 'objc_base/TSEventFetcher.mm' 'objc_base/IOHIDEvent+KIF.m' 'objc_base/UITouch-KIFAdditions.m'; do
  if grep -Fq "$forbidden" Makefile; then
    echo "FAIL: legacy touch source reintroduced: $forbidden"
    fail=1
  fi
done

# Basic balanced-delimiter sanity for the edited Objective-C++ source.
python3 - <<'PY'
from pathlib import Path
p=Path('imgui/ImGuiDrawView.mm')
s=p.read_text()
# Strip comments/strings approximately; this is a smoke check, not a compiler.
import re
x=re.sub(r'/\*.*?\*/','',s,flags=re.S)
x=re.sub(r'//.*','',x)
x=re.sub(r'"(?:\\.|[^"\\])*"','""',x)
stack=[]
pairs={')':'(',']':'[','}':'{'}
for i,c in enumerate(x,1):
    if c in '([{': stack.append(c)
    elif c in ')]}':
        if not stack or stack.pop()!=pairs[c]:
            raise SystemExit(f'FAIL: delimiter mismatch near character {i}')
if stack: raise SystemExit('FAIL: unbalanced delimiters')
PY

if [ "$fail" -ne 0 ]; then exit 1; fi
echo 'PASS: release precheck'
