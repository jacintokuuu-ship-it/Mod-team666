# PROJETINpai v6 — Touch routing rebuild

## Root cause fixed

The previous build used a full-screen external `UIWindow` as the interactive surface. Returning `nil` from that window's `hitTest:` is not a reliable way to pass touches through a system-hosted/external window on every iOS 15 configuration. The result was exactly the reported symptom: the menu could receive touches, while taps outside it were swallowed before reaching the Home screen or the app underneath.

## New architecture

- The visual HUD window is **never interactive**.
- A second transparent `UIWindow` is created only over the actual ImGui menu rectangle.
- The proxy window follows the menu every display frame, including dragging.
- When the menu is closed, the proxy shrinks to the small OPEN region.
- No recognizers are installed into other application windows.
- No synthetic `UITouch`, HID event creation, or global event injection is used by the new touch path.
- Existing ImGui UI callbacks and project functionality remain in place.

## Expected behavior

1. Finger on menu -> PROJETINpai receives it.
2. Drag menu -> proxy follows the menu.
3. Finger anywhere outside menu -> there is no interactive overlay window there, so the underlying app/Home screen receives it.
4. Menu closed -> only OPEN region is interactive.
5. No full-screen transparent touch shield remains.

This is a source-level rebuild. Compile it with the same GitHub Actions/Theos environment used for the project and test on the target iOS 15.x device.
