#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"

fail=0

hit_count="$(grep -R -E -c '^[[:space:]]*-[[:space:]]*\(UIView \*\)hitTest:\(CGPoint\)point withEvent:\(UIEvent \*\)event' "$ROOT/menu/menu.m" || true)"
if [ "$hit_count" -ne 1 ]; then
  echo "ERROR: menu/menu.m must contain exactly one hitTest:withEvent:"
  fail=1
fi

for f in "$ROOT/Resources/Info.plist" "$ROOT/ent.plist"; do
  if [ ! -s "$f" ]; then
    echo "ERROR: missing $f"
    fail=1
  fi
done

if grep -R -n -E '\b(ImClamp|BYTE_SIZE)\b' "$ROOT" --include='*.m' --include='*.mm' --include='*.h' | grep -v 'imgui_internal.h' | grep -v 'define BYTE_SIZE' >/dev/null 2>&1; then
  echo "WARNING: review custom ImGui/macro references"
fi

if grep -n -E 'UIApplicationInstantiateSingleton\(|GSEventInitialize\(|GSEventPushRunLoopMode\(|__completeAndRunAsPlugin\(' "$ROOT/objc_base/HUDApp.mm" >/dev/null 2>&1; then
  echo "ERROR: private C bootstrap APIs must be resolved dynamically"
  fail=1
fi

if [ "$fail" -ne 0 ]; then
  exit 1
fi

echo "Preflight checks passed."
