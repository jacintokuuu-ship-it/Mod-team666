# XternalZ external floating window / touch architecture

This build keeps the existing controller application and launches the HUD through
the existing `-hud` process mode. The HUD remains a separate process/window from
the controller app.

## Floating window

`HUDMainWindow` is a dedicated high-level HUD window. Its hit-testing is selective:
only the actual ImGui menu or the explicit menu-open control can return a hit view.
All other points return `nil`, allowing the underlying application to continue
receiving its normal touch events.

`MenuView` is intentionally fullscreen for rendering/orientation, but its
`hitTest:` accepts only `HUDMenuInteractiveRect()`, which is the live ImGui panel
rectangle. Transparent space around the panel is therefore not interactive.

## Single native touch path

The menu now uses:

UITouch -> HUDMainWindow hit-test -> MenuView hit-test -> TouchableMTKView -> ImGui IO

The previous HID/AX callback and synthetic `TSEventFetcher` delivery path was
removed from the build. This prevents duplicated pointers and coordinate drift.
The first touch entering the panel becomes the menu's primary pointer until that
touch ends/cancels; extra fingers cannot switch the active ImGui pointer.

## Existing backend

The existing project files for hooks, process/task access, Unity helpers, feature
bridges and ESP rendering are left intact. This revision changes the window/input
boundary only.

## Scale

The visual panel is now approximately half the previous maximum size (180x205 vs
360x410), with compact rows and a scrollable feature area.
