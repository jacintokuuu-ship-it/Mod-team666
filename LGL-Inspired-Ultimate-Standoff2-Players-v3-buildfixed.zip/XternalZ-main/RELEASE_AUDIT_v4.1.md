# NEXUS v4.1 release audit

## Scope
This release was reconstructed from all four project archives available in the conversation:
`buildfix`, `pass-through`, `pass-through-v2`, and `pass-through-v3`.

## Changes carried forward
- The original fullscreen overlay remains visual-only.
- A dedicated `HUDTouchWindow` now owns the interactive region.
- `HUDTouchProxyView` implements the full UIKit touch lifecycle.
- Screen-space coordinates are converted exactly once before entering ImGui.
- HID fallback is constrained to the interactive window and never enqueues background events.
- `hotspotMode` has a visible declaration in every translation unit that uses it.

## Regression removed
The v3 proxy could win hit-testing but had no `touchesBegan/Moved/Ended/Cancelled`
implementation. v4.1 keeps those methods and feeds the main ImGui context directly.

## Build hardening
- Root `Makefile` is mandatory.
- The production source graph is explicit.
- Legacy `TSEventFetcher`/KIF synthetic event files are excluded from the target.
- CI checks the Makefile/source graph before compiling.
- CI validates the generated application and `.tipa` archive.

## UI
The NEXUS panel uses a compact dark modder-style layout with a header, status strip,
MAIN/ESP/EXTRA navigation, large touch-friendly controls, close button, and draggable header.
The closed state uses the same centered hotspot that is used by the touch window.

## Verification performed in this environment
- Full archive tree inventory for all available versions.
- Cross-version file diff.
- Key-source structural/bracket validation.
- Makefile dry-run parsing with a stub Theos environment.
- Property/function declaration consistency checks.
- Plist syntax parsing with Python's plist parser.
- ZIP integrity validation after packaging.

A real arm64 iOS compile still requires the macOS/Xcode/Theos toolchain used by the
GitHub Actions workflow; it is not available in this Linux workspace.
