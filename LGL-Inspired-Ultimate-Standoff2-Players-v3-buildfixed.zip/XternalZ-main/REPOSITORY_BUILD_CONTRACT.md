# Repository build contract

The repository builds the checked-out Theos project directly through
`.github/workflows/build.yml`; there is no `SOURCE_ZIP` extraction step.
The workflow installs Theos, installs the pinned iOS 15.6 SDK, then runs:

`make clean` followed by `make all SDKVERSION="15.6" messages=yes`

The release target also produces `packages/LGLInspired.tipa` from the staged
`Excalibur.app`. The workflow separately packages the same app as
`output/Excalibur.ipa` and validates the app bundle before upload.

The v4.2 source includes static guards for the touch-window hit-testing fix,
the live touch-window state bridge, the fast-tap ImGui press latch, explicit
Theos source inventory, and the historical `ImVec2` operator+ regression.
