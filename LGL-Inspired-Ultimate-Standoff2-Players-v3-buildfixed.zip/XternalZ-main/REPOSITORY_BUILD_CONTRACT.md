# Repository build contract

The repository workflow currently reads `SOURCE_ZIP` from
`.github/workflows/build-ipa.yml` and extracts the Makefile it finds inside the
ZIP. The current workflow value is:

`LGL-Inspired-Ultimate-Standoff2-Players-v3-buildfixed.zip`

For compatibility with that workflow, the release ZIP in this package is also
provided under that exact filename. Replace the repository's old ZIP with the
new ZIP without changing the workflow, or change `SOURCE_ZIP` to the new release
filename.

The workflow runs the clean step, re-runs `ci-preflight.sh`, and then executes
`make all SDKVERSION="15.6"`.
Theos documents `make clean` and `make` as the normal clean/rebuild workflow and
project-specific `XXX_CFLAGS`/`XXX_CCFLAGS` as supported Makefile variables.


The v4.1.2 source also includes a static guard against the `ImVec2` operator+ failure that previously stopped compilation in `imgui/ImGuiDrawView.mm`.
