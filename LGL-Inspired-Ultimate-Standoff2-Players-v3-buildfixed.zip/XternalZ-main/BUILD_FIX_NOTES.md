# Build / touch fix v4

- Added a real `Makefile` at repository root and made CI fail early when it is missing.
- Fixed the `hotspotMode` declaration visibility issue from the earlier build.
- Added direct UIKit touch forwarding in `HUDTouchProxyView`.
- Kept HID as a fallback only; it no longer enqueues background HID events into the HUD application.
- Disabled interaction on the fullscreen render view and removed the obsolete hotspot recognizers from the visual window.
- Explicitly attached the dedicated touch window to the main screen.
- Added landscape orientations to the bundle metadata to match the runtime orientation support.
- Refreshed the NEXUS panel with a compact modder-style dark interface and working ESP / utility toggles.


## Build graph hardening

- The root `Makefile` now lists production sources explicitly instead of globbing
  every Objective-C/Objective-C++ file under `objc_base/`.
- The legacy `TSEventFetcher`/KIF synthetic event implementation is therefore not
  linked into the app.
- CI verifies that the explicit source graph exists, that the legacy event files
  are excluded, and that the generated `.tipa` passes `unzip -t`.
- README/package naming was synchronized with the generated `packages/LGLInspired.tipa`.

## Build-session / object-directory fix v5.3

- v5.2 successfully created `.theos/build_session`, but CI then failed at
  `.theos/obj/debug` because the parent object directory had been removed by
  `make clean` and the installed Theos revision attempted to touch that path
  before recreating it.
- CI now creates `.theos/obj/debug` **after** `make clean` and verifies that it
  is a directory before starting the real build.
- No production source, compiler flag, hook, UI/touch implementation, or
  source graph was changed by v5.3.

## Makefile-level object-directory bootstrap v5.4

- The `.theos/obj/debug` bootstrap is now performed by `Makefile` itself during parsing, not only by GitHub Actions.
- This makes the fix independent of which CI workflow invokes `make`, including a workflow that runs `make clean` followed by `make all`.
- `ci-preflight.sh` now verifies the same object-directory invariant.
- No production source file, hook implementation, UI/touch code, compiler flag, framework list, source graph, or packaging logic was changed.
