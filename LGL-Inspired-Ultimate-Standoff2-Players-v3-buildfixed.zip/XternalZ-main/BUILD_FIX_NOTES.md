# NEXUS Touch Pass-Through v3 — build/runtime audit

## Compile error fixed
`HUDApp.mm` referenced `hotspotMode` on `HUDTouchWindow` without a visible declaration. A local `HUDTouchWindow` interface now declares the property before the callback uses it.

## Runtime issue fixed
The BackBoard/HID callback is global. Merely making `HUDTouchWindow` small does not restrict that callback. The previous v2 callback could still inject any screen coordinate into ImGui and could enqueue the raw HID event into the HUD application.

v3 therefore:

- does not call `UIApplication _enqueueHIDEvent:` for every physical touch;
- checks the HID point against `HUDTouchWindow.bounds` after converting from screen/global coordinates;
- starts a HUD menu sequence only when the touch begins inside the menu window;
- continues move/end/cancel events for that active menu sequence even after the finger leaves the rectangle, matching normal touch-sequence semantics;
- ignores unrelated background touches completely, leaving the original HID event available to the underlying system/app;
- handles the closed-state hotspot separately;
- shows `HUDMainWindow` with `hidden = NO` instead of `makeKeyAndVisible`;
- removes the fullscreen three-finger gesture recognizer from `HUDMainWindow`.

## Design basis
UIKit hit testing is view-hierarchy based, while `makeKeyAndVisible` explicitly makes a window key. For a cross-app overlay, the render window should not claim key status or install a fullscreen recognizer. The input surface is kept as a separate, small window.

Apple documentation: `UIWindow` and `makeKeyAndVisible`; `UIView` `hitTest:`/`pointInside:`.
