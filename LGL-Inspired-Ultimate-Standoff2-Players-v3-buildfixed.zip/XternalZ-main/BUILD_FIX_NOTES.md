# Build / touch fix v4

- Added a real `Makefile` at repository root and made CI fail early when it is missing.
- Fixed the `hotspotMode` declaration visibility issue from the earlier build.
- Added direct UIKit touch forwarding in `HUDTouchProxyView`.
- Kept HID as a fallback only; it no longer enqueues background HID events into the HUD application.
- Disabled interaction on the fullscreen render view and removed the obsolete hotspot recognizers from the visual window.
- Explicitly attached the dedicated touch window to the main screen.
- Added landscape orientations to the bundle metadata to match the runtime orientation support.
- Refreshed the NEXUS panel with a compact modder-style dark interface and working ESP / utility toggles.


## Build graph hardening

- The root `Makefile` now lists production sources explicitly instead of globbing
  every Objective-C/Objective-C++ file under `objc_base/`.
- The legacy `TSEventFetcher`/KIF synthetic event implementation is therefore not
  linked into the app.
- CI verifies that the explicit source graph exists, that the legacy event files
  are excluded, and that the generated `.tipa` passes `unzip -t`.
- README/package naming was synchronized with the generated `packages/LGLInspired.tipa`.
