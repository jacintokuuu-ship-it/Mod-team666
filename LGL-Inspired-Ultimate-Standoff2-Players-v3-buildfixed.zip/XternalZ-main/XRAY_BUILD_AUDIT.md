# XternalZ Build X-Ray Audit

## Scope

Static audit of the repository build graph, Theos object-directory bootstrap,
Dear ImGui compiler constraints, notification macro placement, CI workflow,
source existence, local include resolution, plist validity, and ZIP layout.

## Findings fixed

1. **Theos application object collision**
   - The failing path was `.theos/obj/debug/Excalibur.app`.
   - It must be a directory because Theos later writes
     `Excalibur.bbeecd14.unsigned` below it.
   - Both debug and `arm64` application roots are now created before Theos.
   - A stale regular file at either root is removed and replaced with a directory.

2. **Per-architecture source object directories**
   - All production source subdirectories are bootstrapped below both
     `.theos/obj/debug/` and `.theos/obj/debug/arm64/`.

3. **Explicit source graph**
   - `EXCALIBUR_ALL_SOURCES` contains 15 literal production sources.
   - No Makefile wildcard discovery remains.
   - `TSEventFetcher.mm`, `IOHIDEvent+KIF.m`, and `UITouch-KIFAdditions.m`
     are not in the production graph.

4. **Dear ImGui**
   - Custom code includes `<algorithm>` and uses `std::clamp`.
   - No custom `ImClamp` macro remains in `ImGuiDrawView.mm`.
   - The custom source does not use the forbidden `ImVec2 + ImVec2` expression.
   - The four bundled core ImGui `.cpp` units pass a host C++17 syntax check.

5. **Darwin notifications**
   - No `-DNOTIFY_*` compiler flag remains in the Makefile.
   - Notification names are defined as C string literals in `hud-prefix.pch`.

6. **Objective-C++ mode**
   - Target is pinned to `iphone:clang:15.6:15.0`.
   - `arm64` is the only architecture.
   - C++ and Objective-C++ use `-std=c++17`.

7. **CI scripts**
   - `ci-preflight.sh` and `verify_build_contract.sh` are executable.
   - `verify_build_contract.sh` invokes preflight itself, so it is safe to run
     directly on a fresh checkout.

## Validation performed

- `bash -n`/direct execution of the preflight and contract scripts.
- Stale-file recovery test for both application object roots.
- Makefile parse test with a minimal Theos stub.
- Host clang++ C++17 syntax checks for `imgui.cpp`, `imgui_draw.cpp`,
  `imgui_tables.cpp`, and `imgui_widgets.cpp`.
- Literal source graph existence test.
- Legacy source exclusion test.
- Local quoted-include audit using the Makefile include paths; remaining
  unresolved references are optional ImGui headers behind feature macros or
  dependencies belonging only to intentionally excluded legacy source files.
- ZIP integrity test.

## Environment limitation

A full device-targeted Xcode/Theos compile cannot be executed in this Linux
container because the Apple iPhoneOS SDK and Xcode toolchain are not installed.
The GitHub Actions workflow remains the authoritative end-to-end build test.
