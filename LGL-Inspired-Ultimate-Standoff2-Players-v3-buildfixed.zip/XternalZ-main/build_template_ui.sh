#!/bin/sh
set -eu

if [ -z "${THEOS:-}" ]; then
  echo "THEOS is not set. Export THEOS to your Theos installation, then run again."
  exit 1
fi

make clean
make package
