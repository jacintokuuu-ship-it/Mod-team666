# PROJETINpai v7 — floating menu architecture

The uploaded Brazilix external was studied as the reference for the floating-menu behavior. Its important UI pattern is:

1. A fullscreen HUD/ESP view is used for rendering.
2. The HUD view's `hitTest:` only forwards to the actual `MenuView`.
3. The menu itself is the bounded interactive surface.
4. The external window is hosted as a high-level/system HUD.

PROJETINpai keeps its existing ImGui/Metal menu and its existing project modules, but applies the same separation more strictly:

- fullscreen visual HUD: `userInteractionEnabled = NO`
- separate `PROJETINpaiTouchWindow`: interactive only while its frame overlaps the real ImGui menu
- outside that frame there is no interactive PROJETINpai window
- the previous regression in v6 was `applyFrontmostVisibility` setting the fullscreen visual window back to `userInteractionEnabled = YES`; v7 permanently prevents that

No hook/function source files were changed by this UI fix.
