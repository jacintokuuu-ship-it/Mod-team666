# NEXUS v5 — Touch / UI rebuild

## Scope
Only the presentation/input layer was reworked. The existing backend source graph remains in the target, including `functions/Teste.mm`, `tasks/pid.mm`, `unity/unity.mm`, and the existing hook headers/infrastructure.

## Touch architecture

1. `HUDMainWindow` is render-only and returns `nil` from hit-testing.
2. `HUDTouchWindow` is a separate non-key input window whose frame is the exact rendered ImGui panel rectangle.
3. `HUDTouchWindow` implements both `pointInside:withEvent:` and `hitTest:withEvent:`. A point outside its bounds returns `nil`, so the lower application remains eligible for the touch.
4. `HUDTouchProxyView` receives only the bounded menu touch sequence and forwards screen coordinates to the existing ImGui context bridge.
5. The frame setter now updates synchronously when already on the main thread, removing the previous one-run-loop race between drawing the panel and installing the input surface.
6. The render view and visual `MenuView` are explicitly non-interactive; they cannot accidentally become a fullscreen touch shield.

## UI architecture

- Replaced ordinary ImGui checkboxes/buttons for feature toggles with custom animated LGL-inspired switches.
- Switches use a large invisible hit target, animated track/knob movement, active glow, and ACTIVE/OFF state.
- Added a UIKit blur/frosted panel behind the Metal UI.
- Green/cyan cyberpunk palette, rounded surfaces, status tabs, and routing diagnostics.
- The backend calls remain connected through the existing `Teste`, ESP, stealth, and HUD bridges.

## Files changed

- `imgui/ImGuiDrawView.mm`
- `menu/menu.m`
- `objc_base/HUDMainApplication.mm`

No hook/memory implementation file was deleted or replaced.

## Build note

The supplied environment does not contain a configured Theos installation, so a device-level `make package` build could not be executed here. The source was checked for balanced delimiters, placeholder markers, and the expected production source graph. Final compilation must be run in the user's configured Theos environment.
