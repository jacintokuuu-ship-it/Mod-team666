# v4.2.1 — build-fix release

## Blocking compiler error fixed

The arm64 Theos build reported:

`imgui/ImGuiDrawView.mm:187:21: error: use of undeclared identifier 'ending'`

The code declared `ended` and later referenced the undeclared `ending` identifier. The reference has been corrected to `ended`.

## Regression review

- searched the complete Objective-C/Objective-C++ production graph for the stale identifier;
- verified the production Makefile source list;
- verified the touch-window sources remain in the intended graph;
- ran `BUILD_PRECHECK.sh`;
- ran `verify_build_contract.sh`;
- performed delimiter sanity checking on the edited Objective-C++ file.

A real iOS arm64 compilation still requires the user's Theos + iPhoneOS SDK + Xcode toolchain; this environment cannot honestly claim to have executed that external toolchain.
