# XternalZ build fix 82

This revision addresses the HUDApp.mm compiler failures reported by the iPhoneOS 15.6 SDK.

## Fixed

- `UIApplicationInstantiateSingleton` undeclared identifier: resolved dynamically with `dlsym`.
- `UIApplication -_accessibilityInit` missing selector: invoked through a runtime selector and `objc_msgSend`.
- `GSEventInitialize` undeclared identifier: resolved dynamically with the correct one-argument function signature.
- `GSEventPushRunLoopMode` undeclared identifier: resolved dynamically.
- `UIApplication -__completeAndRunAsPlugin` missing selector: invoked through a runtime selector and `objc_msgSend`.
- The existing `GSInitialize`, `BKSDisplayServicesStart`, and `UIApplicationInitialize` bootstrap calls are also resolved dynamically so the same SDK-compatibility issue does not reappear for those private C entry points.

## Existing fix retained

- `menu/menu.m` contains one and only one `hitTest:withEvent:` implementation.
- The retained hit-test keeps the transparent HUD area pass-through behavior.
