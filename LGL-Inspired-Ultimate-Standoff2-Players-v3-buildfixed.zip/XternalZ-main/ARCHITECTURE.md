# XternalZ NOVA — organização

A base foi reorganizada por responsabilidade, sem reescrever a lógica existente.

## Pastas principais

```text
menu/       -> interface/container do menu
hooks/      -> infraestrutura de hooking existente (headers)
tasks/      -> código relacionado a task/PID existente
overlay/    -> overlay e view do ESP
unity/      -> integração Unity existente

imgui/IMGUI/ -> Dear ImGui e backend Metal
esp/helpers/ -> headers/utilitários gerais
objc_base/  -> infraestrutura UIKit/HUD
include/    -> headers privados/auxiliares
layout/     -> pacote/app
```

## Onde procurar

### Menu
`menu/menu.m` e `imgui/ImGuiDrawView.mm`

### Hooks
`hooks/CaptainHook.h`

### Task/PID
`tasks/pid.h` e `tasks/pid.mm`

### Overlay
`overlay/ESPImGuiView.mm`

### Unity
`unity/unity.mm`

A separação é organizacional: os arquivos foram movidos e os imports/Makefile
foram ajustados para os novos caminhos. A lógica existente não foi expandida.

## iOS

O Makefile foi ajustado para usar iOS 15 como deployment target.
