# v4.1.1 — build #58 fix

## Root cause
The Makefile injected Darwin notification names using `-DNAME="..."` through a
Theos compiler flag. In the GitHub Actions shell expansion used by the project,
the quotes were stripped before clang received the argument. The compiler therefore
saw identifiers such as `ch.xxtou.notification.hud.dismissal`, producing the
`use of undeclared identifier 'ch'` errors.

## Fix
Notification names are now defined as real C string-literal macros in
`hud-prefix.pch`. The shell-sensitive `-DNOTIFY_*` flags were removed from the
Makefile.

## Secondary cleanup
The notification callback variables were renamed (`registrationToken` /
`callbackToken`) to remove shadowing and make cancellation semantics explicit.

## Build contract
The source graph remains explicit; the legacy TSEventFetcher/KIF event-synthesis
files are not compiled into the application.
