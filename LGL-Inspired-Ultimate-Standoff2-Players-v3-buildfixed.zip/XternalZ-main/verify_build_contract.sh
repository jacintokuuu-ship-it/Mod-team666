#!/bin/bash
set -euo pipefail
fail(){ echo "FAIL: $1" >&2; exit 1; }
root="$(cd "$(dirname "$0")" && pwd)"
cd "$root"
[ -f Makefile ] || fail 'Makefile missing'
[ -f hud-prefix.pch ] || fail 'hud-prefix.pch missing'
! grep -q 'NOTIFY_.*-D' Makefile || fail 'notification macros still injected via compiler flags'
grep -q '#define NOTIFY_LAUNCHED_HUD "ch.xxtou.notification.hud.launched"' hud-prefix.pch || fail 'notification definitions missing'
grep -q 'registrationToken' objc_base/HUDMainApplication.mm || fail 'notification token fix missing'
grep -q 'callbackToken' objc_base/HUDMainApplication.mm || fail 'callback token fix missing'
! grep -q 'TSEventFetcher.mm' Makefile || fail 'legacy event synthesizer reintroduced'
! grep -q 'IOHIDEvent+KIF.m' Makefile || fail 'legacy KIF event path reintroduced'
! grep -q 'UITouch-KIFAdditions.m' Makefile || fail 'legacy KIF touch path reintroduced'
# Check that every production source named in the Makefile exists.
awk '/EXCALIBUR_CORE_SOURCES :=/{on=1;next} /EXCALIBUR_IMGUI_SOURCES :=/{on=0} on && /objc_base|menu\/|imgui\/|overlay\/|tasks\/|unity\/|functions\// {gsub(/\\/ , ""); print}' Makefile | while read -r f; do [ -f "$f" ] || fail "source missing: $f"; done
unzip -t ../release.zip >/dev/null 2>&1 && echo 'PASS: release ZIP integrity' || true
echo 'PASS: static build contract'
