#!/bin/bash
set -euo pipefail
fail(){ echo "FAIL: $1" >&2; exit 1; }
root="$(cd "$(dirname "$0")" && pwd)"
cd "$root"
[ -f Makefile ] || fail 'Makefile missing'
[ -f hud-prefix.pch ] || fail 'hud-prefix.pch missing'
! grep -q 'NOTIFY_.*-D' Makefile || fail 'notification macros still injected via compiler flags'
grep -q '#define NOTIFY_LAUNCHED_HUD "ch.xxtou.notification.hud.launched"' hud-prefix.pch || fail 'notification definitions missing'
grep -q 'registrationToken' objc_base/HUDMainApplication.mm || fail 'notification token fix missing'
grep -q 'callbackToken' objc_base/HUDMainApplication.mm || fail 'callback token fix missing'
! grep -q 'TSEventFetcher.mm' Makefile || fail 'legacy event synthesizer reintroduced'
! grep -q 'IOHIDEvent+KIF.m' Makefile || fail 'legacy KIF event path reintroduced'
! grep -q 'UITouch-KIFAdditions.m' Makefile || fail 'legacy KIF touch path reintroduced'
! grep -q 'GetWindowPos() + ImGui::GetIO().MouseDelta' imgui/ImGuiDrawView.mm || fail 'ImVec2 operator+ dependency reintroduced in custom source'
# Check that every production source named in both Makefile source graphs exists.
awk '
    /EXCALIBUR_CORE_SOURCES :=/{on=1; next}
    /EXCALIBUR_IMGUI_SOURCES :=/{on=2; next}
    /^Excalibur_USE_MODULES :=/{on=0}
    on && /\.(m|mm|cpp)$/ {gsub(/\\$/, ""); gsub(/^[[:space:]]+/, ""); print}
    ' Makefile | while read -r f; do [ -f "$f" ] || fail "source missing: $f"; done

# Regression guard for the exact compiler failure seen in the CI build.
! grep -q 'GetWindowPos() + ImGui::GetIO().MouseDelta' imgui/ImGuiDrawView.mm || fail 'ImVec2 operator+ dependency reintroduced in custom source'

# The release source graph must never compile the legacy synthetic touch path.
! grep -Eqs '^[[:space:]]*(objc_base/(TSEventFetcher|IOHIDEvent\+KIF|UITouch-KIFAdditions)\.(mm|m))([[:space:]]|\\)?$' Makefile || fail 'legacy event synthesizer reintroduced into Makefile'

# Keep the archive itself valid when this script is run from a packaged release.
if [ -f ../release.zip ]; then
    unzip -t ../release.zip >/dev/null || fail 'release ZIP integrity check failed'
fi

echo 'PASS: static build contract'
