#!/bin/bash
set -euo pipefail
fail(){ echo "FAIL: $1" >&2; exit 1; }
root="$(cd "$(dirname "$0")" && pwd)"
cd "$root"
[ -f Makefile ] || fail 'Makefile missing'
[ -x ./ci-preflight.sh ] || fail 'ci-preflight.sh is not executable'
./ci-preflight.sh >/dev/null || fail 'Theos build directory preflight failed'
[ -f hud-prefix.pch ] || fail 'hud-prefix.pch missing'
! grep -q 'NOTIFY_.*-D' Makefile || fail 'notification macros still injected via compiler flags'
! grep -Fq '$(wildcard' Makefile || fail 'pattern-based source discovery reintroduced'
grep -q '#define NOTIFY_LAUNCHED_HUD "ch.xxtou.notification.hud.launched"' hud-prefix.pch || fail 'notification definitions missing'
grep -q 'registrationToken' objc_base/HUDMainApplication.mm || fail 'notification token fix missing'
grep -q 'callbackToken' objc_base/HUDMainApplication.mm || fail 'callback token fix missing'
source_graph="$(sed -n '/^EXCALIBUR_ALL_SOURCES :=/,/^$/p' Makefile)"
printf '%s\n' "$source_graph" | grep -Eq 'objc_base/(TSEventFetcher|IOHIDEvent\+KIF|UITouch-KIFAdditions)\.(mm|m)' && fail 'legacy synthetic touch source included in production graph' || true
! grep -q 'GetWindowPos() + ImGui::GetIO().MouseDelta' imgui/ImGuiDrawView.mm || fail 'ImVec2 operator+ dependency reintroduced in custom source'
grep -q '^#include <algorithm>$' imgui/ImGuiDrawView.mm || fail 'C++ <algorithm> header missing for std::clamp'
grep -q 'std::clamp' imgui/ImGuiDrawView.mm || fail 'std::clamp usage missing from custom ImGui source'
! grep -Fq '#define ImClamp' imgui/ImGuiDrawView.mm || fail 'custom ImClamp macro reintroduced'
grep -q 'Excalibur_CCFLAGS += -std=c++17' Makefile || fail 'C++17 compiler mode missing'
grep -q 'Excalibur_OBJCCFLAGS += -std=c++17' Makefile || fail 'Objective-C++17 compiler mode missing'
grep -q '^TARGET := iphone:clang:15.6:15.0$' Makefile || fail 'required Theos target is not pinned to iphone:clang:15.6:15.0'
for source_dir in functions imgui/IMGUI objc_base overlay tasks unity menu; do
    test -d ".theos/obj/debug/$source_dir" || fail "debug object directory missing: $source_dir"
    test -d ".theos/obj/debug/arm64/$source_dir" || fail "arm64 object directory missing: $source_dir"
done
test -d .theos/obj/debug/Excalibur.app || fail 'debug application object directory missing'
test -d .theos/obj/debug/arm64/Excalibur.app || fail 'arm64 application object directory missing'
# Check that every production source named in the literal source graph exists.
printf '%s\n' "$source_graph" |
    sed '1s/^EXCALIBUR_ALL_SOURCES :=[[:space:]]*//' |
    sed 's/[[:space:]]*\\$//' |
    sed '/^[[:space:]]*$/d' |
    sed 's/^[[:space:]]*//' |
    while read -r f; do
        [ -f "$f" ] || fail "source missing: $f"
    done

# Regression guard for the exact compiler failure seen in the CI build.
! grep -q 'GetWindowPos() + ImGui::GetIO().MouseDelta' imgui/ImGuiDrawView.mm || fail 'ImVec2 operator+ dependency reintroduced in custom source'

# Keep the archive itself valid when this script is run from a packaged release.
if [ -f ../release.zip ]; then
    unzip -t ../release.zip >/dev/null || fail 'release ZIP integrity check failed'
fi

echo 'PASS: static build contract'
