# NEXUS touch pass-through audit

## Root cause found
The previous implementation used one fullscreen `HUDMainWindow` as both the render surface and the touch window. `hitTest:` was made selective, but the fullscreen window remained registered as a system/accessibility-hosted window, so cross-app routing could still stop at the HUD window before the underlying SpringBoard/game window was selected.

A second problem was the global HID path in `HUDApp.mm`: every physical event was queued into the HUD application and then converted into a synthetic `UITouch` through `TSEventFetcher`, even when the coordinate was outside the visible ImGui panel. That made the fullscreen overlay an unnecessary event sink.

## Architecture of this fix
1. `HUDMainWindow` is now visual-only and returns `_ignoresHitTest = YES`.
2. `HUDTouchWindow` is a separate accessibility-hosted window whose frame is kept equal to the actual NEXUS rectangle (or the 64pt OPEN hotspot when the menu is closed).
3. The global HID callback keeps feeding the normal UIKit queue, but direct ImGui injection occurs only when `HUDTouchWindow` is visible.
4. The old per-event `TSEventFetcher` synthetic UIKit touch injection was removed from the global callback. The menu uses the existing direct ImGui IO injection path.
5. Menu coordinates are converted into global display coordinates before updating `HUDTouchWindow`, so the touch window does not depend on fullscreen view hit-testing.
6. The OPEN hotspot is handled from the HID callback and opens the menu without needing a fullscreen gesture recognizer.

## Expected routing

```text
physical touch
    |
    v
BackBoard/HID callback
    |
    +--> normal HUD UIKit queue
    |
    +--> if HUDTouchWindow is visible:
    |       +--> menu: ImGui IO injection
    |       `--> hotspot: open menu
    |
    `--> outside HUDTouchWindow:
            HUD has no hit-testable window there
            -> underlying SpringBoard / game remains eligible
```

## Static validation
The source tree was inspected for all `UIWindow`, `hitTest:`, `pointInside:`, HID callback, `sendEvent:`, `TSEventFetcher`, and gesture-recognizer paths. The resulting archive is checked with `unzip -t` before delivery.

A device-side iOS build/test is not available in this Linux workspace, so runtime behavior on a particular iOS version still needs to be verified on the target device.
