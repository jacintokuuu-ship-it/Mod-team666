# NEXUS Touch Architecture — v4

## Event ownership

1. `HUDMainWindow` is render-only: it cannot become key and explicitly returns `nil` from hit testing.
2. `HUDTouchWindow` is the only interactive overlay window. Its frame is updated to the exact ImGui panel (or the small OPEN hotspot).
3. `HUDTouchProxyView` implements the complete UIKit touch lifecycle and forwards a touch directly to the main ImGui context.
4. `BKSHIDEventRegisterEventCallback` remains as a fallback for devices where the hosted touch window does not surface UIKit callbacks.
5. The HID fallback never calls `_enqueueHIDEvent:`. Background touches therefore remain untouched by the HUD event queue.
6. When direct UIKit input has recently been observed, the HID fallback suppresses duplicate delivery.

## Why this fixes the v3 regression

The previous proxy view only implemented `pointInside:`/`hitTest:`. It could win the window hit test but had no `touchesBegan/Moved/Ended` implementation, so the menu could become the touch destination without ever updating ImGui IO.

## Build contract

The repository contains a root `Makefile`, Theos `common.mk/application.mk` integration, a pinned iPhoneOS 15.6 SDK in CI, resource validation, bundle validation, and IPA creation.
