# PROJETINpai — Floating Overlay v5

Base: uploaded `LGL-Inspired-Ultimate-Standoff2-Players-v3-buildfixed`.

## What changed

- Kept the existing project modules, menu, ImGui/Metal renderer, ESP code and memory-reading/game-data code intact.
- Reworked the HUD window as a persistent floating overlay with a high window level.
- The HUD window remains non-key; it does not become the keyboard/touch owner of the underlying app.
- Removed foreground-bundle polling as the visibility gate. The overlay no longer disappears just because SpringBoardServices is unavailable or because the HUD process loses active state.
- Preserved UIKit hit-testing as the touch boundary: only the actual ImGui menu window/hotspot captures input; transparent/fullscreen overlay areas pass through.
- Kept the old synthetic HID/KIF source files excluded from the build.
- Guarded the optional private UIApplication selector at runtime.

## Touch model

Underlying app receives touches outside the menu:

    touch
      -> PROJETINpai HUD window
      -> HUDRootViewController / MenuView
      -> actual ImGui rectangle?
          yes: ImGui
          no: nil -> underlying app

This version does not inject synthetic UITouch/HID events.

## iOS target

Designed for the project's iOS 15 target and arm64 Theos build.

## Important

A normal iOS application cannot guarantee being above every system-owned surface (lock screen, SpringBoard/system alerts, etc.). The window level here is intended to stay above ordinary application windows while preserving pass-through input.
