# v4.1.3 — Theos app-object root collision fix

## Root cause

The previous pre-flight created `.theos/obj/debug/arm64/Excalibur.app/`, but
Theos also emits intermediate unsigned output below the architecture-neutral
path `.theos/obj/debug/Excalibur.app/`.

In the failing CI run, Theos first executed `touch .../.theos/obj/debug/Excalibur.app`,
which makes that path a regular file when the directory does not already exist.
The later command then attempted to create:

`.theos/obj/debug/Excalibur.app/Excalibur.bbeecd14.unsigned`

and failed with `Not a directory`.

## Fix

The Makefile now creates both application object roots at parse time, before
Theos is included:

- `.theos/obj/debug/Excalibur.app/`
- `.theos/obj/debug/arm64/Excalibur.app/`

The pre-flight also repairs stale regular files under the known `.theos/obj`
paths by removing only the conflicting build artifact and recreating it as a
directory.

`ci-preflight.sh` mirrors the same invariant, and the CI workflow runs that
pre-flight again immediately after `make clean`.

## Guard

`verify_build_contract.sh` now requires both application object roots to be
directories, in addition to all source object directories.
