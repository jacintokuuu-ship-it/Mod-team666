# Mega Engineering Audit — v4.2.0 Touch-Stable Buildfix

## 1. Scope

This release was reviewed as a complete source-tree engineering task with a focused end-to-end audit of the active production source graph, the UIKit/Metal/ImGui input path, Theos packaging contract, resource files, and release validation scripts.

The target symptom is deterministic: the overlay is visible, but tapping a menu control causes the application behind the overlay to receive the touch. The audit therefore treats event ownership, hit-testing, coordinate conversion, timing, and state transitions as one system rather than as isolated UI bugs.

## 2. Production source graph

The Theos Makefile has an explicit production list instead of wildcard compilation. The active graph contains 15 implementation units:

### Core (10)

- `objc_base/HUDApp.mm` — process/plugin entry and global HID fallback bridge.
- `objc_base/HUDMainApplication.mm` — application delegate, render window, dedicated input window, touch hit-testing and HUD bridges.
- `objc_base/MainApplication.mm` — shared application/runtime support.
- `objc_base/UIView+SecureView.m` — secure-view helper.
- `menu/menu.m` — menu container and menu-side view hierarchy.
- `imgui/ImGuiDrawView.mm` — Metal view, ImGui context, menu rendering and input bridge.
- `overlay/ESPImGuiView.mm` — overlay rendering/context support.
- `tasks/pid.mm` — process/PID support.
- `unity/unity.mm` — Unity-side support.
- `functions/Teste.mm` — test action used by the MAIN tab.

### Dear ImGui (5)

- `imgui/IMGUI/imgui.cpp`
- `imgui/IMGUI/imgui_draw.cpp`
- `imgui/IMGUI/imgui_tables.cpp`
- `imgui/IMGUI/imgui_widgets.cpp`
- `imgui/IMGUI/imgui_impl_metal.mm`

The demo source is intentionally excluded.

## 3. Communication model before the fix

The previous architecture had three potential input producers:

1. UIKit touch callbacks on the dedicated touch proxy.
2. Touch callbacks on the Metal view, despite the Metal view being configured not to capture input.
3. A global HID callback acting as a fallback.

At the same time, the visual window and touch window were separate. The render window correctly remained pass-through, but the dedicated input window was configured with `_usesWindowServerHitTesting = NO`, contradicting its role as the event owner.

The fallback also rediscovered the input window by enumerating `UIApplication.windows` and looking for a class name. That is brittle for hosted/plugin window configurations.

## 4. Root-cause model

### Root cause A — input window hit-testing

`HUDTouchWindow` was created to receive input but had window-server hit testing disabled. This could leave the touch proxy visually present without becoming the system's selected touch destination.

### Root cause B — duplicated input paths

UIKit, the Metal view, and HID could all manipulate the same ImGui mouse state. Multiple writers make event ordering harder to reason about.

### Root cause C — per-frame asynchronous geometry updates

The physical touch-window frame was updated from the Metal render loop and dispatched to the main queue on every update. This adds latency and makes geometry ownership dependent on rendering cadence.

### Root cause D — fast tap race

A touch can begin and end between two ImGui render callbacks. If the code only stores the current boolean state, both observed frames may see `MouseDown == false`, so the button never sees the press transition.

## 5. Fix architecture

The repaired flow is:

`UIKit touch → HUDTouchWindow → HUDTouchProxyView → HUDInjectImGuiTouchAtScreenPoint → ImGui IO → render frame`

The render window is visual-only. The touch window is the only interactive surface, and its frame is restricted to the actual ImGui panel (or the restore hotspot while minimized/hidden).

The HID callback remains a fallback rather than the primary path. It consumes the live touch-window geometry through `HUDGetTouchWindowState` and no longer performs fragile `UIApplication.windows` class-name discovery.

## 6. Hit-testing rules

- Full-screen `HUDMainWindow`: never captures touch.
- Dedicated `HUDTouchWindow`: participates in hit-testing.
- `HUDTouchProxyView`: accepts points inside its own bounds.
- Touch-window frame: follows the actual panel/hotspot screen rectangle.
- Outside the touch window: the HUD does not claim the touch, allowing the underlying application to remain interactive.

## 7. Coordinate contract

All input bridges now use screen-space input as the common handoff format. The ImGui host converts that point exactly once into its local coordinate system.

The old delegate-side conversion was simplified to UIKit's direct `convertPoint:toView:nil` API, preventing manual origin arithmetic from drifting when the view hierarchy changes.

## 8. Press/release state machine

`HUDInjectImGuiTouchAtScreenPoint` maintains:

- current point;
- current held state;
- a one-frame pending press;
- a one-frame pending release.

A normal tap becomes:

`Began → press latch → ImGui frame sees down → Ended → following frame sees release`.

A cancelled touch becomes:

`Began → Cancelled → pending press discarded → released`.

Therefore cancellation cannot synthesize a click.

## 9. Dear ImGui compatibility decision

The vendored ImGui sources are from a 1.83 WIP-era API and do not contain the newer `AddMousePosEvent` / `AddMouseButtonEvent` / `AddMouseSourceEvent` helpers. The release therefore keeps the compatible `MousePos` / `MouseDown` fields rather than introducing APIs the bundled source does not implement.

## 10. Threading contract

UIKit/window operations remain main-thread owned. `HUDSetTouchWindowFrame` applies immediately on the main thread and asynchronously dispatches only when called from another thread.

The existing C bridges that mutate HUD state now use a small `HUDRunOnMain` helper. Calls already made by the main-thread render loop execute immediately rather than enqueueing a block for every frame.

## 11. Metal/render safety

The no-render-pass path previously contained a duplicate command-buffer commit. The duplicate call was removed so the error path has a single commit.

Touch input is consumed before the frame is rendered, which ensures the current ImGui frame observes the press latch deterministically.

## 12. Build-system audit

Theos source compilation is explicit. Legacy synthetic touch files are intentionally absent from the production source list:

- `TSEventFetcher.mm`
- `IOHIDEvent+KIF.m`
- `UITouch-KIFAdditions.m`

The source inventory was checked for missing production files. The pinned target remains iOS 15.0 minimum with the 15.6 SDK contract used by CI.

## 13. Resource/package audit

The release contains `Resources/Info.plist`, `Resources/icon.png`, and `ent.plist`. The Makefile stages `Excalibur.app` and generates `packages/LGLInspired.tipa` after staging.

The repository workflow independently creates `output/Excalibur.ipa` after validating the staged app bundle.

## 14. Regression checklist

Static checks performed on this release:

- project build contract: PASS;
- production source inventory: PASS (15/15 present);
- property-list parsing: PASS;
- vendored Dear ImGui C++ host syntax: PASS;
- Theos Makefile dry-run with a minimal Theos contract: PASS;
- legacy source exclusion checks: PASS;
- touch-window hit-testing invariant: PASS;
- live touch-window bridge invariant: PASS;
- fast-tap latch invariant: PASS;
- cancellation invariant: PASS;
- duplicate Metal commit removed: PASS.

## 15. Device-level matrix

The authoritative iOS test still needs a real arm64 device/runtime. The matrix is:

1. Open menu.
2. Tap `TESTE`.
3. Toggle each checkbox.
4. Drag the header.
5. Tap outside the menu and confirm the underlying app receives the touch.
6. Perform a very fast tap.
7. Trigger an interrupted/cancelled touch and confirm no click is synthesized.
8. Hide/minimize and tap the restore hotspot.
9. Rotate the interface and retest panel alignment.
10. Background/foreground the process and ensure no touch remains stuck.

## 16. Release engineering conclusion

The critical input problem is addressed at the architectural layer rather than by making the Metal view globally interactive. The visual overlay remains transparent to unrelated touches; only the dedicated input rectangle participates in hit-testing.

The source is prepared for a Theos/macOS build, but this Linux environment does not contain Xcode or Apple's iOS SDK, so a real arm64 compile cannot honestly be claimed here. The included macOS GitHub Actions workflow remains the authoritative build environment.
