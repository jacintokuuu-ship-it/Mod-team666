# ESP V5 diagnostic chain

## Confirmed from supplied dump

- `GameFacade.m_UIModelMatch` = `0x318`
- `GameFacade.get_UIModelMatch()` RVA = `0x592ED30`
- `UIModelMatch.LocalTeamId` = `0x11C`
- `UIModelMatch.m_PlayerDataList` = `0x1F0`
- `PlayerData.player` = `0x100`
- `PlayerData.lastPosition` = `0xDC`
- `PlayerData.isDead` = `0x6C`
- `PlayerData.gsTeamId` = `0x34`
- `PlayerData.scTeamId` = `0x35`
- `Player.AHNCPOJPPCL` (`FollowCamera`) = `0x690`
- `Player.BDMMCNJOHNI` (`Transform`) = `0x700`
- `CameraControllerBase.AFMGCAELKBD` (`TargetCamera`) = `0x30`

## Pipeline corrections

1. External snapshot is refreshed at 60 Hz through the HUD timer.
2. Timer is installed in `NSRunLoopCommonModes` so touch/menu interaction does not stop updates.
3. ESP layout no longer depends on the test-mode integer; visibility follows the actual ESP enable flag.
4. `WorldToScreen()` already returns top-left screen coordinates, so the renderer no longer flips Y a second time.
5. Existing UIKit ESP container remains the drawing surface used by the HUD.

## Still external-runtime dependent

The Unity native camera matrix offset (`CameraViewProjectionMatrixOffset = 0x100`) is not an IL2CPP field offset exposed by the supplied C# dump. It remains a runtime-reference value and therefore is not labeled as dump-confirmed.
