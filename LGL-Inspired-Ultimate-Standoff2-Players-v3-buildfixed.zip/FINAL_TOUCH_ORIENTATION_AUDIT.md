# MAKTER BR 2.2.0 — Final Touch/Orientation Audit

## Reference comparison

Compared the supplied project against `TrollSpeed-2.0-13` specifically in:

- `HUDRootViewController` orientation handling.
- `HUDMainWindow` lifecycle.
- `HUDApp` AX event hit-testing.
- `TSEventFetcher` synthetic touch creation and coordinate semantics.

## Final design

1. `HUDMainWindow` is a normal `UIWindow`; it is not an auto-rotating private window subclass.
2. `HUDRootViewController` is a normal `UIViewController`; rotation is explicitly driven by `FBSOrientationObserver`.
3. `updateOrientation:` swaps the root view bounds in landscape and applies one `CGAffineTransformMakeRotation`.
4. The AX `location` is passed unchanged to `hitTest:` and `TSEventFetcher`, matching the supplied reference.
5. The previous deterministic direct-touch router is no longer on the event path.
6. The ESP view remains unrotated locally and follows the parent root view.
7. Menu controls use normal UIKit hit-testing and gesture recognition, so button bounds and pan translations stay in the same coordinate system as the rendered menu.

## Static validation

- ZIP archive passes `unzip -t`.
- Edited Objective-C/Objective-C++ files have balanced braces/parentheses.
- No remaining `HUDRouteTouch` or `atWindowCoordinate` references exist in compiled source.
- Only the root HUD orientation method contains `CGAffineTransformMakeRotation`.

A device-side Theos/Xcode build remains necessary for the actual iOS binary because this Linux environment does not contain the iPhoneOS SDK.
