# MAKTER BR 2.1.0 — Final Touch/Orientation Audit

## Root cause
The HUD was drawn inside a UIWindow rotated with a CGAffineTransform while
the AX touch stream was already expressed in the active screen coordinate
space. Visual rotation therefore succeeded while hit testing and drag
coordinates could be offset or rotated relative to the visible controls.

## Fix
`HUDMainWindow` now:
- keeps `transform = CGAffineTransformIdentity`;
- sizes itself from `UIScreen.coordinateSpace.bounds`;
- chooses portrait/landscape dimensions from the display long/short sides;
- updates the root view using the resulting window bounds.

Touch flow remains:
AX screen point -> `HUDMainWindow convertPoint:fromView:nil` -> root/menu
local coordinates.

No additional 90/180 degree transform is applied to touch points.

## Static checks
The active HUD source contains no `CGAffineTransformMakeRotation` call.
The ESP overlay also no longer contains a rotation helper.
The archive is source-complete for the existing Theos Makefile.

A real iPhoneOS arm64 compilation was not performed because this environment
does not contain the iPhoneOS SDK/Theos toolchain.
