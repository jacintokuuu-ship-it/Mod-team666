#import <cstddef>
#import <cstring>
#import <cstdlib>
#import <dlfcn.h>
#import <spawn.h>
#import <unistd.h>
#import <signal.h>
#import <string.h>
#import <sys/param.h>
#import <sys/sysctl.h>
#import <sys/utsname.h>
#import <mach-o/dyld.h>
#import <objc/runtime.h>
#import <CoreFoundation/CoreFoundation.h>
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


#pragma mark -

typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDNotification *IOHIDNotificationRef;
typedef struct __IOHIDService *IOHIDServiceRef;
typedef struct __GSEvent *GSEventRef;

#if __cplusplus
extern "C" {
#endif
void *BKSHIDEventRegisterEventCallback(void (*)(void *, void *, IOHIDServiceRef, IOHIDEventRef));
void UIApplicationInstantiateSingleton(id aclass);
void UIApplicationInitialize();
void BKSDisplayServicesStart();
void GSInitialize();
void GSEventInitialize(Boolean registerPurple);
void GSEventPopRunLoopMode(CFStringRef mode);
void GSEventPushRunLoopMode(CFStringRef mode);
void GSEventRegisterEventCallBack(void (*)(GSEventRef));
#if __cplusplus
}
#endif


#pragma mark -

@interface UIApplication (Private)
- (id)_systemAnimationFenceExemptQueue;
- (void)_accessibilityInit;
- (void)_enqueueHIDEvent:(IOHIDEventRef)event;
- (void)__completeAndRunAsPlugin;
@end

@interface UIEventFetcher : NSObject
- (void)_receiveHIDEvent:(IOHIDEventRef)arg1;
@end

@interface AXEventPathInfoRepresentation : NSObject
@property (nonatomic, readonly) unsigned char pathIdentity;
@end

@interface AXEventHandInfoRepresentation : NSObject
- (NSArray <AXEventPathInfoRepresentation *> *)paths;
@end

@interface AXEventRepresentation : NSObject
@property (nonatomic, readonly) BOOL isTouchDown; 
@property (nonatomic, readonly) BOOL isMove; 
@property (nonatomic, readonly) BOOL isChordChange; 
@property (nonatomic, readonly) BOOL isLift; 
@property (nonatomic, readonly) BOOL isInRange; 
@property (nonatomic, readonly) BOOL isInRangeLift; 
@property (nonatomic, readonly) BOOL isCancel; 
+ (instancetype)representationWithHIDEvent:(IOHIDEventRef)event hidStreamIdentifier:(NSString *)identifier;
- (AXEventHandInfoRepresentation *)handInfo;
- (CGPoint)location;
@end


#pragma mark -

#import "TSEventFetcher.h"



static NSString *HUDDeviceModel(void)
{
    struct utsname systemInfo;
    uname(&systemInfo);
    return [NSString stringWithCString:systemInfo.machine encoding:NSUTF8StringEncoding];
}

static __used void _HUDEventCallback(void *target, void *refcon, IOHIDServiceRef service, IOHIDEventRef event)
{
    (void)target;
    (void)refcon;
    (void)service;

    static UIApplication *app = [UIApplication sharedApplication];
    if (!app || !event) return;

    // Match the proven TrollSpeed split: modern systems consume the global HID
    // stream through AXEventRepresentation; older 15.0 combinations fall back
    // to UIKit's own HID enqueue path.
    BOOL useAX = NO;
    if (@available(iOS 15.0, *)) {
        useAX = YES;
        NSOperatingSystemVersion version = [NSProcessInfo.processInfo operatingSystemVersion];
        if (version.majorVersion == 15 && version.minorVersion == 0 && version.patchVersion == 0) {
            NSString *model = HUDDeviceModel();
            // Match the reference split used by TrollSpeed for the original
            // iOS 15.0 device families.
            useAX = ([model hasPrefix:@"iPhone13,"] || [model hasPrefix:@"iPhone14,"]);
        }
    }

    if (!useAX) {
        [app _enqueueHIDEvent:event];
        return;
    }

    static Class AXEventRepresentationCls = Nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        [[NSBundle bundleWithPath:@"/System/Library/PrivateFrameworks/AccessibilityUtilities.framework"] load];
        AXEventRepresentationCls = objc_getClass("AXEventRepresentation");
    });
    if (!AXEventRepresentationCls) {
#if DEBUG
        os_log_error(OS_LOG_DEFAULT, "HUD input: AXEventRepresentation class unavailable");
#endif
        return;
    }

    AXEventRepresentation *rep = [AXEventRepresentationCls representationWithHIDEvent:event hidStreamIdentifier:@"UIApplicationEvents"];
    if (!rep) {
#if DEBUG
        os_log_error(OS_LOG_DEFAULT, "HUD input: AXEventRepresentation could not decode HID event");
#endif
        return;
    }

    UITouchPhase phase = UITouchPhaseEnded;
    if (rep.isTouchDown)
        phase = UITouchPhaseBegan;
    else if (rep.isMove || rep.isChordChange)
        phase = UITouchPhaseMoved;
    else if (rep.isCancel)
        phase = UITouchPhaseCancelled;
    else if (rep.isLift || rep.isInRange || rep.isInRangeLift)
        phase = UITouchPhaseEnded;

    AXEventHandInfoRepresentation *handInfo = rep.handInfo;
    NSArray<AXEventPathInfoRepresentation *> *paths = handInfo.paths;
    AXEventPathInfoRepresentation *path = paths.firstObject;
    if (!path) {
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT, "HUD input: AX event has no hand path");
#endif
        return;
    }

    NSInteger pointerId = (NSInteger)path.pathIdentity;
    if (pointerId <= 0) {
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT, "HUD input: invalid AX path identity %ld", (long)pointerId);
#endif
        return;
    }

    // Keep the same practical range used by the reference implementation so a
    // corrupt accessibility path can never create an uncontrolled touch slot.
    pointerId = MIN(MAX(pointerId, 1), 98);
    CGPoint location = rep.location;
    dispatch_async(dispatch_get_main_queue(), ^{
        UIWindow *hudWindow = nil;
        for (UIWindow *window in app.windows.reverseObjectEnumerator) {
            if ([NSStringFromClass(window.class) isEqualToString:@"HUDMainWindow"]) {
                hudWindow = window;
                break;
            }
        }
        if (!hudWindow) hudWindow = app.windows.lastObject ?: app.keyWindow;
        if (!hudWindow) {
#if DEBUG
            os_log_error(OS_LOG_DEFAULT, "HUD input: no HUD window available for HID sample");
#endif
            return;
        }

        UIView *hitView = [hudWindow hitTest:location withEvent:nil];
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT,
                     "HUD input route id=%ld phase=%ld global=(%.1f,%.1f) hit=%{public}@ window=%{public}@",
                     (long)pointerId, (long)phase, location.x, location.y,
                     hitView ? NSStringFromClass(hitView.class) : @"<nil>",
                     NSStringFromClass(hudWindow.class));
#endif
        [TSEventFetcher receiveAXEventID:pointerId
                       atGlobalCoordinate:location
                           withTouchPhase:phase
                                 inWindow:hudWindow
                                   onView:hitView];
    });
}


static NSString *_cachesDirectoryPath = nil;
static NSString *_hudPIDFilePath = nil;
static NSString *GetPIDFilePath(void)
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _cachesDirectoryPath = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES) firstObject];
        _hudPIDFilePath = [_cachesDirectoryPath stringByAppendingPathComponent:@"hud.pid"];
    });
    return _hudPIDFilePath;
}

int main(int argc, char *argv[])
{
    @autoreleasepool
    {
#if DEBUG
        os_log_debug(OS_LOG_DEFAULT, "launched argc %{public}d, argv[1] %{public}s", argc, argc > 1 ? argv[1] : "NULL");
#endif

        if (argc <= 1)
            return UIApplicationMain(argc, argv, @"MainApplication", @"MainApplicationDelegate");
        
        if (strcmp(argv[1], "-hud") == 0)
        {
            NSString *pidString = [NSString stringWithFormat:@"%d", getpid()];
            [pidString writeToFile:GetPIDFilePath()
                        atomically:YES
                          encoding:NSUTF8StringEncoding
                             error:nil];
            
            [UIScreen initialize];
            CFRunLoopGetCurrent();

            GSInitialize();
            BKSDisplayServicesStart();
            UIApplicationInitialize();

            UIApplicationInstantiateSingleton(objc_getClass("HUDMainApplication"));
            static id<UIApplicationDelegate> appDelegate = [[objc_getClass("HUDMainApplicationDelegate") alloc] init];
            [UIApplication.sharedApplication setDelegate:appDelegate];
            [UIApplication.sharedApplication _accessibilityInit];

            [NSRunLoop currentRunLoop];
            BKSHIDEventRegisterEventCallback(_HUDEventCallback);

            if (@available(iOS 15.0, *)) {
                GSEventInitialize(0);
                GSEventPushRunLoopMode(kCFRunLoopDefaultMode);
            }
            
            [UIApplication.sharedApplication __completeAndRunAsPlugin];
            
            CFRunLoopRun();
            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-exit") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                kill(pid, SIGKILL);
                unlink(GetPIDFilePath().UTF8String);
            }

            return EXIT_SUCCESS;
        }
        else if (strcmp(argv[1], "-check") == 0)
        {
            NSString *pidString = [NSString stringWithContentsOfFile:GetPIDFilePath()
                                                            encoding:NSUTF8StringEncoding
                                                               error:nil];
            
            if (pidString)
            {
                pid_t pid = (pid_t)[pidString intValue];
                int killed = kill(pid, 0);
                return (killed == 0 ? EXIT_FAILURE : EXIT_SUCCESS);
            }
            else return EXIT_SUCCESS;  // No PID file, so HUD is not running
        }
    }
}