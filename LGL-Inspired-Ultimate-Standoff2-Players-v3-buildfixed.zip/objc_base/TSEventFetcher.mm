#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "TSEventFetcher.h"
#import "UIApplication+Private.h"
#import "UIEvent+Private.h"
#import "UITouch-KIFAdditions.h"

// Touch state is kept by HID pointer identity. Delivery is serialized on the
// main thread so every UIEvent sees the exact UITouch state for that sample;
// queuing mutable UITouch objects for later delivery can otherwise cause old
// queued events to observe a newer phase/coordinate.
static NSMutableDictionary<NSNumber *, UITouch *> *gTouchesByID = nil;

@implementation TSEventFetcher

+ (void)load
{
    gTouchesByID = [NSMutableDictionary dictionary];
}

+ (NSInteger)receiveAXEventID:(NSInteger)eventId
           atGlobalCoordinate:(CGPoint)coordinate
               withTouchPhase:(UITouchPhase)phase
                     inWindow:(UIWindow *)window
                       onView:(UIView *)view
{
    if (!window || eventId <= 0) {
        return 0;
    }

    // All UITouch/UIEvent mutation and UIApplication sendEvent: must happen on
    // the main thread. The HID callback already normally arrives here, but this
    // guard makes the class safe for any direct caller too.
    if (![NSThread isMainThread]) {
        __weak typeof(self) weakSelf = self;
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf receiveAXEventID:eventId
                     atGlobalCoordinate:coordinate
                         withTouchPhase:phase
                               inWindow:window
                                 onView:view];
        });
        return 0;
    }

    if (!gTouchesByID) {
        gTouchesByID = [NSMutableDictionary dictionary];
    }

    // Preserve the full AX pointer identity so concurrent touches do not alias.
    NSNumber *key = @(eventId);
    UITouch *touch = gTouchesByID[key];

    if (!touch) {
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            return 0;
        }

        UIView *targetView = view;
        if (!targetView) {
            targetView = [window hitTest:coordinate withEvent:nil];
        }

        // A nil target means the HUD intentionally passed this coordinate
        // through. Do not manufacture a UITouch that could consume it.
        if (!targetView) {
            return 0;
        }

        touch = [[UITouch alloc] initAtPoint:coordinate inWindow:window onView:targetView];
        if (!touch) return 0;
        gTouchesByID[key] = touch;
    } else {
        [touch setLocationInWindow:coordinate];
    }

    [touch setPhaseAndUpdateTimestamp:phase];

    UIApplication *app = [UIApplication sharedApplication];
    if (!app) {
        return 0;
    }

    UIEvent *event = [app _touchesEvent];
    if (!event) {
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            [gTouchesByID removeObjectForKey:key];
        }
        return 0;
    }

    [event _clearTouches];
    for (UITouch *activeTouch in gTouchesByID.allValues) {
        [event _addTouch:activeTouch forDelayedDelivery:NO];
    }
    [app sendEvent:event];

    if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
        [gTouchesByID removeObjectForKey:key];
    }

    return 0;
}

@end
