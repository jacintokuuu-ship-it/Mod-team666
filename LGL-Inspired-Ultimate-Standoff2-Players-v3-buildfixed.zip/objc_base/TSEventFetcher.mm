#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <dlfcn.h>
#import <string.h>
#import "TSEventFetcher.h"
#import "UIEvent+Private.h"
#import "UITouch-KIFAdditions.h"
#import "UIApplication+Private.h"

// This follows the proven TrollSpeed/KIF pattern:
// HID callback updates a stable touch object, then signals a main-run-loop source.
// UIKit consumes the touch from that source instead of receiving a UIEvent directly
// from the HID callback thread.
static NSArray *gSafeTouchArray = nil;
static NSMutableArray *gTouchArray = nil;      // 100 pointer slots; NSNull means unused.
static NSMutableArray *gLivingTouchArray = nil;
static CFRunLoopSourceRef gEventSource = NULL;

static UITouch *gTouchToRemove = nil;
static UITouch *gTouchToStationarify = nil;

static void HUDTouchRunLoopSourceCallback(void *info)
{
    (void)info;

    UIApplication *app = [UIApplication sharedApplication];
    if (!app) {
        return;
    }

    UIEvent *event = [app _touchesEvent];
    if (!event) {
        return;
    }

    [event _clearTouches];

    NSArray *touches = gSafeTouchArray;
    for (UITouch *touch in touches) {
        switch (touch.phase) {
            case UITouchPhaseEnded:
            case UITouchPhaseCancelled:
                gTouchToRemove = touch;
                break;

            case UITouchPhaseBegan:
                gTouchToStationarify = touch;
                break;

            default:
                break;
        }

        [event _addTouch:touch forDelayedDelivery:NO];
    }

    [app sendEvent:event];

    // Deliberately defer touch cleanup/stationarization until the next HID
    // sample. This mirrors the reference implementation and avoids mutating
    // the living-touch collection while UIKit is still processing this event.
}

@implementation TSEventFetcher

+ (void)load
{
    gLivingTouchArray = [[NSMutableArray alloc] initWithCapacity:10];
    gTouchArray = [[NSMutableArray alloc] initWithCapacity:100];

    // Keep exactly 100 pointer slots, but do not call the private initTouch
    // helper during +load. That helper expects a connected UIWindowScene and a
    // system HUD process may intentionally have no scene. Touch objects are
    // created lazily from the real HUD window on the first Began event.
    for (NSInteger i = 0; i < 100; i++) {
        [gTouchArray addObject:[NSNull null]];
    }

    CFRunLoopSourceContext context;
    memset(&context, 0, sizeof(context));
    context.perform = HUDTouchRunLoopSourceCallback;

    gEventSource = CFRunLoopSourceCreate(kCFAllocatorDefault, -2, &context);
    if (gEventSource) {
        CFRunLoopAddSource(CFRunLoopGetMain(), gEventSource, kCFRunLoopCommonModes);
    }
}

+ (NSInteger)receiveAXEventID:(NSInteger)eventId
           atWindowCoordinate:(CGPoint)coordinate
               withTouchPhase:(UITouchPhase)phase
                     inWindow:(UIWindow *)window
                       onView:(UIView *)view
{
    if (!window || eventId <= 0 || eventId > 100 || gTouchArray.count != 100) {
        return 0;
    }

    BOOL deleted = NO;
    BOOL needsCopy = NO;
    UITouch *touch = nil;

    if (gTouchToRemove) {
        touch = gTouchToRemove;
        gTouchToRemove = nil;
        [gLivingTouchArray removeObjectIdenticalTo:touch];
        deleted = YES;
        needsCopy = YES;
    }

    if (gTouchToStationarify) {
        touch = gTouchToStationarify;
        gTouchToStationarify = nil;

        if (touch.phase == UITouchPhaseBegan) {
            [touch setPhaseAndUpdateTimestamp:UITouchPhaseStationary];
        }
    }

    NSInteger index = eventId - 1;
    id slot = gTouchArray[index];
    touch = ([slot isKindOfClass:[UITouch class]] ? slot : nil);

    BOOL oldState = (touch != nil && [gLivingTouchArray containsObject:touch]);
    BOOL newState = !oldState;

    if (newState) {
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            return deleted;
        }

        if (!view) {
            return deleted;
        }

        touch = [[UITouch alloc] initAtPoint:coordinate
                                    inWindow:window
                                      onView:view];
        if (!touch) {
            return deleted;
        }

        [gLivingTouchArray addObject:touch];
        [gTouchArray setObject:touch atIndexedSubscript:index];
        needsCopy = YES;
    } else {
        // Ignore a synthetic Moved that arrived before UIKit consumed the
        // corresponding Began.
        if (touch.phase == UITouchPhaseBegan && phase == UITouchPhaseMoved) {
            return deleted;
        }

        [touch setLocationInWindow:coordinate];
    }

    [touch setPhaseAndUpdateTimestamp:phase];

    if (needsCopy || !gSafeTouchArray) {
        // The local snapshot is replaced atomically from UIKit's perspective;
        // retaining it across the run-loop turn prevents premature release.
        gSafeTouchArray = [gLivingTouchArray copy];
    }

    if (gEventSource) {
        CFRunLoopSourceSignal(gEventSource);
        CFRunLoopWakeUp(CFRunLoopGetMain());
    } else {
        HUDTouchRunLoopSourceCallback(NULL);
    }

    return deleted;
}

@end
