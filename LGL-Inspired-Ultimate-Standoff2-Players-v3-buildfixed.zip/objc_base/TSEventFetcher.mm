#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import "TSEventFetcher.h"
#import "UIApplication+Private.h"
#import "UIEvent+Private.h"
#import "UITouch-KIFAdditions.h"

// UIKit expects synthetic touches to be delivered from its event/run-loop
// pipeline.  Sending a mutable UIEvent directly from the HID callback is
// unreliable on modern iOS: the next HID sample can mutate the same UITouch
// before UIKit has consumed the previous event.  Keep a stable snapshot and
// wake a main-run-loop source, following the architecture used by TrollSpeed.
static NSMutableDictionary<NSNumber *, UITouch *> *gTouchesByID = nil;
static NSMutableSet<NSNumber *> *gTouchesPendingRemoval = nil;
static NSArray<UITouch *> *gSafeTouches = nil;
static CFRunLoopSourceRef gEventSource = NULL;

static void TSEventFetcherRunLoopSourceCallback(void *info)
{
    (void)info;

    if (![NSThread isMainThread]) {
        return;
    }

    UIApplication *app = [UIApplication sharedApplication];
    NSArray<UITouch *> *touches = gSafeTouches;
    if (!app || touches.count == 0) {
        gSafeTouches = nil;
        [gTouchesPendingRemoval removeAllObjects];
        return;
    }

    UIEvent *event = [app _touchesEvent];
    if (!event) {
        // Do not leave ended/cancelled pointer identities permanently alive
        // when UIKit refuses to provide a reusable touch event object.
        if (gTouchesPendingRemoval.count != 0) {
            for (NSNumber *key in gTouchesPendingRemoval.copy) {
                [gTouchesByID removeObjectForKey:key];
            }
            [gTouchesPendingRemoval removeAllObjects];
        }
        gSafeTouches = nil;
        return;
    }

    [event _clearTouches];
    for (UITouch *touch in touches) {
        [event _addTouch:touch forDelayedDelivery:NO];
    }

    [app sendEvent:event];

    if (gTouchesPendingRemoval.count != 0) {
        for (NSNumber *key in gTouchesPendingRemoval.copy) {
            [gTouchesByID removeObjectForKey:key];
        }
        [gTouchesPendingRemoval removeAllObjects];
    }

    gSafeTouches = nil;
}

@implementation TSEventFetcher

+ (void)load
{
    gTouchesByID = [NSMutableDictionary dictionaryWithCapacity:16];
    gTouchesPendingRemoval = [NSMutableSet setWithCapacity:8];

    CFRunLoopSourceContext context = {0};
    context.version = 0;
    context.info = NULL;
    context.perform = TSEventFetcherRunLoopSourceCallback;

    gEventSource = CFRunLoopSourceCreate(kCFAllocatorDefault, 0, &context);
    if (gEventSource) {
        CFRunLoopAddSource(CFRunLoopGetMain(), gEventSource, kCFRunLoopCommonModes);
    }
}

+ (NSInteger)receiveAXEventID:(NSInteger)eventId
           atGlobalCoordinate:(CGPoint)coordinate
               withTouchPhase:(UITouchPhase)phase
                     inWindow:(UIWindow *)window
                       onView:(UIView *)view
{
    if (!window || eventId <= 0) {
        return 0;
    }

    if (![NSThread isMainThread]) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [TSEventFetcher receiveAXEventID:eventId
                          atGlobalCoordinate:coordinate
                              withTouchPhase:phase
                                    inWindow:window
                                      onView:view];
        });
        return 0;
    }

    if (!gTouchesByID) {
        gTouchesByID = [NSMutableDictionary dictionaryWithCapacity:16];
    }
    if (!gTouchesPendingRemoval) {
        gTouchesPendingRemoval = [NSMutableSet setWithCapacity:8];
    }

    // AX path identities are small unsigned values, but malformed/foreign
    // events should never create an unbounded dictionary entry.
    NSInteger normalizedID = MIN(MAX(eventId, 1), 98);
    NSNumber *key = @(normalizedID);
    UITouch *touch = gTouchesByID[key];

    if (!touch) {
        // An Ended/Cancelled event without a corresponding Began is ignored.
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            return 0;
        }

        UIView *targetView = view;
        if (!targetView) {
            targetView = [window hitTest:coordinate withEvent:nil];
        }

        // A nil hit view deliberately means that the HUD is transparent at
        // this point. Do not manufacture a touch that would consume it.
        if (!targetView) {
            return 0;
        }

        touch = [[UITouch alloc] initAtPoint:coordinate
                                    inWindow:window
                                      onView:targetView];
        if (!touch) {
            return 0;
        }
        gTouchesByID[key] = touch;
    } else {
        [touch setLocationInWindow:coordinate];
    }

    [touch setPhaseAndUpdateTimestamp:phase];

    // Snapshot the exact UITouch objects for this sample. UIKit consumes them
    // on the run-loop source below, not directly inside the HID callback.
    gSafeTouches = [gTouchesByID.allValues copy];

#if DEBUG
    os_log_debug(OS_LOG_DEFAULT,
                 "HUD touch sample id=%ld phase=%ld x=%.1f y=%.1f active=%lu",
                 (long)normalizedID, (long)phase, coordinate.x, coordinate.y,
                 (unsigned long)gSafeTouches.count);
#endif

    if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
        [gTouchesPendingRemoval addObject:key];
    } else {
        [gTouchesPendingRemoval removeObject:key];
    }

    if (gEventSource) {
        CFRunLoopSourceSignal(gEventSource);
        CFRunLoopWakeUp(CFRunLoopGetMain());
    } else {
        // Defensive fallback for unusual initialization order. Keep this
        // direct path only when the run-loop source could not be created.
        TSEventFetcherRunLoopSourceCallback(NULL);
    }

    return 0;
}

@end
