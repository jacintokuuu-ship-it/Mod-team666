# External Funcional v3 — ESP Line + ESP Box

## Runtime chain

`FreeFire process -> task_t -> UnityFramework -> GameFacade.get_UIModelSpectator()`

`UIModelSpectator + 0x30 -> m_PlayerDic`

`Dictionary entries -> PlayerData`

`PlayerData + 0xDC -> lastPosition`

`PlayerData + 0x100 -> Player`

`Player + 0x690 -> FollowCamera -> CameraControllerBase + 0x30 -> TargetCamera`

`TargetCamera + 0x10 -> Unity internal -> +0x100 -> view/projection matrix`

The player list and object/field offsets above come from the supplied Free Fire dump. The external Transform/matrix math follows the XternalZ reference project's runtime layout.

## ESP output

- Line: bottom-center of HUD -> player feet.
- Box: projected feet/head rectangle, width derived from projected height.
- Team Check: uses the player owning the live FollowCamera as the local player and filters matching team IDs.
- Pixel/point conversion: Unity screen coordinates are pixels; the HUD layer is UIKit points, so the snapshot converts by screen scale.

Unity documents `Camera.WorldToScreenPoint` as pixel-based with a lower-left origin and camera-relative z depth; the renderer converts that coordinate convention before drawing.

## Verification

`make package` still requires the iPhoneOS SDK + Theos. This environment can inspect and statically validate the project, but it cannot honestly claim a device build or live Free Fire validation.
