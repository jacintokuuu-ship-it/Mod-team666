# ESP LINE — estado da atualização

Esta atualização incorpora os dados confirmados pelo estudo anexado e não fabrica uma cadeia runtime que o estudo não comprova.

## Alterações
- Offsets.h recebeu os RVAs confirmados de GameFacade, MatchGame, AttackableEntity e JMAG.
- Os antigos `0x25401`/`0x25402` foram removidos como RVAs de team não confirmados.
- O diagnóstico agora testa os RVAs confirmados relevantes.
- O reader deixa explícito que RVA legível não significa método chamável.
- O snapshot continua sem coordenadas sintéticas.

## Limitação que permanece
O estudo informa que ainda precisam ser validados em runtime:
1. endereço da instância JMAGGLCNGIG;
2. qual coleção de Player é authoritative;
3. layout físico concreto de List/Dictionary da build;
4. obtenção read-only da posição/câmera/projeção.

Por isso esta atualização não declara ESP LINE end-to-end funcional. O renderer já consome `ESPExternalSnapshot`; a etapa pendente é a aquisição runtime real.
