# XternalZ v9 — Native HUD Refactor

Revisão do projeto XternalZ baseada no pipeline de HUD/eventos estudado no TrollSpeed.

### Objetivo

Manter o motor existente de processo/task/leitura/Unity/ESP e substituir a forma como o menu é criado e recebe entrada.

### Menu

O menu principal agora usa UIKit nativo. Isso remove a dependência da antiga `MTKView` fullscreen para hit-testing e deixa os controles como `UIButton`/`UISwitch` reais dentro de um painel com frame próprio. Os arquivos ImGui antigos continuam no repositório, mas não são compilados pelo target atual.

### Input

A cadeia global continua:

`HID -> AXEventRepresentation -> TSEventFetcher -> UITouch/UIEvent -> UIApplication -> UIKit hitTest`

O `TSEventFetcher` usa um estado por ponteiro para suportar eventos concorrentes de forma mais previsível.

### Motor preservado

`tasks/pid.mm`, `functions/Teste.mm`, `functions/Offsets.h`, `unity/unity.mm` e `overlay/ESPImGuiView.mm` continuam sendo os módulos existentes do projeto.

### Entitlements / ambiente

O pacote continua destinado ao ambiente privilegiado para o qual o projeto original foi concebido. A revisão não adiciona novos privilégios nem promete compatibilidade universal com entitlements de versões futuras do iOS.

### Versão

1.9.0-native-hud


### Build-integrity pass

The current source includes the typed AX path fix that addresses the reported `property 'pathIdentity' not found on object of type 'id _Nullable'` error, spawn failure checks, explicit C/C++ standard headers, safer remote image enumeration, and a cleaned native-menu scroll hierarchy. The legacy ImGui files are retained for reference but excluded from the active build.
