# LGL Inspired — Free Fire External HUD v3

Esta revisão reproduz a arquitetura externa do XternalZ: aplicativo separado, acesso ao processo por `task_t`/Mach VM e desenho do HUD fora do Free Fire.

## Verificar

O botão **VERIFICAR — ACESSO AO FREE FIRE** mostra um toast com diagnóstico objetivo: processo encontrado, task aberta, `UnityFramework`, cabeçalho Mach-O e quantidade de RVAs legíveis.

## Sem injetor

O build padrão não contém tweak, dylib injetada nem hook interno.

## Estado do ESP Line + Box

A cadeia externa agora usa `GameFacade.get_UIModelSpectator()` → `UIModelSpectator.m_PlayerDic` → `PlayerData` para preencher o snapshot ao vivo. O HUD desenha Line e Box a partir das coordenadas projetadas. A câmera é resolvida preferencialmente por `Player.FollowCamera` → `CameraControllerBase.TargetCamera`, com `Camera.main` apenas como fallback de resolução.
