# LGL Inspired — Free Fire External HUD

Esta revisão reproduz a arquitetura externa do XternalZ: aplicativo separado, acesso ao processo por `task_t`/Mach VM e desenho do HUD fora do Free Fire.

## Verificar

O botão **VERIFICAR — ACESSO AO FREE FIRE** mostra um toast com diagnóstico objetivo: processo encontrado, task aberta, `UnityFramework`, cabeçalho Mach-O e quantidade de RVAs legíveis.

## Sem injetor

O build padrão não contém tweak, dylib injetada nem hook interno.

## Estado do ESP Line

A infraestrutura de desenho está preparada, porém a enumeração de entidades live ainda não é simulada. Para mostrar linhas sobre jogadores reais é necessário ligar a cadeia externa de jogadores ao snapshot.


## STRUCTURAL LIMITATION
The supplied ZIP does not contain the structural game dump referenced by `Offsets.h`. Therefore live entity/camera/W2S enumeration is not claimed as confirmed. The external reader remains read-only and will not execute code inside the target as a workaround.
