# MAKTER BR v9 — Native HUD Refactor

Revisão do projeto MAKTER BR baseada no pipeline de HUD/eventos estudado no TrollSpeed.

### Objetivo

Manter o motor existente de processo/task/leitura/Unity/ESP e substituir a forma como o menu é criado e recebe entrada.

### Menu

O menu principal agora usa UIKit nativo. Isso remove a dependência da antiga `MTKView` fullscreen para hit-testing e deixa os controles como `UIButton`/`UISwitch` reais dentro de um painel com frame próprio. Os arquivos ImGui antigos continuam no repositório, mas não são compilados pelo target atual.

### Input

A cadeia global continua:

`HID -> AXEventRepresentation -> TSEventFetcher -> UITouch/UIEvent -> UIApplication -> UIKit hitTest`

O `TSEventFetcher` usa um estado por ponteiro para suportar eventos concorrentes de forma mais previsível.

### Motor preservado

`tasks/pid.mm`, `functions/Teste.mm`, `functions/Offsets.h`, `unity/unity.mm` e `overlay/ESPImGuiView.mm` continuam sendo os módulos existentes do projeto.

### Entitlements / ambiente

O pacote continua destinado ao ambiente privilegiado para o qual o projeto original foi concebido. A revisão não adiciona novos privilégios nem promete compatibilidade universal com entitlements de versões futuras do iOS.

### Versão

1.9.2-native-hud-deterministic-touch


### Build-integrity pass

The current source includes the typed AX path fix that addresses the reported `property 'pathIdentity' not found on object of type 'id _Nullable'` error, spawn failure checks, explicit C/C++ standard headers, safer remote image enumeration, and a cleaned native-menu scroll hierarchy. The legacy ImGui files are retained for reference but excluded from the active build.

## Touch routing

The HUD window uses accessibility-style global hosting, delegates hit-testing to the interactive HUD root, and delivers synthetic touch samples through the main run loop. Full-screen bookkeeping views are non-interactive, so only the actual menu/hotspot can consume input.


## Final HUD polish pass

The final pass focuses on runtime interaction and orientation stability:

- the global window uses the `UIAutoRotatingWindow` orientation path rather than rotating only individual content views;
- the initial orientation is read from `FBSOrientationObserver`, so a HUD launched while the active app is already landscape starts in the correct geometry;
- the native menu remains a normal UIKit hierarchy and is not double-rotated;
- the menu header remains the drag surface while normal `UIControl` touches are not stolen by the pan recognizer;
- the floating OPEN control has an independent one-finger pan path and a tap-to-open path, with the tap waiting for the pan to fail;
- synthetic touches follow the TrollSpeed/KIF-style fixed pointer-slot + living-touch + main-run-loop-source model, avoiding scene-dependent touch-pool initialization.

The project does not claim that private UIKit/BackBoard APIs are stable across arbitrary future iOS versions. The target remains iOS 15.x with the Theos/iPhoneOS 15.6 SDK used by the existing workflow.

### Deterministic menu input

The active menu uses a pointer-ID-aware direct touch router for the visible panel and the minimized reopen hotspot. UIKit synthetic touch delivery remains the fallback for touches outside those HUD-owned regions.


### Runtime privilege notes

The project keeps its existing private entitlement set and process/task/Unity modules. TrollStore preserves entitlements in installed IPAs, but its documented limitations and version-specific restrictions still apply; the project does not assume unsupported platformization or system-process injection capabilities.


## Orientation / touch fix 2.1.0

The HUD window is no longer rotated with `CGAffineTransformMakeRotation`.
It is resized to the active `UIScreen.coordinateSpace` dimensions instead.
AX screen coordinates are then converted exactly once into the HUD window
coordinate space before menu hit-testing and direct touch routing.

This removes the 90-degree coordinate mismatch that could leave buttons and
dragging responding at an offset after switching between portrait and
landscape.

## MAKTER BR 2.2.0 — orientation/input architecture

The HUD orientation path follows the supplied TrollSpeed reference architecture. The `UIWindow` remains in its stable base coordinate space, while `HUDRootViewController.view` swaps width/height for landscape and receives one rotation transform. AX touch locations are forwarded unchanged into the HUD window; UIKit performs hit-testing and gesture coordinate conversion through the transformed root view. There is no second direct-touch coordinate conversion in the HID callback.
