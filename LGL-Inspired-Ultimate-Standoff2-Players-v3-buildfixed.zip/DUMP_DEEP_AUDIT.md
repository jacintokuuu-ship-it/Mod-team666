# Dump Deep Audit — ESP V4

## Método

A dump fornecida foi varrida integralmente como texto (1.892.569 linhas, ~70 MB), seguida de buscas indexadas por RVA, classe, campo, tipo genérico e cadeia de câmera/player. A revisão final cruzou a cadeia usada pelo código atual com declarações concretas da mesma dump.

## Achado principal

A cadeia ativa anterior começava em `GameFacade.get_UIModelSpectator()` e lia `UIModelSpectator.m_PlayerDic`.

A mesma dump possui uma cadeia mais diretamente ligada à partida normal:

- `GameFacade.m_UIModelMatch` — campo estático `0x318`.
- `GameFacade.get_UIModelMatch()` — RVA `0x592ED30`.
- `UIModelMatch.m_PlayerDataList` — campo `0x1F0`.
- `UIModelMatch.LocalTeamId` — campo `0x11C`.
- `UIModelMatch.OnAddPlayer(BEADLMGGGGL, Player)` — RVA `0x46D0C58`.
- `UIModelMatch.CreatePlayerData(Player)` — RVA `0x46CDA90`.
- `UIModelMatch.OnDelPlayer(BEADLMGGGGL)` — RVA `0x46D09AC`.

Isso forma uma rota de dados de jogador de partida que o caminho anterior não explorava.

## Offsets confirmados diretamente

`PlayerData`:
- `userId` `0x28`
- `gsTeamId` `0x34`
- `scTeamId` `0x35`
- `isDead` `0x6C`
- `lastPosition` `0xDC`
- `player` `0x100`
- `headScale` `0x108`
- `isSamoAI` `0x130`

`Player`:
- `MainCameraTransform` `0x3E8`
- `FollowCamera` `0x690`
- root `Transform` `0x700`

`CameraControllerBase`:
- `TargetCamera` `0x30`
- getter `get_TargetCamera()` RVA `0x58DCC94`

`UIModelSpectator`:
- `m_PlayerDic` `0x30`
- `PlayerDic` getter RVA `0x48F26F0`

`GameFacade`:
- `LocalPlayerUserID` `0x58`
- `m_UIModelMatch` `0x318`
- `m_UIModelSpectator` `0x320`

## Dictionary consistency

`UIModelSpectator.m_PlayerDic` é `Dictionary<BEADLMGGGGL, PlayerData>`.
`BEADLMGGGGL` possui 24 bytes, compatível com entrada de dictionary de 40 bytes:

`hashCode 0x00 + next 0x04 + key 0x08..0x1F + value 0x20`.

A estrutura de cabeçalho usada no código atual também é compatível com o layout IL2CPP padrão de `Dictionary`.

## Lista de PlayerData

`UIModelMatch.m_PlayerDataList` é `List<PlayerData>`.
O layout genérico exposto pela dump confirma `_items`, `_size`, `_version` e `_syncRoot`; no objeto IL2CPP a leitura externa usa os offsets padrão de objeto/lista:

- `_items` `0x10`
- `_size` `0x18`
- dados do array `0x20`

A implementação V4 usa essa lista como rota primária e deixa o dictionary de espectador como fallback.

## Câmara

A cadeia:

`Player + 0x690 -> FollowCamera + 0x30 -> Camera`

está diretamente respaldada pela dump.

`Camera + 0x10` também tem suporte direto: `UnityEngine.Object.m_CachedPtr` está em `0x10`.

O ponto ainda não provado pela dump é:

`native Camera + 0x100 -> 16 floats de view/projection`.

Esse offset veio da referência externa anterior e não aparece como campo IL2CPP da classe `Camera`. Portanto ele continua sendo o elo de menor confiança da rota de projeção.

## Diagnóstico anterior

O status `RVAs 11/11` somente provava que 4 bytes podiam ser lidos em cada endereço de código. Não provava:

`getter -> objeto -> lista/dictionary -> PlayerData -> Player -> camera -> matriz -> W2S -> targets`.

Além disso, o diagnóstico antigo escondia a mensagem detalhada de `ReadLiveSnapshot`, mostrando apenas `live: FAIL`.

V4 passa a testar também `get_UIModelMatch` e exibe a mensagem interna do snapshot.

## Conclusão operacional

A primeira correção estrutural deve ser a fonte de jogadores: `UIModelMatch.m_PlayerDataList` para partida ativa, com `UIModelSpectator.m_PlayerDic` apenas como fallback.

Se V4 ainda reportar `live: FAIL`, a mensagem anexada ao diagnóstico separará exatamente estas etapas:

`modelo -> lista -> PlayerData -> camera -> matriz`.

O próximo ponto a validar, caso a mensagem pare na matriz, é exclusivamente o layout nativo da `Camera`, sem alterar os offsets de `PlayerData` que já estão confirmados pela dump.
