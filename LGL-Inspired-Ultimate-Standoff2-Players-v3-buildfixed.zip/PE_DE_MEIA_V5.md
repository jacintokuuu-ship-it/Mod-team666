# PE de meia v5 — Free Fire

## Target

- Bundle: `com.dts.freefireth`
- Process: `FreeFire`
- Hook image: `UnityFramework`
- Hook RVA: `0x08CDDFEC`

## What changed

The existing HUD application remains separate. A new Theos tweak target is
included under `tweak/` so the PE de meia code actually runs inside Free Fire.

The tweak is filtered to the Free Fire bundle and hooks:

`UnityEngine.Animator.GetBoneTransform(HumanBodyBones)`

Mapping while enabled:

- `Hips (0)` -> `Head (10)`
- `Chest (8)` -> `Neck (9)`

The HUD menu sends a Darwin notification to toggle the state in the injected
tweak.

## Build

The main HUD:

    make package

The injected tweak:

    cd tweak
    make package

For a Dopamine/rootless device, build/install the tweak with the Theos
rootless package scheme used by your environment.

## Important

The RVA and class/method names come from the supplied dump. The supplied dump
does not expose the generated native prototype, so the hook keeps the IL2CPP
`MethodInfo*` argument explicitly.

The project cannot truthfully be labeled "100% verified" until the resulting
binary is installed and the exact Free Fire build is run on-device. This
package is source-complete for the documented hook architecture; runtime
verification still depends on the target binary and hook backend present on
the device.
