#import "SafeOverlayApplication.h"
#import "SafeOverlayWindow.h"
#import "SafeOverlayViewController.h"

@implementation SafeOverlayApplication
@end

@interface SafeOverlayAppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic,strong) SafeOverlayWindow *window;
@end

@implementation SafeOverlayAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    (void)application; (void)launchOptions;
    self.window = [[SafeOverlayWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.backgroundColor = UIColor.clearColor;
    self.window.rootViewController = [SafeOverlayViewController new];
    self.window.windowLevel = UIWindowLevelAlert + 1.0;
    self.window.hidden = NO;
    [self.window makeKeyAndVisible];
    return YES;
}
@end

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, NSStringFromClass(SafeOverlayApplication.class), NSStringFromClass(SafeOverlayAppDelegate.class));
    }
}
