#import <UIKit/UIKit.h>
@interface SafeOverlayApplication : UIApplication
@end
