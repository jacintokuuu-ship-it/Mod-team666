#import "SafeOverlayViewController.h"

@interface OverlayPassthroughView : UIView
@property(nonatomic,weak) UIView *interactiveRegion;
@end

@implementation OverlayPassthroughView
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *region = self.interactiveRegion;
    if (!region || region.hidden || region.alpha <= 0.01 || !region.userInteractionEnabled) return nil;
    CGPoint p = [self convertPoint:point toView:region];
    if (![region pointInside:p withEvent:event]) return nil;
    UIView *hit = [region hitTest:p withEvent:event];
    return hit == region ? region : hit;
}
@end

@interface SafeOverlayViewController ()
@property(nonatomic,strong) OverlayPassthroughView *rootOverlay;
@property(nonatomic,strong) UIView *menu;
@property(nonatomic,strong) UILabel *titleLabel;
@property(nonatomic,assign) CGPoint dragOffset;
@end

@implementation SafeOverlayViewController

- (void)loadView {
    OverlayPassthroughView *root = [[OverlayPassthroughView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    root.backgroundColor = UIColor.clearColor;
    root.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.view = root;
    self.rootOverlay = root;

    UIView *menu = [[UIView alloc] initWithFrame:CGRectMake(40, 120, 270, 190)];
    menu.backgroundColor = [UIColor colorWithWhite:0 alpha:0.88];
    menu.layer.cornerRadius = 16;
    menu.layer.masksToBounds = YES;
    menu.userInteractionEnabled = YES;
    [root addSubview:menu];
    self.menu = menu;
    root.interactiveRegion = menu;

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(16, 0, 238, 48)];
    label.text = @"Floating Menu";
    label.textColor = UIColor.whiteColor;
    label.font = [UIFont boldSystemFontOfSize:17];
    [menu addSubview:label];
    self.titleLabel = label;

    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = CGRectMake(16, 68, 238, 48);
    [button setTitle:@"Test button" forState:UIControlStateNormal];
    [button setTitleColor:UIColor.whiteColor forState:UIControlStateNormal];
    button.backgroundColor = [UIColor colorWithWhite:1 alpha:0.12];
    button.layer.cornerRadius = 10;
    [menu addSubview:button];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleMenuPan:)];
    [menu addGestureRecognizer:pan];
}

- (void)viewDidLayoutSubviews {
    [super viewDidLayoutSubviews];
    self.rootOverlay.frame = self.view.bounds;
}

- (void)handleMenuPan:(UIPanGestureRecognizer *)pan {
    UIView *menu = self.menu;
    CGPoint delta = [pan translationInView:self.rootOverlay];
    if (pan.state == UIGestureRecognizerStateBegan || pan.state == UIGestureRecognizerStateChanged) {
        CGPoint center = menu.center;
        center.x += delta.x;
        center.y += delta.y;
        CGSize s = self.rootOverlay.bounds.size;
        CGFloat hw = menu.bounds.size.width * 0.5;
        CGFloat hh = menu.bounds.size.height * 0.5;
        center.x = MIN(MAX(center.x, hw + 4), s.width - hw - 4);
        center.y = MIN(MAX(center.y, hh + 4), s.height - hh - 4);
        menu.center = center;
        [pan setTranslation:CGPointZero inView:self.rootOverlay];
    }
}
@end
