#import <UIKit/UIKit.h>
@interface SafeOverlayWindow : UIWindow
@end
