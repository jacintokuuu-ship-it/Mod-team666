#import "SafeOverlayWindow.h"

@implementation SafeOverlayWindow

// The window covers the screen visually, but only returns a hit view for the
// interactive menu. Returning nil for every other point lets UIKit continue
// hit testing below this overlay window where the platform permits it.
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIViewController *root = self.rootViewController;
    if (!root || root.view.hidden || root.view.alpha <= 0.01) return nil;
    UIView *hit = [root.view hitTest:point withEvent:event];
    if (!hit || hit == root.view) return nil;
    return hit;
}
@end
