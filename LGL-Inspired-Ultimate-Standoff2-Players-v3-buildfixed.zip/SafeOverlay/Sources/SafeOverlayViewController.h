#import <UIKit/UIKit.h>
@interface SafeOverlayViewController : UIViewController
@end
