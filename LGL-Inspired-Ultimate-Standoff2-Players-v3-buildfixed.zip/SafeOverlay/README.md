# SafeOverlay — iOS 15 touch-pass-through reference

This is a clean UIKit reference implementation of the floating-menu architecture discussed in the project review.

## Touch model
- The overlay root fills the screen visually.
- It does **not** make the whole screen interactive.
- `SafeOverlayWindow` asks the root view for a hit view and returns `nil` when there is no interactive control.
- `OverlayPassthroughView` only returns a hit inside the menu region.
- There are no global gesture recognizers installed on other windows.
- There is no synthetic `UITouch`, HID event reinjection, `TSEventFetcher`, or modification of other application windows.

## Build
Requires Theos and an iOS SDK compatible with the selected TARGET. The package is source-only; an Apple/iOS SDK build environment is required to produce the application.

## Important limitation
A normal iOS application cannot use this source alone to become a system-wide overlay over other applications. System-level hosting/privileged deployment is a separate platform-specific concern. This reference intentionally contains no game injection, memory hooks, anti-cheat bypass, or synthetic system touch routing.
