#import "menu.h"
#import "../overlay/ESPImGuiView.h"
#import "../functions/Teste.h"
#import <QuartzCore/QuartzCore.h>
#import "../include/HUDBridge.h"

static const NSInteger kMenuTagMaster  = 100;
static const NSInteger kMenuTagBox     = 101;
static const NSInteger kMenuTagLines   = 102;
static const NSInteger kMenuTagHealth  = 103;
static const NSInteger kMenuTagName    = 104;
static const NSInteger kMenuTagWeapon  = 105;
static const NSInteger kMenuTagTeam    = 106;
static const NSInteger kMenuTagChams   = 107;
static const NSInteger kMenuTagStealth = 108;

static CGFloat clampCGFloat(CGFloat value, CGFloat minValue, CGFloat maxValue)
{
    if (maxValue < minValue) {
        CGFloat tmp = minValue;
        minValue = maxValue;
        maxValue = tmp;
    }
    return MIN(MAX(value, minValue), maxValue);
}

static BOOL MenuESPAnyEnabled(void)
{
    return [ESPImGuiView showLines] ||
           [ESPImGuiView showBox] ||
           [ESPImGuiView showHealthBar] ||
           [ESPImGuiView showName] ||
           [ESPImGuiView showWeapon] ||
           [ESPImGuiView chamsEnabled];
}

static void ApplyESPState(void)
{
    const BOOL enabled = MenuESPAnyEnabled();
    [ESPImGuiView setESPEnabled:enabled];
    [ESPImGuiView setTracersEnabled:enabled];
    HUDSetESPEnabled(enabled);
    HUDSetTracersEnabled(enabled);
}

static UIColor *NexusAccentColor(void)
{
    if (@available(iOS 13.0, *)) {
        return [UIColor systemBlueColor];
    }
    return [UIColor colorWithRed:0.20 green:0.52 blue:1.0 alpha:1.0];
}

static UIColor *NexusPanelColor(void)
{
    return [UIColor colorWithWhite:0.075 alpha:0.98];
}

static NSInteger MenuActiveVisualCount(void)
{
    NSInteger count = 0;
    count += [ESPImGuiView showBox] ? 1 : 0;
    count += [ESPImGuiView showLines] ? 1 : 0;
    count += [ESPImGuiView showHealthBar] ? 1 : 0;
    count += [ESPImGuiView showName] ? 1 : 0;
    count += [ESPImGuiView showWeapon] ? 1 : 0;
    count += [ESPImGuiView chamsEnabled] ? 1 : 0;
    return count;
}

@interface MenuView () <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIVisualEffectView *materialView;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIView *statusDot;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UISegmentedControl *tabControl;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIStackView *contentStack;
@property (nonatomic, strong) UIStackView *overviewStack;
@property (nonatomic, strong) UIStackView *visualStack;
@property (nonatomic, strong) UIStackView *styleStack;
@property (nonatomic, strong) UIStackView *systemStack;
@property (nonatomic, strong) UILabel *testStatusLabel;
@property (nonatomic, strong) UILabel *activeCountLabel;
@property (nonatomic, strong) UILabel *masterStatusLabel;
@property (nonatomic, strong) UISegmentedControl *chamsMaterialControl;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, UISwitch *> *switches;
@property (nonatomic, strong) UIPanGestureRecognizer *panGesture;
@property (nonatomic, assign) CGPoint panStartCenter;
@property (nonatomic, assign) UIInterfaceOrientation currentOrientation;
@property (nonatomic, assign) BOOL hasUserPosition;
@property (nonatomic, strong) NSTimer *statusTimer;
@property (nonatomic, assign) NSInteger selectedTab;
@end

@implementation MenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (!self) return nil;

    _currentOrientation = UIInterfaceOrientationPortrait;
    _switches = [NSMutableDictionary dictionary];
    _selectedTab = 0;

    self.backgroundColor = [UIColor clearColor];
    self.opaque = NO;
    self.clipsToBounds = NO;
    self.userInteractionEnabled = YES;
    self.multipleTouchEnabled = YES;
    self.exclusiveTouch = NO;
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOpacity = 0.34;
    self.layer.shadowRadius = 28.0;
    self.layer.shadowOffset = CGSizeMake(0, 14);

    UIBlurEffectStyle blurStyle = UIBlurEffectStyleSystemChromeMaterialDark;
    if (@available(iOS 13.0, *)) {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:blurStyle]];
    } else {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:nil];
        _materialView.backgroundColor = NexusPanelColor();
    }
    _materialView.translatesAutoresizingMaskIntoConstraints = NO;
    _materialView.layer.cornerRadius = 22.0;
    _materialView.clipsToBounds = YES;
    [self addSubview:_materialView];

    UIView *border = [[UIView alloc] init];
    border.translatesAutoresizingMaskIntoConstraints = NO;
    border.userInteractionEnabled = NO;
    border.backgroundColor = [UIColor clearColor];
    border.layer.cornerRadius = 22.0;
    border.layer.borderWidth = 0.8;
    border.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.13].CGColor;
    [_materialView.contentView addSubview:border];

    _headerView = [[UIView alloc] init];
    _headerView.translatesAutoresizingMaskIntoConstraints = NO;
    _headerView.backgroundColor = [UIColor clearColor];
    [_materialView.contentView addSubview:_headerView];

    _titleLabel = [[UILabel alloc] init];
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLabel.text = @"MAKTER";
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:20.0 weight:UIFontWeightBold];
    [_headerView addSubview:_titleLabel];

    _subtitleLabel = [[UILabel alloc] init];
    _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _subtitleLabel.text = @"HUD CONTROL CENTER";
    _subtitleLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.48];
    _subtitleLabel.font = [UIFont systemFontOfSize:9.5 weight:UIFontWeightSemibold];
    [_headerView addSubview:_subtitleLabel];

    _statusDot = [[UIView alloc] init];
    _statusDot.translatesAutoresizingMaskIntoConstraints = NO;
    _statusDot.layer.cornerRadius = 4.0;
    [_headerView addSubview:_statusDot];

    _statusLabel = [[UILabel alloc] init];
    _statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _statusLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.62];
    _statusLabel.font = [UIFont systemFontOfSize:9.5 weight:UIFontWeightSemibold];
    [_headerView addSubview:_statusLabel];

    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _closeButton.translatesAutoresizingMaskIntoConstraints = NO;
    _closeButton.tintColor = [UIColor whiteColor];
    _closeButton.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.075];
    _closeButton.layer.cornerRadius = 17.0;
    if (@available(iOS 13.0, *)) {
        [_closeButton setImage:[UIImage systemImageNamed:@"minus"] forState:UIControlStateNormal];
    } else {
        [_closeButton setTitle:@"−" forState:UIControlStateNormal];
    }
    _closeButton.accessibilityLabel = @"Minimize menu";
    [_closeButton addTarget:self action:@selector(closePressed:) forControlEvents:UIControlEventTouchUpInside];
    [_headerView addSubview:_closeButton];

    _tabControl = [[UISegmentedControl alloc] initWithItems:@[@"HOME", @"VISUAL", @"STYLE", @"SYSTEM"]];
    _tabControl.translatesAutoresizingMaskIntoConstraints = NO;
    _tabControl.selectedSegmentIndex = 0;
    _tabControl.apportionsSegmentWidthsByContent = NO;
    [_tabControl addTarget:self action:@selector(tabChanged:) forControlEvents:UIControlEventValueChanged];
    [_materialView.contentView addSubview:_tabControl];

    _scrollView = [[UIScrollView alloc] init];
    _scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.alwaysBounceVertical = YES;
    _scrollView.directionalLockEnabled = YES;
    _scrollView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    [_materialView.contentView addSubview:_scrollView];

    UIView *scrollContent = [[UIView alloc] init];
    scrollContent.translatesAutoresizingMaskIntoConstraints = NO;
    [_scrollView addSubview:scrollContent];

    _contentStack = [[UIStackView alloc] init];
    _contentStack.translatesAutoresizingMaskIntoConstraints = NO;
    _contentStack.axis = UILayoutConstraintAxisVertical;
    _contentStack.alignment = UIStackViewAlignmentFill;
    _contentStack.spacing = 0.0;
    [scrollContent addSubview:_contentStack];

    _overviewStack = [self makeContentStack];
    _visualStack = [self makeContentStack];
    _styleStack = [self makeContentStack];
    _systemStack = [self makeContentStack];

    [_contentStack addArrangedSubview:_overviewStack];
    [_contentStack addArrangedSubview:_visualStack];
    [_contentStack addArrangedSubview:_styleStack];
    [_contentStack addArrangedSubview:_systemStack];

    [NSLayoutConstraint activateConstraints:@[
        [_materialView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_materialView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_materialView.topAnchor constraintEqualToAnchor:self.topAnchor],
        [_materialView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],

        [border.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [border.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [border.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [border.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [_headerView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_headerView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_headerView.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [_headerView.heightAnchor constraintEqualToConstant:72.0],

        [_titleLabel.leadingAnchor constraintEqualToAnchor:_headerView.leadingAnchor constant:18.0],
        [_titleLabel.topAnchor constraintEqualToAnchor:_headerView.topAnchor constant:12.0],
        [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
        [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:3.0],

        [_statusDot.leadingAnchor constraintEqualToAnchor:_subtitleLabel.trailingAnchor constant:8.0],
        [_statusDot.centerYAnchor constraintEqualToAnchor:_subtitleLabel.centerYAnchor],
        [_statusDot.widthAnchor constraintEqualToConstant:8.0],
        [_statusDot.heightAnchor constraintEqualToConstant:8.0],

        [_statusLabel.leadingAnchor constraintEqualToAnchor:_statusDot.trailingAnchor constant:5.0],
        [_statusLabel.centerYAnchor constraintEqualToAnchor:_subtitleLabel.centerYAnchor],
        [_statusLabel.trailingAnchor constraintLessThanOrEqualToAnchor:_closeButton.leadingAnchor constant:-8.0],

        [_closeButton.trailingAnchor constraintEqualToAnchor:_headerView.trailingAnchor constant:-14.0],
        [_closeButton.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_closeButton.widthAnchor constraintEqualToConstant:34.0],
        [_closeButton.heightAnchor constraintEqualToConstant:34.0],

        [_tabControl.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor constant:13.0],
        [_tabControl.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor constant:-13.0],
        [_tabControl.topAnchor constraintEqualToAnchor:_headerView.bottomAnchor constant:3.0],
        [_tabControl.heightAnchor constraintEqualToConstant:35.0],

        [_scrollView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_scrollView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_scrollView.topAnchor constraintEqualToAnchor:_tabControl.bottomAnchor constant:5.0],
        [_scrollView.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [scrollContent.leadingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.leadingAnchor],
        [scrollContent.trailingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.trailingAnchor],
        [scrollContent.topAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.topAnchor],
        [scrollContent.bottomAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.bottomAnchor],
        [scrollContent.widthAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.widthAnchor],

        [_contentStack.leadingAnchor constraintEqualToAnchor:scrollContent.leadingAnchor],
        [_contentStack.trailingAnchor constraintEqualToAnchor:scrollContent.trailingAnchor],
        [_contentStack.topAnchor constraintEqualToAnchor:scrollContent.topAnchor],
        [_contentStack.bottomAnchor constraintEqualToAnchor:scrollContent.bottomAnchor]
    ]];

    [self buildOverviewTab];
    [self buildVisualTab];
    [self buildStyleTab];
    [self buildSystemTab];

    _visualStack.hidden = YES;
    _styleStack.hidden = YES;
    _systemStack.hidden = YES;

    _panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    _panGesture.cancelsTouchesInView = NO;
    _panGesture.delegate = self;
    [_headerView addGestureRecognizer:_panGesture];

    self.alpha = 1.0;
    self.hidden = NO;

    _statusTimer = [NSTimer scheduledTimerWithTimeInterval:0.20 target:self selector:@selector(refreshStatus) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_statusTimer forMode:NSRunLoopCommonModes];
    [self refreshStatus];

    return self;
}

- (UIStackView *)makeContentStack
{
    UIStackView *stack = [[UIStackView alloc] init];
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    stack.axis = UILayoutConstraintAxisVertical;
    stack.alignment = UIStackViewAlignmentFill;
    stack.spacing = 9.0;
    stack.layoutMarginsRelativeArrangement = YES;
    stack.layoutMargins = UIEdgeInsetsMake(12.0, 14.0, 18.0, 14.0);
    return stack;
}

- (void)dealloc
{
    [_statusTimer invalidate];
}

- (void)buildOverviewTab
{
    UIView *hero = [self dashboardCard];
    [_overviewStack addArrangedSubview:hero];

    UILabel *section = [self sectionLabel:@"QUICK CONTROL"];
    [_overviewStack addArrangedSubview:section];

    [self addSwitchRowToStack:_overviewStack title:@"Master ESP" subtitle:@"Single switch for all visual overlay features" tag:kMenuTagMaster initial:MenuESPAnyEnabled()];

    UIView *active = [self infoCardWithTitle:@"Active features" message:@"Loading…"];
    [_overviewStack addArrangedSubview:active];
    _activeCountLabel = [active viewWithTag:9001];

    UIView *input = [self infoCardWithTitle:@"Touch-safe architecture"
                                    message:@"The panel captures touches only inside its visible bounds. The rest of the screen remains passthrough."];
    [_overviewStack addArrangedSubview:input];
}

- (void)buildVisualTab
{
    UILabel *section = [self sectionLabel:@"PLAYER VISUALS"];
    [_visualStack addArrangedSubview:section];

    [self addSwitchRowToStack:_visualStack title:@"Boxes" subtitle:@"2D player rectangles" tag:kMenuTagBox initial:[ESPImGuiView showBox]];
    [self addSwitchRowToStack:_visualStack title:@"Lines" subtitle:@"Draw a tracer line to targets" tag:kMenuTagLines initial:[ESPImGuiView showLines]];
    [self addSwitchRowToStack:_visualStack title:@"Health" subtitle:@"Show the current health bar" tag:kMenuTagHealth initial:[ESPImGuiView showHealthBar]];
    [self addSwitchRowToStack:_visualStack title:@"Names" subtitle:@"Display player name text" tag:kMenuTagName initial:[ESPImGuiView showName]];
    [self addSwitchRowToStack:_visualStack title:@"Weapons" subtitle:@"Display weapon text" tag:kMenuTagWeapon initial:[ESPImGuiView showWeapon]];
    [self addSwitchRowToStack:_visualStack title:@"Team check" subtitle:@"Use the existing team filter" tag:kMenuTagTeam initial:[ESPImGuiView teamCheck]];

    UILabel *effects = [self sectionLabel:@"RENDER EFFECTS"];
    [_visualStack addArrangedSubview:effects];
    [self addSwitchRowToStack:_visualStack title:@"Chams" subtitle:@"Enable the existing material-based effect" tag:kMenuTagChams initial:[ESPImGuiView chamsEnabled]];

    _chamsMaterialControl = [[UISegmentedControl alloc] initWithItems:@[@"MAT 0", @"MAT 1", @"MAT 2"]];
    _chamsMaterialControl.selectedSegmentIndex = MIN(MAX([ESPImGuiView chamsMaterialId], 0), 2);
    _chamsMaterialControl.translatesAutoresizingMaskIntoConstraints = NO;
    _chamsMaterialControl.accessibilityLabel = @"Chams material selector";
    [_chamsMaterialControl addTarget:self action:@selector(chamsMaterialChanged:) forControlEvents:UIControlEventValueChanged];
    [_visualStack addArrangedSubview:_chamsMaterialControl];

    UIView *warning = [self infoCardWithTitle:@"Existing implementation"
                                       message:@"Only controls already exposed by the project are connected here. No fake toggles are added."];
    [_visualStack addArrangedSubview:warning];
}

- (void)buildStyleTab
{
    UILabel *section = [self sectionLabel:@"OVERLAY STYLE"];
    [_styleStack addArrangedSubview:section];

    UIView *presetCard = [[UIView alloc] init];
    presetCard.translatesAutoresizingMaskIntoConstraints = NO;
    presetCard.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.045];
    presetCard.layer.cornerRadius = 16.0;
    [_styleStack addArrangedSubview:presetCard];

    UILabel *title = [self cardTitleLabel:@"Color presets"];
    UILabel *desc = [self cardDescriptionLabel:@"Apply a consistent palette to lines, boxes, names, weapons and health."];
    [presetCard addSubview:title];
    [presetCard addSubview:desc];

    UIButton *ice = [self actionButtonWithTitle:@"ICE"];
    UIButton *neon = [self actionButtonWithTitle:@"NEON"];
    UIButton *warm = [self actionButtonWithTitle:@"WARM"];
    ice.tag = 1; neon.tag = 2; warm.tag = 3;
    [ice addTarget:self action:@selector(stylePresetPressed:) forControlEvents:UIControlEventTouchUpInside];
    [neon addTarget:self action:@selector(stylePresetPressed:) forControlEvents:UIControlEventTouchUpInside];
    [warm addTarget:self action:@selector(stylePresetPressed:) forControlEvents:UIControlEventTouchUpInside];
    [presetCard addSubview:ice];
    [presetCard addSubview:neon];
    [presetCard addSubview:warm];

    [NSLayoutConstraint activateConstraints:@[
        [presetCard.heightAnchor constraintEqualToConstant:118.0],
        [title.leadingAnchor constraintEqualToAnchor:presetCard.leadingAnchor constant:13.0],
        [title.topAnchor constraintEqualToAnchor:presetCard.topAnchor constant:12.0],
        [title.trailingAnchor constraintEqualToAnchor:presetCard.trailingAnchor constant:-13.0],
        [desc.leadingAnchor constraintEqualToAnchor:title.leadingAnchor],
        [desc.trailingAnchor constraintEqualToAnchor:title.trailingAnchor],
        [desc.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:3.0],
        [ice.leadingAnchor constraintEqualToAnchor:presetCard.leadingAnchor constant:12.0],
        [ice.bottomAnchor constraintEqualToAnchor:presetCard.bottomAnchor constant:-12.0],
        [ice.widthAnchor constraintEqualToAnchor:neon.widthAnchor],
        [neon.leadingAnchor constraintEqualToAnchor:ice.trailingAnchor constant:7.0],
        [neon.bottomAnchor constraintEqualToAnchor:ice.bottomAnchor],
        [neon.widthAnchor constraintEqualToAnchor:warm.widthAnchor],
        [warm.leadingAnchor constraintEqualToAnchor:neon.trailingAnchor constant:7.0],
        [warm.trailingAnchor constraintEqualToAnchor:presetCard.trailingAnchor constant:-12.0],
        [warm.bottomAnchor constraintEqualToAnchor:ice.bottomAnchor],
        [ice.heightAnchor constraintEqualToConstant:38.0]
    ]];

    UILabel *defaults = [self sectionLabel:@"CURRENT PALETTE"];
    [_styleStack addArrangedSubview:defaults];
    [_styleStack addArrangedSubview:[self colorInfoCardWithTitle:@"Lines" color:[ESPImGuiView lineColor]]];
    [_styleStack addArrangedSubview:[self colorInfoCardWithTitle:@"Boxes" color:[ESPImGuiView boxColor]]];
    [_styleStack addArrangedSubview:[self colorInfoCardWithTitle:@"Health" color:[ESPImGuiView hpColor]]];
    [_styleStack addArrangedSubview:[self colorInfoCardWithTitle:@"Text" color:[ESPImGuiView nameColor]]];
}

- (void)buildSystemTab
{
    UILabel *section = [self sectionLabel:@"INTERFACE"];
    [_systemStack addArrangedSubview:section];

    [self addSwitchRowToStack:_systemStack title:@"Capture protection" subtitle:@"Use the existing secure HUD behavior" tag:kMenuTagStealth initial:[ESPImGuiView stealthEnabled]];

    UIButton *recenter = [self actionButtonWithTitle:@"RESET MENU POSITION"];
    [recenter addTarget:self action:@selector(resetPositionPressed:) forControlEvents:UIControlEventTouchUpInside];
    [_systemStack addArrangedSubview:recenter];

    UILabel *diagnostics = [self sectionLabel:@"READ-ONLY DIAGNOSTICS"];
    [_systemStack addArrangedSubview:diagnostics];

    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    card.layer.cornerRadius = 16.0;
    [_systemStack addArrangedSubview:card];

    UILabel *title = [self cardTitleLabel:@"Memory engine test"];
    _testStatusLabel = [self cardDescriptionLabel:@"No test executed."];
    _testStatusLabel.numberOfLines = 0;
    [card addSubview:title];
    [card addSubview:_testStatusLabel];

    UIButton *run = [self actionButtonWithTitle:@"RUN READ TEST"];
    [run addTarget:self action:@selector(runReadTest:) forControlEvents:UIControlEventTouchUpInside];
    [card addSubview:run];

    [NSLayoutConstraint activateConstraints:@[
        [card.heightAnchor constraintGreaterThanOrEqualToConstant:145.0],
        [title.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:13.0],
        [title.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-13.0],
        [title.topAnchor constraintEqualToAnchor:card.topAnchor constant:12.0],
        [_testStatusLabel.leadingAnchor constraintEqualToAnchor:title.leadingAnchor],
        [_testStatusLabel.trailingAnchor constraintEqualToAnchor:title.trailingAnchor],
        [_testStatusLabel.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:5.0],
        [run.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:12.0],
        [run.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-12.0],
        [run.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-12.0],
        [run.heightAnchor constraintEqualToConstant:38.0],
        [_testStatusLabel.bottomAnchor constraintLessThanOrEqualToAnchor:run.topAnchor constant:-10.0]
    ]];

    UILabel *about = [self sectionLabel:@"ABOUT"];
    [_systemStack addArrangedSubview:about];
    [_systemStack addArrangedSubview:[self infoCardWithTitle:@"MAKTER HUD"
                                                      message:@"Professional control surface for the existing HUD project. The underlying engine modules remain untouched."]];
}

- (UIView *)dashboardCard
{
    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.060];
    card.layer.cornerRadius = 18.0;

    UILabel *eyebrow = [self cardDescriptionLabel:@"SESSION STATUS"];
    eyebrow.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.46];
    eyebrow.font = [UIFont systemFontOfSize:9.0 weight:UIFontWeightBold];

    UILabel *title = [self cardTitleLabel:@"NEXUS is ready"];
    title.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];

    UILabel *summary = [self cardDescriptionLabel:@"Your controls stay synchronized with the existing ESP state."];
    summary.numberOfLines = 2;

    [card addSubview:eyebrow];
    [card addSubview:title];
    [card addSubview:summary];

    [NSLayoutConstraint activateConstraints:@[
        [card.heightAnchor constraintEqualToConstant:112.0],
        [eyebrow.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:14.0],
        [eyebrow.topAnchor constraintEqualToAnchor:card.topAnchor constant:11.0],
        [eyebrow.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-14.0],
        [title.leadingAnchor constraintEqualToAnchor:eyebrow.leadingAnchor],
        [title.topAnchor constraintEqualToAnchor:eyebrow.bottomAnchor constant:3.0],
        [title.trailingAnchor constraintEqualToAnchor:eyebrow.trailingAnchor],
        [summary.leadingAnchor constraintEqualToAnchor:title.leadingAnchor],
        [summary.trailingAnchor constraintEqualToAnchor:title.trailingAnchor],
        [summary.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:5.0],
        [summary.bottomAnchor constraintLessThanOrEqualToAnchor:card.bottomAnchor constant:-11.0]
    ]];

    return card;
}

- (UILabel *)sectionLabel:(NSString *)text
{
    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.textColor = [NexusAccentColor() colorWithAlphaComponent:0.92];
    label.font = [UIFont systemFontOfSize:9.5 weight:UIFontWeightBold];
    label.textAlignment = NSTextAlignmentLeft;
    return label;
}

- (UILabel *)cardTitleLabel:(NSString *)text
{
    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.textColor = [UIColor whiteColor];
    label.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightSemibold];
    return label;
}

- (UILabel *)cardDescriptionLabel:(NSString *)text
{
    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.57];
    label.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightRegular];
    label.numberOfLines = 0;
    return label;
}

- (UIView *)infoCardWithTitle:(NSString *)title message:(NSString *)message
{
    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.045];
    card.layer.cornerRadius = 14.0;

    UILabel *titleLabel = [self cardTitleLabel:title];
    UILabel *messageLabel = [self cardDescriptionLabel:message];
    if ([title isEqualToString:@"Active features"]) {
        messageLabel.tag = 9001;
    }
    [card addSubview:titleLabel];
    [card addSubview:messageLabel];

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:13.0],
        [titleLabel.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-13.0],
        [titleLabel.topAnchor constraintEqualToAnchor:card.topAnchor constant:11.0],
        [messageLabel.leadingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor],
        [messageLabel.trailingAnchor constraintEqualToAnchor:titleLabel.trailingAnchor],
        [messageLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:4.0],
        [messageLabel.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-11.0]
    ]];

    return card;
}

- (UIView *)colorInfoCardWithTitle:(NSString *)title color:(UIColor *)color
{
    UIView *card = [self infoCardWithTitle:title message:@"Synced with the current overlay renderer."];
    UIView *swatch = [[UIView alloc] init];
    swatch.translatesAutoresizingMaskIntoConstraints = NO;
    swatch.backgroundColor = color ?: [UIColor whiteColor];
    swatch.layer.cornerRadius = 10.0;
    swatch.layer.borderWidth = 1.0;
    swatch.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.22].CGColor;
    [card addSubview:swatch];
    [NSLayoutConstraint activateConstraints:@[
        [swatch.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-13.0],
        [swatch.centerYAnchor constraintEqualToAnchor:card.centerYAnchor],
        [swatch.widthAnchor constraintEqualToConstant:20.0],
        [swatch.heightAnchor constraintEqualToConstant:20.0]
    ]];
    return card;
}

- (UIButton *)actionButtonWithTitle:(NSString *)title
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    button.backgroundColor = [NexusAccentColor() colorWithAlphaComponent:0.18];
    button.layer.cornerRadius = 12.0;
    button.tintColor = [UIColor whiteColor];
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightBold];
    button.accessibilityTraits = UIAccessibilityTraitButton;
    [button.heightAnchor constraintEqualToConstant:38.0].active = YES;
    return button;
}

- (void)addSwitchRowToStack:(UIStackView *)stack title:(NSString *)title subtitle:(NSString *)subtitle tag:(NSInteger)tag initial:(BOOL)initial
{
    UIView *row = [[UIView alloc] init];
    row.translatesAutoresizingMaskIntoConstraints = NO;
    row.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    row.layer.cornerRadius = 14.0;
    [row.heightAnchor constraintEqualToConstant:61.0].active = YES;

    UILabel *titleLabel = [self cardTitleLabel:title];
    titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    UILabel *subtitleLabel = [self cardDescriptionLabel:subtitle];
    subtitleLabel.font = [UIFont systemFontOfSize:9.5 weight:UIFontWeightRegular];

    UISwitch *toggle = [[UISwitch alloc] init];
    toggle.translatesAutoresizingMaskIntoConstraints = NO;
    toggle.onTintColor = NexusAccentColor();
    toggle.on = initial;
    toggle.tag = tag;
    toggle.accessibilityLabel = title;
    [toggle addTarget:self action:@selector(featureSwitchChanged:) forControlEvents:UIControlEventValueChanged];

    [row addSubview:titleLabel];
    [row addSubview:subtitleLabel];
    [row addSubview:toggle];
    self.switches[@(tag)] = toggle;

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:13.0],
        [titleLabel.topAnchor constraintEqualToAnchor:row.topAnchor constant:10.0],
        [titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:toggle.leadingAnchor constant:-10.0],
        [subtitleLabel.leadingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor],
        [subtitleLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:2.0],
        [subtitleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:toggle.leadingAnchor constant:-10.0],
        [toggle.trailingAnchor constraintEqualToAnchor:row.trailingAnchor constant:-11.0],
        [toggle.centerYAnchor constraintEqualToAnchor:row.centerYAnchor]
    ]];

    [stack addArrangedSubview:row];
}

- (void)closePressed:(UIButton *)sender
{
    if (self.closeHandler) {
        self.closeHandler();
    } else {
        [self hideMenu];
    }
}

- (void)tabChanged:(UISegmentedControl *)sender
{
    _selectedTab = sender.selectedSegmentIndex;
    _overviewStack.hidden = (_selectedTab != 0);
    _visualStack.hidden = (_selectedTab != 1);
    _styleStack.hidden = (_selectedTab != 2);
    _systemStack.hidden = (_selectedTab != 3);
    [_scrollView setContentOffset:CGPointZero animated:NO];
}

- (void)featureSwitchChanged:(UISwitch *)sender
{
    if (sender.tag == kMenuTagMaster) {
        if (!sender.on) {
            [ESPImGuiView setShowBox:NO];
            [ESPImGuiView setShowLines:NO];
            [ESPImGuiView setShowHealthBar:NO];
            [ESPImGuiView setShowName:NO];
            [ESPImGuiView setShowWeapon:NO];
            [ESPImGuiView setChamsEnabled:NO];
        } else if (!MenuESPAnyEnabled()) {
            [ESPImGuiView setShowLines:YES];
        }
        [self synchronizeVisualSwitches];
        ApplyESPState();
        return;
    }

    switch (sender.tag) {
        case kMenuTagBox:     [ESPImGuiView setShowBox:sender.on]; break;
        case kMenuTagLines:   [ESPImGuiView setShowLines:sender.on]; break;
        case kMenuTagHealth:  [ESPImGuiView setShowHealthBar:sender.on]; break;
        case kMenuTagName:    [ESPImGuiView setShowName:sender.on]; break;
        case kMenuTagWeapon:  [ESPImGuiView setShowWeapon:sender.on]; break;
        case kMenuTagTeam:    [ESPImGuiView setTeamCheck:sender.on]; return;
        case kMenuTagChams:   [ESPImGuiView setChamsEnabled:sender.on]; break;
        case kMenuTagStealth: {
            [ESPImGuiView setStealthEnabled:sender.on];
            HUDSetStealthEnabled(sender.on);
            return;
        }
        default: return;
    }

    [self synchronizeVisualSwitches];
    ApplyESPState();
}

- (void)synchronizeVisualSwitches
{
    NSDictionary<NSNumber *, NSNumber *> *states = @{
        @(kMenuTagMaster): @(MenuESPAnyEnabled()),
        @(kMenuTagBox): @([ESPImGuiView showBox]),
        @(kMenuTagLines): @([ESPImGuiView showLines]),
        @(kMenuTagHealth): @([ESPImGuiView showHealthBar]),
        @(kMenuTagName): @([ESPImGuiView showName]),
        @(kMenuTagWeapon): @([ESPImGuiView showWeapon]),
        @(kMenuTagTeam): @([ESPImGuiView teamCheck]),
        @(kMenuTagChams): @([ESPImGuiView chamsEnabled]),
        @(kMenuTagStealth): @([ESPImGuiView stealthEnabled])
    };

    [states enumerateKeysAndObjectsUsingBlock:^(NSNumber *key, NSNumber *value, BOOL *stop) {
        UISwitch *control = self.switches[key];
        if (control && control.on != value.boolValue) {
            control.on = value.boolValue;
        }
    }];
}

- (void)chamsMaterialChanged:(UISegmentedControl *)sender
{
    [ESPImGuiView setChamsMaterialId:(int)sender.selectedSegmentIndex];
}

- (void)stylePresetPressed:(UIButton *)sender
{
    UIColor *line = [UIColor whiteColor];
    UIColor *box = [UIColor whiteColor];
    UIColor *hp = [UIColor colorWithRed:0.20 green:0.90 blue:0.30 alpha:1.0];
    UIColor *text = [UIColor whiteColor];

    switch (sender.tag) {
        case 1: // ICE
            line = [UIColor colorWithRed:0.45 green:0.85 blue:1.0 alpha:1.0];
            box = [UIColor colorWithRed:0.30 green:0.70 blue:1.0 alpha:1.0];
            hp = [UIColor colorWithRed:0.30 green:1.0 blue:0.90 alpha:1.0];
            text = [UIColor colorWithRed:0.82 green:0.95 blue:1.0 alpha:1.0];
            break;
        case 2: // NEON
            line = [UIColor colorWithRed:0.96 green:0.24 blue:1.0 alpha:1.0];
            box = [UIColor colorWithRed:0.25 green:1.0 blue:0.76 alpha:1.0];
            hp = [UIColor colorWithRed:1.0 green:0.92 blue:0.18 alpha:1.0];
            text = [UIColor colorWithRed:0.95 green:0.96 blue:1.0 alpha:1.0];
            break;
        case 3: // WARM
            line = [UIColor colorWithRed:1.0 green:0.74 blue:0.25 alpha:1.0];
            box = [UIColor colorWithRed:1.0 green:0.34 blue:0.28 alpha:1.0];
            hp = [UIColor colorWithRed:0.42 green:1.0 blue:0.38 alpha:1.0];
            text = [UIColor colorWithRed:1.0 green:0.92 blue:0.80 alpha:1.0];
            break;
        default:
            break;
    }

    [ESPImGuiView setLineColor:line];
    [ESPImGuiView setBoxColor:box];
    [ESPImGuiView setHpColor:hp];
    [ESPImGuiView setNameColor:text];
    [ESPImGuiView setWeaponColor:text];
}

- (void)toggleStealth:(UIButton *)sender
{
    const BOOL enabled = ![ESPImGuiView stealthEnabled];
    [ESPImGuiView setStealthEnabled:enabled];
    HUDSetStealthEnabled(enabled);
    [self synchronizeVisualSwitches];
}

- (void)resetPositionPressed:(UIButton *)sender
{
    [self centerMenu];
}

- (void)runReadTest:(UIButton *)sender
{
    sender.enabled = NO;
    MenuFuncaoTeste();
    [self refreshStatus];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.55 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        sender.enabled = YES;
    });
}

- (void)refreshStatus
{
    if (_activeCountLabel) {
        NSInteger count = MenuActiveVisualCount();
        _activeCountLabel.text = [NSString stringWithFormat:@"%ld feature%@ active", (long)count, count == 1 ? @"" : @"s"];
    }

    if (_masterStatusLabel) {
        _masterStatusLabel.text = MenuESPAnyEnabled() ? @"ESP ACTIVE" : @"ESP STANDBY";
    }

    const BOOL active = MenuESPAnyEnabled();
    _statusDot.backgroundColor = active ? [UIColor colorWithRed:0.24 green:0.92 blue:0.48 alpha:1.0] : [[UIColor whiteColor] colorWithAlphaComponent:0.30];
    _statusLabel.text = active ? @"ACTIVE" : @"STANDBY";

    [self synchronizeVisualSwitches];

    if (_chamsMaterialControl) {
        NSInteger material = MIN(MAX([ESPImGuiView chamsMaterialId], 0), 2);
        if (_chamsMaterialControl.selectedSegmentIndex != material) {
            _chamsMaterialControl.selectedSegmentIndex = material;
        }
    }

    if (!_testStatusLabel) return;
    if (TesteMensagemVisivel()) {
        const char *raw = TesteMensagem();
        NSString *value = raw ? [NSString stringWithUTF8String:raw] : nil;
        _testStatusLabel.text = value.length ? value : @"Test completed.";
    } else if (_testStatusLabel.text.length > 0 && ![_testStatusLabel.text isEqualToString:@"No test executed."]) {
        _testStatusLabel.text = @"No active test message.";
    }
}

- (void)hideMenu
{
    [UIView animateWithDuration:0.18 animations:^{
        self.alpha = 0.0;
        self.transform = CGAffineTransformMakeScale(0.97, 0.97);
    } completion:^(__unused BOOL finished) {
        self.hidden = YES;
        self.userInteractionEnabled = NO;
    }];
}

- (void)showMenu
{
    self.hidden = NO;
    self.userInteractionEnabled = YES;
    [UIView animateWithDuration:0.20 animations:^{
        self.alpha = 1.0;
        self.transform = CGAffineTransformIdentity;
    }];
    [self refreshStatus];
}

- (void)centerMenu
{
    UIView *host = self.superview;
    if (!host) return;
    _hasUserPosition = NO;
    [self updateForOrientation:_currentOrientation];
}

- (void)updateForOrientation:(UIInterfaceOrientation)orientation
{
    if (orientation == UIInterfaceOrientationUnknown) {
        orientation = UIInterfaceOrientationPortrait;
    }
    _currentOrientation = orientation;

    UIView *host = self.superview;
    if (!host) return;

    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) {
        safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    }
    safe = CGRectInset(safe, 10.0, 10.0);

    BOOL landscape = UIInterfaceOrientationIsLandscape(orientation);
    CGFloat desiredWidth = landscape ? 390.0 : 350.0;
    CGFloat desiredHeight = landscape ? 350.0 : 510.0;

    CGFloat availableWidth = MAX(0.0, CGRectGetWidth(safe));
    CGFloat availableHeight = MAX(0.0, CGRectGetHeight(safe));
    CGFloat width = MIN(desiredWidth, availableWidth);
    CGFloat height = MIN(desiredHeight, availableHeight);

    if (availableWidth >= 260.0) width = MAX(260.0, width);
    if (availableHeight >= 320.0) height = MAX(320.0, height);

    self.transform = CGAffineTransformIdentity;
    self.bounds = CGRectMake(0, 0, width, height);

    if (!_hasUserPosition) {
        self.center = CGPointMake(CGRectGetMidX(safe), CGRectGetMidY(safe));
        _hasUserPosition = YES;
    } else {
        self.center = [self clampedCenter:self.center inRect:safe];
    }

    self.layer.cornerRadius = 22.0;
    self.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:22.0].CGPath;
}

- (CGPoint)clampedCenter:(CGPoint)center inRect:(CGRect)safe
{
    CGFloat halfW = CGRectGetWidth(self.bounds) * 0.5;
    CGFloat halfH = CGRectGetHeight(self.bounds) * 0.5;
    CGFloat minX = CGRectGetMinX(safe) + halfW;
    CGFloat maxX = CGRectGetMaxX(safe) - halfW;
    CGFloat minY = CGRectGetMinY(safe) + halfH;
    CGFloat maxY = CGRectGetMaxY(safe) - halfH;
    center.x = clampCGFloat(center.x, minX, maxX);
    center.y = clampCGFloat(center.y, minY, maxY);
    return center;
}

- (void)handlePan:(UIPanGestureRecognizer *)gesture
{
    UIView *host = self.superview;
    if (!host) return;

    if (gesture.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
        return;
    }

    if (gesture.state != UIGestureRecognizerStateChanged &&
        gesture.state != UIGestureRecognizerStateEnded) {
        return;
    }

    CGPoint translation = [gesture translationInView:host];
    CGPoint center = CGPointMake(_panStartCenter.x + translation.x,
                                 _panStartCenter.y + translation.y);

    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) {
        safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    }
    safe = CGRectInset(safe, 10.0, 10.0);

    self.transform = CGAffineTransformIdentity;
    self.center = [self clampedCenter:center inRect:safe];
    _hasUserPosition = YES;

    if (gesture.state == UIGestureRecognizerStateEnded) {
        [gesture setTranslation:CGPointZero inView:host];
    }
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (self.hidden || self.alpha <= 0.01 || !self.userInteractionEnabled) return nil;
    return [super hitTest:point withEvent:event];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldReceiveTouch:(UITouch *)touch
{
    if (gestureRecognizer == _panGesture) {
        UIView *view = touch.view;
        while (view && view != _headerView) {
            if ([view isKindOfClass:[UIControl class]]) {
                return NO;
            }
            view = view.superview;
        }
    }

    return YES;
}

@end
