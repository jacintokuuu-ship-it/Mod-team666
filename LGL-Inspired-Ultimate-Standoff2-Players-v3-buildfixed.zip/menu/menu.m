#import "menu.h"
#import "../functions/Teste.h"
#import <QuartzCore/QuartzCore.h>
#include <math.h>

static UIColor *MakterAccentColor(void)
{
    if (@available(iOS 13.0, *)) {
        return [UIColor systemOrangeColor];
    }
    return [UIColor colorWithRed:1.0 green:0.42 blue:0.08 alpha:1.0];
}

static CGFloat MakterClamp(CGFloat value, CGFloat minValue, CGFloat maxValue)
{
    if (maxValue < minValue) {
        CGFloat tmp = minValue;
        minValue = maxValue;
        maxValue = tmp;
    }
    return MIN(MAX(value, minValue), maxValue);
}

@interface MenuView ()
@property (nonatomic, strong) UIVisualEffectView *materialView;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UIView *statusDot;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *functionRow;
@property (nonatomic, strong) UISwitch *testeSwitch;
@property (nonatomic, strong) UILabel *testeValueLabel;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) UIPanGestureRecognizer *headerPanGesture;
@property (nonatomic, assign) CGPoint panStartCenter;
@property (nonatomic, assign) BOOL hasUserPosition;
@property (nonatomic, assign) UIInterfaceOrientation currentOrientation;
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, assign) NSInteger directTouchPointerId;
@property (nonatomic, assign) CGPoint directTouchStartPoint;
@property (nonatomic, assign) CGPoint directTouchStartCenter;
@property (nonatomic, assign) CGPoint directTouchStartContentOffset;
@property (nonatomic, assign) BOOL directTouchDragging;
@property (nonatomic, assign) NSInteger directTouchMode;
@end

enum {
    kDirectTouchNone = 0,
    kDirectTouchHeaderDrag = 1,
    kDirectTouchClose = 2,
    kDirectTouchContent = 3
};

@implementation MenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (!self) return nil;

    _currentOrientation = UIInterfaceOrientationPortrait;
    _directTouchPointerId = -1;
    _directTouchMode = kDirectTouchNone;
    _directTouchDragging = NO;

    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.clipsToBounds = NO;
    self.userInteractionEnabled = YES;
    self.multipleTouchEnabled = YES;
    self.exclusiveTouch = NO;

    if (@available(iOS 13.0, *)) {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:
                         [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]];
    } else {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:nil];
        _materialView.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.98];
    }
    _materialView.translatesAutoresizingMaskIntoConstraints = NO;
    _materialView.layer.cornerRadius = 18.0;
    _materialView.clipsToBounds = YES;
    [self addSubview:_materialView];

    UIView *border = [[UIView alloc] init];
    border.translatesAutoresizingMaskIntoConstraints = NO;
    border.userInteractionEnabled = NO;
    border.backgroundColor = UIColor.clearColor;
    border.layer.cornerRadius = 18.0;
    border.layer.borderWidth = 0.8;
    border.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.14].CGColor;
    [_materialView.contentView addSubview:border];

    _headerView = [[UIView alloc] init];
    _headerView.translatesAutoresizingMaskIntoConstraints = NO;
    _headerView.backgroundColor = UIColor.clearColor;
    [_materialView.contentView addSubview:_headerView];

    _titleLabel = [[UILabel alloc] init];
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLabel.text = @"MAKTER";
    _titleLabel.textColor = UIColor.whiteColor;
    _titleLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightBold];
    [_headerView addSubview:_titleLabel];

    _subtitleLabel = [[UILabel alloc] init];
    _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _subtitleLabel.text = @"MENU DE CONTROLE";
    _subtitleLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.48];
    _subtitleLabel.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightSemibold];
    [_headerView addSubview:_subtitleLabel];

    _statusDot = [[UIView alloc] init];
    _statusDot.translatesAutoresizingMaskIntoConstraints = NO;
    _statusDot.layer.cornerRadius = 4.0;
    [_headerView addSubview:_statusDot];

    _statusLabel = [[UILabel alloc] init];
    _statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _statusLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.58];
    _statusLabel.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightSemibold];
    [_headerView addSubview:_statusLabel];

    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _closeButton.translatesAutoresizingMaskIntoConstraints = NO;
    _closeButton.tintColor = UIColor.whiteColor;
    _closeButton.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.08];
    _closeButton.layer.cornerRadius = 15.0;
    [_closeButton setTitle:@"−" forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:20.0 weight:UIFontWeightMedium];
    _closeButton.accessibilityLabel = @"Minimizar menu";
    [_closeButton addTarget:self action:@selector(closePressed:) forControlEvents:UIControlEventTouchUpInside];
    [_headerView addSubview:_closeButton];

    _scrollView = [[UIScrollView alloc] init];
    _scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.alwaysBounceVertical = NO;
    _scrollView.directionalLockEnabled = YES;
    _scrollView.delaysContentTouches = NO;
    _scrollView.canCancelContentTouches = YES;
    [_materialView.contentView addSubview:_scrollView];

    UIView *content = [[UIView alloc] init];
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [_scrollView addSubview:content];

    UILabel *section = [[UILabel alloc] init];
    section.translatesAutoresizingMaskIntoConstraints = NO;
    section.text = @"FUNÇÃO";
    section.textColor = MakterAccentColor();
    section.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightBold];
    [content addSubview:section];

    _functionRow = [[UIView alloc] init];
    _functionRow.translatesAutoresizingMaskIntoConstraints = NO;
    _functionRow.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    _functionRow.layer.cornerRadius = 13.0;
    [content addSubview:_functionRow];

    UILabel *functionTitle = [[UILabel alloc] init];
    functionTitle.translatesAutoresizingMaskIntoConstraints = NO;
    functionTitle.text = @"Teste";
    functionTitle.textColor = UIColor.whiteColor;
    functionTitle.font = [UIFont systemFontOfSize:13.0 weight:UIFontWeightSemibold];
    [_functionRow addSubview:functionTitle];

    UILabel *functionSubtitle = [[UILabel alloc] init];
    functionSubtitle.translatesAutoresizingMaskIntoConstraints = NO;
    functionSubtitle.text = @"Mostra a quantidade de jogadores na partida.";
    functionSubtitle.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.50];
    functionSubtitle.font = [UIFont systemFontOfSize:9.0 weight:UIFontWeightRegular];
    functionSubtitle.numberOfLines = 2;
    [_functionRow addSubview:functionSubtitle];

    _testeSwitch = [[UISwitch alloc] init];
    _testeSwitch.translatesAutoresizingMaskIntoConstraints = NO;
    _testeSwitch.onTintColor = MakterAccentColor();
    _testeSwitch.accessibilityLabel = @"Teste";
    [_testeSwitch addTarget:self action:@selector(testeSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [_functionRow addSubview:_testeSwitch];

    UIView *resultCard = [[UIView alloc] init];
    resultCard.translatesAutoresizingMaskIntoConstraints = NO;
    resultCard.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.045];
    resultCard.layer.cornerRadius = 13.0;
    [content addSubview:resultCard];

    UILabel *resultTitle = [[UILabel alloc] init];
    resultTitle.translatesAutoresizingMaskIntoConstraints = NO;
    resultTitle.text = @"JOGADORES NA PARTIDA";
    resultTitle.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.45];
    resultTitle.font = [UIFont systemFontOfSize:8.0 weight:UIFontWeightBold];
    [resultCard addSubview:resultTitle];

    _testeValueLabel = [[UILabel alloc] init];
    _testeValueLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _testeValueLabel.text = @"—";
    _testeValueLabel.textColor = UIColor.whiteColor;
    _testeValueLabel.font = [UIFont monospacedDigitSystemFontOfSize:22.0 weight:UIFontWeightBold];
    [resultCard addSubview:_testeValueLabel];

    _hintLabel = [[UILabel alloc] init];
    _hintLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _hintLabel.text = @"Toque no Teste para iniciar a leitura.";
    _hintLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.42];
    _hintLabel.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightRegular];
    _hintLabel.numberOfLines = 2;
    [content addSubview:_hintLabel];

    [NSLayoutConstraint activateConstraints:@[
        [_materialView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_materialView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_materialView.topAnchor constraintEqualToAnchor:self.topAnchor],
        [_materialView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],

        [border.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [border.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [border.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [border.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [_headerView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_headerView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_headerView.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [_headerView.heightAnchor constraintEqualToConstant:58.0],

        [_titleLabel.leadingAnchor constraintEqualToAnchor:_headerView.leadingAnchor constant:15.0],
        [_titleLabel.topAnchor constraintEqualToAnchor:_headerView.topAnchor constant:9.0],

        [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
        [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:2.0],

        [_statusDot.leadingAnchor constraintEqualToAnchor:_subtitleLabel.trailingAnchor constant:7.0],
        [_statusDot.centerYAnchor constraintEqualToAnchor:_subtitleLabel.centerYAnchor],
        [_statusDot.widthAnchor constraintEqualToConstant:8.0],
        [_statusDot.heightAnchor constraintEqualToConstant:8.0],

        [_statusLabel.leadingAnchor constraintEqualToAnchor:_statusDot.trailingAnchor constant:4.0],
        [_statusLabel.centerYAnchor constraintEqualToAnchor:_subtitleLabel.centerYAnchor],

        [_closeButton.trailingAnchor constraintEqualToAnchor:_headerView.trailingAnchor constant:-11.0],
        [_closeButton.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_closeButton.widthAnchor constraintEqualToConstant:30.0],
        [_closeButton.heightAnchor constraintEqualToConstant:30.0],

        [_scrollView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_scrollView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_scrollView.topAnchor constraintEqualToAnchor:_headerView.bottomAnchor constant:2.0],
        [_scrollView.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [content.leadingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.leadingAnchor],
        [content.trailingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.trailingAnchor],
        [content.topAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.topAnchor],
        [content.bottomAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.bottomAnchor],
        [content.widthAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.widthAnchor],

        [section.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:13.0],
        [section.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-13.0],
        [section.topAnchor constraintEqualToAnchor:content.topAnchor constant:10.0],
        [section.heightAnchor constraintEqualToConstant:14.0],

        [_functionRow.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:10.0],
        [_functionRow.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-10.0],
        [_functionRow.topAnchor constraintEqualToAnchor:section.bottomAnchor constant:5.0],
        [_functionRow.heightAnchor constraintEqualToConstant:62.0],

        [functionTitle.leadingAnchor constraintEqualToAnchor:_functionRow.leadingAnchor constant:12.0],
        [functionTitle.topAnchor constraintEqualToAnchor:_functionRow.topAnchor constant:9.0],
        [functionTitle.trailingAnchor constraintLessThanOrEqualToAnchor:_testeSwitch.leadingAnchor constant:-10.0],

        [functionSubtitle.leadingAnchor constraintEqualToAnchor:functionTitle.leadingAnchor],
        [functionSubtitle.topAnchor constraintEqualToAnchor:functionTitle.bottomAnchor constant:2.0],
        [functionSubtitle.trailingAnchor constraintLessThanOrEqualToAnchor:_testeSwitch.leadingAnchor constant:-10.0],

        [_testeSwitch.trailingAnchor constraintEqualToAnchor:_functionRow.trailingAnchor constant:-10.0],
        [_testeSwitch.centerYAnchor constraintEqualToAnchor:_functionRow.centerYAnchor],

        [resultCard.leadingAnchor constraintEqualToAnchor:_functionRow.leadingAnchor],
        [resultCard.trailingAnchor constraintEqualToAnchor:_functionRow.trailingAnchor],
        [resultCard.topAnchor constraintEqualToAnchor:_functionRow.bottomAnchor constant:8.0],
        [resultCard.heightAnchor constraintEqualToConstant:86.0],

        [resultTitle.leadingAnchor constraintEqualToAnchor:resultCard.leadingAnchor constant:12.0],
        [resultTitle.topAnchor constraintEqualToAnchor:resultCard.topAnchor constant:10.0],
        [resultTitle.trailingAnchor constraintEqualToAnchor:resultCard.trailingAnchor constant:-12.0],

        [_testeValueLabel.leadingAnchor constraintEqualToAnchor:resultTitle.leadingAnchor],
        [_testeValueLabel.topAnchor constraintEqualToAnchor:resultTitle.bottomAnchor constant:6.0],
        [_testeValueLabel.trailingAnchor constraintEqualToAnchor:resultTitle.trailingAnchor],
        [_testeValueLabel.bottomAnchor constraintLessThanOrEqualToAnchor:resultCard.bottomAnchor constant:-9.0],

        [_hintLabel.leadingAnchor constraintEqualToAnchor:_functionRow.leadingAnchor],
        [_hintLabel.trailingAnchor constraintEqualToAnchor:_functionRow.trailingAnchor],
        [_hintLabel.topAnchor constraintEqualToAnchor:resultCard.bottomAnchor constant:7.0],
        [_hintLabel.bottomAnchor constraintEqualToAnchor:content.bottomAnchor constant:-10.0]
    ]];

    _headerPanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleHeaderPan:)];
    _headerPanGesture.minimumNumberOfTouches = 1;
    _headerPanGesture.maximumNumberOfTouches = 1;
    _headerPanGesture.cancelsTouchesInView = NO;
    _headerPanGesture.delegate = self;
    [_headerView addGestureRecognizer:_headerPanGesture];

    // Make the entire function row tappable through UIKit fallback as well.
    UITapGestureRecognizer *rowTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(functionRowTapped:)];
    rowTap.cancelsTouchesInView = NO;
    [_functionRow addGestureRecognizer:rowTap];

    self.alpha = 1.0;
    self.hidden = NO;
    [self updateFunctionPresentation];

    _refreshTimer = [NSTimer scheduledTimerWithTimeInterval:0.65
                                                     target:self
                                                   selector:@selector(refresh)
                                                   userInfo:nil
                                                    repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_refreshTimer forMode:NSRunLoopCommonModes];

    return self;
}

- (void)dealloc
{
    [_refreshTimer invalidate];
}

- (void)functionRowTapped:(UITapGestureRecognizer *)gesture
{
    if (gesture.state != UIGestureRecognizerStateRecognized) return;

    CGPoint point = [gesture locationInView:_testeSwitch];
    if (CGRectContainsPoint(_testeSwitch.bounds, point)) {
        return;
    }

    _testeSwitch.on = !_testeSwitch.isOn;
    [self testeSwitchChanged:_testeSwitch];
}

- (void)testeSwitchChanged:(UISwitch *)sender
{
    if (sender.isOn) {
        MenuFuncaoTeste();
        _hintLabel.text = @"Leitura ativa. O valor é atualizado automaticamente.";
    } else {
        _testeValueLabel.text = @"—";
        _hintLabel.text = @"Toque no Teste para iniciar a leitura.";
    }
    [self updateFunctionPresentation];
}

- (void)refresh
{
    if (_testeSwitch.isOn) {
        MenuFuncaoTeste();
    }

    if (TesteMensagemVisivel()) {
        const char *raw = TesteMensagem();
        NSString *message = raw ? [NSString stringWithUTF8String:raw] : nil;
        if (message.length) {
            NSRegularExpression *numberRegex =
                [NSRegularExpression regularExpressionWithPattern:@"Jogadores:\\s*(\\d+)"
                                                           options:0
                                                             error:nil];
            NSTextCheckingResult *match =
                [numberRegex firstMatchInString:message options:0 range:NSMakeRange(0, message.length)];
            if (match.numberOfRanges > 1) {
                NSString *number =
                    [message substringWithRange:[match rangeAtIndex:1]];
                _testeValueLabel.text = number;
            } else if (_testeSwitch.isOn) {
                _testeValueLabel.text = @"—";
            }
        }
    }

    [self updateFunctionPresentation];
}

- (void)updateFunctionPresentation
{
    BOOL active = _testeSwitch.isOn;
    _statusDot.backgroundColor = active ? [UIColor colorWithRed:1.0 green:0.55 blue:0.12 alpha:1.0]
                                         : [[UIColor whiteColor] colorWithAlphaComponent:0.26];
    _statusLabel.text = active ? @"ATIVO" : @"PRONTO";
}

- (void)closePressed:(UIButton *)sender
{
    if (self.closeHandler) {
        self.closeHandler();
    } else {
        [self hideMenu];
    }
}

- (void)hideMenu
{
    [UIView animateWithDuration:0.16
                     animations:^{
        self.alpha = 0.0;
        self.transform = CGAffineTransformMakeScale(0.97, 0.97);
    }
                     completion:^(__unused BOOL finished) {
        self.hidden = YES;
        self.userInteractionEnabled = NO;
    }];
}

- (void)showMenu
{
    self.hidden = NO;
    self.userInteractionEnabled = YES;
    self.alpha = 1.0;
    self.transform = CGAffineTransformIdentity;
    [self refresh];
}

- (void)centerMenu
{
    UIView *host = self.superview;
    if (!host) return;
    _hasUserPosition = NO;
    [self updateForOrientation:_currentOrientation];
}

- (void)updateForOrientation:(UIInterfaceOrientation)orientation
{
    if (orientation == UIInterfaceOrientationUnknown) {
        orientation = UIInterfaceOrientationPortrait;
    }

    _currentOrientation = orientation;

    UIView *host = self.superview;
    if (!host) return;

    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) {
        safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    }
    safe = CGRectInset(safe, 8.0, 8.0);

    BOOL landscape = UIInterfaceOrientationIsLandscape(orientation);

    CGFloat desiredWidth = landscape ? 305.0 : 285.0;
    CGFloat desiredHeight = landscape ? 218.0 : 258.0;

    CGFloat availableWidth = MAX(CGRectGetWidth(safe), 1.0);
    CGFloat availableHeight = MAX(CGRectGetHeight(safe), 1.0);

    CGFloat width = MIN(desiredWidth, availableWidth);
    CGFloat height = MIN(desiredHeight, availableHeight);

    if (availableWidth >= 275.0) width = MAX(275.0, width);
    if (availableHeight >= 220.0) height = MAX(220.0, height);

    self.transform = CGAffineTransformIdentity;
    self.bounds = CGRectMake(0, 0, width, height);

    if (!_hasUserPosition) {
        self.center = CGPointMake(CGRectGetMidX(safe), CGRectGetMidY(safe));
        _hasUserPosition = YES;
    } else {
        self.center = [self clampedCenter:self.center inRect:safe];
    }

    self.layer.cornerRadius = 18.0;
    self.layer.shadowColor = UIColor.blackColor.CGColor;
    self.layer.shadowOpacity = 0.32;
    self.layer.shadowRadius = 22.0;
    self.layer.shadowOffset = CGSizeMake(0, 10);
    self.layer.shadowPath =
        [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:18.0].CGPath;
}

- (CGPoint)clampedCenter:(CGPoint)center inRect:(CGRect)safe
{
    CGFloat halfW = CGRectGetWidth(self.bounds) * 0.5;
    CGFloat halfH = CGRectGetHeight(self.bounds) * 0.5;

    CGFloat minX = CGRectGetMinX(safe) + halfW;
    CGFloat maxX = CGRectGetMaxX(safe) - halfW;
    CGFloat minY = CGRectGetMinY(safe) + halfH;
    CGFloat maxY = CGRectGetMaxY(safe) - halfH;

    center.x = MakterClamp(center.x, minX, maxX);
    center.y = MakterClamp(center.y, minY, maxY);
    return center;
}

- (void)handleHeaderPan:(UIPanGestureRecognizer *)gesture
{
    UIView *host = self.superview;
    if (!host) return;

    if (gesture.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
        return;
    }

    if (gesture.state != UIGestureRecognizerStateChanged &&
        gesture.state != UIGestureRecognizerStateEnded) {
        return;
    }

    CGPoint translation = [gesture translationInView:host];
    CGPoint center = CGPointMake(_panStartCenter.x + translation.x,
                                 _panStartCenter.y + translation.y);

    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) {
        safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    }
    safe = CGRectInset(safe, 8.0, 8.0);

    self.transform = CGAffineTransformIdentity;
    self.center = [self clampedCenter:center inRect:safe];
    _hasUserPosition = YES;

    if (gesture.state == UIGestureRecognizerStateEnded) {
        [gesture setTranslation:CGPointZero inView:host];
    }
}

#pragma mark - Deterministic HUD touch router

- (CGPoint)localPointForHUDWindowPoint:(CGPoint)point
{
    UIWindow *window = self.window;
    if (window) {
        return [self convertPoint:point fromView:window];
    }

    if (self.superview) {
        return [self convertPoint:point fromView:self.superview];
    }

    return point;
}

- (BOOL)directPoint:(CGPoint)point insideView:(UIView *)view
{
    if (!view || view.hidden || view.alpha <= 0.01) return NO;
    CGPoint local = [view convertPoint:point fromView:self];
    return CGRectContainsPoint(view.bounds, local);
}

- (UISwitch *)findSwitchInView:(UIView *)view
{
    if (!view) return nil;
    if ([view isKindOfClass:[UISwitch class]]) {
        return (UISwitch *)view;
    }

    for (UIView *subview in view.subviews) {
        UISwitch *result = [self findSwitchInView:subview];
        if (result) return result;
    }

    return nil;
}

- (void)activateContentAtPoint:(CGPoint)local
{
    CGPoint functionPoint = [_functionRow convertPoint:local fromView:self];
    if (CGRectContainsPoint(_functionRow.bounds, functionPoint)) {
        UISwitch *toggle = _testeSwitch;
        toggle.on = !toggle.isOn;
        [self testeSwitchChanged:toggle];
    }
}

- (BOOL)handleHUDTouchAtWindowPoint:(CGPoint)point
                              phase:(UITouchPhase)phase
                          pointerId:(NSInteger)pointerId
{
    if (pointerId <= 0) return NO;

    CGPoint local = [self localPointForHUDWindowPoint:point];

    if (phase == UITouchPhaseBegan) {
        if (self.hidden || self.alpha <= 0.01 || !self.userInteractionEnabled) {
            return NO;
        }

        if (_directTouchPointerId != -1) {
            return NO;
        }

        _directTouchPointerId = pointerId;
        _directTouchStartPoint = local;
        _directTouchStartCenter = self.center;
        _directTouchStartContentOffset = _scrollView.contentOffset;
        _directTouchDragging = NO;
        _directTouchMode = kDirectTouchNone;

        CGPoint closePoint = [_closeButton convertPoint:local fromView:self];
        CGPoint headerPoint = [_headerView convertPoint:local fromView:self];

        if (CGRectContainsPoint(_closeButton.bounds, closePoint)) {
            _directTouchMode = kDirectTouchClose;
        } else if (CGRectContainsPoint(_headerView.bounds, headerPoint)) {
            _directTouchMode = kDirectTouchHeaderDrag;
        } else if ([self directPoint:local insideView:_scrollView]) {
            _directTouchMode = kDirectTouchContent;
        }

        // Every touch that starts inside the visible panel belongs to the HUD.
        // It cannot leak a game touch and it cannot dismiss the menu.
        return CGRectContainsPoint(self.bounds, local);
    }

    if (_directTouchPointerId != pointerId) {
        return NO;
    }

    CGPoint delta = CGPointMake(local.x - _directTouchStartPoint.x,
                                local.y - _directTouchStartPoint.y);
    CGFloat distance = hypot(delta.x, delta.y);

    if (phase == UITouchPhaseMoved || phase == UITouchPhaseStationary) {
        if (_directTouchMode == kDirectTouchHeaderDrag) {
            if (distance > 2.0) {
                _directTouchDragging = YES;
            }

            if (_directTouchDragging) {
                UIView *host = self.superview;
                if (host) {
                    CGRect safe = host.bounds;
                    if (@available(iOS 11.0, *)) {
                        safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
                    }
                    safe = CGRectInset(safe, 8.0, 8.0);

                    CGPoint desired =
                        CGPointMake(_directTouchStartCenter.x + delta.x,
                                    _directTouchStartCenter.y + delta.y);

                    self.center = [self clampedCenter:desired inRect:safe];
                    _hasUserPosition = YES;
                }
            }
            return YES;
        }

        if (_directTouchMode == kDirectTouchContent && distance > 4.0) {
            _directTouchDragging = YES;

            CGPoint offset = _directTouchStartContentOffset;
            offset.y -= delta.y;

            CGFloat maxOffset =
                MAX(0.0, _scrollView.contentSize.height - _scrollView.bounds.size.height);
            offset.y = MakterClamp(offset.y, 0.0, maxOffset);

            _scrollView.contentOffset = offset;
            return YES;
        }

        return YES;
    }

    if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
        BOOL tap = (distance <= 10.0 && !_directTouchDragging);
        NSInteger mode = _directTouchMode;
        CGPoint start = _directTouchStartPoint;

        _directTouchPointerId = -1;
        _directTouchMode = kDirectTouchNone;
        _directTouchDragging = NO;

        if (phase == UITouchPhaseEnded && tap) {
            if (mode == kDirectTouchClose) {
                [self closePressed:_closeButton];
            } else if (mode == kDirectTouchContent) {
                [self activateContentAtPoint:start];
            }
        }

        return YES;
    }

    return YES;
}

- (BOOL)hitTestAllowsHUD
{
    return !self.hidden && self.alpha > 0.01 && self.userInteractionEnabled;
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (![self hitTestAllowsHUD]) return nil;
    return [super hitTest:point withEvent:event];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldReceiveTouch:(UITouch *)touch
{
    if (gestureRecognizer == _headerPanGesture) {
        UIView *view = touch.view;
        while (view && view != _headerView) {
            if ([view isKindOfClass:[UIControl class]]) {
                return NO;
            }
            view = view.superview;
        }
    }
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
    shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

@end
