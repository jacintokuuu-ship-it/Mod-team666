#import "menu.h"
#import "../overlay/ESPImGuiView.h"
#import "../functions/Teste.h"
#import <QuartzCore/QuartzCore.h>
#import "../include/HUDBridge.h"

static const NSInteger kMenuTagBox      = 101;
static const NSInteger kMenuTagLines    = 102;
static const NSInteger kMenuTagHealth   = 103;
static const NSInteger kMenuTagName     = 104;
static const NSInteger kMenuTagWeapon   = 105;
static const NSInteger kMenuTagTeam     = 106;
static const NSInteger kMenuTagChams    = 107;
static const NSInteger kMenuTagStealth  = 108;

static CGFloat clampCGFloat(CGFloat value, CGFloat minValue, CGFloat maxValue)
{
    return MIN(MAX(value, minValue), maxValue);
}

static BOOL MenuESPAnyEnabled(void)
{
    return [ESPImGuiView showLines] ||
           [ESPImGuiView showBox] ||
           [ESPImGuiView showHealthBar] ||
           [ESPImGuiView showName] ||
           [ESPImGuiView showWeapon] ||
           [ESPImGuiView chamsEnabled];
}

static void ApplyESPState(void)
{
    const BOOL enabled = MenuESPAnyEnabled();
    [ESPImGuiView setESPEnabled:enabled];
    [ESPImGuiView setTracersEnabled:enabled];
    HUDSetESPEnabled(enabled);
    HUDSetTracersEnabled(enabled);
}

@interface MenuView () <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIVisualEffectView *materialView;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UISegmentedControl *tabControl;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIStackView *contentStack;
@property (nonatomic, strong) UIStackView *mainStack;
@property (nonatomic, strong) UIStackView *toolsStack;
@property (nonatomic, strong) UILabel *testStatusLabel;
@property (nonatomic, strong) NSMutableDictionary<NSNumber *, UISwitch *> *switches;
@property (nonatomic, strong) UIPanGestureRecognizer *panGesture;
@property (nonatomic, assign) CGPoint panStartCenter;
@property (nonatomic, assign) UIInterfaceOrientation currentOrientation;
@property (nonatomic, assign) BOOL hasUserPosition;
@property (nonatomic, strong) NSTimer *statusTimer;
@end

@implementation MenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (!self) return nil;

    _currentOrientation = UIInterfaceOrientationPortrait;
    _switches = [NSMutableDictionary dictionary];

    self.backgroundColor = [UIColor clearColor];
    self.opaque = NO;
    self.clipsToBounds = NO;
    self.userInteractionEnabled = YES;
    self.multipleTouchEnabled = YES;
    self.exclusiveTouch = NO;
    self.layer.shadowColor = [UIColor blackColor].CGColor;
    self.layer.shadowOpacity = 0.30;
    self.layer.shadowRadius = 24.0;
    self.layer.shadowOffset = CGSizeMake(0, 12);

    UIBlurEffectStyle blurStyle = UIBlurEffectStyleSystemChromeMaterialDark;
    if (@available(iOS 13.0, *)) {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:[UIBlurEffect effectWithStyle:blurStyle]];
    } else {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:nil];
        _materialView.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.98];
    }
    _materialView.translatesAutoresizingMaskIntoConstraints = NO;
    _materialView.layer.cornerRadius = 22.0;
    _materialView.clipsToBounds = YES;
    [self addSubview:_materialView];

    UIView *border = [[UIView alloc] init];
    border.translatesAutoresizingMaskIntoConstraints = NO;
    border.userInteractionEnabled = NO;
    border.backgroundColor = [UIColor clearColor];
    border.layer.cornerRadius = 22.0;
    border.layer.borderWidth = 0.8;
    border.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.12].CGColor;
    [_materialView.contentView addSubview:border];

    _headerView = [[UIView alloc] init];
    _headerView.translatesAutoresizingMaskIntoConstraints = NO;
    _headerView.backgroundColor = [UIColor clearColor];
    [_materialView.contentView addSubview:_headerView];

    _titleLabel = [[UILabel alloc] init];
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLabel.text = @"NEXUS";
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.font = [UIFont systemFontOfSize:18.0 weight:UIFontWeightBold];
    [_headerView addSubview:_titleLabel];

    _subtitleLabel = [[UILabel alloc] init];
    _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _subtitleLabel.text = @"Universal HUD";
    _subtitleLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.52];
    _subtitleLabel.font = [UIFont systemFontOfSize:11.0 weight:UIFontWeightMedium];
    [_headerView addSubview:_subtitleLabel];

    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _closeButton.translatesAutoresizingMaskIntoConstraints = NO;
    _closeButton.tintColor = [UIColor whiteColor];
    _closeButton.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.08];
    _closeButton.layer.cornerRadius = 17.0;
    if (@available(iOS 13.0, *)) {
        [_closeButton setImage:[UIImage systemImageNamed:@"xmark"] forState:UIControlStateNormal];
    } else {
        [_closeButton setTitle:@"×" forState:UIControlStateNormal];
    }
    [_closeButton addTarget:self action:@selector(closePressed:) forControlEvents:UIControlEventTouchUpInside];
    [_headerView addSubview:_closeButton];

    _tabControl = [[UISegmentedControl alloc] initWithItems:@[@"ESP", @"TOOLS"]];
    _tabControl.translatesAutoresizingMaskIntoConstraints = NO;
    _tabControl.selectedSegmentIndex = 0;
    [_tabControl addTarget:self action:@selector(tabChanged:) forControlEvents:UIControlEventValueChanged];
    [_materialView.contentView addSubview:_tabControl];

    _scrollView = [[UIScrollView alloc] init];
    _scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.alwaysBounceVertical = YES;
    _scrollView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    [_materialView.contentView addSubview:_scrollView];

    UIView *scrollContent = [[UIView alloc] init];
    scrollContent.translatesAutoresizingMaskIntoConstraints = NO;
    [_scrollView addSubview:scrollContent];

    _contentStack = [[UIStackView alloc] init];
    _contentStack.translatesAutoresizingMaskIntoConstraints = NO;
    _contentStack.axis = UILayoutConstraintAxisVertical;
    _contentStack.alignment = UIStackViewAlignmentFill;
    _contentStack.spacing = 0.0;
    [scrollContent addSubview:_contentStack];

    _mainStack = [[UIStackView alloc] init];
    _mainStack.translatesAutoresizingMaskIntoConstraints = NO;
    _mainStack.axis = UILayoutConstraintAxisVertical;
    _mainStack.spacing = 9.0;
    [_mainStack setLayoutMargins:UIEdgeInsetsMake(12, 14, 18, 14)];
    _mainStack.layoutMarginsRelativeArrangement = YES;
    [_contentStack addArrangedSubview:_mainStack];

    _toolsStack = [[UIStackView alloc] init];
    _toolsStack.translatesAutoresizingMaskIntoConstraints = NO;
    _toolsStack.axis = UILayoutConstraintAxisVertical;
    _toolsStack.spacing = 10.0;
    _toolsStack.layoutMarginsRelativeArrangement = YES;
    _toolsStack.layoutMargins = UIEdgeInsetsMake(12, 14, 18, 14);
    [_contentStack addArrangedSubview:_toolsStack];

    [NSLayoutConstraint activateConstraints:@[
        [_materialView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_materialView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_materialView.topAnchor constraintEqualToAnchor:self.topAnchor],
        [_materialView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],

        [border.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [border.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [border.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [border.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [_headerView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_headerView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_headerView.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [_headerView.heightAnchor constraintEqualToConstant:62.0],

        [_titleLabel.leadingAnchor constraintEqualToAnchor:_headerView.leadingAnchor constant:18.0],
        [_titleLabel.topAnchor constraintEqualToAnchor:_headerView.topAnchor constant:13.0],
        [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
        [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:2.0],

        [_closeButton.trailingAnchor constraintEqualToAnchor:_headerView.trailingAnchor constant:-14.0],
        [_closeButton.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_closeButton.widthAnchor constraintEqualToConstant:34.0],
        [_closeButton.heightAnchor constraintEqualToConstant:34.0],

        [_tabControl.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor constant:14.0],
        [_tabControl.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor constant:-14.0],
        [_tabControl.topAnchor constraintEqualToAnchor:_headerView.bottomAnchor constant:4.0],
        [_tabControl.heightAnchor constraintEqualToConstant:34.0],

        [_scrollView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_scrollView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_scrollView.topAnchor constraintEqualToAnchor:_tabControl.bottomAnchor constant:5.0],
        [_scrollView.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [scrollContent.leadingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.leadingAnchor],
        [scrollContent.trailingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.trailingAnchor],
        [scrollContent.topAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.topAnchor],
        [scrollContent.bottomAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.bottomAnchor],
        [scrollContent.widthAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.widthAnchor],

        [_contentStack.leadingAnchor constraintEqualToAnchor:scrollContent.leadingAnchor],
        [_contentStack.trailingAnchor constraintEqualToAnchor:scrollContent.trailingAnchor],
        [_contentStack.topAnchor constraintEqualToAnchor:scrollContent.topAnchor],
        [_contentStack.bottomAnchor constraintEqualToAnchor:scrollContent.bottomAnchor]
    ]];

    [self buildMainTab];
    [self buildToolsTab];

    _toolsStack.hidden = YES;
    _mainStack.hidden = NO;
    _panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handlePan:)];
    _panGesture.cancelsTouchesInView = NO;
    _panGesture.delegate = self;
    [_headerView addGestureRecognizer:_panGesture];

    self.alpha = 1.0;
    self.hidden = NO;

    _statusTimer = [NSTimer scheduledTimerWithTimeInterval:0.25 target:self selector:@selector(refreshStatus) userInfo:nil repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_statusTimer forMode:NSRunLoopCommonModes];
    [self refreshStatus];

    return self;
}

- (void)dealloc
{
    [_statusTimer invalidate];
}

- (void)buildMainTab
{
    UILabel *section = [self sectionLabel:@"VISUAL"];
    [_mainStack addArrangedSubview:section];

    [self addSwitchRowToStack:_mainStack title:@"Boxes" subtitle:@"2D player rectangles" tag:kMenuTagBox initial:[ESPImGuiView showBox]];
    [self addSwitchRowToStack:_mainStack title:@"Lines" subtitle:@"Snap lines to targets" tag:kMenuTagLines initial:[ESPImGuiView showLines]];
    [self addSwitchRowToStack:_mainStack title:@"Health" subtitle:@"Draw the health bar" tag:kMenuTagHealth initial:[ESPImGuiView showHealthBar]];
    [self addSwitchRowToStack:_mainStack title:@"Names" subtitle:@"Display player names" tag:kMenuTagName initial:[ESPImGuiView showName]];
    [self addSwitchRowToStack:_mainStack title:@"Weapons" subtitle:@"Display weapon text" tag:kMenuTagWeapon initial:[ESPImGuiView showWeapon]];
    [self addSwitchRowToStack:_mainStack title:@"Team check" subtitle:@"Use the existing team filter" tag:kMenuTagTeam initial:[ESPImGuiView teamCheck]];

    UILabel *note = [self sectionLabel:@"HUD INPUT"];
    [_mainStack addArrangedSubview:note];

    UIView *inputCard = [self infoCardWithTitle:@"Native event pipeline"
                                         message:@"HUD window → HID/AX → UITouch/UIEvent → UIKit controls"];
    [_mainStack addArrangedSubview:inputCard];

    UIButton *stealth = [self actionButtonWithTitle:@"Stealth / Capture protection"];
    stealth.accessibilityIdentifier = @"nexus.stealth";
    [stealth addTarget:self action:@selector(toggleStealth:) forControlEvents:UIControlEventTouchUpInside];
    [_mainStack addArrangedSubview:stealth];
}

- (void)buildToolsTab
{
    UILabel *section = [self sectionLabel:@"READ-ONLY TEST"];
    [_toolsStack addArrangedSubview:section];

    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    card.layer.cornerRadius = 16.0;

    UILabel *title = [[UILabel alloc] init];
    title.translatesAutoresizingMaskIntoConstraints = NO;
    title.text = @"Memory engine test";
    title.textColor = [UIColor whiteColor];
    title.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    [card addSubview:title];

    _testStatusLabel = [[UILabel alloc] init];
    _testStatusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _testStatusLabel.numberOfLines = 0;
    _testStatusLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.62];
    _testStatusLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightRegular];
    _testStatusLabel.text = @"No test executed.";
    [card addSubview:_testStatusLabel];

    UIButton *run = [self actionButtonWithTitle:@"TEST READ PATH"];
    [run addTarget:self action:@selector(runReadTest:) forControlEvents:UIControlEventTouchUpInside];

    [card addSubview:run];

    [NSLayoutConstraint activateConstraints:@[
        [card.heightAnchor constraintGreaterThanOrEqualToConstant:132.0],
        [title.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:14.0],
        [title.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-14.0],
        [title.topAnchor constraintEqualToAnchor:card.topAnchor constant:13.0],
        [_testStatusLabel.leadingAnchor constraintEqualToAnchor:title.leadingAnchor],
        [_testStatusLabel.trailingAnchor constraintEqualToAnchor:title.trailingAnchor],
        [_testStatusLabel.topAnchor constraintEqualToAnchor:title.bottomAnchor constant:6.0],
        [_testStatusLabel.bottomAnchor constraintLessThanOrEqualToAnchor:run.topAnchor constant:-10.0],
        [run.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:12.0],
        [run.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-12.0],
        [run.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-12.0],
        [run.heightAnchor constraintEqualToConstant:38.0]
    ]];

    [_toolsStack addArrangedSubview:card];

    UILabel *status = [self sectionLabel:@"ENGINE"];
    [_toolsStack addArrangedSubview:status];
    UIView *engine = [self infoCardWithTitle:@"External core preserved"
                                      message:@"PID/task lookup, Unity address resolution and existing read path remain in their original modules."];
    [_toolsStack addArrangedSubview:engine];
}

- (UILabel *)sectionLabel:(NSString *)text
{
    UILabel *label = [[UILabel alloc] init];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.textColor = [[UIColor systemBlueColor] colorWithAlphaComponent:0.85];
    label.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
    label.textAlignment = NSTextAlignmentLeft;
    return label;
}

- (UIView *)infoCardWithTitle:(NSString *)title message:(NSString *)message
{
    UIView *card = [[UIView alloc] init];
    card.translatesAutoresizingMaskIntoConstraints = NO;
    card.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.045];
    card.layer.cornerRadius = 14.0;

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = title;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold];
    [card addSubview:titleLabel];

    UILabel *messageLabel = [[UILabel alloc] init];
    messageLabel.translatesAutoresizingMaskIntoConstraints = NO;
    messageLabel.text = message;
    messageLabel.numberOfLines = 0;
    messageLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.58];
    messageLabel.font = [UIFont systemFontOfSize:10.5 weight:UIFontWeightRegular];
    [card addSubview:messageLabel];

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.leadingAnchor constraintEqualToAnchor:card.leadingAnchor constant:13.0],
        [titleLabel.trailingAnchor constraintEqualToAnchor:card.trailingAnchor constant:-13.0],
        [titleLabel.topAnchor constraintEqualToAnchor:card.topAnchor constant:11.0],
        [messageLabel.leadingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor],
        [messageLabel.trailingAnchor constraintEqualToAnchor:titleLabel.trailingAnchor],
        [messageLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:4.0],
        [messageLabel.bottomAnchor constraintEqualToAnchor:card.bottomAnchor constant:-11.0]
    ]];

    return card;
}

- (UIButton *)actionButtonWithTitle:(NSString *)title
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    button.backgroundColor = [[UIColor systemBlueColor] colorWithAlphaComponent:0.18];
    button.layer.cornerRadius = 12.0;
    button.tintColor = [UIColor whiteColor];
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightBold];
    button.accessibilityTraits = UIAccessibilityTraitButton;
    return button;
}

- (void)addSwitchRowToStack:(UIStackView *)stack title:(NSString *)title subtitle:(NSString *)subtitle tag:(NSInteger)tag initial:(BOOL)initial
{
    UIView *row = [[UIView alloc] init];
    row.translatesAutoresizingMaskIntoConstraints = NO;
    row.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    row.layer.cornerRadius = 14.0;
    [row.heightAnchor constraintEqualToConstant:60.0].active = YES;

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = title;
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [row addSubview:titleLabel];

    UILabel *subtitleLabel = [[UILabel alloc] init];
    subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    subtitleLabel.text = subtitle;
    subtitleLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.47];
    subtitleLabel.font = [UIFont systemFontOfSize:9.5 weight:UIFontWeightRegular];
    [row addSubview:subtitleLabel];

    UISwitch *toggle = [[UISwitch alloc] init];
    toggle.translatesAutoresizingMaskIntoConstraints = NO;
    toggle.onTintColor = [UIColor systemBlueColor];
    toggle.on = initial;
    toggle.tag = tag;
    [toggle addTarget:self action:@selector(featureSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [row addSubview:toggle];
    self.switches[@(tag)] = toggle;

    [NSLayoutConstraint activateConstraints:@[
        [titleLabel.leadingAnchor constraintEqualToAnchor:row.leadingAnchor constant:13.0],
        [titleLabel.topAnchor constraintEqualToAnchor:row.topAnchor constant:10.0],
        [titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:toggle.leadingAnchor constant:-10.0],
        [subtitleLabel.leadingAnchor constraintEqualToAnchor:titleLabel.leadingAnchor],
        [subtitleLabel.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:2.0],
        [subtitleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:toggle.leadingAnchor constant:-10.0],
        [toggle.trailingAnchor constraintEqualToAnchor:row.trailingAnchor constant:-11.0],
        [toggle.centerYAnchor constraintEqualToAnchor:row.centerYAnchor]
    ]];

    [stack addArrangedSubview:row];
}

- (void)closePressed:(UIButton *)sender
{
    if (self.closeHandler) {
        self.closeHandler();
    } else {
        [self hideMenu];
    }
}

- (void)tabChanged:(UISegmentedControl *)sender
{
    const BOOL tools = (sender.selectedSegmentIndex == 1);
    _mainStack.hidden = tools;
    _toolsStack.hidden = !tools;
    [_scrollView setContentOffset:CGPointZero animated:NO];
}

- (void)featureSwitchChanged:(UISwitch *)sender
{
    switch (sender.tag) {
        case kMenuTagBox:     [ESPImGuiView setShowBox:sender.on]; break;
        case kMenuTagLines:   [ESPImGuiView setShowLines:sender.on]; break;
        case kMenuTagHealth:  [ESPImGuiView setShowHealthBar:sender.on]; break;
        case kMenuTagName:    [ESPImGuiView setShowName:sender.on]; break;
        case kMenuTagWeapon:  [ESPImGuiView setShowWeapon:sender.on]; break;
        case kMenuTagTeam:    [ESPImGuiView setTeamCheck:sender.on]; return;
        default: return;
    }
    ApplyESPState();
}

- (void)toggleStealth:(UIButton *)sender
{
    const BOOL enabled = ![ESPImGuiView stealthEnabled];
    [ESPImGuiView setStealthEnabled:enabled];
    HUDSetStealthEnabled(enabled);
    [sender setTitle:(enabled ? @"Stealth: ON" : @"Stealth / Capture protection") forState:UIControlStateNormal];
}

- (void)runReadTest:(UIButton *)sender
{
    sender.enabled = NO;
    MenuFuncaoTeste();
    [self refreshStatus];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.55 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        sender.enabled = YES;
    });
}

- (void)refreshStatus
{
    if (!_testStatusLabel) return;
    if (TesteMensagemVisivel()) {
        _testStatusLabel.text = [NSString stringWithUTF8String:TesteMensagem()] ?: @"Test completed.";
    } else if (_testStatusLabel.text.length > 0 && ![_testStatusLabel.text isEqualToString:@"No test executed."]) {
        _testStatusLabel.text = @"No active test message.";
    }
}

- (void)hideMenu
{
    [UIView animateWithDuration:0.18 animations:^{
        self.alpha = 0.0;
        self.transform = CGAffineTransformMakeScale(0.97, 0.97);
    } completion:^(__unused BOOL finished) {
        self.hidden = YES;
        self.userInteractionEnabled = NO;
    }];
}

- (void)showMenu
{
    self.hidden = NO;
    self.userInteractionEnabled = YES;
    [UIView animateWithDuration:0.20 animations:^{
        self.alpha = 1.0;
        self.transform = CGAffineTransformIdentity;
    }];
    [self refreshStatus];
}

- (void)centerMenu
{
    UIView *host = self.superview;
    if (!host) return;
    _hasUserPosition = NO;
    [self updateForOrientation:_currentOrientation];
}

- (void)updateForOrientation:(UIInterfaceOrientation)orientation
{
    if (orientation == UIInterfaceOrientationUnknown) {
        orientation = UIInterfaceOrientationPortrait;
    }
    _currentOrientation = orientation;

    UIView *host = self.superview;
    if (!host) return;

    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) {
        safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    }
    safe = CGRectInset(safe, 12.0, 12.0);

    BOOL landscape = UIInterfaceOrientationIsLandscape(orientation);
    CGFloat desiredWidth = landscape ? 340.0 : 308.0;
    CGFloat desiredHeight = landscape ? 300.0 : 440.0;

    CGFloat availableWidth = MAX(0.0, CGRectGetWidth(safe));
    CGFloat availableHeight = MAX(0.0, CGRectGetHeight(safe));
    CGFloat width = MIN(desiredWidth, availableWidth);
    CGFloat height = MIN(desiredHeight, availableHeight);
    if (availableWidth >= 220.0) width = MAX(220.0, width);
    if (availableHeight >= 250.0) height = MAX(250.0, height);

    self.transform = CGAffineTransformIdentity;
    self.bounds = CGRectMake(0, 0, width, height);

    if (!_hasUserPosition) {
        self.center = CGPointMake(CGRectGetMidX(safe), CGRectGetMidY(safe));
        _hasUserPosition = YES;
    } else {
        self.center = [self clampedCenter:self.center inRect:safe];
    }

    self.layer.cornerRadius = 22.0;
    self.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:22.0].CGPath;
}

- (CGPoint)clampedCenter:(CGPoint)center inRect:(CGRect)safe
{
    CGFloat halfW = CGRectGetWidth(self.bounds) * 0.5;
    CGFloat halfH = CGRectGetHeight(self.bounds) * 0.5;
    center.x = clampCGFloat(center.x, CGRectGetMinX(safe) + halfW, CGRectGetMaxX(safe) - halfW);
    center.y = clampCGFloat(center.y, CGRectGetMinY(safe) + halfH, CGRectGetMaxY(safe) - halfH);
    return center;
}

- (void)handlePan:(UIPanGestureRecognizer *)gesture
{
    UIView *host = self.superview;
    if (!host) return;

    if (gesture.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
        return;
    }

    if (gesture.state != UIGestureRecognizerStateChanged &&
        gesture.state != UIGestureRecognizerStateEnded) {
        return;
    }

    CGPoint translation = [gesture translationInView:host];
    CGPoint center = CGPointMake(_panStartCenter.x + translation.x,
                                 _panStartCenter.y + translation.y);

    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) {
        safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    }
    safe = CGRectInset(safe, 12.0, 12.0);

    self.transform = CGAffineTransformIdentity;
    self.center = [self clampedCenter:center inRect:safe];
    _hasUserPosition = YES;

    if (gesture.state == UIGestureRecognizerStateEnded) {
        [gesture setTranslation:CGPointZero inView:host];
    }
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (self.hidden || self.alpha <= 0.01 || !self.userInteractionEnabled) return nil;
    return [super hitTest:point withEvent:event];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldReceiveTouch:(UITouch *)touch
{
    if (gestureRecognizer == _panGesture) {
        UIView *view = touch.view;

        // Never let the header pan steal a normal control interaction.
        while (view && view != _headerView) {
            if ([view isKindOfClass:[UIControl class]]) {
                return NO;
            }
            view = view.superview;
        }
    }

    return YES;
}

@end
