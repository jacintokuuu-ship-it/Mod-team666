#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface MenuView : UIView

/// Called by the native close button.
@property (nonatomic, copy, nullable) void (^closeHandler)(void);

/// Creates the HUD panel. The panel itself is a normal UIKit hierarchy; the
/// global HUD/window/event pipeline is owned by objc_base, not by the menu.
- (instancetype)initWithFrame:(CGRect)frame;

- (void)hideMenu;
- (void)showMenu;
- (void)centerMenu;
- (void)updateForOrientation:(UIInterfaceOrientation)orientation;

@end

NS_ASSUME_NONNULL_END
