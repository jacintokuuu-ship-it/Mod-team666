MAKTER BR 2.2.1 — launch/orientation audit

Root cause isolated from the supplied source versions:
- In 2.2.0, objc_base/TSEventFetcher.mm created 100 UITouch objects inside +load via initTouch.
- The supplied UITouch-KIFAdditions implementation of initTouch indexes connectedScenes[0] and then windows.
- This project runs its HUD as a separately hosted system/accessibility process and may have no connected UIWindowScene at +load.
- That makes startup crash possible before the HUD is shown.
- The 2.1.0 source avoided this by allocating empty pointer slots and creating UITouch lazily from the real HUD window after the first Began event.

Changes in 2.2.1:
1. Restored the 2.1.0 lazy TSEventFetcher initialization.
2. Preserved the 2.2.0/reference orientation model:
   - HUDMainWindow remains an ordinary stable UIWindow.
   - HUDRootViewController owns the orientation transform.
   - landscape swaps root-view bounds, then applies exactly one rotation to the root view.
3. Preserved global AX coordinates for TSEventFetcher; no extra screen->window rotation conversion.
4. Added application-identifier=com.makterbr.app to ent.plist for a consistent TrollStore-style entitlement profile.
5. Added UIRequiresFullScreen=true to avoid scene/multitasking resize behavior.
6. Synced staged Info.plist and package version to 2.2.1.
7. Makefile emits both MAKTERBR.tipa and MAKTERBR.ipa aliases.

Known limitation:
- No iPhoneOS SDK/Theos is installed in this Linux runtime, so no device-side binary/signature launch test can be performed here.
