XternalZ LGL Template UI v10 — TOUCHSAFE / SCALE2

Changes in this revision:

1. Menu visual footprint reduced to 50% of v9 dimensions (target 180 x 205 pt on devices where the original 360 x 410 pt panel fit).
2. All menu typography, row heights, toggle geometry and header/footer spacing scaled with the same 0.5 factor.
3. UIKit/MTKView is now the single authoritative touch stream for the interactive menu. The legacy AX/TSEventFetcher route is no longer used to inject/synthesize ordinary menu touches; UIKit/MTKView is the sole interactive pointer path.
4. Fullscreen transparent surfaces remain present for the existing floating-window lifecycle, but their hitTest returns nil outside the rendered ImGui window.
5. A stable primary UITouch is tracked during a finger sequence so multi-touch set enumeration cannot change the pointer to another finger mid-click.
6. Touch release is explicitly cleared when no primary touch survives, preventing a stuck MouseDown state.
7. Hidden-menu/background taps are not fed into ImGui, so the application underneath remains interactive.
8. Existing project files for hooks/memory/test/ESP were not rearchitected by this UI/touch fix.

Build:
    make clean
    make package

The repository must still be compiled with Theos + the matching iOS SDK on the build runner.
