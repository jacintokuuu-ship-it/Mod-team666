# XternalZ v9 — HUD nativo + motor externo preservado

Esta revisão mantém os módulos existentes de processo, task, leitura Unity e ESP e substitui a camada de menu/interação.

## Arquitetura

```text
Global HID/AX
     |
     v
TSEventFetcher
     |
     v
UIKit UIEvent
     |
     v
HUDMainWindow -> HUDRootViewController -> MenuView (UIKit)
                                      |
                                      +-> Teste / existing read path
                                      +-> ESP state bridge

Existing engine (unchanged in purpose)
     |
     +-> tasks/pid.mm
     +-> functions/Teste.mm / Offsets.h
     +-> unity/unity.mm
     +-> overlay/ESPImGuiView.mm
     +-> hooks/CaptainHook.h (header retained)
```

## O que mudou

- `menu/menu.m` não cria mais um `MTKView` fullscreen nem usa `gMenuWindowRect` para decidir toque.
- O menu agora é uma árvore UIKit normal (`UIView`, `UIButton`, `UISwitch`, `UIScrollView`, `UIStackView`).
- O painel possui tamanho real e é o próprio alvo do `hitTest:`; áreas externas continuam passando através da `HUDMainWindow`.
- O painel pode ser arrastado pelo cabeçalho com `UIPanGestureRecognizer`.
- A orientação reposiciona/redimensiona o painel sem aplicar a antiga rotação manual da superfície fullscreen.
- `HUDApp.mm` segue a divisão de eventos do TrollSpeed: AX em versões modernas e fallback `_enqueueHIDEvent:` quando necessário.
- `TSEventFetcher.mm` foi refeito para manter um touch por `pathIdentity` e enfileirar snapshots de eventos, eliminando os slots globais únicos `toRemove`/`toStationarify`.
- A checagem LaunchServices agora usa o bundle identifier real `com.xternalz.app` presente no `Info.plist`.

## O que não foi reescrito

Os arquivos de leitura e transformação permanecem como estavam em propósito e estrutura:

- `tasks/pid.mm`
- `functions/Teste.mm`
- `functions/Offsets.h`
- `unity/unity.mm`
- `overlay/ESPImGuiView.mm`

O código Dear ImGui também continua no projeto para compatibilidade, mas não é mais o host do menu principal.

## Observação sobre hooks

O ZIP original contém `hooks/CaptainHook.h`, mas a análise do código não encontrou call-sites ativos de `CHMethod`, `CHConstructor` ou `MSHookMessageEx` fora do próprio header/import legado. Portanto, esta revisão preserva o suporte/arquivo existente, mas não inventa hooks que não estavam implementados no ZIP.

## Build

O projeto continua com Theos e deployment target iOS 15.0. O ambiente de análise Linux não contém um SDK iPhoneOS/Theos configurado, então esta revisão foi validada estruturalmente (plists, referências e fontes) e não deve ser apresentada como um binário já compilado.
