#import <CoreFoundation/CoreFoundation.h>
#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "TSEventFetcher.h"
#import "UIApplication+Private.h"
#import "UIEvent+Private.h"
#import "UITouch-KIFAdditions.h"

// The original implementation indexed 100 reusable touches and kept one
// global "toRemove" / "toStationarify" slot. That works for simple taps but is
// fragile when two pointers change state close together. The refactor keeps a
// touch per HID pointer ID and queues immutable snapshots for UIKit delivery.
static NSMutableDictionary<NSNumber *, UITouch *> *gTouchesByID = nil;
static NSMutableArray<NSArray<UITouch *> *> *gPendingBatches = nil;
static CFRunLoopSourceRef gEventSource = NULL;

static void DeliverPendingEvents(void *info)
{
    UIApplication *app = [UIApplication sharedApplication];
    if (!app) return;

    while (gPendingBatches.count > 0) {
        NSArray<UITouch *> *batch = gPendingBatches.firstObject;
        [gPendingBatches removeObjectAtIndex:0];

        UIEvent *event = [app _touchesEvent];
        [event _clearTouches];
        for (UITouch *touch in batch) {
            [event _addTouch:touch forDelayedDelivery:NO];
        }
        [app sendEvent:event];
    }
}

@implementation TSEventFetcher

+ (void)load
{
    gTouchesByID = [NSMutableDictionary dictionary];
    gPendingBatches = [NSMutableArray array];

    CFRunLoopSourceContext context;
    memset(&context, 0, sizeof(context));
    context.perform = DeliverPendingEvents;

    gEventSource = CFRunLoopSourceCreate(kCFAllocatorDefault, -2, &context);
    if (gEventSource) {
        CFRunLoopAddSource(CFRunLoopGetMain(), gEventSource, kCFRunLoopCommonModes);
    }
}

+ (NSInteger)receiveAXEventID:(NSInteger)eventId
           atGlobalCoordinate:(CGPoint)coordinate
               withTouchPhase:(UITouchPhase)phase
                     inWindow:(UIWindow *)window
                       onView:(UIView *)view
{
    if (!window || eventId <= 0) {
        return 0;
    }

    // AX pathIdentity is an unsigned byte. Keep 1..255 usable without the old
    // 98-entry array collision/clamp behaviour.
    NSNumber *key = @(eventId & 0xFF);
    UITouch *touch = gTouchesByID[key];

    if (!touch) {
        if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
            return 0;
        }

        UIView *targetView = view;
        if (!targetView) {
            targetView = [window hitTest:coordinate withEvent:nil];
        }

        // UIKit needs a concrete view on the initial touch. A nil target means
        // the HUD has intentionally passed the coordinate through; don't create
        // a synthetic touch that would otherwise make the root consume it.
        if (!targetView) {
            return 0;
        }

        touch = [[UITouch alloc] initAtPoint:coordinate inWindow:window onView:targetView];
        if (!touch) return 0;
        gTouchesByID[key] = touch;
    } else {
        [touch setLocationInWindow:coordinate];
    }

    [touch setPhaseAndUpdateTimestamp:phase];

    NSMutableArray<UITouch *> *snapshot = [NSMutableArray arrayWithCapacity:gTouchesByID.count];
    [snapshot addObjectsFromArray:gTouchesByID.allValues];
    [gPendingBatches addObject:[snapshot copy]];

    if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
        [gTouchesByID removeObjectForKey:key];
    }

    if (gEventSource) {
        CFRunLoopSourceSignal(gEventSource);
        CFRunLoopWakeUp(CFRunLoopGetMain());
    }

    return 0;
}

@end
