# DIAGNOSTIC.md

Fluxo diagnosticado:

`attach → module → reader → entities → camera → W2S → renderer`

- **attach**: `processFound`, `processPID`, `taskOpened`
- **module**: `unityFound`, `unityBase`, `machoReadable`
- **reader**: `rvaReadableCount / rvaTestCount`
- **entities**: `entitySourceAvailable`, `entityCount`, `validEntityCount`
- **camera**: `cameraAvailable`, `projectionAvailable`
- **W2S**: somente pode ser marcado após uma cadeia estrutural comprovada
- **renderer**: `rendererFrameCount`, `rendererDrawCount`

Nenhum estágio posterior é mostrado como OK apenas porque um estágio anterior passou.
