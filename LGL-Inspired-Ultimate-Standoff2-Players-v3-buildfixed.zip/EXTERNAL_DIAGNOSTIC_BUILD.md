# XternalZ — External Diagnostic Build

This build adds a **safe standalone diagnostic** to the existing HUD.

## What it tests

- The `Excalibur` application/HUD starts normally.
- The menu refresh timer is running.
- `functions/Offsets.h` is compiled and the supplied Free Fire RVA constants are available.
- The status card updates repeatedly.
- A synthetic `Players(test)` counter changes from 0–11 so the UI update path is obvious.

Example:

```text
EXTERNAL TEST
Offsets: OK | PlayerCount RVA 0x48F8C34
Player enum RVA 0x48F8818
Players(test): 7 | HUD: OK
```

## Important

`Players(test)` is intentionally **not** a live Free Fire player count. This build does not
dereference Free Fire process memory or implement player enumeration/ESP. It is only a
diagnostic proving that the standalone External HUD and the supplied offset table are wired
into the application.

The original project files and build layout are otherwise preserved.
