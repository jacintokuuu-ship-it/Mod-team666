#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif

void MenuFuncaoPEDeMeia(void);
void MenuFuncaoDiagnosticoMemoria(void);

const char *PEDeMeiaMensagem(void);
BOOL PEDeMeiaMensagemVisivel(void);
const char *PEDeMeiaDiagnostico(void);

#ifdef __cplusplus
}
#endif
