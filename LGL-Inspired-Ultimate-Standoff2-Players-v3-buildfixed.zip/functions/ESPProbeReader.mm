#import "ESPProbeShared.h"

#include <CoreFoundation/CoreFoundation.h>
#include <Foundation/Foundation.h>
#include <dispatch/dispatch.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <cerrno>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <cstdint>

static const CFStringRef kMode0 = CFSTR("com.xternalz.esp.mode.0");
static const CFStringRef kMode1 = CFSTR("com.xternalz.esp.mode.1");
static const CFStringRef kMode2 = CFSTR("com.xternalz.esp.mode.2");
static const CFStringRef kMode3 = CFSTR("com.xternalz.esp.mode.3");

static int gSocketFD = -1;
static std::atomic<int> gLastIPCError{0};
static std::atomic<int> gLastIPCStage{0};
static std::atomic<int> gRequestedMode{0};
static ESPProbeSnapshot gLastSnapshot{};
static bool gHaveSnapshot = false;

static bool ReadFull(int fd, void *buf, size_t len)
{
    uint8_t *p = (uint8_t *)buf;
    while (len) {
        ssize_t n = recv(fd, p, len, 0);
        if (n <= 0) return false;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return true;
}

static bool ConnectIPC(void)
{
    if (gSocketFD >= 0) return true;

    gLastIPCStage.store(1, std::memory_order_release); // creating socket
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        gLastIPCError.store(errno, std::memory_order_release);
        gLastIPCStage.store(2, std::memory_order_release);
        return false;
    }

    sockaddr_in addr{};
    addr.sin_len = sizeof(addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)ESP_PROBE_IPC_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    gLastIPCStage.store(3, std::memory_order_release); // connecting
    if (connect(fd, (sockaddr *)&addr, sizeof(addr)) != 0) {
        gLastIPCError.store(errno, std::memory_order_release);
        gLastIPCStage.store(4, std::memory_order_release);
        close(fd);
        return false;
    }

    gSocketFD = fd;
    gLastIPCError.store(0, std::memory_order_release);
    gLastIPCStage.store(5, std::memory_order_release); // connected
    return true;
}

static void CloseIPC(void)
{
    if (gSocketFD >= 0) {
        close(gSocketFD);
        gSocketFD = -1;
    }
    gHaveSnapshot = false;
}

static bool ReadIPC(ESPProbeSnapshot *out)
{
    if (!out) return false;
    if (!ConnectIPC()) return false;

    ESPProbeIPCHeader hdr{};
    if (!ReadFull(gSocketFD, &hdr, sizeof(hdr))) {
        gLastIPCError.store(errno ? errno : ECONNRESET, std::memory_order_release);
        CloseIPC();
        return false;
    }

    if (hdr.magic != ESP_PROBE_IPC_MAGIC ||
        hdr.version != ESP_PROBE_IPC_VERSION ||
        hdr.payloadSize != sizeof(ESPProbeSnapshot)) {
        gLastIPCError.store(EPROTO, std::memory_order_release);
        gLastIPCStage.store(6, std::memory_order_release);
        CloseIPC();
        return false;
    }

    ESPProbeSnapshot snap{};
    if (!ReadFull(gSocketFD, &snap, sizeof(snap))) {
        gLastIPCError.store(errno ? errno : ECONNRESET, std::memory_order_release);
        CloseIPC();
        return false;
    }

    if (snap.magic != ESP_PROBE_MAGIC || snap.version != ESP_PROBE_VERSION) {
        gLastIPCError.store(EPROTO, std::memory_order_release);
        gLastIPCStage.store(7, std::memory_order_release);
        CloseIPC();
        return false;
    }

    *out = snap;
    gLastSnapshot = snap;
    gHaveSnapshot = true;
    gLastIPCError.store(0, std::memory_order_release);
    gLastIPCStage.store(5, std::memory_order_release);
    return true;
}

static void PostMode(CFStringRef name, int mode)
{
    gRequestedMode.store(mode, std::memory_order_release);
    CFNotificationCenterPostNotification(
        CFNotificationCenterGetDarwinNotifyCenter(), name, nullptr, nullptr, true);
}

extern "C" int ESPProbeSetMode(int mode)
{
    if (mode < 0 || mode > 3) mode = 0;
    switch (mode) {
        case 1: PostMode(kMode1, 1); break;
        case 2: PostMode(kMode2, 2); break;
        case 3: PostMode(kMode3, 3); break;
        default: PostMode(kMode0, 0); break;
    }
    return mode;
}

extern "C" int ESPProbeGetMode(void)
{
    if (gHaveSnapshot)
        return (int)gLastSnapshot.activeMode;
    return gRequestedMode.load(std::memory_order_acquire);
}

extern "C" int ESPProbeReadSnapshot(ESPProbeSnapshot *out)
{
    return ReadIPC(out) ? 1 : 0;
}

static const char *StageName(uint32_t stage)
{
    switch (stage) {
        case ESP_PROBE_STAGE_SHARED_READY:   return "IPC_READY";
        case ESP_PROBE_STAGE_WAITING_MSHOOK: return "AGUARDANDO_MSHOOK";
        case ESP_PROBE_STAGE_WAITING_UNITY:  return "AGUARDANDO_UNITY";
        case ESP_PROBE_STAGE_HOOKING:       return "INSTALANDO_HOOKS";
        case ESP_PROBE_STAGE_READY:         return "PRONTO";
        case ESP_PROBE_STAGE_ERROR:         return "ERRO";
        default:                             return "NAO_INICIALIZADO";
    }
}

extern "C" const char *ESPProbeStatusText(void)
{
    static char text[448];
    ESPProbeSnapshot snap{};

    if (!ReadIPC(&snap)) {
        const int stage = gLastIPCStage.load(std::memory_order_acquire);
        const int err = gLastIPCError.load(std::memory_order_acquire);
        const char *where = "socket";
        switch (stage) {
            case 1: where = "socket()"; break;
            case 2: where = "socket-falhou"; break;
            case 3: where = "connect"; break;
            case 4: where = "connect-falhou"; break;
            case 6: where = "header-invalido"; break;
            case 7: where = "snapshot-invalido"; break;
            default: break;
        }
        std::snprintf(text, sizeof(text),
                      "PROBE: IPC indisponivel | %s | 127.0.0.1:%u | errno=%d | pedido=%d",
                      where, (unsigned)ESP_PROBE_IPC_PORT, err,
                      gRequestedMode.load(std::memory_order_acquire));
        return text;
    }

    std::snprintf(text, sizeof(text),
                  "PROBE: %s | pid %u | ipc TCP | hooks 0x%02X | tent %u | Unity 0x%llX | "
                  "T%u P%u C%u W2S%u | players %u | modo %u | erro %u",
                  StageName(snap.stage),
                  snap.processPID,
                  snap.hookMask,
                  snap.hookAttempts,
                  (unsigned long long)snap.unityBase,
                  snap.transformNodeHits,
                  snap.positionHits,
                  snap.cameraHits,
                  snap.projectionHits,
                  snap.count,
                  snap.activeMode,
                  snap.errorCode);
    return text;
}
