#import "ESPProbeShared.h"

#include <CoreFoundation/CoreFoundation.h>
#include <Foundation/Foundation.h>
#include <dispatch/dispatch.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <cerrno>
#include <atomic>
#include <cmath>
#include <cstdio>
#include <cstring>

static const CFStringRef kMode0 = CFSTR("com.xternalz.esp.mode.0");
static const CFStringRef kMode1 = CFSTR("com.xternalz.esp.mode.1");
static const CFStringRef kMode2 = CFSTR("com.xternalz.esp.mode.2");
static const CFStringRef kMode3 = CFSTR("com.xternalz.esp.mode.3");

static int gFD = -1;
static ESPProbeSnapshot *gMap = nullptr;
static std::atomic<int> gRequestedMode{0};
static dispatch_once_t gInitOnce;

static void EnsureShared(void)
{
    dispatch_once(&gInitOnce, ^{
        gFD = shm_open(ESP_PROBE_SHM_NAME, O_CREAT | O_RDWR, 0600);
        if (gFD < 0) return;
        if (ftruncate(gFD, (off_t)sizeof(ESPProbeSnapshot)) != 0) {
            close(gFD);
            gFD = -1;
            return;
        }

        void *p = mmap(nullptr,
                       sizeof(ESPProbeSnapshot),
                       PROT_READ | PROT_WRITE,
                       MAP_SHARED,
                       gFD,
                       0);
        if (p == MAP_FAILED) {
            close(gFD);
            gFD = -1;
            return;
        }

        gMap = (ESPProbeSnapshot *)p;
        if (gMap->magic != ESP_PROBE_MAGIC || gMap->version != ESP_PROBE_VERSION) {
            std::memset(gMap, 0, sizeof(*gMap));
            gMap->magic = ESP_PROBE_MAGIC;
            gMap->version = ESP_PROBE_VERSION;
        }
    });
}

static void PostMode(CFStringRef name, int mode)
{
    gRequestedMode.store(mode, std::memory_order_release);
    EnsureShared();
    CFNotificationCenterPostNotification(
        CFNotificationCenterGetDarwinNotifyCenter(), name, nullptr, nullptr, true);
}

extern "C" int ESPProbeSetMode(int mode)
{
    if (mode < 0 || mode > 3) mode = 0;
    switch (mode) {
        case 1: PostMode(kMode1, 1); break;
        case 2: PostMode(kMode2, 2); break;
        case 3: PostMode(kMode3, 3); break;
        default: PostMode(kMode0, 0); break;
    }
    return mode;
}

extern "C" int ESPProbeGetMode(void)
{
    EnsureShared();
    if (gMap && gMap->magic == ESP_PROBE_MAGIC)
        return (int)gMap->activeMode;
    return gRequestedMode.load(std::memory_order_acquire);
}

static int ReadStable(ESPProbeSnapshot *out)
{
    if (!out) return 0;
    EnsureShared();
    if (!gMap || gMap->magic != ESP_PROBE_MAGIC || gMap->version != ESP_PROBE_VERSION)
        return 0;

    for (int attempt = 0; attempt < 8; ++attempt) {
        uint32_t a = gMap->sequence;
        if (a & 1u) continue;
        std::atomic_thread_fence(std::memory_order_acquire);
        std::memcpy(out, gMap, sizeof(*out));
        std::atomic_thread_fence(std::memory_order_acquire);
        uint32_t b = gMap->sequence;
        if (a == b && !(b & 1u)) return 1;
    }
    return 0;
}

extern "C" int ESPProbeReadSnapshot(ESPProbeSnapshot *out)
{
    return ReadStable(out);
}

static const char *StageName(uint32_t stage)
{
    switch (stage) {
        case ESP_PROBE_STAGE_SHARED_READY:   return "SHM_OK";
        case ESP_PROBE_STAGE_WAITING_MSHOOK: return "AGUARDANDO_MSHOOK";
        case ESP_PROBE_STAGE_WAITING_UNITY:  return "AGUARDANDO_UNITY";
        case ESP_PROBE_STAGE_HOOKING:       return "INSTALANDO_HOOKS";
        case ESP_PROBE_STAGE_READY:         return "PRONTO";
        case ESP_PROBE_STAGE_ERROR:         return "ERRO";
        default:                             return "NAO_INICIALIZADO";
    }
}

extern "C" const char *ESPProbeStatusText(void)
{
    static char text[384];
    ESPProbeSnapshot snap{};
    EnsureShared();

    if (!gMap) {
        std::snprintf(text, sizeof(text),
                      "PROBE: SHM indisponivel | fd=%d errno=%d | pedido=%d",
                      gFD, errno, gRequestedMode.load(std::memory_order_acquire));
        return text;
    }

    if (!ReadStable(&snap)) {
        std::snprintf(text, sizeof(text),
                      "PROBE: snapshot instavel | SHM OK | pedido=%d",
                      gRequestedMode.load(std::memory_order_acquire));
        return text;
    }

    std::snprintf(text, sizeof(text),
                  "PROBE: %s | pid %u | hooks 0x%02X | tent %u | Unity 0x%llX | "
                  "T%u P%u C%u W2S%u | players %u | modo %u | erro %u",
                  StageName(snap.stage),
                  snap.processPID,
                  snap.hookMask,
                  snap.hookAttempts,
                  (unsigned long long)snap.unityBase,
                  snap.transformNodeHits,
                  snap.positionHits,
                  snap.cameraHits,
                  snap.projectionHits,
                  snap.count,
                  snap.activeMode,
                  snap.errorCode);
    return text;
}
