#pragma once

#ifdef __OBJC__
#import <Foundation/Foundation.h>
#else
#include <stdbool.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

// Scans the currently running Standoff 2 process and shows the
// detected room/player count using the same memory path as the existing ESP.
void MenuFuncaoTeste(void);

const char *TesteMensagem(void);

#ifdef __OBJC__
BOOL TesteMensagemVisivel(void);
#else
int TesteMensagemVisivel(void);
#endif

#ifdef __cplusplus
}
#endif
