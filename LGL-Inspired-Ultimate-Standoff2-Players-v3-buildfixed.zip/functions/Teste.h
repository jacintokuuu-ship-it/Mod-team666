#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

#ifdef __cplusplus
extern "C" {
#endif

void MenuFuncaoTeste(void);
void MenuFuncaoDiagnosticoMemoria(void);

const char *TesteMensagem(void);
BOOL TesteMensagemVisivel(void);

const char *TesteDiagnostico(void);
BOOL TesteProcessoEncontrado(void);
BOOL TesteTaskObtida(void);
BOOL TesteLeituraOK(void);

#ifdef __cplusplus
}
#endif
