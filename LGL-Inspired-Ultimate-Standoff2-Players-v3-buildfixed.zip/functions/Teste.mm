#import "Teste.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#include <cstdio>
#include <cstdint>

static char gTesteMessage[192] = "";
static char gTesteDiagnostic[256] = "Aguardando teste...";
static CFTimeInterval gTesteMessageUntil = 0.0;

static BOOL gProcessFound = NO;
static BOOL gTaskObtained = NO;
static BOOL gReadOK = NO;

static bool ValidPtr(mach_vm_address_t p)
{
    return p >= 0x1000000;
}

static void SetDiagnostic(const char *message)
{
    if (!message) message = "";
    std::snprintf(gTesteDiagnostic, sizeof(gTesteDiagnostic), "%s", message);
}

static bool ReadProbe(task_t task, mach_vm_address_t address)
{
    if (!task || !ValidPtr(address)) return false;

    uint32_t value = 0;
    mach_vm_size_t outSize = 0;
    kern_return_t kr = mach_vm_read_overwrite(
        task,
        address,
        sizeof(value),
        (mach_vm_address_t)&value,
        &outSize
    );

    return kr == KERN_SUCCESS && outSize == sizeof(value);
}

/*
 * Read-only infrastructure diagnostic.
 *
 * It verifies:
 *   1) Standoff2 process is discoverable;
 *   2) a task port can be obtained;
 *   3) UnityFramework is discoverable;
 *   4) a harmless read from the discovered image succeeds.
 *
 * It intentionally performs NO memory write and NO injection.
 */
static void RunMemoryDiagnostic(void)
{
    gProcessFound = NO;
    gTaskObtained = NO;
    gReadOK = NO;

    pid_t pid = get_pid_by_name("Standoff2");
    if (pid <= 0) {
        SetDiagnostic("PROCESSO: FALHOU\nTASK: —\nUNITYFRAMEWORK: —\nLEITURA: —\nESCRITA/INJEÇÃO: NÃO TESTADA");
        return;
    }
    gProcessFound = YES;

    task_t task = get_task_by_pid(pid);
    if (!task) {
        char msg[256];
        std::snprintf(
            msg, sizeof(msg),
            "PROCESSO: OK (PID %d)\nTASK: FALHOU\n%s\nLEITURA: —\nESCRITA/INJEÇÃO: NÃO TESTADA",
            pid, get_task_last_error());
        SetDiagnostic(msg);
        return;
    }
    gTaskObtained = YES;

    mach_vm_address_t base = get_image_base_address(task, "UnityFramework");
    if (!base) {
        SetDiagnostic("PROCESSO: OK\nTASK: OK\nUNITYFRAMEWORK: NÃO ENCONTRADO\nLEITURA: NÃO CONFIRMADA\nESCRITA/INJEÇÃO: NÃO TESTADA");
        return;
    }

    gReadOK = ReadProbe(task, base);

    if (!gReadOK) {
        SetDiagnostic("PROCESSO: OK\nTASK: OK\nUNITYFRAMEWORK: OK\nLEITURA: FALHOU\nESCRITA/INJEÇÃO: NÃO TESTADA");
        return;
    }

    SetDiagnostic("PROCESSO: OK\nTASK: OK\nUNITYFRAMEWORK: OK\nLEITURA: OK\nESCRITA/INJEÇÃO: NÃO TESTADA");
}

extern "C" void TesteDefinirMensagem(const char *message)
{
    if (!message) message = "";
    std::snprintf(gTesteMessage, sizeof(gTesteMessage), "%s", message);
    gTesteMessageUntil = CACurrentMediaTime() + 2.5;
}

extern "C" void MenuFuncaoDiagnosticoMemoria(void)
{
    RunMemoryDiagnostic();

    if (!gProcessFound) {
        TesteDefinirMensagem("Memória: Standoff 2 não encontrado");
    } else if (!gTaskObtained) {
        TesteDefinirMensagem("Memória: processo OK • task falhou");
    } else if (!gReadOK) {
        TesteDefinirMensagem("Memória: task OK • leitura falhou");
    } else {
        TesteDefinirMensagem("Memória: PROCESSO OK • TASK OK • LEITURA OK");
    }
}

/* Existing player-count test remains read-only and separate from the
 * infrastructure diagnostic. */
static bool ScanStandoff2PlayerCount(int *outPlayers)
{
    if (!outPlayers) return false;
    *outPlayers = 0;

    pid_t pid = get_pid_by_name("Standoff2");
    if (pid <= 0) return false;

    task_t task = get_task_by_pid(pid);
    if (!task) return false;

    mach_vm_address_t base = get_image_base_address(task, "UnityFramework");
    if (!base) return false;

    mach_vm_address_t typeInfo =
        base + SO2Offsets::PlayerManagerTypeInfoRVA;

    mach_vm_address_t parentTypeInfo =
        Read<mach_vm_address_t>(
            typeInfo + SO2Offsets::TypeInfoParentOffset, task);
    if (!ValidPtr(parentTypeInfo)) return false;

    mach_vm_address_t staticFields =
        Read<mach_vm_address_t>(
            parentTypeInfo + SO2Offsets::StaticFieldsOffsetPrimary, task);

    if (!ValidPtr(staticFields)) {
        staticFields =
            Read<mach_vm_address_t>(
                parentTypeInfo + SO2Offsets::StaticFieldsOffsetFallback, task);
    }
    if (!ValidPtr(staticFields)) return false;

    mach_vm_address_t playerManager =
        Read<mach_vm_address_t>(
            staticFields + SO2Offsets::PlayerManagerStaticFieldOffset, task);
    if (!ValidPtr(playerManager)) return false;

    mach_vm_address_t playersDict =
        Read<mach_vm_address_t>(
            playerManager + SO2Offsets::PlayersDictionaryOffset, task);
    if (!ValidPtr(playersDict)) return false;

    int c20 = Read<int>(playersDict + SO2Offsets::DictionaryCountA, task);
    int c40 = Read<int>(playersDict + SO2Offsets::DictionaryCountB, task);
    int c18 = Read<int>(playersDict + SO2Offsets::DictionaryCountC, task);

    int playersCount = 0;
    if (c20 > 0 && c20 <= 64) playersCount = c20;
    else if (c40 > 0 && c40 <= 64) playersCount = c40;
    else if (c18 > 0 && c18 <= 64) playersCount = c18;

    if (playersCount <= 0 || playersCount > 64) return false;

    *outPlayers = playersCount;
    return true;
}

extern "C" void MenuFuncaoTeste(void)
{
    int players = 0;

    if (!ScanStandoff2PlayerCount(&players)) {
        TesteDefinirMensagem("Jogadores: —");
        return;
    }

    char message[64];
    std::snprintf(message, sizeof(message), "Jogadores: %d", players);
    TesteDefinirMensagem(message);
}

extern "C" const char *TesteMensagem(void)
{
    return gTesteMessage;
}

extern "C" BOOL TesteMensagemVisivel(void)
{
    return gTesteMessage[0] != '\0' &&
           CACurrentMediaTime() < gTesteMessageUntil;
}

extern "C" const char *TesteDiagnostico(void)
{
    return gTesteDiagnostic;
}

extern "C" BOOL TesteProcessoEncontrado(void)
{
    return gProcessFound;
}

extern "C" BOOL TesteTaskObtida(void)
{
    return gTaskObtained;
}

extern "C" BOOL TesteLeituraOK(void)
{
    return gReadOK;
}
