#import "Teste.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#include <cstdio>
#include <cstdint>

static char gTesteMessage[128] = "";
static CFTimeInterval gTesteMessageUntil = 0.0;

static bool ValidPtr(mach_vm_address_t p)
{
    return p >= 0x1000000;
}

/*
 * Read-only player counter.
 *
 * The memory path intentionally stays the same as the existing project:
 * Standoff 2 -> UnityFramework -> PlayerManager -> players dictionary.
 * No game memory is written by this feature.
 */
static bool ScanStandoff2PlayerCount(int *outPlayers)
{
    if (!outPlayers) return false;
    *outPlayers = 0;

    pid_t pid = get_pid_by_name("Standoff2");
    if (pid <= 0) return false;

    task_t task = get_task_by_pid(pid);
    if (!task) return false;

    mach_vm_address_t base = get_image_base_address(task, "UnityFramework");
    if (!base) return false;

    mach_vm_address_t typeInfo =
        base + SO2Offsets::PlayerManagerTypeInfoRVA;

    mach_vm_address_t parentTypeInfo =
        Read<mach_vm_address_t>(
            typeInfo + SO2Offsets::TypeInfoParentOffset, task);
    if (!ValidPtr(parentTypeInfo)) return false;

    mach_vm_address_t staticFields =
        Read<mach_vm_address_t>(
            parentTypeInfo + SO2Offsets::StaticFieldsOffsetPrimary, task);

    if (!ValidPtr(staticFields)) {
        staticFields =
            Read<mach_vm_address_t>(
                parentTypeInfo + SO2Offsets::StaticFieldsOffsetFallback, task);
    }
    if (!ValidPtr(staticFields)) return false;

    mach_vm_address_t playerManager =
        Read<mach_vm_address_t>(
            staticFields + SO2Offsets::PlayerManagerStaticFieldOffset, task);
    if (!ValidPtr(playerManager)) return false;

    mach_vm_address_t playersDict =
        Read<mach_vm_address_t>(
            playerManager + SO2Offsets::PlayersDictionaryOffset, task);
    if (!ValidPtr(playersDict)) return false;

    int c20 = Read<int>(playersDict + SO2Offsets::DictionaryCountA, task);
    int c40 = Read<int>(playersDict + SO2Offsets::DictionaryCountB, task);
    int c18 = Read<int>(playersDict + SO2Offsets::DictionaryCountC, task);

    int playersCount = 0;
    if (c20 > 0 && c20 <= 64) {
        playersCount = c20;
    } else if (c40 > 0 && c40 <= 64) {
        playersCount = c40;
    } else if (c18 > 0 && c18 <= 64) {
        playersCount = c18;
    }

    if (playersCount <= 0 || playersCount > 64) {
        return false;
    }

    *outPlayers = playersCount;
    return true;
}

extern "C" void TesteDefinirMensagem(const char *message)
{
    if (!message) message = "";

    std::snprintf(gTesteMessage, sizeof(gTesteMessage), "%s", message);
    gTesteMessageUntil = CACurrentMediaTime() + 1.5;
}

extern "C" void MenuFuncaoTeste(void)
{
    int players = 0;

    if (!ScanStandoff2PlayerCount(&players)) {
        TesteDefinirMensagem("Jogadores: —");
        return;
    }

    char message[64];
    std::snprintf(message, sizeof(message), "Jogadores: %d", players);
    TesteDefinirMensagem(message);
}

extern "C" const char *TesteMensagem(void)
{
    return gTesteMessage;
}

extern "C" BOOL TesteMensagemVisivel(void)
{
    return gTesteMessage[0] != '\0' &&
           CACurrentMediaTime() < gTesteMessageUntil;
}
