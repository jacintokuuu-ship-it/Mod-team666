#import "PEDeMeia.h"
#import <CoreFoundation/CoreFoundation.h>
#import <QuartzCore/QuartzCore.h>
#include <cstdio>

static const CFStringRef kPEDeMeiaToggleNotification =
    CFSTR("com.lgl.pedemeia.toggle");

static char gMessage[192] = "";
static char gDiagnostic[256] =
    "Alvo: FreeFire\n"
    "Bundle: com.dts.freefireth\n"
    "Hook: UnityFramework + 0x08CDDFEC";

static CFTimeInterval gMessageUntil = 0.0;
static BOOL gEnabledState = NO;

static void SetMessage(const char *message)
{
    if (!message) message = "";
    std::snprintf(gMessage, sizeof(gMessage), "%s", message);
    gMessageUntil = CACurrentMediaTime() + 2.5;
}

extern "C" void MenuFuncaoPEDeMeia(void)
{
    gEnabledState = !gEnabledState;

    // Darwin notifications are cross-process and do not carry a payload.
    // The injected tweak flips its own state when it receives this event.
    CFNotificationCenterPostNotification(
        CFNotificationCenterGetDarwinNotifyCenter(),
        kPEDeMeiaToggleNotification,
        nullptr,
        nullptr,
        true
    );

    SetMessage(gEnabledState
        ? "PE de meia: ATIVADO"
        : "PE de meia: DESATIVADO");
}

extern "C" void MenuFuncaoDiagnosticoMemoria(void)
{
    SetMessage(gEnabledState
        ? "PE de meia: comando enviado • ATIVO"
        : "PE de meia: comando enviado • INATIVO");
}

extern "C" const char *PEDeMeiaMensagem(void)
{
    return gMessage;
}

extern "C" BOOL PEDeMeiaMensagemVisivel(void)
{
    return gMessage[0] != '\0' &&
           CACurrentMediaTime() < gMessageUntil;
}

extern "C" const char *PEDeMeiaDiagnostico(void)
{
    return gDiagnostic;
}
