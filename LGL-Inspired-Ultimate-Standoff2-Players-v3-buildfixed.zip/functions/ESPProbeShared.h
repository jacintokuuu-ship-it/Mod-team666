#pragma once

#include <stdint.h>

#define ESP_PROBE_MAGIC   0x45535031u /* ESP1 */
#define ESP_PROBE_VERSION 1u
#define ESP_PROBE_MAX_TARGETS 64u
#define ESP_PROBE_SHM_NAME "/com.xternalz.esp.probe.v1"

typedef struct ESPProbeTarget {
    uint64_t player;
    float x;
    float y;
    float z;
    float depth;
    uint32_t sourceMode;
    uint32_t valid;
    uint64_t lastUpdateNanos;
} ESPProbeTarget;

typedef struct ESPProbeSnapshot {
    uint32_t magic;
    uint32_t version;
    uint32_t sequence;
    uint32_t activeMode;
    uint32_t count;
    uint32_t hookMask;
    uint32_t transformNodeHits;
    uint32_t transformGetterHits[3];
    uint32_t positionHits;
    uint32_t cameraHits;
    uint32_t projectionHits;
    uint64_t frame;
    uint64_t updatedNanos;
    ESPProbeTarget targets[ESP_PROBE_MAX_TARGETS];
} ESPProbeSnapshot;

#ifdef __cplusplus
extern "C" {
#endif

/* HUD-side controls/reader. The same functions are harmless no-ops when the probe isn't loaded. */
int ESPProbeSetMode(int mode);
int ESPProbeGetMode(void);
int ESPProbeReadSnapshot(ESPProbeSnapshot *out);
const char *ESPProbeStatusText(void);

#ifdef __cplusplus
}
#endif
