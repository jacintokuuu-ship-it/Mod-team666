#pragma once

#include <stdint.h>

#define ESP_PROBE_MAGIC   0x45535031u /* ESP1 */
#define ESP_PROBE_VERSION 2u
#define ESP_PROBE_MAX_TARGETS 64u
#define ESP_PROBE_SHM_NAME "/com.xternalz.esp.probe.v1" /* legacy/diagnostic only */
#define ESP_PROBE_IPC_PORT 37241u
#define ESP_PROBE_IPC_MAGIC 0x45535049u /* ESPI */
#define ESP_PROBE_IPC_VERSION 1u

/* Diagnostic stages. These report lifecycle only; they do not change hook behavior. */
#define ESP_PROBE_STAGE_UNINITIALIZED   0u
#define ESP_PROBE_STAGE_SHARED_READY    1u
#define ESP_PROBE_STAGE_WAITING_MSHOOK  2u
#define ESP_PROBE_STAGE_WAITING_UNITY   3u
#define ESP_PROBE_STAGE_HOOKING         4u
#define ESP_PROBE_STAGE_READY           5u
#define ESP_PROBE_STAGE_ERROR           6u

typedef struct ESPProbeTarget {
    uint64_t player;
    float x;
    float y;
    float z;
    float depth;
    uint32_t sourceMode;
    uint32_t valid;
    uint64_t lastUpdateNanos;
} ESPProbeTarget;

typedef struct ESPProbeIPCHeader {
    uint32_t magic;
    uint32_t version;
    uint32_t payloadSize;
    uint32_t sequence;
} ESPProbeIPCHeader;

typedef struct ESPProbeSnapshot {
    uint32_t magic;
    uint32_t version;
    uint32_t sequence;
    uint32_t activeMode;
    uint32_t count;
    uint32_t hookMask;
    uint32_t transformNodeHits;
    uint32_t transformGetterHits[3];
    uint32_t positionHits;
    uint32_t cameraHits;
    uint32_t projectionHits;
    uint64_t frame;
    uint64_t updatedNanos;
    uint32_t stage;
    uint32_t errorCode;
    uint32_t hookAttempts;
    uint32_t processPID;
    uint64_t unityBase;
    uint64_t lastStageNanos;
    ESPProbeTarget targets[ESP_PROBE_MAX_TARGETS];
} ESPProbeSnapshot;

#ifdef __cplusplus
extern "C" {
#endif

/* HUD-side controls/reader. The same functions are harmless no-ops when the probe isn't loaded. */
int ESPProbeSetMode(int mode);
int ESPProbeGetMode(void);
int ESPProbeReadSnapshot(ESPProbeSnapshot *out);
const char *ESPProbeStatusText(void);

#ifdef __cplusplus
}
#endif
