#pragma once
#include <stdint.h>

/* Free Fire external-reference RVAs supplied by the user's dump. */
namespace FreeFireOffsets {
    // Player enumeration candidates.
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA = 0x048F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA   = 0x048F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA            = 0x048F84D4;
    static constexpr uintptr_t GetPlayerCountRVA                         = 0x048F8C34;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA                = 0x048F85F4;

    // Player -> Transform candidates.
    static constexpr uintptr_t PlayerGetTransformNodeRVA                 = 0x05735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA             = 0x0890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA              = 0x06B4964C;
    static constexpr uintptr_t BFOONIGAIFKGetTransformRVA                = 0x0581FB80;
    static constexpr uintptr_t EntityGetTransformNodeRVA                 = 0x06B4B418;
    static constexpr uintptr_t LEntityGetTransformNodeRVA                = 0x06AF1F24;
    static constexpr uintptr_t TransformNodeTransformOffset              = 0x10;
    static constexpr uintptr_t BFOONIGAIFKTransformOffset                = 0x10;
    static constexpr uintptr_t EntityCachedTransformOffset               = 0x58;
    static constexpr uintptr_t TransformGetPositionRVA                   = 0x08D6C1EC;

    // Unity Camera candidates.
    static constexpr uintptr_t CameraGetMainRVA                          = 0x08CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA               = 0x08CFE9C0;
    static constexpr uintptr_t CameraWorldToScreenPointEyeRVA            = 0x08CFE5C0;
    static constexpr uintptr_t CameraWorldToViewportPointRVA             = 0x08CFEA34;
    static constexpr uintptr_t CameraGetWorldToCameraMatrixRVA            = 0x08CFE220;
    static constexpr uintptr_t CameraGetProjectionMatrixRVA               = 0x08CFE3C8;

    // Team helpers supplied in the notes; kept as references only.
    static constexpr uintptr_t IsSameTeam0RVA                            = 0x00025401;
    static constexpr uintptr_t IsSameTeam1RVA                            = 0x00025402;

    // Bone/Animator candidates supplied in the dump.
    static constexpr uintptr_t AnimatorGetBoneTransformRVA               = 0x08CDDFEC;
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA       = 0x08CDE404;
    static constexpr int HumanBoneHips  = 0;
    static constexpr int HumanBoneChest = 8;
    static constexpr int HumanBoneNeck  = 9;
    static constexpr int HumanBoneHead  = 10;
    // Additional Player/Transform offsets supplied in the dump.
    static constexpr uintptr_t PlayerGetHeadTFRVA                         = 0x056CA948;
    static constexpr uintptr_t PlayerGetHipTFRVA                          = 0x056CAAF8;
    static constexpr uintptr_t PlayerGetLeftAnkleTFRVA                    = 0x056CAF48;
    static constexpr uintptr_t PlayerGetRightAnkleTFRVA                   = 0x056CB054;
    static constexpr uintptr_t PlayerGetLeftToeTFRVA                      = 0x056CB160;
    static constexpr uintptr_t PlayerGetRightToeTFRVA                     = 0x056CB280;
    static constexpr uintptr_t PlayerGetCharacterControllerTopPositionRVA = 0x056CB3A0;
    static constexpr uintptr_t PlayerGetAttackableCenterWSRVA             = 0x064CA83C;
    static constexpr uintptr_t PlayerGetHitDamagePosRVA                   = 0x064CAABC;
    static constexpr uintptr_t PlayerIsLocalTeammateRVA                   = 0x064CA738;
    static constexpr uintptr_t PlayerGetRotationRVA                       = 0x067A1DD4;
    static constexpr uintptr_t PlayerSetRotationRVA                       = 0x067A1EE4;
    static constexpr uintptr_t PlayerGetIsDeadRVA                         = 0x067A200C;
    static constexpr uintptr_t UMASkeletonGetBoneTransformRVA             = 0x01ACB998;
    static constexpr uintptr_t UMASkeletonSetPositionRVA                  = 0x01ACBAFC;
    static constexpr uintptr_t UMASkeletonSetRotationRVA                  = 0x01ACBC8C;
    static constexpr uintptr_t BodyPartUtilReFindBoneTransformRVA         = 0x041B2524;
    static constexpr uintptr_t BodyPartUtilSearchAllBoneTransformRVA      = 0x041B2818;
    static constexpr uintptr_t UGCSkeletonBoneOwnerGetOrAddBoneRVA        = 0x05301030;
    static constexpr uintptr_t UGCSkeletonBoneOwnerGetSkeletonBoneRVA     = 0x05301574;
    static constexpr uintptr_t UGCSkeletonBoneOwnerRebindBoneTransformRVA = 0x053009B0;
    static constexpr uintptr_t UGCSkeletonBoneOwnerGetOrCreateRVA         = 0x05300CFC;
    static constexpr uintptr_t BFOONIGAIFKBODJPJHIMALRVA                 = 0x0582044C;

}
