#pragma once
#include <stdint.h>

/*
 * Free Fire current-dump references.
 *
 * The dump confirms the method/field identity and current RVA/offset values.
 * The external reader never calls these managed methods directly; for the
 * out-of-process path it uses the RVAs as code/data anchors and validates
 * the remote objects before using a value.
 */
namespace FreeFireOffsets {
    // ---------------------------------------------------------------------
    // GameFacade / current match
    // ---------------------------------------------------------------------
    // GameFacade.CurrentMatch() -> JMAGGLCNGIG
    static constexpr uintptr_t GameFacadeCurrentMatchRVA = 0x0591B898;
    // GameFacade.get_UIModelSpectator() -> UIModelSpectator*
    static constexpr uintptr_t GameFacadeGetUISpectatorRVA = 0x05933D60;

    // MatchGame.m_Match
    static constexpr uintptr_t MatchGameMatchFieldOffset = 0x90;

    // ---------------------------------------------------------------------
    // JMAGGLCNGIG (TypeDefIndex 32046) current player-related storage
    // ---------------------------------------------------------------------
    static constexpr uintptr_t JMAGLocalPlayerFieldOffset        = 0xD8;  // Player
    static constexpr uintptr_t JMAGPlayerDictionary0Offset       = 0x128; // Dictionary<..., Player>
    static constexpr uintptr_t JMAGPlayerDictionary1Offset       = 0x130;
    static constexpr uintptr_t JMAGPlayerDictionary2Offset       = 0x140;
    static constexpr uintptr_t JMAGPlayerDictionaryByteOffset    = 0x148; // Dictionary<byte, Player>
    static constexpr uintptr_t JMAGPlayerDictionary3Offset       = 0x150;
    static constexpr uintptr_t JMAGPlayerList0Offset              = 0x158; // List<Player>
    static constexpr uintptr_t JMAGPlayerList1Offset              = 0x160; // List<Player>
    static constexpr uintptr_t JMAGPlayerListPrivateOffset        = 0x570; // List<Player>
    static constexpr uintptr_t JMAGPlayerDictionary5Offset        = 0x5D8; // Dictionary<..., Player>
    static constexpr uintptr_t JMAGPlayerDictionary6Offset        = 0x5E0; // Dictionary<..., Player>

    // JMAG methods immediately surrounding the count-like accessors.
    static constexpr uintptr_t JMAGGetPlayerDictionaryRVA        = 0x0596CB44;
    static constexpr uintptr_t JMAGCountLikeMethodRVA             = 0x0596CD78; // int
    static constexpr uintptr_t JMAGGetPlayerDictionary2RVA       = 0x0596D088;
    static constexpr uintptr_t JMAGGetPlayerDictionary3RVA       = 0x0596D2C4;
    static constexpr uintptr_t JMAGGetPlayerDictionaryForPlayerRVA = 0x0596DB68;

    // ---------------------------------------------------------------------
    // UIModelSpectator (TypeDefIndex 25184)
    // ---------------------------------------------------------------------
    // This is the strongest semantic "GetPlayerCount" match in the dump:
    // the dump places get_PlayerDic() and GetPlayerCount() in the same class.
    static constexpr uintptr_t UIModelSpectatorGetPlayerDicRVA   = 0x048F26F0;
    static constexpr uintptr_t UIModelSpectatorGetPlayerCountRVA = 0x048F8C34;
    static constexpr uintptr_t UIModelSpectatorPlayerDicOffset   = 0x30;

    // Backwards-compatible alias used by the previous project.
    static constexpr uintptr_t GetPlayerCountRVA = UIModelSpectatorGetPlayerCountRVA;

    // ---------------------------------------------------------------------
    // JMAG player enumeration helpers (dump-confirmed RVAs)
    // ---------------------------------------------------------------------
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA = 0x048F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA   = 0x048F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA           = 0x048F84D4;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA               = 0x048F85F4;

    // ---------------------------------------------------------------------
    // Player -> Transform candidates
    // ---------------------------------------------------------------------
    static constexpr uintptr_t PlayerGetTransformNodeRVA          = 0x05735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA      = 0x0890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA       = 0x06B4964C;
    static constexpr uintptr_t BFOONIGAIFKGetTransformRVA         = 0x0581FB80;
    static constexpr uintptr_t EntityGetTransformNodeRVA          = 0x06B4B418;
    static constexpr uintptr_t LEntityGetTransformNodeRVA          = 0x06AF1F24;
    static constexpr uintptr_t TransformNodeTransformOffset       = 0x10;
    static constexpr uintptr_t BFOONIGAIFKTransformOffset         = 0x10;
    static constexpr uintptr_t EntityCachedTransformOffset        = 0x58;
    static constexpr uintptr_t TransformGetPositionRVA             = 0x08D6C1EC;

    // Unity Camera candidates
    static constexpr uintptr_t CameraGetMainRVA                   = 0x08CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA         = 0x08CFE9C0;
    static constexpr uintptr_t CameraWorldToScreenPointEyeRVA      = 0x08CFE5C0;
    static constexpr uintptr_t CameraWorldToViewportPointRVA       = 0x08CFEA34;
    static constexpr uintptr_t CameraGetWorldToCameraMatrixRVA     = 0x08CFE220;
    static constexpr uintptr_t CameraGetProjectionMatrixRVA        = 0x08CFE3C8;

    // Bone/Animator candidates
    static constexpr uintptr_t AnimatorGetBoneTransformRVA         = 0x08CDDFEC;
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA = 0x08CDE404;
    static constexpr int HumanBoneHips  = 0;
    static constexpr int HumanBoneChest = 8;
    static constexpr int HumanBoneNeck  = 9;
    static constexpr int HumanBoneHead  = 10;
}
