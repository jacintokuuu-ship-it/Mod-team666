#pragma once
#include <stdint.h>

namespace FreeFireOffsets {

    // UnityEngine.Animator.GetBoneTransform(HumanBodyBones)
    static constexpr uintptr_t AnimatorGetBoneTransformRVA = 0x08CDDFEC;

    // UnityEngine.Animator.GetBoneTransformInternal(int)
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA = 0x08CDE404;

    // COW.Gameplay.UGC.UGCSkeletonBoneOwner.GetOrAddBone(string)
    static constexpr uintptr_t UGCSkeletonGetOrAddBoneRVA = 0x05301030;

    // COW.Gameplay.UGC.UGCSkeletonBoneOwner.GetSkeletonBone(string)
    static constexpr uintptr_t UGCSkeletonGetSkeletonBoneRVA = 0x05301574;

    // COW.Gameplay.UGC.UGCSkeletonBoneOwner.RebindBoneTransform(Transform)
    static constexpr uintptr_t UGCSkeletonRebindBoneTransformRVA = 0x053009B0;

    // GetTransformNode(string)
    static constexpr uintptr_t GetTransformNodeStringRVA = 0x05735538;

    // LBJCFPMCLMN.BODJPJHIMAL(string) -> BFOONIGAIFK
    static constexpr uintptr_t BoneNodeLookupRVA = 0x0582044C;

    // Unity HumanBodyBones enum values confirmed by the supplied dump.
    static constexpr int HumanBoneHips  = 0;
    static constexpr int HumanBoneChest = 8;
    static constexpr int HumanBoneNeck  = 9;
    static constexpr int HumanBoneHead  = 10;
}
