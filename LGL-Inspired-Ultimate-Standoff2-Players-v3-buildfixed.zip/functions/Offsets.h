#pragma once
#include <stdint.h>

/*
 * ONLY values established by the supplied dump/offset notes are kept here.
 * No legacy PlayerManager / matrix / player-field offsets are used.
 */
namespace FreeFireOffsets {
    // Player enumeration helpers.
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA = 0x048F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA   = 0x048F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA            = 0x048F84D4;
    static constexpr uintptr_t GetPlayerCountRVA                         = 0x048F8C34;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA                = 0x048F85F4;

    // Player -> Transform chain.
    static constexpr uintptr_t PlayerGetTransformNodeRVA                 = 0x05735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA             = 0x0890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA              = 0x06B4964C;
    static constexpr uintptr_t BFOONIGAIFKGetTransformRVA                = 0x0581FB80;
    static constexpr uintptr_t EntityGetTransformNodeRVA                 = 0x06B4B418;
    static constexpr uintptr_t LEntityGetTransformNodeRVA                = 0x06AF1F24;

    // Confirmed field offsets for the corresponding classes.
    static constexpr uintptr_t TransformNodeTransformOffset             = 0x10;
    static constexpr uintptr_t BFOONIGAIFKTransformOffset               = 0x10;
    static constexpr uintptr_t EntityCachedTransformOffset              = 0x58;

    // UnityEngine.Transform.get_position was confirmed directly in the supplied raw dump.
    static constexpr uintptr_t TransformGetPositionRVA                   = 0x08D6C1EC;

    // Unity Camera.
    static constexpr uintptr_t CameraGetMainRVA                          = 0x08CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA               = 0x08CFE9C0;
    static constexpr uintptr_t CameraWorldToScreenPointEyeRVA            = 0x08CFE5C0;
    static constexpr uintptr_t CameraWorldToViewportPointRVA             = 0x08CFEA34;
    static constexpr uintptr_t CameraGetWorldToCameraMatrixRVA            = 0x08CFE220;
    static constexpr uintptr_t CameraGetProjectionMatrixRVA               = 0x08CFE3C8;

    // Team helper RVAs supplied in the notes.
    static constexpr uintptr_t IsSameTeam0RVA                            = 0x00025401;
    static constexpr uintptr_t IsSameTeam1RVA                            = 0x00025402;

    // Bone methods are retained because they were explicitly supplied.
    static constexpr uintptr_t AnimatorGetBoneTransformRVA               = 0x08CDDFEC;
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA       = 0x08CDE404;

    static constexpr int HumanBoneHips  = 0;
    static constexpr int HumanBoneChest = 8;
    static constexpr int HumanBoneNeck  = 9;
    static constexpr int HumanBoneHead  = 10;
}
