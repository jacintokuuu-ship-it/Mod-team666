#pragma once
#include <stdint.h>

/*
 * Free Fire external-reference map for the dump supplied with this build.
 * RVAs are relative to UnityFramework. Object/field offsets are IL2CPP
 * instance-layout offsets from the same dump. The Unity camera/Transform
 * internal offsets are carried over from the XternalZ external reference.
 */
namespace FreeFireOffsets {
    // -------------------------------------------------------------------------
    // UIModelSpectator / entity enumeration
    // -------------------------------------------------------------------------
    static constexpr uintptr_t GameFacadeGetUIModelMatchRVA            = 0x0592ED30;
    static constexpr uintptr_t GameFacadeGetUIModelSpectatorRVA        = 0x05933D60;
    static constexpr uintptr_t GameFacadeGetLocalPlayerUserIDRVA       = 0x0591BBB4;
    static constexpr uintptr_t UIModelMatchPlayerDataListOffset       = 0x1F0;
    static constexpr uintptr_t UIModelMatchLocalTeamIdOffset           = 0x11C;
    static constexpr uintptr_t UIModelSpectatorPlayerDicOffset         = 0x30;

    // Dictionary<BEADLMGGGGL, PlayerData> layout.
    // System.Collections.Generic.List<T> object layout.
    static constexpr uintptr_t ManagedListItemsOffset                  = 0x10;
    static constexpr uintptr_t ManagedListSizeOffset                   = 0x18;
    static constexpr uintptr_t ManagedListDataOffset                   = 0x20;

    static constexpr uintptr_t DictionaryEntriesOffset                 = 0x18;
    static constexpr uintptr_t DictionaryCountOffset                   = 0x20;
    static constexpr uintptr_t ManagedArrayDataOffset                   = 0x20;
    static constexpr uintptr_t PlayerDictionaryEntryKeyOffset           = 0x08;
    static constexpr uintptr_t PlayerDictionaryEntryValueOffset         = 0x20;
    static constexpr uintptr_t PlayerDictionaryEntryStride               = 0x28;

    // PlayerData fields.
    static constexpr uintptr_t PlayerDataTeamIdOffset                  = 0x34;
    static constexpr uintptr_t PlayerDataSecondaryTeamIdOffset          = 0x35;
    static constexpr uintptr_t PlayerDataIsDeadOffset                   = 0x6C;
    static constexpr uintptr_t PlayerDataLastPositionOffset             = 0xDC;
    static constexpr uintptr_t PlayerDataPlayerOffset                   = 0x100;
    static constexpr uintptr_t PlayerDataHeadScaleOffset                = 0x108;
    static constexpr uintptr_t PlayerDataIsBotOffset                    = 0x130;
    static constexpr uintptr_t PlayerDataUserIdOffset                   = 0x28;

    // -------------------------------------------------------------------------
    // Player -> camera / transform
    // -------------------------------------------------------------------------
    static constexpr uintptr_t PlayerFollowCameraOffset                 = 0x690;
    static constexpr uintptr_t PlayerRootTransformOffset                 = 0x700;
    static constexpr uintptr_t CameraControllerTargetCameraOffset        = 0x30;
    static constexpr uintptr_t PlayerMainCameraTransformOffset            = 0x3E8;

    // Original reference RVAs kept for diagnostics and future expansion.
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA = 0x048F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA   = 0x048F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA            = 0x048F84D4;
    static constexpr uintptr_t GetPlayerCountRVA                         = 0x048F8C34;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA                = 0x048F85F4;
    static constexpr uintptr_t PlayerGetTransformNodeRVA                 = 0x05735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA             = 0x0890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA              = 0x06B4964C;
    static constexpr uintptr_t BFOONIGAIFKGetTransformRVA                = 0x0581FB80;
    static constexpr uintptr_t EntityGetTransformNodeRVA                 = 0x06B4B418;
    static constexpr uintptr_t LEntityGetTransformNodeRVA                = 0x06AF1F24;
    static constexpr uintptr_t TransformGetPositionRVA                   = 0x08D6C1EC;

    // Unity Camera methods from the supplied dump.
    static constexpr uintptr_t CameraGetMainRVA                          = 0x08CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA               = 0x08CFE9C0;
    static constexpr uintptr_t CameraWorldToScreenPointEyeRVA            = 0x08CFE5C0;
    static constexpr uintptr_t CameraWorldToViewportPointRVA             = 0x08CFEA34;
    static constexpr uintptr_t CameraGetWorldToCameraMatrixRVA            = 0x08CFE220;
    static constexpr uintptr_t CameraGetProjectionMatrixRVA               = 0x08CFE3C8;

    // Animator/bone RVAs from the supplied dump.
    static constexpr uintptr_t AnimatorGetBoneTransformRVA                = 0x08CDDFEC;
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA        = 0x08CDE404;
    static constexpr int HumanBoneHips  = 0;
    static constexpr int HumanBoneChest = 8;
    static constexpr int HumanBoneNeck  = 9;
    static constexpr int HumanBoneHead  = 10;

    // -------------------------------------------------------------------------
    // XternalZ reference runtime layout used for external Unity math.
    // These are not IL2CPP method RVAs.
    // -------------------------------------------------------------------------
    static constexpr uintptr_t TransformInternalOffset                 = 0x10;
    static constexpr uintptr_t TransformMatrixOffset                   = 0x38;
    static constexpr uintptr_t TransformIndexOffset                    = 0x40;
    static constexpr uintptr_t TransformMatrixListOffset               = 0x18;
    static constexpr uintptr_t TransformMatrixIndicesOffset             = 0x20;
    static constexpr uintptr_t CameraInternalOffset                    = 0x10;
    static constexpr uintptr_t CameraViewProjectionMatrixOffset        = 0x100;
}
