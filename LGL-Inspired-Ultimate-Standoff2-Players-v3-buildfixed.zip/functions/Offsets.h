#pragma once
#include <stdint.h>

// Legacy game offsets retained for reference. They are NOT verified for Free Fire.
// These are version-specific and must be updated when the game build changes.
namespace GameOffsets {
    // Legacy PlayerManager type-info RVA from the previous target.
    static constexpr uintptr_t PlayerManagerTypeInfoRVA = 0x08E7F520;

    // TypeInfo -> parent TypeInfo -> static fields -> PlayerManager.
    static constexpr uintptr_t TypeInfoParentOffset = 0x58;
    static constexpr uintptr_t StaticFieldsOffsetPrimary = 0xB8;
    static constexpr uintptr_t StaticFieldsOffsetFallback = 0xB0;
    static constexpr uintptr_t PlayerManagerStaticFieldOffset = 0x00;

    // PlayerManager -> players dictionary / local player.
    static constexpr uintptr_t PlayersDictionaryOffset = 0x28;
    static constexpr uintptr_t LocalPlayerOffsetPrimary = 0x70;
    static constexpr uintptr_t LocalPlayerOffsetFallback = 0x68;

    // Dictionary layout used by the existing ESP.
    static constexpr uintptr_t DictionaryCountA = 0x20;
    static constexpr uintptr_t DictionaryCountB = 0x40;
    static constexpr uintptr_t DictionaryCountC = 0x18;
    static constexpr uintptr_t DictionaryEntriesOffset = 0x18;
    static constexpr uintptr_t DictionaryEntryStride = 0x18;
    static constexpr uintptr_t DictionaryEntryValueOffset = 0x10;
    static constexpr uintptr_t DictionaryEntryStart = 0x20;

    // Player -> PhotonPlayer and PhotonPlayer -> custom properties.
    static constexpr uintptr_t PlayerPhotonOffset = 0x160;
    static constexpr uintptr_t PhotonCustomPropertiesOffset = 0x38;
    // Confirmed by the supplied _PUN.dll dump: PhotonPlayer.CustomProperties.
    static constexpr uintptr_t PhotonPlayerCustomPropertiesOffset = 0x38;
    // Confirmed by the supplied _PUN.dll dump: PhotonPlayer.IsInactive.
    static constexpr uintptr_t PhotonPlayerIsInactiveOffset = 0x31;
    static constexpr uintptr_t PropertiesSizeOffset = 0x20;
    static constexpr uintptr_t PropertiesEntriesOffset = 0x18;
    static constexpr uintptr_t PropertyKeyStart = 0x28;
    static constexpr uintptr_t PropertyValueDelta = 0x08;
    static constexpr uintptr_t PropertyStride = 0x18;
    static constexpr uintptr_t PropertyKeyStringOffset = 0x14;
    static constexpr uintptr_t PropertyKeyLengthOffset = 0x10;
    static constexpr uintptr_t PropertyValueObjectOffset = 0x30;
    static constexpr uintptr_t PropertyIntValueOffset = 0x10;

    // Confirmed from the supplied dump: Room.PlayerCount getter RVA.
    // Kept here for reference/documentation; the counter below deliberately
    // uses the project's already-working PlayerManager path instead of
    // guessing PhotonNetwork.room's getter.
    static constexpr uintptr_t RoomGetPlayerCountRVA_Legacy = 0x07705FC8;
}
