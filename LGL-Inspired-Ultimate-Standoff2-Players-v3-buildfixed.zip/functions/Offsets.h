#pragma once
#include <stdint.h>

/* Free Fire dump-backed references used by the player-count external HUD. */
namespace FreeFireOffsets {
    // GameFacade::get_UIModelSpectator()
    static constexpr uintptr_t GameFacadeGetUIModelSpectatorRVA = 0x05933D60;

    // UIModelSpectator.m_RemainingPlayerCount
    static constexpr uintptr_t GameFacadeUIModelSpectatorStaticOffset = 0x320;
    static constexpr uintptr_t UIModelSpectatorRemainingPlayerCountOffset = 0xC4;
}
