#pragma once

#include <stdint.h>

#define ESP_EXTERNAL_MAGIC         0x45585431u /* EXT1 */
#define ESP_EXTERNAL_VERSION       3u
#define ESP_EXTERNAL_MAX_TARGETS  64u

typedef struct ESPExternalTarget {
    uint64_t player;
    float x;
    float y;
    float z;
    float depth;
    uint32_t valid;
} ESPExternalTarget;

/*
 * Snapshot v3 adds a current-match/count diagnostic block.  Existing drawing
 * fields stay in the same order so the overlay code remains source-compatible.
 */
typedef struct ESPExternalSnapshot {
    uint32_t magic;
    uint32_t version;
    uint32_t processFound;
    uint32_t taskOpened;
    uint32_t unityFound;
    uint32_t machoReadable;
    uint32_t rvaReadableCount;
    uint32_t rvaTestCount;
    int32_t processPID;
    uint64_t task;
    uint64_t unityBase;
    uint64_t lastCheckNanos;
    uint32_t lastError;

    // Live external count diagnostics.
    uint32_t count;
    uint32_t playerCountValid;
    uint32_t playerCountSourceKind;
    uint32_t playerCountSourceOffset;
    uint32_t countCandidate158;
    uint32_t countCandidate160;
    uint32_t countCandidate570;
    uint32_t countCandidate128;
    uint32_t countCandidate130;
    uint32_t countCandidate140;
    uint32_t countCandidate148;
    uint32_t countCandidate150;
    uint32_t countCandidate5D8;
    uint32_t countCandidate5E0;
    uint64_t currentMatch;
    uint64_t localPlayer;

    ESPExternalTarget targets[ESP_EXTERNAL_MAX_TARGETS];
    char message[768];
} ESPExternalSnapshot;

#ifdef __cplusplus
extern "C" {
#endif

int ESPExternalSetMode(int mode);
int ESPExternalGetMode(void);
int ESPExternalVerify(ESPExternalSnapshot *out);
int ESPExternalReadSnapshot(ESPExternalSnapshot *out);
const char *ESPExternalStatusText(void);
const char *ESPExternalDiagnosticText(void);

#ifdef __cplusplus
}
#endif
