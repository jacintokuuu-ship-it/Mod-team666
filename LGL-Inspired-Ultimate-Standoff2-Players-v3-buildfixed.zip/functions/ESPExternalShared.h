#pragma once

#include <stdint.h>

#define ESP_EXTERNAL_MAGIC    0x45585433u /* EXT3 */
#define ESP_EXTERNAL_VERSION  3u
#define ESP_EXTERNAL_MAX_TARGETS 64u

#define ESP_TARGET_HAS_LINE   (1u << 0)
#define ESP_TARGET_HAS_BOX    (1u << 1)
#define ESP_TARGET_IS_BOT     (1u << 2)

#ifdef __cplusplus
extern "C" {
#endif

typedef struct ESPExternalTarget {
    uint64_t player;
    float x;
    float y;
    float z;
    float depth;
    float topX;
    float topY;
    float bottomX;
    float bottomY;
    float boxLeft;
    float boxTop;
    float boxRight;
    float boxBottom;
    uint32_t teamId;
    uint32_t flags;
    uint32_t valid;
} ESPExternalTarget;

typedef struct ESPExternalSnapshot {
    uint32_t magic;
    uint32_t version;
    uint32_t processFound;
    uint32_t taskOpened;
    uint32_t unityFound;
    uint32_t machoReadable;
    uint32_t rvaReadableCount;
    uint32_t rvaTestCount;
    int32_t processPID;
    uint64_t task;
    uint64_t unityBase;
    uint64_t camera;
    uint64_t localPlayer;
    uint64_t lastCheckNanos;
    uint32_t lastError;
    uint32_t count;
    ESPExternalTarget targets[ESP_EXTERNAL_MAX_TARGETS];
    char message[512];
} ESPExternalSnapshot;

int ESPExternalSetMode(int mode);
int ESPExternalGetMode(void);
int ESPExternalSetTeamFilterEnabled(int enabled);
int ESPExternalGetTeamFilterEnabled(void);
int ESPExternalSetDisplayMetrics(float widthPoints, float heightPoints, float scale);
int ESPExternalVerify(ESPExternalSnapshot *out);
int ESPExternalReadSnapshot(ESPExternalSnapshot *out);
const char *ESPExternalStatusText(void);
const char *ESPExternalDiagnosticText(void);

#ifdef __cplusplus
}
#endif
