#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <dispatch/dispatch.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <atomic>
#include <mutex>
#include <algorithm>
#include <cmath>

namespace {

static task_t gTask = MACH_PORT_NULL;
static vm_address_t gUnityBase = 0;
static pid_t gPID = -1;
static std::atomic<int> gMode{0};
static std::mutex gRuntimeMutex;
static std::mutex gSnapshotMutex;
static std::atomic<bool> gRefreshScheduled{false};
static ESPExternalSnapshot gCachedSnapshot{};
static bool gHasCachedSnapshot = false;
static uint64_t gLastRefreshNanos = 0;
static constexpr uint32_t kSnapshotRefreshIntervalMs = 50u;

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}

static bool ValidateRemoteRange(vm_address_t address, vm_size_t size)
{
    if (address == 0 || size == 0)
        return false;

    const vm_address_t end = address + (vm_address_t)size;
    if (end < address)
        return false;

#if defined(UINT64_MAX)
    if ((uint64_t)address > UINT64_MAX - (uint64_t)size)
        return false;
#endif
    return true;
}

static bool ReadRemote(task_t task, vm_address_t address, void *out, vm_size_t size)
{
    if (task == MACH_PORT_NULL || !out || !ValidateRemoteRange(address, size))
        return false;

    vm_size_t copied = 0;
    const kern_return_t kr = vm_read_overwrite(task,
                                                address,
                                                size,
                                                (vm_address_t)out,
                                                &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool ReadRVA(task_t task, vm_address_t base, uintptr_t rva)
{
    uint32_t bytes = 0;
    return ReadRemote(task, base + (vm_address_t)rva, &bytes, sizeof(bytes));
}

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
    gPID = -1;
}

static bool EnsureConnection(ESPExternalSnapshot &s)
{
    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
        return false;
    }

    if (gTask != MACH_PORT_NULL && gPID != pid && gPID > 0)
        CloseTask();

    if (gTask == MACH_PORT_NULL) {
        gTask = get_task_by_pid(pid);
        if (gTask == MACH_PORT_NULL) {
            BuildFailure(s,
                         "FALHOU: PID %d encontrado; task nao abriu: %s",
                         pid,
                         get_task_last_error());
            return false;
        }
        gPID = pid;
    }

    s.processFound = 1;
    s.processPID = pid;
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;

    if (!gUnityBase)
        gUnityBase = get_image_base_address(gTask, "UnityFramework");

    if (!gUnityBase) {
        BuildFailure(s, "FALHOU: task OK, UnityFramework nao localizado | PID %d", pid);
        CloseTask();
        return false;
    }

    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    uint32_t magic = 0;
    if (!ReadRemote(gTask, gUnityBase, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        BuildFailure(s,
                     "FALHOU: UnityFramework 0x%llX, Mach-O nao legivel",
                     (unsigned long long)gUnityBase);
        CloseTask();
        return false;
    }

    s.machoReadable = 1;
    return true;
}

static bool ValidateConfiguredRVAs(ESPExternalSnapshot &s)
{
    const uintptr_t rvas[] = {
        FreeFireOffsets::GameFacadeGetUIModelSpectatorRVA,
        FreeFireOffsets::GetLivePlayerByTeamIdAndPlayerIndexRVA,
        FreeFireOffsets::GetPlayerCountRVA,
        FreeFireOffsets::GetPlayerListFromTeamIdRVA,
        FreeFireOffsets::PlayerGetTransformNodeRVA,
        FreeFireOffsets::TransformGetPositionRVA,
        FreeFireOffsets::CameraGetMainRVA,
        FreeFireOffsets::CameraWorldToScreenPointRVA,
        FreeFireOffsets::PlayerGetAttackableCenterWSRVA,
    };

    s.rvaTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
    for (uint32_t i = 0; i < s.rvaTestCount; ++i) {
        if (ReadRVA(gTask, gUnityBase, rvas[i]))
            ++s.rvaReadableCount;
    }

    return s.rvaReadableCount == s.rvaTestCount;
}

static bool RefreshSnapshotLocked(ESPExternalSnapshot &out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    if (!EnsureConnection(s)) {
        out = s;
        return false;
    }

    if (!ValidateConfiguredRVAs(s)) {
        BuildFailure(s,
                     "PARCIAL: PID %d | Unity 0x%llX | RVAs legiveis %u/%u",
                     s.processPID,
                     (unsigned long long)s.unityBase,
                     s.rvaReadableCount,
                     s.rvaTestCount);
        out = s;
        return false;
    }

    // The supplied project does not contain the structural dump required to
    // prove the object/field chain for live entity enumeration. Do not invent
    // field offsets and do not execute code in the target as a workaround.
    s.entitySourceAvailable = 0;
    s.entityCount = 0;
    s.validEntityCount = 0;
    s.cameraAvailable = 0;
    s.projectionAvailable = 0;
    s.rendererFrameCount = 0;
    s.rendererDrawCount = 0;

    BuildFailure(s,
                 "EXTERNAL READ-ONLY OK | PID %d | Unity 0x%llX | "
                 "RVAs %u/%u | entity chain: NOT CONFIRMED",
                 s.processPID,
                 (unsigned long long)s.unityBase,
                 s.rvaReadableCount,
                 s.rvaTestCount);

    out = s;
    return true;
}

static void ScheduleBackgroundRefresh(void)
{
    bool expected = false;
    if (!gRefreshScheduled.compare_exchange_strong(expected, true))
        return;

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        ESPExternalSnapshot fresh{};
        {
            std::lock_guard<std::mutex> guard(gRuntimeMutex);
            RefreshSnapshotLocked(fresh);
        }
        {
            std::lock_guard<std::mutex> guard(gSnapshotMutex);
            gCachedSnapshot = fresh;
            gHasCachedSnapshot = true;
            gLastRefreshNanos = NowNanos();
        }
        gRefreshScheduled.store(false, std::memory_order_release);
    });
}

} // namespace

extern "C" int ESPExternalSetMode(int mode)
{
    mode = mode ? 1 : 0;
    gMode.store(mode, std::memory_order_release);

    if (!mode) {
        std::lock_guard<std::mutex> guard(gSnapshotMutex);
        gCachedSnapshot = {};
        gHasCachedSnapshot = false;
    } else {
        ScheduleBackgroundRefresh();
    }
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    std::lock_guard<std::mutex> guard(gRuntimeMutex);
    const bool ok = RefreshSnapshotLocked(s);
    if (out)
        *out = s;
    return ok ? 1 : 0;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    if (!out)
        return 0;

    ESPExternalSnapshot snapshot{};
    snapshot.magic = ESP_EXTERNAL_MAGIC;
    snapshot.version = ESP_EXTERNAL_VERSION;

    if (!gMode.load(std::memory_order_acquire)) {
        *out = snapshot;
        return 0;
    }

    const uint64_t now = NowNanos();
    bool hasSnapshot = false;
    bool stale = true;

    {
        std::lock_guard<std::mutex> guard(gSnapshotMutex);
        hasSnapshot = gHasCachedSnapshot;
        stale = !hasSnapshot ||
                now - gLastRefreshNanos >=
                    (uint64_t)kSnapshotRefreshIntervalMs * 1000000ull;
        if (hasSnapshot)
            snapshot = gCachedSnapshot;
    }

    if (!hasSnapshot) {
        ScheduleBackgroundRefresh();
        *out = snapshot;
        return 0;
    }

    if (stale)
        ScheduleBackgroundRefresh();

    *out = snapshot;
    return snapshot.processFound &&
           snapshot.taskOpened &&
           snapshot.unityFound &&
           snapshot.machoReadable;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[1024];
    ESPExternalSnapshot s{};
    ESPExternalReadSnapshot(&s);
    snprintf(text,
             sizeof(text),
             "%s",
             s.message[0] ? s.message : "AGUARDANDO: leitura externa");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1536];
    ESPExternalSnapshot s{};
    ESPExternalReadSnapshot(&s);

    snprintf(text,
             sizeof(text),
             "EXTERNAL DIAGNOSTIC\n"
             "Process: found=%u pid=%d task=%u\n"
             "Module: Unity=0x%llX found=%u MachO=%u\n"
             "Reader: RVA=%u/%u\n"
             "Entities: source=%u count=%u valid=%u\n"
             "Camera: available=%u projection=%u\n"
             "Renderer: frames=%u draws=%u\n"
             "Status: %s",
             s.processFound,
             s.processPID,
             s.taskOpened,
             (unsigned long long)s.unityBase,
             s.unityFound,
             s.machoReadable,
             s.rvaReadableCount,
             s.rvaTestCount,
             s.entitySourceAvailable,
             s.entityCount,
             s.validEntityCount,
             s.cameraAvailable,
             s.projectionAvailable,
             s.rendererFrameCount,
             s.rendererDrawCount,
             s.message[0] ? s.message : "sem diagnostico");
    return text;
}
