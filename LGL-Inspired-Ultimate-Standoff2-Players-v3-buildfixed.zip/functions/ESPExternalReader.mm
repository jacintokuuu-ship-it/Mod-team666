#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"
#import "../unity/unity.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <atomic>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>

namespace {

static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static pid_t gPID = -1;
static std::atomic<int> gMode{0};
static std::atomic<int> gTeamFilter{1};
static std::atomic<float> gDisplayWidth{0.0f};
static std::atomic<float> gDisplayHeight{0.0f};
static std::atomic<float> gDisplayScale{1.0f};
static uint64_t gLastVerification = 0;
static uint32_t gLastReadable = 0;
static uint32_t gLastTestCount = 0;
static bool gLastMachoReadable = false;

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static inline bool PlausibleAddress(mach_vm_address_t p)
{
    return p > 0x100000000ull && (p & 0x7ull) == 0;
}

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gPID = -1;
    gUnityBase = 0;
    gLastVerification = 0;
    gLastReadable = 0;
    gLastTestCount = 0;
    gLastMachoReadable = false;
}

template <typename T>
static bool ReadValue(mach_vm_address_t address, T *out)
{
    return out && ESPRemoteRead(gTask, address, out, sizeof(T));
}

static bool ReadBytes(mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    return ESPRemoteRead(gTask, address, out, size);
}

static bool ReadRVA(uintptr_t rva)
{
    uint32_t bytes = 0;
    return ReadBytes(gUnityBase + (mach_vm_address_t)rva, &bytes, sizeof(bytes));
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}

struct RegisterState {
    bool hasAddress[32];
    mach_vm_address_t address[32];
    bool hasValue[32];
    uint64_t value[32];
    bool hasLoadSource[32];
    mach_vm_address_t loadSource[32];
};

static inline int32_t SignExtend21(int64_t value)
{
    if (value & (1ll << 20)) value |= ~((1ll << 21) - 1ll);
    return (int32_t)value;
}

static bool DecodeADRP(uint32_t insn, mach_vm_address_t pc, uint8_t *rd, mach_vm_address_t *absolutePage)
{
    if ((insn & 0x9F000000u) != 0x90000000u) return false;
    const uint32_t rdLocal = insn & 0x1Fu;
    const int64_t immhi = (int64_t)((insn >> 5) & 0x7FFFFu);
    const int64_t immlo = (int64_t)((insn >> 29) & 0x3u);
    const int32_t imm21 = SignExtend21((immhi << 2) | immlo);
    const int64_t offset = ((int64_t)imm21) << 12;
    const mach_vm_address_t page = pc & ~0xFFFull;
    const mach_vm_address_t resolved = (mach_vm_address_t)((int64_t)page + offset);
    if (!absolutePage) return false;
    *rd = (uint8_t)rdLocal;
    *absolutePage = resolved;
    return true;
}

static bool DecodeADDImm(uint32_t insn, uint8_t *rd, uint8_t *rn, uint64_t *imm)
{
    if ((insn & 0x7F000000u) != 0x11000000u) return false;
    // Restrict to ADD (immediate), 64-bit destination.
    if ((insn & 0x80000000u) == 0) return false;
    const uint32_t sh = (insn >> 22) & 0x1u;
    const uint64_t imm12 = (insn >> 10) & 0xFFFu;
    *rd = (uint8_t)(insn & 0x1Fu);
    *rn = (uint8_t)((insn >> 5) & 0x1Fu);
    *imm = imm12 << (sh ? 12 : 0);
    return true;
}

static bool DecodeLDR64Imm(uint32_t insn, uint8_t *rt, uint8_t *rn, uint64_t *imm)
{
    if ((insn & 0xFFC00000u) != 0xF9400000u) return false;
    *rt = (uint8_t)(insn & 0x1Fu);
    *rn = (uint8_t)((insn >> 5) & 0x1Fu);
    *imm = ((uint64_t)((insn >> 10) & 0xFFFu)) << 3;
    return true;
}

static bool DecodeMOVReg(uint32_t insn, uint8_t *rd, uint8_t *rn)
{
    // ORR Xd, XZR, Xn alias.
    if ((insn & 0xFFE0FFE0u) != 0xAA0003E0u) return false;
    *rd = (uint8_t)(insn & 0x1Fu);
    *rn = (uint8_t)((insn >> 16) & 0x1Fu);
    return true;
}

static bool ResolveGetterReturnObject(uintptr_t rva, mach_vm_address_t *outObject)
{
    if (!outObject || !gUnityBase) return false;
    uint32_t code[40]{};
    if (!ReadBytes(gUnityBase + rva, code, sizeof(code))) return false;

    RegisterState regs{};

    for (size_t i = 0; i < sizeof(code) / sizeof(code[0]); ++i) {
        const uint32_t insn = code[i];
        const mach_vm_address_t pc = gUnityBase + rva + (mach_vm_address_t)(i * 4);

        uint8_t rd = 0, rn = 0;
        mach_vm_address_t page = 0;
        if (DecodeADRP(insn, pc, &rd, &page)) {
            regs.hasAddress[rd] = true;
            regs.address[rd] = page;
            regs.hasValue[rd] = false;
            regs.hasLoadSource[rd] = false;
            continue;
        }

        uint64_t imm = 0;
        if (DecodeADDImm(insn, &rd, &rn, &imm)) {
            if (regs.hasAddress[rn]) {
                regs.hasAddress[rd] = true;
                regs.address[rd] = regs.address[rn] + imm;
                regs.hasValue[rd] = false;
                regs.hasLoadSource[rd] = false;
            }
            continue;
        }

        if (DecodeMOVReg(insn, &rd, &rn)) {
            regs.hasAddress[rd] = regs.hasAddress[rn];
            regs.address[rd] = regs.address[rn];
            regs.hasValue[rd] = regs.hasValue[rn];
            regs.value[rd] = regs.value[rn];
            regs.hasLoadSource[rd] = regs.hasLoadSource[rn];
            regs.loadSource[rd] = regs.loadSource[rn];
            continue;
        }

        if (DecodeLDR64Imm(insn, &rd, &rn, &imm)) {
            if (regs.hasAddress[rn]) {
                const mach_vm_address_t source = regs.address[rn] + imm;
                uint64_t value = 0;
                if (ReadValue(source, &value)) {
                    regs.hasAddress[rd] = PlausibleAddress((mach_vm_address_t)value);
                    regs.address[rd] = (mach_vm_address_t)value;
                    regs.hasValue[rd] = true;
                    regs.value[rd] = value;
                    regs.hasLoadSource[rd] = true;
                    regs.loadSource[rd] = source;
                }
            }
            continue;
        }

        // RET X30.
        if ((insn & 0xFFFFFC1Fu) == 0xD65F0000u) {
            if (regs.hasValue[0] && PlausibleAddress((mach_vm_address_t)regs.value[0])) {
                *outObject = (mach_vm_address_t)regs.value[0];
                return true;
            }
            return false;
        }

        // Class initialization / metadata helpers may be called inside an IL2CPP
        // getter. Register values are caller-clobbered, so discard provenance and
        // continue looking for the post-call ADRP/ADD/LDR sequence.
        if ((insn & 0xFC000000u) == 0x94000000u || (insn & 0xFFFFFC1Fu) == 0xD63F0000u) {
            regs = RegisterState{};
            continue;
        }
    }

    return false;
}

static bool ResolveGetterReturnFieldAddress(uintptr_t rva, mach_vm_address_t *outAddress)
{
    if (!outAddress || !gUnityBase) return false;
    uint32_t code[40]{};
    if (!ReadBytes(gUnityBase + rva, code, sizeof(code))) return false;

    RegisterState regs{};
    for (size_t i = 0; i < sizeof(code) / sizeof(code[0]); ++i) {
        const uint32_t insn = code[i];
        const mach_vm_address_t pc = gUnityBase + rva + (mach_vm_address_t)(i * 4);

        uint8_t rd = 0, rn = 0;
        mach_vm_address_t page = 0;
        if (DecodeADRP(insn, pc, &rd, &page)) {
            regs.hasAddress[rd] = true;
            regs.address[rd] = page;
            regs.hasValue[rd] = false;
            regs.hasLoadSource[rd] = false;
            continue;
        }

        uint64_t imm = 0;
        if (DecodeADDImm(insn, &rd, &rn, &imm)) {
            if (regs.hasAddress[rn]) {
                regs.hasAddress[rd] = true;
                regs.address[rd] = regs.address[rn] + imm;
            }
            continue;
        }

        if (DecodeMOVReg(insn, &rd, &rn)) {
            regs.hasAddress[rd] = regs.hasAddress[rn];
            regs.address[rd] = regs.address[rn];
            regs.hasLoadSource[rd] = regs.hasLoadSource[rn];
            regs.loadSource[rd] = regs.loadSource[rn];
            continue;
        }

        if (DecodeLDR64Imm(insn, &rd, &rn, &imm)) {
            if (regs.hasAddress[rn]) {
                regs.hasLoadSource[rd] = true;
                regs.loadSource[rd] = regs.address[rn] + imm;
                regs.hasAddress[rd] = false;
            }
            continue;
        }

        if ((insn & 0xFFFFFC1Fu) == 0xD65F0000u) {
            if (regs.hasLoadSource[0]) {
                *outAddress = regs.loadSource[0];
                return true;
            }
            return false;
        }
        if ((insn & 0xFC000000u) == 0x94000000u || (insn & 0xFFFFFC1Fu) == 0xD63F0000u) {
            regs = RegisterState{};
            continue;
        }
    }
    return false;
}

static bool EnsureTargetContext(ESPExternalSnapshot &s, bool forceRvaCheck)
{
    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        CloseTask();
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
        return false;
    }

    if (gTask == MACH_PORT_NULL || gPID != pid) {
        CloseTask();
        gTask = get_task_by_pid(pid);
        if (gTask == MACH_PORT_NULL) {
            BuildFailure(s, "FALHOU: FreeFire PID %d encontrado; task nao abriu: %s",
                         pid, get_task_last_error());
            return false;
        }
        gPID = pid;
        gUnityBase = get_image_base_address(gTask, "UnityFramework");
        if (!gUnityBase) {
            CloseTask();
            BuildFailure(s, "FALHOU: task OK, UnityFramework nao localizado | PID %d", pid);
            return false;
        }
        gLastVerification = 0;
    }

    s.processFound = 1;
    s.processPID = pid;
    s.taskOpened = (gTask != MACH_PORT_NULL);
    s.task = (uint64_t)gTask;
    s.unityFound = (gUnityBase != 0);
    s.unityBase = (uint64_t)gUnityBase;

    uint32_t magic = 0;
    if (!ReadValue(gUnityBase, &magic) || magic != MH_MAGIC_64) {
        CloseTask();
        BuildFailure(s, "FALHOU: UnityFramework 0x%llX, cabecalho Mach-O nao legivel",
                     (unsigned long long)gUnityBase);
        return false;
    }
    s.machoReadable = 1;
    gLastMachoReadable = true;

    const uint64_t now = NowNanos();
    if (forceRvaCheck || now - gLastVerification > 1000000000ull) {
        const uintptr_t rvas[] = {
            FreeFireOffsets::GameFacadeGetUIModelMatchRVA,
            FreeFireOffsets::GameFacadeGetUIModelSpectatorRVA,
            FreeFireOffsets::GetPlayerByTeamIdAndPlayerIndexStrictRVA,
            FreeFireOffsets::GetLivePlayerByTeamIdAndPlayerIndexRVA,
            FreeFireOffsets::GetPlayerCountRVA,
            FreeFireOffsets::GetPlayerListFromTeamIdRVA,
            FreeFireOffsets::PlayerGetTransformNodeRVA,
            FreeFireOffsets::TransformGetPositionRVA,
            FreeFireOffsets::CameraGetMainRVA,
            FreeFireOffsets::CameraWorldToScreenPointRVA,
            FreeFireOffsets::AnimatorGetBoneTransformRVA,
            FreeFireOffsets::AnimatorGetBoneTransformInternalRVA,
        };
        gLastTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
        gLastReadable = 0;
        for (uint32_t i = 0; i < gLastTestCount; ++i)
            if (ReadRVA(rvas[i])) ++gLastReadable;
        gLastVerification = now;
    }

    s.rvaReadableCount = gLastReadable;
    s.rvaTestCount = gLastTestCount;
    return true;
}

struct RemoteDictionaryHeader {
    uint64_t klass;
    uint64_t monitor;
    uint64_t buckets;
    uint64_t entries;
    int32_t count;
    int32_t version;
    int32_t freeList;
    int32_t freeCount;
    uint64_t comparer;
    uint64_t keys;
    uint64_t values;
    uint64_t syncRoot;
};

struct PlayerRecord {
    mach_vm_address_t data = 0;
    mach_vm_address_t player = 0;
    uint64_t userId = 0;
    uint32_t teamId = 0;
    uint32_t secondaryTeamId = 0;
    bool dead = false;
    bool bot = false;
    Vector3 lastPosition{};
};

static bool ReadPlayerRecord(mach_vm_address_t playerData, PlayerRecord *out)
{
    if (!out || !PlausibleAddress(playerData)) return false;

    unsigned char bytes[0x138]{};
    if (!ReadBytes(playerData, bytes, sizeof(bytes))) return false;

    PlayerRecord r{};
    r.data = playerData;
    std::memcpy(&r.userId, bytes + FreeFireOffsets::PlayerDataUserIdOffset, sizeof(r.userId));
    r.teamId = bytes[FreeFireOffsets::PlayerDataTeamIdOffset];
    r.secondaryTeamId = bytes[FreeFireOffsets::PlayerDataSecondaryTeamIdOffset];
    r.dead = (*(bytes + FreeFireOffsets::PlayerDataIsDeadOffset)) != 0;
    std::memcpy(&r.lastPosition, bytes + FreeFireOffsets::PlayerDataLastPositionOffset, sizeof(r.lastPosition));
    std::memcpy(&r.player, bytes + FreeFireOffsets::PlayerDataPlayerOffset, sizeof(r.player));
    r.bot = (*(bytes + FreeFireOffsets::PlayerDataIsBotOffset)) != 0;

    if (!PlausibleAddress(r.player)) r.player = 0;
    if (!std::isfinite(r.lastPosition.x) || !std::isfinite(r.lastPosition.y) || !std::isfinite(r.lastPosition.z))
        return false;

    *out = r;
    return true;
}


static bool ReadPlayerDataList(mach_vm_address_t playerList,
                                  std::vector<PlayerRecord> *outRecords)
{
    if (!outRecords || !PlausibleAddress(playerList)) return false;

    mach_vm_address_t items = 0;
    int32_t size = 0;
    if (!ReadValue(playerList + FreeFireOffsets::ManagedListItemsOffset, &items) ||
        !ReadValue(playerList + FreeFireOffsets::ManagedListSizeOffset, &size)) {
        return false;
    }

    if (size <= 0) {
        outRecords->clear();
        return true;
    }
    if (size > 2048 || !PlausibleAddress(items)) return false;

    const int entryCount = std::min(size, 256);
    const mach_vm_size_t bytes =
        (mach_vm_size_t)FreeFireOffsets::ManagedListDataOffset +
        (mach_vm_size_t)entryCount * sizeof(mach_vm_address_t);

    std::vector<unsigned char> elementBytes((size_t)bytes);
    if (!ReadBytes(items, elementBytes.data(), bytes)) return false;

    outRecords->clear();
    outRecords->reserve(std::min(entryCount, (int)ESP_EXTERNAL_MAX_TARGETS * 2));

    const size_t dataBase = (size_t)FreeFireOffsets::ManagedListDataOffset;
    for (int i = 0; i < entryCount; ++i) {
        mach_vm_address_t playerData = 0;
        std::memcpy(&playerData,
                    elementBytes.data() + dataBase + (size_t)i * sizeof(playerData),
                    sizeof(playerData));
        if (!PlausibleAddress(playerData)) continue;

        PlayerRecord record{};
        if (!ReadPlayerRecord(playerData, &record)) continue;
        outRecords->push_back(record);
    }

    return true;
}


static mach_vm_address_t FindActiveCamera(const std::vector<PlayerRecord> &records,
                                          uint32_t localTeamHint,
                                          mach_vm_address_t *localPlayerOut)
{
    if (localPlayerOut) *localPlayerOut = 0;

    auto tryRecord = [&](const PlayerRecord &r, mach_vm_address_t *cameraOut) -> bool {
        if (!r.player || !cameraOut) return false;

        mach_vm_address_t followCamera = 0;
        if (!ReadValue(r.player + FreeFireOffsets::PlayerFollowCameraOffset, &followCamera) ||
            !PlausibleAddress(followCamera)) {
            return false;
        }

        mach_vm_address_t camera = 0;
        if (!ReadValue(followCamera + FreeFireOffsets::CameraControllerTargetCameraOffset, &camera) ||
            !PlausibleAddress(camera)) {
            return false;
        }

        ESPMatrix4x4 matrix{};
        if (ESPReadCameraMatrix(gTask, camera, &matrix)) {
            if (localPlayerOut) *localPlayerOut = r.player;
            *cameraOut = camera;
            return true;
        }
        return false;
    };

    if (localTeamHint != 0) {
        for (const PlayerRecord &r : records) {
            const uint32_t team = r.teamId ? r.teamId : r.secondaryTeamId;
            mach_vm_address_t candidate = 0;
            if (team == localTeamHint && tryRecord(r, &candidate))
                return candidate;
        }
    }

    for (const PlayerRecord &r : records) {
        mach_vm_address_t candidate = 0;
        if (tryRecord(r, &candidate))
            return candidate;
    }

    // Reference fallback: resolve Camera.main only when the dump's player-owned
    // FollowCamera chain doesn't expose a live Camera object.
    mach_vm_address_t camera = 0;
    if (ResolveGetterReturnObject(FreeFireOffsets::CameraGetMainRVA, &camera)) {
        ESPMatrix4x4 matrix{};
        if (ESPReadCameraMatrix(gTask, camera, &matrix))
            return camera;
    }
    return 0;
}

static Vector3 SelectWorldPosition(const PlayerRecord &r)
{
    if (std::fabs(r.lastPosition.x) + std::fabs(r.lastPosition.y) + std::fabs(r.lastPosition.z) > 0.001f)
        return r.lastPosition;

    if (r.player) {
        mach_vm_address_t transform = 0;
        if (ReadValue(r.player + FreeFireOffsets::PlayerRootTransformOffset, &transform)) {
            Vector3 p{};
            if (ESPReadTransformPosition(gTask, transform, &p))
                return p;
        }
    }
    return r.lastPosition;
}

static void MakeTarget(const PlayerRecord &r,
                       const ESPMatrix4x4 &matrix,
                       float pixelW,
                       float pixelH,
                       float scale,
                       ESPExternalTarget *out)
{
    *out = ESPExternalTarget{};
    out->player = (uint64_t)r.player;
    out->teamId = r.teamId ? r.teamId : r.secondaryTeamId;
    if (r.bot) out->flags |= ESP_TARGET_IS_BOT;

    const Vector3 feetWorld = SelectWorldPosition(r);
    Vector3 feetScreen{};
    if (!ESPWorldToScreen(feetWorld, matrix, pixelW, pixelH, &feetScreen)) return;

    const float modelHeight = 1.75f;
    const Vector3 headWorld(feetWorld.x, feetWorld.y + modelHeight, feetWorld.z);
    Vector3 headScreen{};
    const bool headValid = ESPWorldToScreen(headWorld, matrix, pixelW, pixelH, &headScreen);

    const float invScale = scale > 0.1f ? (1.0f / scale) : 1.0f;
    const float bottomX = feetScreen.x * invScale;
    const float bottomY = (pixelH - feetScreen.y) * invScale;

    out->x = bottomX;
    out->y = bottomY;
    out->z = feetScreen.z;
    out->depth = feetScreen.z;
    out->bottomX = bottomX;
    out->bottomY = bottomY;
    out->flags |= ESP_TARGET_HAS_LINE;

    if (headValid && std::isfinite(headScreen.x) && std::isfinite(headScreen.y)) {
        float topX = headScreen.x * invScale;
        float topY = (pixelH - headScreen.y) * invScale;
        float height = std::fabs(bottomY - topY);
        if (height >= 3.0f && height <= 3000.0f) {
            const float boxWidth = std::max(4.0f, std::min(240.0f, height * 0.42f));
            out->topX = topX;
            out->topY = topY;
            out->boxLeft = bottomX - boxWidth * 0.5f;
            out->boxRight = bottomX + boxWidth * 0.5f;
            out->boxTop = std::min(topY, bottomY);
            out->boxBottom = std::max(topY, bottomY);
            out->flags |= ESP_TARGET_HAS_BOX;
        }
    }

    out->valid = 1;
}

static bool ReadLiveSnapshot(ESPExternalSnapshot &s)
{
    if (!EnsureTargetContext(s, false)) return false;
    if (!gLastMachoReadable) return false;

    uint32_t localTeamHint = 0;
    std::vector<PlayerRecord> records;
    bool matchModelResolved = false;

    mach_vm_address_t uiModelMatch = 0;
    if (ResolveGetterReturnObject(FreeFireOffsets::GameFacadeGetUIModelMatchRVA,
                                  &uiModelMatch) &&
        PlausibleAddress(uiModelMatch)) {
        matchModelResolved = true;

        uint8_t localTeam = 0;
        if (ReadValue(uiModelMatch + FreeFireOffsets::UIModelMatchLocalTeamIdOffset, &localTeam))
            localTeamHint = localTeam;

        mach_vm_address_t playerList = 0;
        if (ReadValue(uiModelMatch + FreeFireOffsets::UIModelMatchPlayerDataListOffset,
                      &playerList) &&
            PlausibleAddress(playerList) &&
            ReadPlayerDataList(playerList, &records)) {
            if (!records.empty()) {
                // Active-match path is authoritative when it has PlayerData.
                goto HAVE_PLAYER_RECORDS;
            }
        }
    }

    // Spectator-model fallback. The dump contains this model separately, but its
    // data is still useful for observer/replay states.
    {
        mach_vm_address_t uiModelSpectator = 0;
        if (!ResolveGetterReturnObject(FreeFireOffsets::GameFacadeGetUIModelSpectatorRVA,
                                       &uiModelSpectator) ||
            !PlausibleAddress(uiModelSpectator)) {
            BuildFailure(s,
                         "FALHOU: modelos UI nao resolveram | match=%s",
                         matchModelResolved ? "objeto-ok/lista-vazia" : "nao-resolvido");
            return false;
        }

        mach_vm_address_t playerDictionary = 0;
    if (!ReadValue(uiModelSpectator + FreeFireOffsets::UIModelSpectatorPlayerDicOffset,
                   &playerDictionary) || !PlausibleAddress(playerDictionary)) {
        BuildFailure(s, "FALHOU: UIModelSpectator resolvido, m_PlayerDic invalido");
        return false;
    }

    RemoteDictionaryHeader dictionary{};
    if (!ReadValue(playerDictionary, &dictionary)) {
        BuildFailure(s, "FALHOU: m_PlayerDic nao legivel");
        return false;
    }

    if (!PlausibleAddress(dictionary.entries) || dictionary.count <= 0 || dictionary.count > 2048) {
        s.count = 0;
        snprintf(s.message, sizeof(s.message),
                 "OK: contexto externo vivo | PID %d | PlayerDic vazio/inativo (%d)",
                 s.processPID, dictionary.count);
        return true;
    }

    const int entryCount = std::min(dictionary.count, 256);
    const mach_vm_size_t entryBytes = FreeFireOffsets::ManagedArrayDataOffset +
        (mach_vm_size_t)entryCount * FreeFireOffsets::PlayerDictionaryEntryStride;
    std::vector<unsigned char> entries((size_t)entryBytes);
    if (!ReadBytes(dictionary.entries, entries.data(), entryBytes)) {
        BuildFailure(s, "FALHOU: entries de m_PlayerDic nao legiveis");
        return false;
    }

        records.clear();
        records.reserve(std::min(entryCount, (int)ESP_EXTERNAL_MAX_TARGETS * 2));

        for (int i = 0; i < entryCount; ++i) {
        const size_t entryOffset = (size_t)FreeFireOffsets::ManagedArrayDataOffset +
            (size_t)i * (size_t)FreeFireOffsets::PlayerDictionaryEntryStride;

        int32_t hashCode = -1;
        std::memcpy(&hashCode, entries.data() + entryOffset, sizeof(hashCode));
        if (hashCode < 0) continue;

        mach_vm_address_t playerData = 0;
        std::memcpy(&playerData,
                    entries.data() + entryOffset + FreeFireOffsets::PlayerDictionaryEntryValueOffset,
                    sizeof(playerData));
        if (!PlausibleAddress(playerData)) continue;

            PlayerRecord record{};
            if (!ReadPlayerRecord(playerData, &record)) continue;
            records.push_back(record);
        }
    }

HAVE_PLAYER_RECORDS:
    if (records.empty()) {
        BuildFailure(s, "FALHOU: nenhum PlayerData valido | model=%s",
                     matchModelResolved ? "UIModelMatch/UIModelSpectator" : "UIModelSpectator");
        return false;
    }

    mach_vm_address_t localPlayer = 0;
    mach_vm_address_t camera = FindActiveCamera(records, localTeamHint, &localPlayer);
    if (!camera) {
        BuildFailure(s,
                     "FALHOU: PlayerDic vivo, mas camera externa nao resolveu | records=%lu",
                     (unsigned long)records.size());
        return false;
    }

    ESPMatrix4x4 matrix{};
    if (!ESPReadCameraMatrix(gTask, camera, &matrix)) {
        BuildFailure(s, "FALHOU: camera 0x%llX sem matriz valida",
                     (unsigned long long)camera);
        return false;
    }

    float widthPoints = gDisplayWidth.load(std::memory_order_acquire);
    float heightPoints = gDisplayHeight.load(std::memory_order_acquire);
    float scale = gDisplayScale.load(std::memory_order_acquire);
    if (widthPoints <= 1.0f || heightPoints <= 1.0f) {
        widthPoints = 1000.0f;
        heightPoints = 600.0f;
    }
    if (scale < 0.1f) scale = 1.0f;

    const float pixelW = widthPoints * scale;
    const float pixelH = heightPoints * scale;
    const bool teamFilter = gTeamFilter.load(std::memory_order_acquire) != 0;

    uint32_t localTeam = 0;
    for (const PlayerRecord &r : records) {
        if (r.player == localPlayer) {
            localTeam = r.teamId ? r.teamId : r.secondaryTeamId;
            break;
        }
    }

    s.camera = (uint64_t)camera;
    s.localPlayer = (uint64_t)localPlayer;
    s.count = 0;

    for (const PlayerRecord &r : records) {
        if (!r.player || r.dead || r.player == localPlayer) continue;

        const uint32_t team = r.teamId ? r.teamId : r.secondaryTeamId;
        if (teamFilter && localTeam != 0 && team == localTeam) continue;

        ESPExternalTarget target{};
        MakeTarget(r, matrix, pixelW, pixelH, scale, &target);
        if (!target.valid) continue;

        if (s.count < ESP_EXTERNAL_MAX_TARGETS)
            s.targets[s.count++] = target;
    }

    snprintf(s.message, sizeof(s.message),
             "OK: ESP externo | PID %d | records=%lu | enemies=%u | camera=0x%llX",
             s.processPID,
             (unsigned long)records.size(),
             s.count,
             (unsigned long long)camera);
    return true;
}
}

extern "C" int ESPExternalSetMode(int mode)
{
    if (mode < 0 || mode > 1) mode = 0;
    gMode.store(mode, std::memory_order_release);
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalSetTeamFilterEnabled(int enabled)
{
    gTeamFilter.store(enabled ? 1 : 0, std::memory_order_release);
    return enabled ? 1 : 0;
}

extern "C" int ESPExternalGetTeamFilterEnabled(void)
{
    return gTeamFilter.load(std::memory_order_acquire);
}

extern "C" int ESPExternalSetDisplayMetrics(float widthPoints, float heightPoints, float scale)
{
    if (!std::isfinite(widthPoints) || !std::isfinite(heightPoints) || widthPoints <= 1.0f || heightPoints <= 1.0f)
        return 0;
    if (!std::isfinite(scale) || scale <= 0.1f) scale = 1.0f;
    gDisplayWidth.store(widthPoints, std::memory_order_release);
    gDisplayHeight.store(heightPoints, std::memory_order_release);
    gDisplayScale.store(scale, std::memory_order_release);
    return 1;
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    const bool ok = EnsureTargetContext(s, true);
    s.rvaReadableCount = gLastReadable;
    s.rvaTestCount = gLastTestCount;

    if (!ok) {
        if (out) *out = s;
        return 0;
    }

    if (gLastReadable != gLastTestCount) {
        BuildFailure(s,
                     "PARCIAL: FreeFire OK | PID %d | Unity 0x%llX | Mach-O OK | RVAs %u/%u",
                     s.processPID,
                     (unsigned long long)s.unityBase,
                     gLastReadable,
                     gLastTestCount);
        if (out) *out = s;
        return 0;
    }

    snprintf(s.message, sizeof(s.message),
             "OK: FreeFire externo | PID %d | task OK | UnityFramework 0x%llX | Mach-O OK | RVAs %u/%u",
             s.processPID,
             (unsigned long long)s.unityBase,
             gLastReadable,
             gLastTestCount);

    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    const bool ok = ReadLiveSnapshot(s);
    s.rvaReadableCount = gLastReadable;
    s.rvaTestCount = gLastTestCount;
    s.processPID = gPID;
    s.task = (uint64_t)gTask;
    s.unityBase = (uint64_t)gUnityBase;
    s.taskOpened = gTask != MACH_PORT_NULL;
    s.processFound = gPID > 0;
    s.unityFound = gUnityBase != 0;
    s.machoReadable = gLastMachoReadable ? 1u : 0u;

    if (out) *out = s;
    return ok ? 1 : 0;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[768];
    ESPExternalSnapshot s{};
    ESPExternalVerify(&s);
    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: sem diagnostico");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1024];
    ESPExternalSnapshot s{};
    const int verifyOk = ESPExternalVerify(&s);
    if (!verifyOk) {
        snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: diagnostico externo");
        return text;
    }

    ESPExternalSnapshot live{};
    const int liveOk = ESPExternalReadSnapshot(&live);
    snprintf(text, sizeof(text),
             "EXTERNAL ESP V4\nFreeFire: OK | PID: %d\n"
             "task: OK | UnityFramework: 0x%llX\n"
             "RVAs: %u/%u | live: %s\n"
             "targets: %u | camera: 0x%llX\n"
             "%s",
             s.processPID,
             (unsigned long long)s.unityBase,
             s.rvaReadableCount,
             s.rvaTestCount,
             liveOk ? "OK" : "FAIL",
             live.count,
             (unsigned long long)live.camera,
             live.message[0] ? live.message : "sem detalhe do snapshot");
    return text;
}
