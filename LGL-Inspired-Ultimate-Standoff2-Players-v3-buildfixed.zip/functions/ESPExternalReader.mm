#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <mach-o/loader.h>
#include <mach/thread_act.h>
#include <mach/thread_status.h>
#include <Foundation/Foundation.h>
#include <dispatch/dispatch.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <atomic>
#include <mutex>
#include <vector>
#include <algorithm>
#include <cmath>

namespace {

static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static pid_t gPID = -1;
static std::atomic<int> gMode{0};
static std::mutex gRuntimeMutex;
static std::mutex gSnapshotMutex;
static std::atomic<bool> gRefreshScheduled{false};
static ESPExternalSnapshot gCachedSnapshot{};
static bool gHasCachedSnapshot = false;
static uint64_t gLastRefreshNanos = 0;

static constexpr uint32_t kRemoteTargetSlots = 256u;
static constexpr uint32_t kRemoteTargetStride = 32u;
static constexpr uint32_t kRemoteHeaderSize = 16u;
static constexpr uint32_t kSnapshotRefreshIntervalMs = 50u;
static constexpr uint32_t kRemoteCallTimeoutMs = 120u;

// These are scan ceilings, not offsets. The supplied dump proves the
// (teamId, playerIndex) API exists, but does not define the maximum index.
// Keeping the scan bounded avoids an unbounded target-process loop.
static constexpr int kScanMaxTeams = 32;
static constexpr int kScanPlayersPerTeam = 8;

struct RemoteWorkspace {
    mach_vm_address_t code = 0;
    mach_vm_size_t codeSize = 0;
    mach_vm_address_t stack = 0;
    mach_vm_size_t stackSize = 0;
    mach_vm_address_t output = 0;
    mach_vm_size_t outputSize = 0;
};

struct RemoteBulkTarget {
    uint64_t player;
    float x;
    float y;
    float z;
    float pad;
    uint8_t reserved[8];
};

struct RemoteBulkBuffer {
    uint32_t count;
    uint32_t done;
    uint64_t reserved;
    RemoteBulkTarget targets[kRemoteTargetSlots];
};

static RemoteWorkspace gRemote;

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}

static bool ReadRemote(task_t task, mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !out || size == 0)
        return false;

    mach_vm_size_t copied = 0;
    const kern_return_t kr = mach_vm_read_overwrite(task, address, size,
                                                     (mach_vm_address_t)out, &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool WriteRemote(task_t task, mach_vm_address_t address, const void *data, mach_vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !data || size == 0)
        return false;

    const kern_return_t kr = mach_vm_write(task,
                                           address,
                                           (pointer_t)data,
                                           (mach_msg_type_number_t)size);
    return kr == KERN_SUCCESS;
}

static bool ReadRVA(task_t task, mach_vm_address_t base, uintptr_t rva)
{
    uint32_t bytes = 0;
    return ReadRemote(task, base + (mach_vm_address_t)rva, &bytes, sizeof(bytes));
}

static void DestroyRemoteWorkspace(void)
{
    if (gTask != MACH_PORT_NULL) {
        if (gRemote.code)   mach_vm_deallocate(gTask, gRemote.code, gRemote.codeSize);
        if (gRemote.stack)  mach_vm_deallocate(gTask, gRemote.stack, gRemote.stackSize);
        if (gRemote.output) mach_vm_deallocate(gTask, gRemote.output, gRemote.outputSize);
    }
    gRemote = RemoteWorkspace{};
}

static void CloseTask(void)
{
    DestroyRemoteWorkspace();
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
    gPID = -1;
}

static uint32_t MovZ(int rd, uint16_t imm16, int hw = 0)
{
    return 0xD2800000u |
           (((uint32_t)hw & 0x3u) << 21) |
           ((uint32_t)imm16 << 5) |
           ((uint32_t)rd & 0x1Fu);
}

static uint32_t MovReg(int rd, int rm)
{
    return 0xAA0003E0u |
           (((uint32_t)rm & 0x1Fu) << 16) |
           ((uint32_t)rd & 0x1Fu);
}

static uint32_t Blr(int rn)
{
    return 0xD63F0000u | (((uint32_t)rn & 0x1Fu) << 5);
}

static uint32_t Cbz(int rt)
{
    return 0xB4000000u | ((uint32_t)rt & 0x1Fu);
}

static uint32_t AddImm(int rd, int rn, uint16_t imm12)
{
    return 0x91000000u |
           (((uint32_t)imm12 & 0xFFFu) << 10) |
           (((uint32_t)rn & 0x1Fu) << 5) |
           ((uint32_t)rd & 0x1Fu);
}

static uint32_t AddShifted(int rd, int rn, int rm, int shift)
{
    return 0x8B000000u |
           (((uint32_t)rm & 0x1Fu) << 16) |
           (((uint32_t)shift & 0x3Fu) << 10) |
           (((uint32_t)rn & 0x1Fu) << 5) |
           ((uint32_t)rd & 0x1Fu);
}

static uint32_t StrX(int rt, int rn)
{
    return 0xF9000000u |
           (((uint32_t)rn & 0x1Fu) << 5) |
           ((uint32_t)rt & 0x1Fu);
}

static uint32_t StrW(int rt, int rn, uint16_t byteOffset)
{
    const uint32_t imm12 = (uint32_t)(byteOffset / 4u);
    return 0xB9000000u |
           ((imm12 & 0xFFFu) << 10) |
           (((uint32_t)rn & 0x1Fu) << 5) |
           ((uint32_t)rt & 0x1Fu);
}

static uint32_t SturQ0(int rn, int byteOffset)
{
    const int imm9 = byteOffset;
    return 0x3C800000u |
           (((uint32_t)imm9 & 0x1FFu) << 12) |
           (((uint32_t)rn & 0x1Fu) << 5);
}

static uint32_t B(int imm26)
{
    return 0x14000000u | ((uint32_t)imm26 & 0x03FFFFFFu);
}

static void EmitMovImm64(std::vector<uint32_t> &code, int rd, uint64_t value)
{
    code.push_back(MovZ(rd, (uint16_t)((value >> 0) & 0xFFFFu), 0));
    code.push_back(0xF2800000u | (((uint32_t)((value >> 16) & 0xFFFFu)) << 5) |
                     (1u << 21) | ((uint32_t)rd & 0x1Fu));
    code.push_back(0xF2800000u | (((uint32_t)((value >> 32) & 0xFFFFu)) << 5) |
                     (2u << 21) | ((uint32_t)rd & 0x1Fu));
    code.push_back(0xF2800000u | (((uint32_t)((value >> 48) & 0xFFFFu)) << 5) |
                     (3u << 21) | ((uint32_t)rd & 0x1Fu));
}

static void PatchCBZ(std::vector<uint32_t> &code, size_t fromIndex, size_t toIndex)
{
    const int64_t byteDelta = ((int64_t)toIndex - (int64_t)fromIndex) * 4ll;
    const int32_t imm19 = (int32_t)(byteDelta >> 2);
    code[fromIndex] = (code[fromIndex] & 0xFF00001Fu) |
                       (((uint32_t)imm19 & 0x7FFFFu) << 5);
}

static void PatchB(std::vector<uint32_t> &code, size_t fromIndex, size_t toIndex)
{
    const int64_t byteDelta = ((int64_t)toIndex - (int64_t)fromIndex) * 4ll;
    const int32_t imm26 = (int32_t)(byteDelta >> 2);
    code[fromIndex] = 0x14000000u | ((uint32_t)imm26 & 0x03FFFFFFu);
}

static std::vector<uint32_t> BuildRemoteCollector(mach_vm_address_t gameFacadeGetter,
                                                  mach_vm_address_t cameraGetter,
                                                  mach_vm_address_t playerGetter,
                                                  mach_vm_address_t centerGetter,
                                                  mach_vm_address_t worldToScreen,
                                                  mach_vm_address_t output)
{
    std::vector<uint32_t> code;
    code.reserve(8192);

    // Callee-saved registers are used deliberately because every managed call
    // must preserve x19-x28 under the AArch64 ABI.
    EmitMovImm64(code, 26, gameFacadeGetter);
    EmitMovImm64(code, 27, cameraGetter);
    EmitMovImm64(code, 19, playerGetter);
    EmitMovImm64(code, 21, centerGetter);
    EmitMovImm64(code, 23, worldToScreen);
    EmitMovImm64(code, 24, output);
    code.push_back(MovZ(25, 0));

    // GameFacade.get_UIModelSpectator() -> UIModelSpectator*
    code.push_back(MovReg(16, 26));
    code.push_back(Blr(16));
    code.push_back(MovReg(20, 0));
    const size_t noSpectatorBranch = code.size();
    code.push_back(Cbz(20));

    // Camera.get_main() -> Camera*
    code.push_back(MovReg(16, 27));
    code.push_back(Blr(16));
    code.push_back(MovReg(22, 0));
    const size_t noCameraBranch = code.size();
    code.push_back(Cbz(22));

    for (int team = 0; team < kScanMaxTeams; ++team) {
        for (int index = 0; index < kScanPlayersPerTeam; ++index) {
            code.push_back(MovReg(0, 20));
            code.push_back(MovZ(1, (uint16_t)team));
            code.push_back(MovZ(2, (uint16_t)index));
            code.push_back(Blr(19));

            const size_t skip = code.size();
            code.push_back(Cbz(0));

            // Keep Player* only for diagnostics/deduplication in the snapshot.
            code.push_back(MovReg(18, 0));

            // Player.GetAttackableCenterWS() -> Vector3 in q0.
            code.push_back(Blr(21));

            // q0 still contains the world position: only x0 changes before
            // Camera.WorldToScreenPoint(Vector3).
            code.push_back(MovReg(0, 22));
            code.push_back(Blr(23));

            // target = output + 16 + count*32
            code.push_back(AddShifted(17, 24, 25, 5));
            code.push_back(AddImm(17, 17, 16));
            code.push_back(StrX(18, 17));
            code.push_back(SturQ0(17, 8));
            code.push_back(AddImm(25, 25, 1));

            const size_t next = code.size();
            PatchCBZ(code, skip, next);
        }
    }

    // count + done header.
    code.push_back(StrW(25, 24, 0));
    code.push_back(MovZ(17, 1));
    code.push_back(StrW(17, 24, 4));

    // Permanent loop. The host terminates the Mach thread after reading output.
    const size_t loopIndex = code.size();
    const size_t permanentBranch = code.size();
    code.push_back(B(0));
    PatchB(code, permanentBranch, loopIndex);

    PatchCBZ(code, noSpectatorBranch, code.size() - 4);
    PatchCBZ(code, noCameraBranch, code.size() - 4);
    return code;
}

static bool AllocateRemoteWorkspace(void)
{
    if (gTask == MACH_PORT_NULL)
        return false;

    DestroyRemoteWorkspace();

    gRemote.codeSize = 0x10000;
    gRemote.stackSize = 0x20000;
    gRemote.outputSize = kRemoteHeaderSize +
        (mach_vm_size_t)kRemoteTargetSlots * (mach_vm_size_t)kRemoteTargetStride;

    if (mach_vm_allocate(gTask, &gRemote.code, gRemote.codeSize, VM_FLAGS_ANYWHERE) != KERN_SUCCESS)
        goto fail;
    if (mach_vm_allocate(gTask, &gRemote.stack, gRemote.stackSize, VM_FLAGS_ANYWHERE) != KERN_SUCCESS)
        goto fail;
    if (mach_vm_allocate(gTask, &gRemote.output, gRemote.outputSize, VM_FLAGS_ANYWHERE) != KERN_SUCCESS)
        goto fail;

    if (mach_vm_protect(gTask,
                        gRemote.code,
                        gRemote.codeSize,
                        false,
                        VM_PROT_READ | VM_PROT_WRITE | VM_PROT_EXECUTE) != KERN_SUCCESS)
        goto fail;

    {
        std::vector<uint8_t> zero((size_t)gRemote.outputSize, 0);
        if (!WriteRemote(gTask, gRemote.output, zero.data(), gRemote.outputSize))
            goto fail;
    }

    return true;

fail:
    DestroyRemoteWorkspace();
    return false;
}

static bool InstallRemoteCollectorCode(const std::vector<uint32_t> &code)
{
    if (code.empty() || gRemote.code == 0 || code.size() * sizeof(uint32_t) > gRemote.codeSize)
        return false;
    return WriteRemote(gTask,
                       gRemote.code,
                       code.data(),
                       (mach_vm_size_t)(code.size() * sizeof(uint32_t)));
}

static bool EnsureConnection(ESPExternalSnapshot &s)
{
    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
        return false;
    }

    if (gTask != MACH_PORT_NULL && gPID != pid && gPID > 0)
        CloseTask();

    if (gTask == MACH_PORT_NULL) {
        gTask = get_task_by_pid(pid);
        if (gTask == MACH_PORT_NULL) {
            BuildFailure(s, "FALHOU: FreeFire PID %d encontrado; task nao abriu: %s",
                         pid, get_task_last_error());
            return false;
        }
        gPID = pid;
    }

    s.processFound = 1;
    s.processPID = pid;
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;

    if (!gUnityBase)
        gUnityBase = get_image_base_address(gTask, "UnityFramework");

    if (!gUnityBase) {
        BuildFailure(s, "FALHOU: task OK, UnityFramework nao localizado | PID %d", pid);
        CloseTask();
        return false;
    }

    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    uint32_t magic = 0;
    if (!ReadRemote(gTask, gUnityBase, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        BuildFailure(s, "FALHOU: UnityFramework 0x%llX, cabecalho Mach-O nao legivel",
                     (unsigned long long)gUnityBase);
        CloseTask();
        return false;
    }
    s.machoReadable = 1;
    return true;
}

static bool BuildAndInstallCollector(ESPExternalSnapshot &s)
{
    if (!gRemote.code && !AllocateRemoteWorkspace()) {
        BuildFailure(s, "FALHOU: nao foi possivel reservar workspace remoto RX/RW no FreeFire");
        return false;
    }

    const mach_vm_address_t gameFacadeGetter = gUnityBase + FreeFireOffsets::GameFacadeGetUIModelSpectatorRVA;
    const mach_vm_address_t cameraGetter = gUnityBase + FreeFireOffsets::CameraGetMainRVA;
    const mach_vm_address_t playerGetter = gUnityBase + FreeFireOffsets::GetLivePlayerByTeamIdAndPlayerIndexRVA;
    const mach_vm_address_t centerGetter = gUnityBase + FreeFireOffsets::PlayerGetAttackableCenterWSRVA;
    const mach_vm_address_t worldToScreen = gUnityBase + FreeFireOffsets::CameraWorldToScreenPointRVA;

    const std::vector<uint32_t> code = BuildRemoteCollector(gameFacadeGetter,
                                                              cameraGetter,
                                                              playerGetter,
                                                              centerGetter,
                                                              worldToScreen,
                                                              gRemote.output);
    if (!InstallRemoteCollectorCode(code)) {
        BuildFailure(s, "FALHOU: codigo coletor remoto nao pode ser instalado");
        return false;
    }
    return true;
}

static bool RunRemoteCollector(ESPExternalSnapshot &s)
{
    if (gTask == MACH_PORT_NULL || gRemote.code == 0 || gRemote.stack == 0 || gRemote.output == 0)
        return false;

    RemoteBulkBuffer reset{};
    if (!WriteRemote(gTask, gRemote.output, &reset, sizeof(reset))) {
        BuildFailure(s, "FALHOU: nao foi possivel limpar o buffer remoto");
        return false;
    }

    arm_thread_state64_t state{};
    state.__pc = gRemote.code;
    state.__sp = (gRemote.stack + gRemote.stackSize - 0x1000ull) & ~0xFull;

    thread_act_t thread = MACH_PORT_NULL;
    kern_return_t kr = thread_create(gTask, &thread);
    if (kr != KERN_SUCCESS || thread == MACH_PORT_NULL) {
        BuildFailure(s, "FALHOU: thread remota nao criada: 0x%x", kr);
        return false;
    }

    state.__x[0] = 0;
    state.__x[1] = 0;
    state.__x[2] = 0;
    state.__x[3] = 0;

    kr = thread_set_state(thread,
                          ARM_THREAD_STATE64,
                          (thread_state_t)&state,
                          ARM_THREAD_STATE64_COUNT);
    if (kr == KERN_SUCCESS)
        kr = thread_resume(thread);

    if (kr != KERN_SUCCESS) {
        thread_terminate(thread);
        mach_port_deallocate(mach_task_self(), thread);
        BuildFailure(s, "FALHOU: thread remota nao iniciou: 0x%x", kr);
        return false;
    }

    const uint64_t deadline = NowNanos() + (uint64_t)kRemoteCallTimeoutMs * 1000000ull;
    uint32_t done = 0;
    while (NowNanos() < deadline) {
        if (ReadRemote(gTask, gRemote.output + 4, &done, sizeof(done)) && done == 1u)
            break;
        usleep(1000);
    }

    RemoteBulkBuffer remote{};
    const bool completed = done == 1u && ReadRemote(gTask, gRemote.output, &remote, sizeof(remote));

    thread_terminate(thread);
    mach_port_deallocate(mach_task_self(), thread);

    if (!completed) {
        BuildFailure(s, "FALHOU: coletor remoto nao concluiu em %ums", kRemoteCallTimeoutMs);
        CloseTask();
        return false;
    }

    const uint32_t remoteCount = std::min(remote.count, kRemoteTargetSlots);
    s.count = std::min(remoteCount, ESP_EXTERNAL_MAX_TARGETS);

    uint32_t outputCount = 0;
    for (uint32_t i = 0; i < s.count; ++i) {
        const RemoteBulkTarget &src = remote.targets[i];
        ESPExternalTarget &dst = s.targets[outputCount];

        if (!src.player || !std::isfinite(src.x) || !std::isfinite(src.y) || !std::isfinite(src.z))
            continue;
        if (src.z <= 0.001f)
            continue;
        if (std::fabs(src.x) > 100000.0f || std::fabs(src.y) > 100000.0f)
            continue;

        dst.player = src.player;
        dst.x = src.x;
        dst.y = src.y;
        dst.z = src.z;
        dst.depth = src.z;
        dst.valid = 1;
        ++outputCount;
    }

    s.count = outputCount;
    snprintf(s.message, sizeof(s.message),
             "OK: externo | PID %d | Unity 0x%llX | targets %u/%u",
             s.processPID,
             (unsigned long long)s.unityBase,
             s.count,
             remoteCount);
    return true;
}

static bool RefreshSnapshotLocked(ESPExternalSnapshot &out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    if (!EnsureConnection(s)) {
        out = s;
        return false;
    }

    if (!BuildAndInstallCollector(s) || !RunRemoteCollector(s)) {
        out = s;
        return false;
    }

    out = s;
    return true;
}

static void ScheduleBackgroundRefresh(void)
{
    bool expected = false;
    if (!gRefreshScheduled.compare_exchange_strong(expected, true))
        return;

    dispatch_async(dispatch_get_global_queue(QOS_CLASS_USER_INITIATED, 0), ^{
        ESPExternalSnapshot fresh{};
        {
            std::lock_guard<std::mutex> guard(gRuntimeMutex);
            RefreshSnapshotLocked(fresh);
        }
        {
            std::lock_guard<std::mutex> guard(gSnapshotMutex);
            gCachedSnapshot = fresh;
            gHasCachedSnapshot = true;
            gLastRefreshNanos = NowNanos();
        }
        gRefreshScheduled.store(false, std::memory_order_release);
    });
}

} // namespace

extern "C" int ESPExternalSetMode(int mode)
{
    if (mode < 0 || mode > 1) mode = 0;
    gMode.store(mode, std::memory_order_release);

    if (mode == 0) {
        std::lock_guard<std::mutex> guard(gSnapshotMutex);
        gCachedSnapshot.count = 0;
    } else {
        ScheduleBackgroundRefresh();
    }
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    std::lock_guard<std::mutex> guard(gRuntimeMutex);
    const bool ok = EnsureConnection(s);
    if (!ok) {
        if (out) *out = s;
        return 0;
    }

    const uintptr_t rvas[] = {
        FreeFireOffsets::GameFacadeGetUIModelSpectatorRVA,
        FreeFireOffsets::GetLivePlayerByTeamIdAndPlayerIndexRVA,
        FreeFireOffsets::GetPlayerCountRVA,
        FreeFireOffsets::GetPlayerListFromTeamIdRVA,
        FreeFireOffsets::PlayerGetTransformNodeRVA,
        FreeFireOffsets::TransformGetPositionRVA,
        FreeFireOffsets::CameraGetMainRVA,
        FreeFireOffsets::CameraWorldToScreenPointRVA,
        FreeFireOffsets::PlayerGetAttackableCenterWSRVA,
    };

    s.rvaTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
    for (uint32_t i = 0; i < s.rvaTestCount; ++i) {
        if (ReadRVA(gTask, gUnityBase, rvas[i]))
            ++s.rvaReadableCount;
    }

    if (s.rvaReadableCount != s.rvaTestCount) {
        BuildFailure(s,
                     "PARCIAL: PID %d | Unity 0x%llX | RVAs legiveis %u/%u",
                     s.processPID,
                     (unsigned long long)s.unityBase,
                     s.rvaReadableCount,
                     s.rvaTestCount);
        if (out) *out = s;
        return 0;
    }

    snprintf(s.message, sizeof(s.message),
             "OK: processo/task/Unity/RVAs | PID %d | Unity 0x%llX | %u/%u RVAs",
             s.processPID,
             (unsigned long long)s.unityBase,
             s.rvaReadableCount,
             s.rvaTestCount);

    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot snapshot{};
    snapshot.magic = ESP_EXTERNAL_MAGIC;
    snapshot.version = ESP_EXTERNAL_VERSION;

    if (gMode.load(std::memory_order_acquire) == 0) {
        if (out) *out = snapshot;
        return 0;
    }

    const uint64_t now = NowNanos();
    bool hasSnapshot = false;
    bool stale = true;
    {
        std::lock_guard<std::mutex> guard(gSnapshotMutex);
        hasSnapshot = gHasCachedSnapshot;
        stale = !hasSnapshot || now - gLastRefreshNanos >= (uint64_t)kSnapshotRefreshIntervalMs * 1000000ull;
        snapshot = gCachedSnapshot;
    }

    if (!hasSnapshot) {
        std::lock_guard<std::mutex> guard(gRuntimeMutex);
        RefreshSnapshotLocked(snapshot);
        std::lock_guard<std::mutex> cacheGuard(gSnapshotMutex);
        gCachedSnapshot = snapshot;
        gHasCachedSnapshot = true;
        gLastRefreshNanos = NowNanos();
    } else if (stale) {
        ScheduleBackgroundRefresh();
    }

    if (out) *out = snapshot;
    return snapshot.processFound && snapshot.taskOpened && snapshot.unityFound;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[768];
    ESPExternalSnapshot s{};
    ESPExternalReadSnapshot(&s);
    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: sem diagnostico");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1024];
    ESPExternalSnapshot s{};
    const int ok = ESPExternalVerify(&s);

    if (!ok) {
        snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: diagnostico externo");
        return text;
    }

    ESPExternalSnapshot live{};
    ESPExternalReadSnapshot(&live);

    snprintf(text, sizeof(text),
             "EXTERNAL CHECK\nFreeFire: OK | PID: %d\n"
             "task: OK | UnityFramework: 0x%llX\n"
             "RVAs legiveis: %u/%u\n"
             "ESP targets: %u",
             s.processPID,
             (unsigned long long)s.unityBase,
             s.rvaReadableCount,
             s.rvaTestCount,
             live.count);
    return text;
}
