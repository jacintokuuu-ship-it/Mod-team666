#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <atomic>
#include <stdint.h>

namespace {
static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static std::atomic<int> gMode{0};

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
}

static bool ReadRemote(task_t task, mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !out || size == 0)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, address, size,
                                               (mach_vm_address_t)out, &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool IsReadablePointer(task_t task, uint64_t p)
{
    if (p < 0x100000000ull || p > 0xFFFFFFFF00000000ull)
        return false;
    uint64_t probe = 0;
    return ReadRemote(task, (mach_vm_address_t)p, &probe, sizeof(probe));
}

/*
 * The dump gives GameFacade::get_UIModelSpectator().  We do not execute that
 * method remotely.  Instead, inspect its ARM64 ADRP/LDR sequence and recover
 * the static/object pointer that the getter loads.  The candidate is accepted
 * only when +0xC4 contains a plausible remaining-player count.
 */
static bool TrySpectatorCandidate(task_t task, uint64_t candidate,
                                  uint64_t *spectatorOut, int32_t *countOut)
{
    if (!IsReadablePointer(task, candidate))
        return false;

    int32_t count = -1;
    if (!ReadRemote(task,
                    (mach_vm_address_t)(candidate + FreeFireOffsets::UIModelSpectatorRemainingPlayerCountOffset),
                    &count, sizeof(count)))
        return false;

    if (count < 0 || count > 1000)
        return false;

    if (spectatorOut) *spectatorOut = candidate;
    if (countOut) *countOut = count;
    return true;
}

static bool ResolveSpectatorFromGetter(task_t task, uint64_t unityBase,
                                       uint64_t *spectatorOut, int32_t *countOut)
{
    const uint64_t getter = unityBase + FreeFireOffsets::GameFacadeGetUIModelSpectatorRVA;
    uint32_t insn[24]{};
    if (!ReadRemote(task, (mach_vm_address_t)getter, insn, sizeof(insn)))
        return false;

    uint64_t pageBase = 0;
    int adrpReg = -1;

    for (int i = 0; i < 24; ++i) {
        const uint32_t op = insn[i];

        // ADRP Xd, <page>
        if ((op & 0x9F000000u) == 0x90000000u) {
            const int rd = (int)(op & 0x1Fu);
            int64_t imm = ((int64_t)((op >> 5) & 0x7FFFFu) << 2) |
                          (int64_t)((op >> 29) & 0x3u);
            if (imm & (1LL << 20))
                imm |= ~((1LL << 21) - 1);
            const uint64_t pc = getter + ((uint64_t)i * 4ull);
            pageBase = (pc & ~0xFFFULL) + ((int64_t)imm << 12);
            adrpReg = rd;
            continue;
        }

        if (adrpReg < 0)
            continue;

        // ADD Xd, Xn, #imm12
        if ((op & 0xFFC00000u) == 0x91000000u) {
            const int rd = (int)(op & 0x1Fu);
            const int rn = (int)((op >> 5) & 0x1Fu);
            if (rn == adrpReg) {
                const uint64_t imm = (uint64_t)((op >> 10) & 0xFFFu);
                uint64_t value = 0;
                if (ReadRemote(task, (mach_vm_address_t)(pageBase + imm), &value, sizeof(value)) &&
                    TrySpectatorCandidate(task, value, spectatorOut, countOut))
                    return true;
                (void)rd;
            }
        }

        // LDR Xt, [Xn, #imm12]
        if ((op & 0xFFC00000u) == 0xF9400000u) {
            const int rt = (int)(op & 0x1Fu);
            const int rn = (int)((op >> 5) & 0x1Fu);
            const uint64_t imm = (uint64_t)((op >> 10) & 0xFFFu) << 3;

            if (rn != adrpReg && rt != adrpReg)
                continue;

            uint64_t value = 0;
            if (!ReadRemote(task, (mach_vm_address_t)(pageBase + imm), &value, sizeof(value)))
                continue;

            if (TrySpectatorCandidate(task, value, spectatorOut, countOut))
                return true;

            // Common IL2CPP static-field indirection: the first load can be
            // the GameFacade static-fields block. The dump says the target
            // field is +0x320 inside that block.
            if (IsReadablePointer(task, value)) {
                uint64_t fieldValue = 0;
                if (ReadRemote(task, (mach_vm_address_t)(value + FreeFireOffsets::GameFacadeUIModelSpectatorStaticOffset),
                               &fieldValue, sizeof(fieldValue)) &&
                    TrySpectatorCandidate(task, fieldValue, spectatorOut, countOut))
                    return true;

                // Also tolerate an additional pointer layer used by some
                // IL2CPP builds.
                uint64_t next = 0;
                if (ReadRemote(task, (mach_vm_address_t)value, &next, sizeof(next)) &&
                    TrySpectatorCandidate(task, next, spectatorOut, countOut))
                    return true;
            }
        }
    }

    return false;
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}
}

extern "C" int ESPExternalSetMode(int mode)
{
    if (mode < 0 || mode > 1) mode = 0;
    gMode.store(mode, std::memory_order_release);
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    CloseTask();
    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
        if (out) *out = s;
        return 0;
    }
    s.processFound = 1;
    s.processPID = pid;

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        BuildFailure(s, "FALHOU: task nao abriu: %s", get_task_last_error());
        if (out) *out = s;
        return 0;
    }
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        BuildFailure(s, "FALHOU: UnityFramework nao localizado | PID %d", pid);
        if (out) *out = s;
        return 0;
    }
    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    uint32_t magic = 0;
    if (!ReadRemote(gTask, gUnityBase, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        BuildFailure(s, "FALHOU: Mach-O UnityFramework nao legivel");
        if (out) *out = s;
        return 0;
    }
    s.machoReadable = 1;
    s.rvaTestCount = 1;

    uint32_t getterProbe = 0;
    if (!ReadRemote(gTask, gUnityBase + FreeFireOffsets::GameFacadeGetUIModelSpectatorRVA,
                    &getterProbe, sizeof(getterProbe))) {
        BuildFailure(s, "FALHOU: getter UIModelSpectator nao legivel");
        if (out) *out = s;
        return 0;
    }
    s.rvaReadableCount = 1;

    uint64_t spectator = 0;
    int32_t count = -1;
    if (!ResolveSpectatorFromGetter(gTask, gUnityBase, &spectator, &count)) {
        BuildFailure(s, "PARCIAL: Unity OK, UIModelSpectator nao resolvido pelo getter");
        if (out) *out = s;
        return 0;
    }

    s.count = (uint32_t)count;
    snprintf(s.message, sizeof(s.message),
             "OK: UIModelSpectator resolvido | PID %d | JOGADORES: %d", pid, count);
    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FreeFire nao encontrado");
        if (out) *out = s;
        return 0;
    }

    // Keep the external path read-only and refresh the task/base each sample.
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        BuildFailure(s, "task nao abriu: %s", get_task_last_error());
        if (out) *out = s;
        return 0;
    }
    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        BuildFailure(s, "UnityFramework nao localizado");
        if (out) *out = s;
        return 0;
    }

    uint64_t spectator = 0;
    int32_t count = -1;
    if (!ResolveSpectatorFromGetter(gTask, gUnityBase, &spectator, &count)) {
        BuildFailure(s, "JOGADORES: -- (UIModelSpectator indisponivel)");
        if (out) *out = s;
        return 0;
    }

    s.processFound = 1;
    s.taskOpened = 1;
    s.unityFound = 1;
    s.machoReadable = 1;
    s.rvaReadableCount = 1;
    s.rvaTestCount = 1;
    s.processPID = pid;
    s.task = (uint64_t)gTask;
    s.unityBase = (uint64_t)gUnityBase;
    s.count = (uint32_t)count;
    snprintf(s.message, sizeof(s.message), "JOGADORES: %d", count);

    if (out) *out = s;
    return 1;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[768];
    ESPExternalSnapshot s{};
    ESPExternalReadSnapshot(&s);
    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "JOGADORES: --");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1024];
    ESPExternalSnapshot s{};
    const int ok = ESPExternalReadSnapshot(&s);
    if (!ok) {
        snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: contador externo");
        return text;
    }
    snprintf(text, sizeof(text),
             "EXTERNAL PLAYER COUNT\nFreeFire: OK | PID: %d\n"
             "UnityFramework: 0x%llX\nUIModelSpectator: OK | +0x%llX\n"
             "JOGADORES: %u",
             s.processPID, (unsigned long long)s.unityBase,
             (unsigned long long)FreeFireOffsets::UIModelSpectatorRemainingPlayerCountOffset,
             s.count);
    return text;
}
