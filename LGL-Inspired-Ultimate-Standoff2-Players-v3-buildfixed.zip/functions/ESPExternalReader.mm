#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <atomic>

namespace {

static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static std::atomic<int> gMode{0};

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
}

static bool ReadRemote(task_t task, mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !out || size == 0)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, address, size,
                                               (mach_vm_address_t)out, &copied);
    return kr == KERN_SUCCESS && copied == size;
}

template <typename T>
static bool ReadValue(task_t task, uint64_t address, T &out)
{
    return ReadRemote(task, (mach_vm_address_t)address, &out, sizeof(T));
}

static bool ReadRVA(task_t task, mach_vm_address_t base, uintptr_t rva)
{
    uint32_t bytes = 0;
    return ReadRemote(task, base + (mach_vm_address_t)rva, &bytes, sizeof(bytes));
}

static bool IsPlausiblePointer(uint64_t p)
{
    return p >= 0x100000000ull && p <= 0xFFFFFFFFFFFFull;
}

static bool IsPlausibleCount(uint32_t count)
{
    // Covers current BR/CS-style match sizes while rejecting random memory.
    return count <= 256u;
}

static bool ReadListCount(task_t task, uint64_t listObject, uint32_t &count)
{
    count = 0;
    if (!IsPlausiblePointer(listObject))
        return false;

    uint64_t items = 0;
    uint32_t size = 0;
    if (!ReadValue(task, listObject + 0x10, items))
        return false;
    if (!ReadValue(task, listObject + 0x18, size))
        return false;
    if (!IsPlausiblePointer(items) && size != 0)
        return false;
    if (!IsPlausibleCount(size))
        return false;

    count = size;
    return true;
}

static bool ReadDictionaryCount(task_t task, uint64_t dictionaryObject, uint32_t &count)
{
    count = 0;
    if (!IsPlausiblePointer(dictionaryObject))
        return false;

    uint64_t buckets = 0;
    uint32_t value = 0;
    if (!ReadValue(task, dictionaryObject + 0x10, buckets))
        return false;
    if (!ReadValue(task, dictionaryObject + 0x20, value))
        return false;

    if (!IsPlausiblePointer(buckets) && value != 0)
        return false;
    if (!IsPlausibleCount(value))
        return false;

    count = value;
    return true;
}

/*
 * Small AArch64 symbolic executor.
 *
 * Purpose: recover the return pointer of simple IL2CPP static getter methods
 * from the remote machine code without calling target-process code.
 *
 * Supported instructions intentionally stay conservative:
 *   ADR / ADRP, ADD/SUB immediate, LDR literal, LDR [base,#imm],
 *   MOV register and RET.
 *
 * This is used for GameFacade.get_UIModelSpectator() and CurrentMatch().
 */
struct RegState {
    uint64_t value = 0;
    bool valid = false;
};

static int64_t SignExtend(int64_t value, int bits)
{
    const int64_t shift = 64 - bits;
    return (value << shift) >> shift;
}

static bool ExecuteSimpleA64Return(task_t task,
                                   uint64_t functionAddress,
                                   uint64_t *returnValue,
                                   char *why,
                                   size_t whySize)
{
    if (returnValue) *returnValue = 0;
    if (why && whySize) why[0] = '\0';

    uint32_t code[64]{};
    if (!ReadRemote(task, (mach_vm_address_t)functionAddress, code, sizeof(code))) {
        if (why && whySize) snprintf(why, whySize, "metodo nao legivel");
        return false;
    }

    RegState r[31]{};

    for (uint32_t i = 0; i < 64; ++i) {
        const uint32_t insn = code[i];
        const uint64_t pc = functionAddress + (uint64_t)i * 4ull;

        // ADRP Xd, page
        if ((insn & 0x9F000000u) == 0x90000000u) {
            const uint32_t rd = insn & 31u;
            const int64_t immlo = (insn >> 29) & 0x3u;
            const int64_t immhi = (insn >> 5) & 0x7FFFFu;
            const int64_t imm21 = SignExtend((immhi << 2) | immlo, 21);
            const uint64_t page = pc & ~0xFFFULL;
            r[rd].value = (uint64_t)((int64_t)page + (imm21 << 12));
            r[rd].valid = true;
            continue;
        }

        // ADR Xd, #imm
        if ((insn & 0x9F000000u) == 0x10000000u) {
            const uint32_t rd = insn & 31u;
            const int64_t immlo = (insn >> 29) & 0x3u;
            const int64_t immhi = (insn >> 5) & 0x7FFFFu;
            const int64_t imm21 = SignExtend((immhi << 2) | immlo, 21);
            r[rd].value = (uint64_t)((int64_t)pc + imm21);
            r[rd].valid = true;
            continue;
        }

        // ADD Xd, Xn, #imm12[, LSL #12]
        if ((insn & 0xFF000000u) == 0x91000000u) {
            const uint32_t rd = insn & 31u;
            const uint32_t rn = (insn >> 5) & 31u;
            const uint32_t imm12 = (insn >> 10) & 0xFFFu;
            const uint32_t shift = (insn >> 22) & 1u;
            if (rd < 31u && rn < 31u && r[rn].valid && shift <= 1u) {
                r[rd].value = r[rn].value + ((uint64_t)imm12 << (shift ? 12 : 0));
                r[rd].valid = true;
                continue;
            }
        }

        // SUB Xd, Xn, #imm12[, LSL #12]
        if ((insn & 0xFF000000u) == 0xD1000000u) {
            const uint32_t rd = insn & 31u;
            const uint32_t rn = (insn >> 5) & 31u;
            const uint32_t imm12 = (insn >> 10) & 0xFFFu;
            const uint32_t shift = (insn >> 22) & 1u;
            if (rd < 31u && rn < 31u && r[rn].valid && shift <= 1u) {
                r[rd].value = r[rn].value - ((uint64_t)imm12 << (shift ? 12 : 0));
                r[rd].valid = true;
                continue;
            }
        }

        // LDR Xd, [Xn, #imm12]
        if ((insn & 0xFFC00000u) == 0xF9400000u) {
            const uint32_t rt = insn & 31u;
            const uint32_t rn = (insn >> 5) & 31u;
            const uint64_t imm = ((uint64_t)((insn >> 10) & 0xFFFu)) << 3;
            if (rt < 31u && rn < 31u && r[rn].valid) {
                uint64_t value = 0;
                const uint64_t address = r[rn].value + imm;
                if (ReadValue(task, address, value)) {
                    r[rt].value = value;
                    r[rt].valid = true;
                } else {
                    r[rt].valid = false;
                }
                continue;
            }
        }

        // LDR Wd, [Xn, #imm12]
        if ((insn & 0xFFC00000u) == 0xB9400000u) {
            const uint32_t rt = insn & 31u;
            const uint32_t rn = (insn >> 5) & 31u;
            const uint64_t imm = ((uint64_t)((insn >> 10) & 0xFFFu)) << 2;
            if (rt < 31u && rn < 31u && r[rn].valid) {
                uint32_t value = 0;
                const uint64_t address = r[rn].value + imm;
                if (ReadValue(task, address, value)) {
                    r[rt].value = value;
                    r[rt].valid = true;
                } else {
                    r[rt].valid = false;
                }
                continue;
            }
        }

        // LDR Xt, literal
        if ((insn & 0xFF000000u) == 0x58000000u) {
            const uint32_t rt = insn & 31u;
            const int64_t imm19 = SignExtend((int64_t)((insn >> 5) & 0x7FFFFu), 19);
            const uint64_t address = (uint64_t)((int64_t)pc + (imm19 << 2));
            if (rt < 31u) {
                uint64_t value = 0;
                if (ReadValue(task, address, value)) {
                    r[rt].value = value;
                    r[rt].valid = true;
                } else {
                    r[rt].valid = false;
                }
                continue;
            }
        }

        // MOV Xd, Xn (ORR alias)
        if ((insn & 0xFFE0FC1Fu) == 0xAA0003E0u) {
            const uint32_t rd = insn & 31u;
            const uint32_t rn = (insn >> 16) & 31u;
            if (rd < 31u && rn < 31u) {
                r[rd] = r[rn];
                continue;
            }
        }

        // RET Xn (normally X30). The function return value itself is X0.
        if ((insn & 0xFFFFFC1Fu) == 0xD65F0000u) {
            const uint32_t rn = (insn >> 5) & 31u;
            if (r[0].valid) {
                if (returnValue) *returnValue = r[0].value;
                if (why && whySize) snprintf(why, whySize, "ret x%u / x0", rn);
                return IsPlausiblePointer(r[0].value);
            }
            if (rn < 31u && r[rn].valid) {
                if (returnValue) *returnValue = r[rn].value;
                if (why && whySize) snprintf(why, whySize, "ret x%u fallback", rn);
                return IsPlausiblePointer(r[rn].value);
            }
            if (why && whySize) snprintf(why, whySize, "ret sem valor");
            return false;
        }

        // PAC-authenticated returns used by arm64e code.
        if (insn == 0xD65F0BFFu || insn == 0xD65F0FFFu) {
            if (r[0].valid) {
                if (returnValue) *returnValue = r[0].value;
                if (why && whySize) snprintf(why, whySize, "reta*/retab x0");
                return IsPlausiblePointer(r[0].value);
            }
            if (why && whySize) snprintf(why, whySize, "reta*/retab sem valor");
            return false;
        }

        /*
         * A BL/BR/B/conditional branch means the conservative executor cannot
         * safely continue through another function body.
         */
        if ((insn & 0xFC000000u) == 0x94000000u ||  // BL
            (insn & 0x7C000000u) == 0x14000000u ||  // B
            (insn & 0xFFFFFC1Fu) == 0xD61F0000u ||  // BR
            (insn & 0xFF000010u) == 0x54000000u) {  // B.cond
            if (why && whySize) snprintf(why, whySize, "metodo possui branch/call");
            return false;
        }
    }

    if (why && whySize) snprintf(why, whySize, "ret nao encontrado");
    return false;
}

static bool InferContainerCountFromMethod(task_t task,
                                           uint64_t functionAddress,
                                           uint32_t *sourceOffset,
                                           uint32_t *containerKind,
                                           char *why,
                                           size_t whySize)
{
    if (sourceOffset) *sourceOffset = 0;
    if (containerKind) *containerKind = 0;
    if (why && whySize) why[0] = '\0';

    uint32_t code[64]{};
    if (!ReadRemote(task, (mach_vm_address_t)functionAddress, code, sizeof(code))) {
        if (why && whySize) snprintf(why, whySize, "codigo nao legivel");
        return false;
    }

    // Patterns sought:
    //   LDR Xn, [X0, #field]
    //   LDR W0, [Xn, #0x18]   => List<T>._size
    //   LDR W0, [Xn, #0x20]   => Dictionary<,>._count
    //
    // or:
    //   LDR W0, [X0, #field]  => direct int field
    for (uint32_t i = 0; i < 60; ++i) {
        const uint32_t a = code[i];
        const uint32_t b = code[i + 1];

        // direct W0 field load
        if ((a & 0xFFC0001Fu) == 0xB9400000u) {
            const uint32_t rn = (a >> 5) & 31u;
            const uint32_t rt = a & 31u;
            if (rn == 0u && rt == 0u) {
                const uint32_t field = ((a >> 10) & 0xFFFu) << 2;
                if ((b & 0xFFFFFC1Fu) == 0xD65F0000u) {
                    if (sourceOffset) *sourceOffset = field;
                    if (containerKind) *containerKind = 3;
                    if (why && whySize) snprintf(why, whySize, "direto int +0x%X", field);
                    return true;
                }
            }
        }

        // LDR Xn,[X0,#field]
        if ((a & 0xFFC00000u) == 0xF9400000u) {
            const uint32_t rn = (a >> 5) & 31u;
            const uint32_t rt = a & 31u;
            if (rn != 0u && rt < 31u) {
                const uint32_t field = ((a >> 10) & 0xFFFu) << 3;

                if ((b & 0xFFC0001Fu) == 0xB9400000u) {
                    const uint32_t bRn = (b >> 5) & 31u;
                    const uint32_t bRt = b & 31u;
                    const uint32_t bOff = ((b >> 10) & 0xFFFu) << 2;

                    if (bRn == rt && bRt == 0u && bOff == 0x18u) {
                        if (sourceOffset) *sourceOffset = field;
                        if (containerKind) *containerKind = 1;
                        if (why && whySize) snprintf(why, whySize, "List.Count via +0x%X", field);
                        return true;
                    }

                    if (bRn == rt && bRt == 0u && bOff == 0x20u) {
                        if (sourceOffset) *sourceOffset = field;
                        if (containerKind) *containerKind = 2;
                        if (why && whySize) snprintf(why, whySize, "Dictionary.Count via +0x%X", field);
                        return true;
                    }
                }
            }
        }
    }

    if (why && whySize) snprintf(why, whySize, "padrao de Count nao identificado");
    return false;
}

static bool ResolveCurrentMatch(task_t task, uint64_t base, uint64_t &match, char *why, size_t whySize)
{
    match = 0;
    return ExecuteSimpleA64Return(task,
                                  base + FreeFireOffsets::GameFacadeCurrentMatchRVA,
                                  &match, why, whySize);
}

static bool ResolveUISpectator(task_t task, uint64_t base, uint64_t &spectator, char *why, size_t whySize)
{
    spectator = 0;
    return ExecuteSimpleA64Return(task,
                                  base + FreeFireOffsets::GameFacadeGetUISpectatorRVA,
                                  &spectator, why, whySize);
}

static void ReadPlayerCollectionDiagnostics(task_t task,
                                            uint64_t match,
                                            ESPExternalSnapshot &s)
{
    uint64_t p = 0;
    uint32_t count = 0;

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerList0Offset, p))
        (void)ReadListCount(task, p, s.countCandidate158);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerList1Offset, p))
        (void)ReadListCount(task, p, s.countCandidate160);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerListPrivateOffset, p))
        (void)ReadListCount(task, p, s.countCandidate570);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerDictionary0Offset, p))
        (void)ReadDictionaryCount(task, p, s.countCandidate128);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerDictionary1Offset, p))
        (void)ReadDictionaryCount(task, p, s.countCandidate130);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerDictionary2Offset, p))
        (void)ReadDictionaryCount(task, p, s.countCandidate140);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerDictionaryByteOffset, p))
        (void)ReadDictionaryCount(task, p, s.countCandidate148);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerDictionary3Offset, p))
        (void)ReadDictionaryCount(task, p, s.countCandidate150);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerDictionary5Offset, p))
        (void)ReadDictionaryCount(task, p, s.countCandidate5D8);

    if (ReadValue(task, match + FreeFireOffsets::JMAGPlayerDictionary6Offset, p))
        (void)ReadDictionaryCount(task, p, s.countCandidate5E0);

    (void)count;
}

static bool ReadUISpectatorPlayerCount(task_t task,
                                       uint64_t base,
                                       ESPExternalSnapshot &s,
                                       char *detail,
                                       size_t detailSize)
{
    s.playerCountValid = 0;
    s.playerCountSourceKind = 0;
    s.playerCountSourceOffset = 0;
    s.count = 0;
    s.currentMatch = 0;
    s.localPlayer = 0;

    uint64_t spectator = 0;
    char resolveWhy[128]{};

    if (ResolveUISpectator(task, base, spectator, resolveWhy, sizeof(resolveWhy))) {
        uint64_t playerDic = 0;
        uint32_t count = 0;

        if (ReadValue(task, spectator + FreeFireOffsets::UIModelSpectatorPlayerDicOffset, playerDic) &&
            ReadDictionaryCount(task, playerDic, count)) {
            s.playerCountValid = 1;
            s.playerCountSourceKind = 2; // UIModelSpectator.m_PlayerDic
            s.playerCountSourceOffset = FreeFireOffsets::UIModelSpectatorPlayerDicOffset;
            s.count = count;

            if (detail && detailSize) {
                snprintf(detail, detailSize,
                         "UIModelSpectator +0x30 -> Dictionary.Count +0x20");
            }
            return true;
        }
    }

    // Fallback: resolve the live match and read its current Player collections.
    uint64_t match = 0;
    char matchWhy[128]{};
    if (ResolveCurrentMatch(task, base, match, matchWhy, sizeof(match))) {
        s.currentMatch = match;

        uint64_t local = 0;
        if (ReadValue(task, match + FreeFireOffsets::JMAGLocalPlayerFieldOffset, local) &&
            IsPlausiblePointer(local)) {
            s.localPlayer = local;
        }

        ReadPlayerCollectionDiagnostics(task, match, s);

        /*
         * The JMAG list/dictionary fields are dump-confirmed storage types.
         * They are fallback diagnostics, not silently relabeled as the
         * semantic GetPlayerCount method.
         */
        if (s.countCandidate158 <= 256u && s.countCandidate158 > 0u) {
            s.playerCountValid = 1;
            s.playerCountSourceKind = 11;
            s.playerCountSourceOffset = FreeFireOffsets::JMAGPlayerList0Offset;
            s.count = s.countCandidate158;
            if (detail && detailSize)
                snprintf(detail, detailSize, "fallback JMAG List<Player> +0x158");
            return true;
        }

        if (s.countCandidate160 <= 256u && s.countCandidate160 > 0u) {
            s.playerCountValid = 1;
            s.playerCountSourceKind = 12;
            s.playerCountSourceOffset = FreeFireOffsets::JMAGPlayerList1Offset;
            s.count = s.countCandidate160;
            if (detail && detailSize)
                snprintf(detail, detailSize, "fallback JMAG List<Player> +0x160");
            return true;
        }

        if (detail && detailSize)
            snprintf(detail, detailSize, "JMAG resolvido; nenhuma colecao retornou Count plausivel");
        return false;
    }

    if (detail && detailSize)
        snprintf(detail, detailSize, "UIModelSpectator/CurrentMatch nao resolvidos");
    return false;
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}

} // namespace

extern "C" int ESPExternalSetMode(int mode)
{
    if (mode < 0 || mode > 1) mode = 0;
    gMode.store(mode, std::memory_order_release);
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    CloseTask();

    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
        if (out) *out = s;
        return 0;
    }

    s.processFound = 1;
    s.processPID = pid;

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        BuildFailure(s, "FALHOU: FreeFire PID %d encontrado; task nao abriu: %s",
                     pid, get_task_last_error());
        if (out) *out = s;
        return 0;
    }
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        BuildFailure(s, "FALHOU: task OK, UnityFramework nao localizado | PID %d", pid);
        if (out) *out = s;
        return 0;
    }
    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    uint32_t magic = 0;
    if (!ReadRemote(gTask, gUnityBase, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        BuildFailure(s, "FALHOU: UnityFramework 0x%llX, cabecalho Mach-O nao legivel",
                     (unsigned long long)gUnityBase);
        if (out) *out = s;
        return 0;
    }
    s.machoReadable = 1;

    const uintptr_t rvas[] = {
        FreeFireOffsets::GameFacadeCurrentMatchRVA,
        FreeFireOffsets::GameFacadeGetUISpectatorRVA,
        FreeFireOffsets::UIModelSpectatorGetPlayerDicRVA,
        FreeFireOffsets::UIModelSpectatorGetPlayerCountRVA,
        FreeFireOffsets::JMAGGetPlayerDictionaryRVA,
        FreeFireOffsets::JMAGCountLikeMethodRVA,
        FreeFireOffsets::GetPlayerByTeamIdAndPlayerIndexStrictRVA,
        FreeFireOffsets::GetLivePlayerByTeamIdAndPlayerIndexRVA,
        FreeFireOffsets::PlayerGetTransformNodeRVA,
        FreeFireOffsets::TransformGetPositionRVA,
        FreeFireOffsets::CameraGetMainRVA,
        FreeFireOffsets::CameraWorldToScreenPointRVA,
        FreeFireOffsets::AnimatorGetBoneTransformRVA,
        FreeFireOffsets::AnimatorGetBoneTransformInternalRVA,
    };

    s.rvaTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
    for (uint32_t i = 0; i < s.rvaTestCount; ++i) {
        if (ReadRVA(gTask, gUnityBase, rvas[i]))
            ++s.rvaReadableCount;
    }

    if (s.rvaReadableCount != s.rvaTestCount) {
        BuildFailure(s,
                     "PARCIAL: FreeFire OK | PID %d | task OK | Unity 0x%llX | Mach-O OK | RVAs legiveis %u/%u",
                     pid, (unsigned long long)gUnityBase,
                     s.rvaReadableCount, s.rvaTestCount);
        if (out) *out = s;
        return 0;
    }

    snprintf(s.message, sizeof(s.message),
             "OK: acesso externo | PID %d | Unity 0x%llX | RVAs %u/%u",
             pid,
             (unsigned long long)gUnityBase,
             s.rvaReadableCount,
             s.rvaTestCount);

    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    if (!ESPExternalVerify(&s)) {
        if (out) *out = s;
        return 0;
    }

    char countDetail[160]{};
    const bool gotCount = ReadUISpectatorPlayerCount(gTask, gUnityBase, s,
                                                       countDetail, sizeof(countDetail));

    uint32_t inferredOffset = 0;
    uint32_t inferredKind = 0;
    char inferredWhy[128]{};
    const bool methodShape =
        InferContainerCountFromMethod(gTask,
                                      gUnityBase + FreeFireOffsets::UIModelSpectatorGetPlayerCountRVA,
                                      &inferredOffset,
                                      &inferredKind,
                                      inferredWhy,
                                      sizeof(inferredWhy));

    if (gotCount) {
        if (methodShape && inferredKind == 2) {
            snprintf(s.message, sizeof(s.message),
                     "PLAYER COUNT OK | %u jogadores | UIModelSpectator +0x30 -> Dictionary.Count +0x20 | GetPlayerCount shape: %s",
                     s.count, inferredWhy);
        } else {
            snprintf(s.message, sizeof(s.message),
                     "PLAYER COUNT OK | %u jogadores | fonte: %s",
                     s.count, countDetail[0] ? countDetail : "externa");
        }
    } else {
        snprintf(s.message, sizeof(s.message),
                 "COUNT INDISPONIVEL | CurrentMatch/UISpectator nao entregaram uma colecao valida | GetPlayerCount shape: %s",
                 methodShape ? inferredWhy : "nao identificado");
    }

    if (out) *out = s;
    return 1;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[768];
    ESPExternalSnapshot s{};
    ESPExternalReadSnapshot(&s);
    snprintf(text, sizeof(text), "%s",
             s.message[0] ? s.message : "FALHOU: sem diagnostico");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1536];
    ESPExternalSnapshot s{};
    const int ok = ESPExternalReadSnapshot(&s);

    if (!ok) {
        snprintf(text, sizeof(text), "%s",
                 s.message[0] ? s.message : "FALHOU: diagnostico externo");
        return text;
    }

    snprintf(text, sizeof(text),
             "EXTERNAL CHECK\n"
             "FreeFire: OK | PID: %d\n"
             "Unity: 0x%llX | RVAs: %u/%u\n"
             "JOGADORES: %s%u\n"
             "FONTE: %s",
             s.processPID,
             (unsigned long long)s.unityBase,
             s.rvaReadableCount,
             s.rvaTestCount,
             s.playerCountValid ? "" : "-- ",
             s.playerCountValid ? s.count : 0u,
             s.playerCountSourceKind == 2 ? "UIModelSpectator +0x30" :
             s.playerCountSourceKind == 11 ? "JMAG List<Player> +0x158 (fallback)" :
             s.playerCountSourceKind == 12 ? "JMAG List<Player> +0x160 (fallback)" :
             "nao resolvida");

    return text;
}
