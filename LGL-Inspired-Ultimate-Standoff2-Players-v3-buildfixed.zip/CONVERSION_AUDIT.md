# CONVERSION_AUDIT.md

## Confirmado nesta auditoria
- Aplicação continua standalone.
- Removido o caminho de execução remota dentro do target.
- Removidos `vm_write`, `vm_allocate`/`vm_protect` no target e `thread_create`/`thread_set_state` no target.
- Reader publica snapshot e agenda refresh em background.
- Diagnóstico separa processo, task, módulo, leitura, entidades, câmera e renderer.
- Makefile não instala/copia launch daemon.
- Entitlements reduzidos a `get-task-allow` e `task_for_pid-allow`.
- `Offset_AUDIT.md` marca os RVAs existentes como NÃO CONFIRMADO porque a dump não está presente neste ZIP.

## Não confirmado
- Enumeração real de jogadores.
- Cadeia de campos/objetos Unity.
- Ponteiro de câmera e matriz.
- WorldToScreen real.
- Funcionamento de `task_for_pid` no dispositivo alvo.

## Build
A tentativa de `make clean && make package FINALPACKAGE=1` neste ambiente falhou antes de compilar porque `$(THEOS)/makefiles/common.mk` não existe no ambiente. Portanto não há alegação de IPA compilado.
