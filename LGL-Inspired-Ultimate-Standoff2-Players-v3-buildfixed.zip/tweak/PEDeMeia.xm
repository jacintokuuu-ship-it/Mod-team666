#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <mach-o/dyld.h>
#import <dlfcn.h>
#import <dispatch/dispatch.h>
#import <os/log.h>
#include <stdint.h>

#import "../functions/Offsets.h"

/*
 * Free Fire / PE de meia
 *
 * This file is loaded IN the FreeFire process by the jailbreak tweak loader.
 * It does not use the external task_for_pid reader from the HUD application.
 *
 * Publicly documented backend:
 *   MSHookFunction(void *symbol, void *replace, void **result)
 *
 * ElleKit provides a Substrate-compatible hook API on arm64/iOS 15+.
 */

typedef void (*MSHookFunctionFn)(void *, void *, void **);

static MSHookFunctionFn gMSHookFunction = nullptr;
static bool gHookInstalled = false;
static bool gEnabled = false;

static const CFStringRef kPEDeMeiaToggleNotification =
    CFSTR("com.lgl.pedemeia.toggle");

typedef void *(*AnimatorGetBoneTransformFn)(
    void *self,
    int humanBoneId,
    const void *methodInfo
);

static AnimatorGetBoneTransformFn gOriginalAnimatorGetBoneTransform = nullptr;

static void *HookedAnimatorGetBoneTransform(void *self, int humanBoneId, const void *methodInfo);

static void PEDMLog(NSString *format, ...)
{
    va_list args;
    va_start(args, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    NSLog(@"[PEDeMeia] %@", message);
}

static void *FindImageBase(const char *needle)
{
    if (!needle) return nullptr;

    const uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; i++) {
        const char *name = _dyld_get_image_name(i);
        if (!name) continue;

        if (strstr(name, needle)) {
            const struct mach_header *header = _dyld_get_image_header(i);
            return (void *)header;
        }
    }

    return nullptr;
}

static void HookAnimatorBoneTransform(void)
{
    if (gHookInstalled) return;

    if (!gMSHookFunction) {
        gMSHookFunction = (MSHookFunctionFn)dlsym(RTLD_DEFAULT, "MSHookFunction");
    }

    if (!gMSHookFunction) {
        PEDMLog(@"MSHookFunction não está disponível no processo.");
        return;
    }

    void *base = FindImageBase("UnityFramework");
    if (!base) {
        PEDMLog(@"UnityFramework ainda não carregou.");
        return;
    }

    uintptr_t targetAddress =
        (uintptr_t)base + FreeFireOffsets::AnimatorGetBoneTransformRVA;

    /*
     * IL2CPP instance-method ABI used here:
     *   self, enum/int argument, MethodInfo*
     *
     * The supplied dump identifies the exact method/RVA, but does not expose
     * the generated native prototype. The third argument is therefore kept
     * explicitly as an opaque pointer rather than guessed away.
     */
    void *original = nullptr;
    gMSHookFunction(
        (void *)targetAddress,
        (void *)&HookedAnimatorGetBoneTransform,
        &original
    );

    if (!original) {
        PEDMLog(@"Hook falhou em %p.", (void *)targetAddress);
        return;
    }

    gOriginalAnimatorGetBoneTransform =
        (AnimatorGetBoneTransformFn)original;

    gHookInstalled = true;

    PEDMLog(@"Hook instalado: UnityFramework + 0x%08llX",
            (unsigned long long)FreeFireOffsets::AnimatorGetBoneTransformRVA);
}

static void *HookedAnimatorGetBoneTransform(
    void *self,
    int humanBoneId,
    const void *methodInfo)
{
    int requestedBone = humanBoneId;

    if (gEnabled) {
        if (requestedBone == FreeFireOffsets::HumanBoneHips) {
            requestedBone = FreeFireOffsets::HumanBoneHead;
        } else if (requestedBone == FreeFireOffsets::HumanBoneChest) {
            requestedBone = FreeFireOffsets::HumanBoneNeck;
        }
    }

    return gOriginalAnimatorGetBoneTransform(
        self,
        requestedBone,
        methodInfo
    );
}

static void TogglePEDeMeia(
    CFNotificationCenterRef center,
    void *observer,
    CFStringRef name,
    const void *object,
    CFDictionaryRef userInfo)
{
    (void)center;
    (void)observer;
    (void)name;
    (void)object;
    (void)userInfo;

    gEnabled = !gEnabled;
    PEDMLog(@"PE de meia: %@", gEnabled ? @"ATIVADO" : @"DESATIVADO");
}

static void TryInstallHook(void)
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (!gMSHookFunction) {
            gMSHookFunction =
                (MSHookFunctionFn)dlsym(RTLD_DEFAULT, "MSHookFunction");
        }
    });

    if (!gHookInstalled) {
        HookAnimatorBoneTransform();
    }
}

static void ImageAdded(
    const struct mach_header *mh,
    intptr_t vmaddr_slide)
{
    (void)mh;
    (void)vmaddr_slide;
    TryInstallHook();
}

__attribute__((constructor))
static void PEDeMeiaInit(void)
{
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(),
        nullptr,
        TogglePEDeMeia,
        kPEDeMeiaToggleNotification,
        nullptr,
        CFNotificationSuspensionBehaviorDeliverImmediately
    );

    // UnityFramework can be loaded after the tweak itself.
    _dyld_register_func_for_add_image(ImageAdded);

    // Also attempt immediately in case it is already present.
    dispatch_after(
        dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
        dispatch_get_main_queue(),
        ^{
            TryInstallHook();
        }
    );
}
