#import <Foundation/Foundation.h>
#import <CoreFoundation/CoreFoundation.h>
#import <mach-o/dyld.h>
#import <dlfcn.h>
#import <dispatch/dispatch.h>
#import <os/log.h>
#import <fcntl.h>
#import <sys/mman.h>
#import <sys/stat.h>
#import <unistd.h>
#import <pthread.h>
#include <stdint.h>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <unordered_map>
#include <algorithm>
#include <atomic>
#include <cerrno>
#include <ctime>

#import "../functions/Offsets.h"
#import "../functions/ESPProbeShared.h"
#import "../esp/helpers/Vector3.h"

/*
 * Free Fire / external ESP probe
 *
 * The renderer remains in the Excalibur HUD process. This tweak is only the
 * in-process telemetry bridge required to exercise the exact methods supplied
 * in the dump without falling back to the discarded PlayerManager offsets.
 *
 * Three test modes compare these confirmed Transform accessors:
 *   1) TransformNode.transform field          +0x10
 *   2) TransformNode::get_transform            0x6B4964C
 *   3) BFOONIGAIFK::get_transform              0x581FB80
 *
 * Player::GetTransformNode 0x5735538 is the common association point.
 * Camera::get_main 0x8CFF0B4 and Transform::get_position 0x8D6C1EC feed the
 * final projection chain. Camera::WorldToScreenPoint 0x8CFE9C0 is called on
 * the real in-process camera object, so no stale external camera matrix is used.
 */

typedef void (*MSHookFunctionFn)(void *, void *, void **);
static MSHookFunctionFn gMSHookFunction = nullptr;

static const CFStringRef kMode0 = CFSTR("com.xternalz.esp.mode.0");
static const CFStringRef kMode1 = CFSTR("com.xternalz.esp.mode.1");
static const CFStringRef kMode2 = CFSTR("com.xternalz.esp.mode.2");
static const CFStringRef kMode3 = CFSTR("com.xternalz.esp.mode.3");


static int gESPFD = -1;
static ESPProbeSnapshot *gESPSnapshot = nullptr;
static std::mutex gESPStateMutex;
static std::atomic<int> gESPMode{0};
static uint64_t gESPFrame = 0;
static uint64_t gNodeHits = 0;
static uint64_t gPosHits = 0;
static uint64_t gCameraHits = 0;
static uint64_t gProjectionHits = 0;
static uint64_t gGetterHits[3] = {0, 0, 0};
static uint32_t gHookMask = 0;
static bool gESPProbeHooksInstalled = false;
static std::atomic<uint32_t> gProbeStage{ESP_PROBE_STAGE_UNINITIALIZED};
static std::atomic<uint32_t> gProbeError{0};
static std::atomic<uint32_t> gHookAttempts{0};
static std::atomic<uint64_t> gUnityBase{0};
static void *gCamera = nullptr;
static const void *gWorldToScreenMethodInfo = nullptr;

static int gIPCListenFD = -1;
static pthread_t gIPCThread{};
static std::atomic<bool> gIPCStarted{false};

static bool SendFull(int fd, const void *buf, size_t len)
{
    const uint8_t *p = (const uint8_t *)buf;
    while (len) {
        ssize_t n = send(fd, p, len, 0);
        if (n <= 0) return false;
        p += (size_t)n;
        len -= (size_t)n;
    }
    return true;
}

static bool CopyLatestSnapshot(ESPProbeSnapshot *out)
{
    if (!out || !gESPSnapshot) return false;
    std::lock_guard<std::mutex> lock(gESPStateMutex);
    std::memcpy(out, gESPSnapshot, sizeof(*out));
    if (out->magic != ESP_PROBE_MAGIC || out->version != ESP_PROBE_VERSION)
        return false;
    return !(out->sequence & 1u);
}

static void *IPCServerMain(void *)
{
    int serverFD = socket(AF_INET, SOCK_STREAM, 0);
    if (serverFD < 0) {
        Log(@"IPC socket() falhou: %d", errno);
        return nullptr;
    }

    int one = 1;
    setsockopt(serverFD, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));

    sockaddr_in addr{};
    addr.sin_len = sizeof(addr);
    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)ESP_PROBE_IPC_PORT);
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);

    if (bind(serverFD, (sockaddr *)&addr, sizeof(addr)) != 0) {
        Log(@"IPC bind 127.0.0.1:%u falhou: %d", (unsigned)ESP_PROBE_IPC_PORT, errno);
        close(serverFD);
        return nullptr;
    }

    if (listen(serverFD, 2) != 0) {
        Log(@"IPC listen falhou: %d", errno);
        close(serverFD);
        return nullptr;
    }

    gIPCListenFD = serverFD;
    Log(@"IPC TCP pronto em 127.0.0.1:%u", (unsigned)ESP_PROBE_IPC_PORT);

    for (;;) {
        int clientFD = accept(serverFD, nullptr, nullptr);
        if (clientFD < 0) {
            if (errno == EINTR) continue;
            Log(@"IPC accept falhou: %d", errno);
            continue;
        }

        for (;;) {
            ESPProbeSnapshot snap{};
            if (!CopyLatestSnapshot(&snap)) break;

            ESPProbeIPCHeader hdr{};
            hdr.magic = ESP_PROBE_IPC_MAGIC;
            hdr.version = ESP_PROBE_IPC_VERSION;
            hdr.payloadSize = sizeof(ESPProbeSnapshot);
            hdr.sequence = snap.sequence;

            if (!SendFull(clientFD, &hdr, sizeof(hdr)) ||
                !SendFull(clientFD, &snap, sizeof(snap))) {
                break;
            }

            usleep(50000); // 20 Hz diagnostics/data stream
        }

        close(clientFD);
    }

    return nullptr;
}

static void StartIPCServer(void)
{
    bool expected = false;
    if (!gIPCStarted.compare_exchange_strong(expected, true)) return;
    if (pthread_create(&gIPCThread, nullptr, IPCServerMain, nullptr) != 0) {
        gIPCStarted.store(false, std::memory_order_release);
        Log(@"IPC pthread_create falhou: %d", errno);
    }
    else {
        pthread_detach(gIPCThread);
    }
}

struct NodeRecord {
    void *player = nullptr;
    uint64_t lastSeen = 0;
};

struct TargetRecord {
    void *player = nullptr;
    void *transform = nullptr;
    uint32_t sourceMode = 0;
    float x = 0;
    float y = 0;
    float z = 0;
    float depth = 0;
    uint64_t lastSeen = 0;
};

static std::unordered_map<void *, NodeRecord> gNodeToPlayer;
static std::unordered_map<void *, TargetRecord> gTransformToTarget;

static uint64_t MonotonicNanos(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static void Log(NSString *format, ...)
{
    va_list args;
    va_start(args, format);
    NSString *message = [[NSString alloc] initWithFormat:format arguments:args];
    va_end(args);
    NSLog(@"[ESPProbe] %@", message);
}

static void SetDiagnosticStage(uint32_t stage, uint32_t errorCode = 0)
{
    gProbeStage.store(stage, std::memory_order_release);
    if (errorCode) gProbeError.store(errorCode, std::memory_order_release);
    Log(@"Stage=%u error=%u", stage, errorCode);
}

static void EnsureShared(void)
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        gESPFD = shm_open(ESP_PROBE_SHM_NAME, O_CREAT | O_RDWR, 0600);
        if (gESPFD < 0) {
            Log(@"shm_open falhou: %d", errno);
            return;
        }

        if (ftruncate(gESPFD, (off_t)sizeof(ESPProbeSnapshot)) != 0) {
            Log(@"ftruncate falhou: %d", errno);
            close(gESPFD);
            gESPFD = -1;
            return;
        }

        void *mapped = mmap(nullptr,
                            sizeof(ESPProbeSnapshot),
                            PROT_READ | PROT_WRITE,
                            MAP_SHARED,
                            gESPFD,
                            0);
        if (mapped == MAP_FAILED) {
            Log(@"mmap falhou: %d", errno);
            close(gESPFD);
            gESPFD = -1;
            return;
        }

        gESPSnapshot = (ESPProbeSnapshot *)mapped;
        std::memset(gESPSnapshot, 0, sizeof(*gESPSnapshot));
        gESPSnapshot->magic = ESP_PROBE_MAGIC;
        gESPSnapshot->version = ESP_PROBE_VERSION;
        SetDiagnosticStage(ESP_PROBE_STAGE_SHARED_READY);
    });
}

static void PublishSnapshotLocked(uint64_t now)
{
    if (!gESPSnapshot) return;

    /* Sequence-lock: odd = writer in progress, even = stable. */
    uint32_t seq = gESPSnapshot->sequence;
    if (seq & 1u) seq++;
    gESPSnapshot->sequence = seq + 1u;

    gESPSnapshot->magic = ESP_PROBE_MAGIC;
    gESPSnapshot->version = ESP_PROBE_VERSION;
    gESPSnapshot->activeMode = (uint32_t)gESPMode.load(std::memory_order_relaxed);
    gESPSnapshot->hookMask = gHookMask;
    gESPSnapshot->transformNodeHits = (uint32_t)std::min<uint64_t>(gNodeHits, 0xFFFFFFFFULL);
    gESPSnapshot->transformGetterHits[0] = (uint32_t)std::min<uint64_t>(gGetterHits[0], 0xFFFFFFFFULL);
    gESPSnapshot->transformGetterHits[1] = (uint32_t)std::min<uint64_t>(gGetterHits[1], 0xFFFFFFFFULL);
    gESPSnapshot->transformGetterHits[2] = (uint32_t)std::min<uint64_t>(gGetterHits[2], 0xFFFFFFFFULL);
    gESPSnapshot->positionHits = (uint32_t)std::min<uint64_t>(gPosHits, 0xFFFFFFFFULL);
    gESPSnapshot->cameraHits = (uint32_t)std::min<uint64_t>(gCameraHits, 0xFFFFFFFFULL);
    gESPSnapshot->projectionHits = (uint32_t)std::min<uint64_t>(gProjectionHits, 0xFFFFFFFFULL);
    gESPSnapshot->frame = gESPFrame;
    gESPSnapshot->updatedNanos = now;
    gESPSnapshot->stage = gProbeStage.load(std::memory_order_acquire);
    gESPSnapshot->errorCode = gProbeError.load(std::memory_order_acquire);
    gESPSnapshot->hookAttempts = gHookAttempts.load(std::memory_order_acquire);
    gESPSnapshot->processPID = (uint32_t)getpid();
    gESPSnapshot->unityBase = gUnityBase.load(std::memory_order_acquire);
    gESPSnapshot->lastStageNanos = now;

    uint32_t count = 0;
    for (auto it = gTransformToTarget.begin(); it != gTransformToTarget.end();) {
        const TargetRecord &r = it->second;
        if (!r.player || !r.transform || r.sourceMode != gESPMode.load() || now - r.lastSeen > 1200000000ULL) {
            it = gTransformToTarget.erase(it);
            continue;
        }

        if (count >= ESP_PROBE_MAX_TARGETS) break;
        ESPProbeTarget &dst = gESPSnapshot->targets[count++];
        dst.player = (uint64_t)(uintptr_t)r.player;
        dst.x = r.x;
        dst.y = r.y;
        dst.z = r.z;
        dst.depth = r.depth;
        dst.sourceMode = r.sourceMode;
        dst.valid = (std::isfinite(r.x) && std::isfinite(r.y) && std::isfinite(r.depth)) ? 1u : 0u;
        dst.lastUpdateNanos = r.lastSeen;
        ++it;
    }

    for (uint32_t i = count; i < ESP_PROBE_MAX_TARGETS; ++i) {
        std::memset(&gESPSnapshot->targets[i], 0, sizeof(gESPSnapshot->targets[i]));
    }
    gESPSnapshot->count = count;
    gESPSnapshot->sequence = seq + 2u;
}

static void SetMode(int mode)
{
    if (mode < 0 || mode > 3) mode = 0;
    gESPMode.store(mode, std::memory_order_release);
    std::lock_guard<std::mutex> lock(gESPStateMutex);
    gNodeToPlayer.clear();
    gTransformToTarget.clear();
    EnsureShared();
    if (gESPSnapshot) {
        gESPFrame = 0;
        gNodeHits = 0;
        gPosHits = 0;
        gProjectionHits = 0;
        gGetterHits[0] = gGetterHits[1] = gGetterHits[2] = 0;
        PublishSnapshotLocked(MonotonicNanos());
    }
}

static void ModeNotification(
    CFNotificationCenterRef center,
    void *observer,
    CFStringRef name,
    const void *object,
    CFDictionaryRef userInfo)
{
    (void)center; (void)observer; (void)object; (void)userInfo;
    if (name && CFEqual(name, kMode1)) SetMode(1);
    else if (name && CFEqual(name, kMode2)) SetMode(2);
    else if (name && CFEqual(name, kMode3)) SetMode(3);
    else if (name && CFEqual(name, kMode0)) SetMode(0);
}

#pragma mark - ESP hooks

/* IL2CPP reference returns are represented here as opaque pointers. */
typedef void *(*PlayerGetTransformNodeFn)(void *self, void *name, const void *methodInfo);
typedef void *(*TransformGetterFn)(void *self, const void *methodInfo);
typedef Vector3 (*TransformGetPositionFn)(void *self, const void *methodInfo);
typedef void *(*CameraGetMainFn)(const void *methodInfo);
typedef Vector3 (*CameraWorldToScreenPointFn)(void *self, Vector3 position, const void *methodInfo);

static PlayerGetTransformNodeFn gOriginalPlayerGetTransformNode = nullptr;
static TransformGetterFn gOriginalITransformNodeGetTransform = nullptr;
static TransformGetterFn gOriginalTransformNodeGetTransform = nullptr;
static TransformGetterFn gOriginalBFOONIGAIFKGetTransform = nullptr;
static TransformGetPositionFn gOriginalTransformGetPosition = nullptr;
static CameraGetMainFn gOriginalCameraGetMain = nullptr;
static CameraWorldToScreenPointFn gOriginalCameraWorldToScreenPoint = nullptr;

static void RememberNode(void *player, void *node)
{
    if (!player || !node) return;
    const uint64_t now = MonotonicNanos();
    std::lock_guard<std::mutex> lock(gESPStateMutex);
    gNodeToPlayer[node] = NodeRecord{player, now};
    if (gNodeToPlayer.size() > 2048) {
        for (auto it = gNodeToPlayer.begin(); it != gNodeToPlayer.end();) {
            if (now - it->second.lastSeen > 3000000000ULL) it = gNodeToPlayer.erase(it);
            else ++it;
        }
    }
    ++gNodeHits;
}

static void RememberTransform(void *sourceObject, uint32_t sourceMode, void *transform)
{
    if (!sourceObject || !transform) return;
    const int active = gESPMode.load(std::memory_order_acquire);
    if (active != (int)sourceMode || active == 0) return;

    const uint64_t now = MonotonicNanos();
    std::lock_guard<std::mutex> lock(gESPStateMutex);
    auto nodeIt = gNodeToPlayer.find(sourceObject);
    if (nodeIt == gNodeToPlayer.end()) return;

    TargetRecord &r = gTransformToTarget[transform];
    r.player = nodeIt->second.player;
    r.transform = transform;
    r.sourceMode = sourceMode;
    r.lastSeen = now;
    gGetterHits[sourceMode - 1]++;

    if (gTransformToTarget.size() > 2048) {
        for (auto it = gTransformToTarget.begin(); it != gTransformToTarget.end();) {
            if (now - it->second.lastSeen > 3000000000ULL) it = gTransformToTarget.erase(it);
            else ++it;
        }
    }
}

static void CaptureDirectTransformNode(void *node);

static void *HookedPlayerGetTransformNode(void *self, void *name, const void *methodInfo)
{
    void *node = gOriginalPlayerGetTransformNode
        ? gOriginalPlayerGetTransformNode(self, name, methodInfo)
        : nullptr;
    if (gESPMode.load(std::memory_order_acquire) != 0) {
        RememberNode(self, node);
        CaptureDirectTransformNode(node);
    }
    return node;
}

static void *HookedITransformNodeGetTransform(void *self, const void *methodInfo)
{
    void *transform = gOriginalITransformNodeGetTransform
        ? gOriginalITransformNodeGetTransform(self, methodInfo)
        : nullptr;
    (void)transform;
    return transform;
}

/*
 * ESP 1 is deliberately no longer dependent on the interface getter.
 * The supplied notes confirm TransformNode.transform at +0x10.  The node
 * returned by Player::GetTransformNode is therefore used directly for this
 * test. This is the replacement for the non-working interface route.
 */
static void CaptureDirectTransformNode(void *node)
{
    if (!node || gESPMode.load(std::memory_order_acquire) != 1) return;
    void *transform = *(void **)((uint8_t *)node + FreeFireOffsets::TransformNodeTransformOffset);
    RememberTransform(node, 1, transform);
}

static void *HookedTransformNodeGetTransform(void *self, const void *methodInfo)
{
    void *transform = gOriginalTransformNodeGetTransform
        ? gOriginalTransformNodeGetTransform(self, methodInfo)
        : nullptr;
    RememberTransform(self, 2, transform);
    return transform;
}

static void *HookedBFOONIGAIFKGetTransform(void *self, const void *methodInfo)
{
    void *transform = gOriginalBFOONIGAIFKGetTransform
        ? gOriginalBFOONIGAIFKGetTransform(self, methodInfo)
        : nullptr;
    RememberTransform(self, 3, transform);
    return transform;
}

static Vector3 HookedTransformGetPosition(void *self, const void *methodInfo)
{
    Vector3 pos = {0, 0, 0};
    if (gOriginalTransformGetPosition)
        pos = gOriginalTransformGetPosition(self, methodInfo);

    const int active = gESPMode.load(std::memory_order_acquire);
    if (active == 0 || !self) return pos;

    std::lock_guard<std::mutex> lock(gESPStateMutex);
    auto it = gTransformToTarget.find(self);
    if (it == gTransformToTarget.end()) return pos;
    TargetRecord &r = it->second;

    r.x = pos.x;
    r.y = pos.y;
    r.z = pos.z;
    r.lastSeen = MonotonicNanos();
    ++gPosHits;

    void *camera = gCamera;
    if (!camera || !gOriginalCameraWorldToScreenPoint) {
        PublishSnapshotLocked(r.lastSeen);
        return pos;
    }

    const void *mi = gWorldToScreenMethodInfo;
    if (mi) {
        Vector3 screen = gOriginalCameraWorldToScreenPoint(camera, pos, mi);
        r.x = screen.x;
        r.y = screen.y;
        r.z = screen.z;
        r.depth = screen.z;
        ++gProjectionHits;
        ++gESPFrame;
    }
    PublishSnapshotLocked(r.lastSeen);
    return pos;
}

static void *HookedCameraGetMain(const void *methodInfo)
{
    void *camera = gOriginalCameraGetMain
        ? gOriginalCameraGetMain(methodInfo)
        : nullptr;
    if (camera) {
        std::lock_guard<std::mutex> lock(gESPStateMutex);
        gCamera = camera;
        ++gCameraHits;
        PublishSnapshotLocked(MonotonicNanos());
    }
    return camera;
}

static Vector3 HookedCameraWorldToScreenPoint(void *self, Vector3 position, const void *methodInfo)
{
    gWorldToScreenMethodInfo = methodInfo;
    Vector3 out = {0, 0, 0};
    if (gOriginalCameraWorldToScreenPoint)
        out = gOriginalCameraWorldToScreenPoint(self, position, methodInfo);
    return out;
}

static void *FindImageBase(const char *needle)
{
    if (!needle) return nullptr;
    const uint32_t count = _dyld_image_count();
    for (uint32_t i = 0; i < count; ++i) {
        const char *name = _dyld_get_image_name(i);
        if (!name || !strstr(name, needle)) continue;
        return (void *)_dyld_get_image_header(i);
    }
    return nullptr;
}

static bool InstallHook(void *target, void *replacement, void **originalOut, const char *label)
{
    if (!target || !replacement || !gMSHookFunction || !originalOut) return false;
    void *original = nullptr;
    gMSHookFunction(target, replacement, &original);
    if (!original) {
        Log(@"Hook falhou: %s (%p)", label, target);
        return false;
    }
    *originalOut = original;
    Log(@"Hook OK: %s", label);
    return true;
}

static void InstallESPProbeHooks(void)
{
    if (gESPProbeHooksInstalled) return;

    gHookAttempts.fetch_add(1, std::memory_order_relaxed);
    void *unityBase = FindImageBase("UnityFramework");
    if (!unityBase) {
        SetDiagnosticStage(ESP_PROBE_STAGE_WAITING_UNITY);
        Log(@"UnityFramework ainda não carregou");
        EnsureShared();
        std::lock_guard<std::mutex> lock(gESPStateMutex);
        PublishSnapshotLocked(MonotonicNanos());
        return;
    }

    uintptr_t base = (uintptr_t)unityBase;
    gUnityBase.store((uint64_t)base, std::memory_order_release);
    SetDiagnosticStage(ESP_PROBE_STAGE_HOOKING);
    gHookMask |= InstallHook((void *)(base + FreeFireOffsets::PlayerGetTransformNodeRVA),
                             (void *)&HookedPlayerGetTransformNode,
                             (void **)&gOriginalPlayerGetTransformNode,
                             "Player::GetTransformNode") ? (1u << 0) : 0;

    /* ITransformNode::get_transform remains documented but is not used by ESP 1. */
    gHookMask |= InstallHook((void *)(base + FreeFireOffsets::TransformNodeGetTransformRVA),
                             (void *)&HookedTransformNodeGetTransform,
                             (void **)&gOriginalTransformNodeGetTransform,
                             "TransformNode::get_transform") ? (1u << 1) : 0;

    gHookMask |= InstallHook((void *)(base + FreeFireOffsets::BFOONIGAIFKGetTransformRVA),
                             (void *)&HookedBFOONIGAIFKGetTransform,
                             (void **)&gOriginalBFOONIGAIFKGetTransform,
                             "BFOONIGAIFK::get_transform") ? (1u << 2) : 0;

    gHookMask |= InstallHook((void *)(base + FreeFireOffsets::TransformGetPositionRVA),
                             (void *)&HookedTransformGetPosition,
                             (void **)&gOriginalTransformGetPosition,
                             "Transform::get_position") ? (1u << 3) : 0;

    gHookMask |= InstallHook((void *)(base + FreeFireOffsets::CameraGetMainRVA),
                             (void *)&HookedCameraGetMain,
                             (void **)&gOriginalCameraGetMain,
                             "Camera::get_main") ? (1u << 4) : 0;

    gHookMask |= InstallHook((void *)(base + FreeFireOffsets::CameraWorldToScreenPointRVA),
                             (void *)&HookedCameraWorldToScreenPoint,
                             (void **)&gOriginalCameraWorldToScreenPoint,
                             "Camera::WorldToScreenPoint") ? (1u << 5) : 0;

    EnsureShared();
    gESPProbeHooksInstalled = (gOriginalPlayerGetTransformNode && gOriginalTransformGetPosition && gOriginalCameraGetMain && gOriginalCameraWorldToScreenPoint);
    if (gESPProbeHooksInstalled)
        SetDiagnosticStage(ESP_PROBE_STAGE_READY);
    else
        SetDiagnosticStage(ESP_PROBE_STAGE_ERROR, 1001);
    Log(@"Probe hooks: mask=0x%08X core=%@", gHookMask, gESPProbeHooksInstalled ? @"OK" : @"PENDENTE");
    std::lock_guard<std::mutex> lock(gESPStateMutex);
    PublishSnapshotLocked(MonotonicNanos());
}

static void TryInstallEverything(void)
{
    if (!gMSHookFunction) {
        gMSHookFunction = (MSHookFunctionFn)dlsym(RTLD_DEFAULT, "MSHookFunction");
    }
    if (!gMSHookFunction) {
        SetDiagnosticStage(ESP_PROBE_STAGE_WAITING_MSHOOK, 1000);
        EnsureShared();
        std::lock_guard<std::mutex> lock(gESPStateMutex);
        PublishSnapshotLocked(MonotonicNanos());
        return;
    }

    InstallESPProbeHooks();
}

static void ImageAdded(const struct mach_header *mh, intptr_t slide)
{
    (void)mh; (void)slide;
    dispatch_async(dispatch_get_main_queue(), ^{
        TryInstallEverything();
    });
}

__attribute__((constructor))
static void ESPProbeInit(void)
{
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(), nullptr,
        ModeNotification, kMode0, nullptr,
        CFNotificationSuspensionBehaviorDeliverImmediately);
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(), nullptr,
        ModeNotification, kMode1, nullptr,
        CFNotificationSuspensionBehaviorDeliverImmediately);
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(), nullptr,
        ModeNotification, kMode2, nullptr,
        CFNotificationSuspensionBehaviorDeliverImmediately);
    CFNotificationCenterAddObserver(
        CFNotificationCenterGetDarwinNotifyCenter(), nullptr,
        ModeNotification, kMode3, nullptr,
        CFNotificationSuspensionBehaviorDeliverImmediately);

    EnsureShared();
    SetMode(0);
    SetDiagnosticStage(ESP_PROBE_STAGE_SHARED_READY);
    {
        std::lock_guard<std::mutex> lock(gESPStateMutex);
        PublishSnapshotLocked(MonotonicNanos());
    }

    StartIPCServer();

    _dyld_register_func_for_add_image(ImageAdded);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.0 * NSEC_PER_SEC)),
                   dispatch_get_main_queue(), ^{
        TryInstallEverything();
    });
}
