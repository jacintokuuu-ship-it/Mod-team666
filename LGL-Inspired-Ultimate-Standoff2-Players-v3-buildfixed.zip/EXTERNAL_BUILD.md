# XternalZ external build contract

- Product type: standalone iOS application / external HUD.
- Theos target: `APPLICATION_NAME := Excalibur`.
- Output: `Excalibur.ipa` (and the staged `Excalibur.app`).
- No MobileSubstrate/Substitute/ElleKit tweak target is built.
- No DynamicLibraries `.dylib` is copied into the app payload by the default build.
- `hooks/CaptainHook.h` is retained as legacy source/reference only; an external process cannot execute in-process hooks merely by including that header.
- Existing task/process/Unity/ESP source files remain in the application target as they were in the supplied external project.
- The HUD/window/input architecture remains out-of-process; it is not converted into an injected module.
