# Free Fire ESP chain — source study

## Dump-derived anchors

- `GameFacade::get_UIModelSpectator` — RVA `0x5933D60`
- `GameFacade::LocalPlayerUserID` — field `0x58`
- `GameFacade::m_UIModelSpectator` — field `0x320`
- `UIModelSpectator::m_PlayerDic` — field `0x30`
- `PlayerData::gsTeamId` — field `0x34`
- `PlayerData::scTeamId` — field `0x35`
- `PlayerData::isDead` — field `0x6C`
- `PlayerData::lastPosition` — field `0xDC`
- `PlayerData::player` — field `0x100`
- `PlayerData::headScale` — field `0x108`
- `Player::FollowCamera` — field `0x690`
- `Player::MainCameraTransform` — field `0x3E8`
- `Player::BDMMCNJOHNI` (Transform) — field `0x700`
- `CameraControllerBase::AFMGCAELKBD` (Camera TargetCamera) — field `0x30`
- `Camera.get_main` — RVA `0x8CFF0B4`
- `Camera.WorldToScreenPoint` — RVA `0x8CFE9C0`
- `Camera.worldToCameraMatrix` — RVA `0x8CFE220`
- `Camera.projectionMatrix` — RVA `0x8CFE3C8`

## Reference-derived runtime layout

The older XternalZ project supplies the external Unity math used here:

- `Transform + 0x10` -> internal transform object
- internal `+ 0x38` -> transform matrix container
- internal `+ 0x40` -> transform index
- matrix `+ 0x18` -> matrix list
- matrix `+ 0x20` -> parent-index list
- `Camera + 0x10` -> Unity internal object
- camera internal `+ 0x100` -> 4x4 view/projection matrix used by the reference W2S routine

## Important boundary

The current build uses only external task-memory reads and UIKit rendering. The anti-cheat bypass and dylib-hiding code present in the legacy materials are not part of this ESP implementation.
