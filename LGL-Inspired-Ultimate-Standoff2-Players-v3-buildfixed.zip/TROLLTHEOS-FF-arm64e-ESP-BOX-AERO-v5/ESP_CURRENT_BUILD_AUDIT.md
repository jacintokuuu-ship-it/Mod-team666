# ESP current-build audit

This build keeps the HUD renderer independent from Free Fire and removes the invalid pattern of executing UnityFramework addresses directly from the HUD process.

## Runtime chain used

```text
UnityFramework base
  -> GameFacade static storage (compatibility bootstrap)
  -> GameFacade.CurrentMatchGame +0x8
  -> MatchGame.m_Match +0x90
  -> JMAGGLCNGIG.LMOIPODCHOL +0x158  (List<Player>)
  -> List._items +0x10 / _size +0x18 / array data +0x20
  -> Player* entries
  -> Player.TeamModeID +0x434
  -> Player.BDMMCNJOHNI +0x700 (Transform)
  -> Transform native bridge +0x10
  -> Transform hierarchy position reader
```

Camera path:

```text
MatchGame.m_CameraControllerManager +0xD8
  -> CameraControllerManager.GameCamera +0x20
  -> native-camera bridge +0x10
  -> validated matrix candidate (historical +0xD8 first, small heuristic scan fallback)
  -> local WorldToScreen math
```

## Confirmed from the supplied current metadata dump

- `GameFacade.CurrentMatchGame` static field: `+0x8`
- `MatchGame.m_Match`: `+0x90`
- `MatchGame.m_CameraControllerManager`: `+0xD8`
- `JMAGGLCNGIG.MHJCLOPOBAA`: `+0xD8` (`Player` candidate used as local anchor)
- `JMAGGLCNGIG.LMOIPODCHOL`: `+0x158` (`List<Player>`)
- `Player.TeamModeID`: `+0x434`
- `Player.BDMMCNJOHNI`: `+0x700` (`Transform`)
- `CameraControllerManager.GameCamera`: `+0x20`

The metadata also confirms the following method RVAs, but this external reader does **not** call them cross-process:

- `GameFacade.CurrentMatch()` `0x591B898`
- `Player.get_HeadBoneTransform()` `0x563A1E0`
- `Camera.get_main()` `0x8CFF0B4`
- `Camera.WorldToScreenPoint(Vector3)` `0x8CFE9C0`
- `Transform.get_position()` `0x8D6C1EC`

## Important boundary

The dump identifies methods and field types, but it does not expose their machine-code bodies or the native Unity Camera object's complete internal layout. Therefore the camera matrix offset is runtime-validated rather than treated as a dump-confirmed game offset.

The head point is selected from the current Player `ITransformNode` cluster when a plausible highest node exists; otherwise the reader uses a small fixed world-height fallback above the confirmed root Transform.

## Renderer probe

The CALayer renderer always emits a status layer while Box ESP is enabled. When there are no accepted targets, it also emits a faint center probe. That separates a broken HUD renderer from a valid HUD with an empty/invalid game-data chain.
