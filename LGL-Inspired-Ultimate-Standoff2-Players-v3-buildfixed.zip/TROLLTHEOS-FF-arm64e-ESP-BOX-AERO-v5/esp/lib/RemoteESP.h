#pragma once

#include "Vector3.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct RemoteESPBox {
    float x;
    float y;
    float width;
    float height;
    float distance;
    unsigned int teamModeID;
} RemoteESPBox;

typedef struct RemoteESPFrame {
    int connected;
    int chainValid;
    int matrixValid;
    int listCount;
    int targetCount;
    unsigned long long pid;
    unsigned long long unityBase;
    RemoteESPBox boxes[64];
    char status[192];
} RemoteESPFrame;

int RemoteESPBuildFrame(float screenWidth, float screenHeight, int teamCheck, RemoteESPFrame *outFrame);
int RemoteESPRendererReady(void);

#ifdef __cplusplus
}
#endif
