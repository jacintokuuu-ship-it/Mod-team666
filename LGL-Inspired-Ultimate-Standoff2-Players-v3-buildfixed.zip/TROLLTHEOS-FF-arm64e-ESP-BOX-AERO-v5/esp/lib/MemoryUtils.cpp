#import "MemoryUtils.h"
#import <mach-o/loader.h>
#import <mach-o/dyld_images.h>
#include <vector>
#include <cstring>
#include <cstdio>
#include <cctype>

pid_t GetGameProcesspid(char* GameProcessName) {
    if (!GameProcessName || !*GameProcessName) return -1;

    size_t length = 0;
    static const int name[] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};
    int err = sysctl((int *)name, (sizeof(name) / sizeof(*name)) - 1, NULL, &length, NULL, 0);
    if (err != 0 || length == 0) return -1;

    struct kinfo_proc *procBuffer = (struct kinfo_proc *)malloc(length);
    if (!procBuffer) return -1;

    err = sysctl((int *)name, (sizeof(name) / sizeof(*name)) - 1, procBuffer, &length, NULL, 0);
    if (err != 0) { free(procBuffer); return -1; }

    auto containsInsensitive = [](const char *haystack, const char *needle) -> bool {
        if (!haystack || !needle || !*needle) return false;
        for (const char *h = haystack; *h; ++h) {
            const char *a = h;
            const char *b = needle;
            while (*a && *b && std::tolower((unsigned char)*a) == std::tolower((unsigned char)*b)) { ++a; ++b; }
            if (!*b) return true;
        }
        return false;
    };

    int count = (int)(length / sizeof(struct kinfo_proc));
    for (int i = 0; i < count; ++i) {
        const char *procname = procBuffer[i].kp_proc.p_comm;
        if (containsInsensitive(procname, GameProcessName)) {
            pid_t pid = procBuffer[i].kp_proc.p_pid;
            free(procBuffer);
            return pid;
        }
    }

    free(procBuffer);
    return -1;
}

struct dyld_image_info64_local {
    mach_vm_address_t imageLoadAddress;
    mach_vm_address_t imageFilePath;
    mach_vm_size_t imageFileModDate;
};

struct dyld_all_image_infos64_local {
    uint32_t version;
    uint32_t infoArrayCount;
    mach_vm_address_t infoArray;
    mach_vm_address_t notification;
    bool processDetachedFromSharedRegion;
    bool libSystemInitialized;
    mach_vm_address_t dyldImageLoadAddress;
    mach_vm_address_t jitInfo;
    mach_vm_address_t dyldVersion;
    mach_vm_address_t errorMessage;
    uint64_t terminationFlags;
    mach_vm_address_t coreSymbolicationShmPage;
    uint64_t systemOrderFlag;
    uint64_t uuidArrayCount;
    mach_vm_address_t uuidArray;
    mach_vm_address_t dyldAllImageInfosAddress;
    uint64_t initialImageCount;
    uint64_t errorKind;
    mach_vm_address_t errorClientOfDylibPath;
    mach_vm_address_t errorTargetDylibPath;
    mach_vm_address_t errorSymbol;
    uint64_t sharedCacheSlide;
};

static bool readRemote(task_t task, mach_vm_address_t address, void *buffer, mach_vm_size_t size) {
    if (task == MACH_PORT_NULL || !address || !buffer || !size) return false;
    vm_size_t out = 0;
    kern_return_t kr = vm_read_overwrite(task, (vm_address_t)address, (vm_size_t)size, (vm_address_t)buffer, &out);
    return kr == KERN_SUCCESS && out == size;
}

static mach_vm_address_t getUnityFrameworkBase(task_t task) {
    task_dyld_info_data_t dyldInfo{};
    mach_msg_type_number_t count = TASK_DYLD_INFO_COUNT;
    if (task_info(task, TASK_DYLD_INFO, (task_info_t)&dyldInfo, &count) != KERN_SUCCESS) return 0;

    dyld_all_image_infos64_local infos{};
    if (!readRemote(task, dyldInfo.all_image_info_addr, &infos, sizeof(infos))) return 0;
    if (!infos.infoArray || infos.infoArrayCount == 0 || infos.infoArrayCount > 65536) return 0;

    size_t bytes = (size_t)infos.infoArrayCount * sizeof(dyld_image_info64_local);
    std::vector<dyld_image_info64_local> images(infos.infoArrayCount);
    if (!readRemote(task, infos.infoArray, images.data(), bytes)) return 0;

    for (uint32_t i = 0; i < infos.infoArrayCount; ++i) {
        char path[PATH_MAX]{};
        if (!images[i].imageFilePath) continue;
        if (!readRemote(task, images[i].imageFilePath, path, sizeof(path) - 1)) continue;
        path[sizeof(path) - 1] = '\0';
        if (strstr(path, "UnityFramework")) return images[i].imageLoadAddress;
    }
    return 0;
}

vm_map_offset_t GetGameModule_Base(char* GameProcessName) {
    pid_t pid = GetGameProcesspid(GameProcessName);
    if (pid <= 0) return 0;
    Processpid = pid;

    if (get_task != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), get_task);
        get_task = MACH_PORT_NULL;
    }

    kern_return_t kr = task_for_pid(mach_task_self(), pid, &get_task);
    if (kr != KERN_SUCCESS || get_task == MACH_PORT_NULL) return 0;

    mach_vm_address_t base = getUnityFrameworkBase(get_task);
    if (!base) {
        mach_port_deallocate(mach_task_self(), get_task);
        get_task = MACH_PORT_NULL;
        return 0;
    }

    uint32_t magic = 0;
    if (!readRemote(get_task, base, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        mach_port_deallocate(mach_task_self(), get_task);
        get_task = MACH_PORT_NULL;
        return 0;
    }

    return base;
}

bool _read(long addr, void *buffer, int len) {
    if (get_task == MACH_PORT_NULL || addr <= 0 || !buffer || len <= 0) return false;
    vm_size_t size = 0;
    kern_return_t error = vm_read_overwrite(get_task,
                                               (vm_address_t)addr,
                                               (vm_size_t)len,
                                               (vm_address_t)buffer,
                                               &size);
    return error == KERN_SUCCESS && size == (mach_vm_size_t)len;
}

bool _write(long addr, const void *buffer, int len) {
    if (get_task == MACH_PORT_NULL || addr <= 0 || !buffer || len <= 0) return false;
    kern_return_t kr = vm_write(get_task,
                                  (vm_address_t)addr,
                                  (pointer_t)buffer,
                                  (mach_msg_type_number_t)len);
    return kr == KERN_SUCCESS;
}
