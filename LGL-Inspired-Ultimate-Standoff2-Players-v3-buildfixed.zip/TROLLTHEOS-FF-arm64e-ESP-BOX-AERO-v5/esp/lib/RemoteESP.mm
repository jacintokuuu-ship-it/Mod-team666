#import "RemoteESP.h"
#import "MemoryUtils.h"
#import "UnityMath.h"
#include <CoreFoundation/CoreFoundation.h>
#include <cmath>
#include <cfloat>
#include <cstdio>
#include <cstring>
#include <cstdint>
#include <algorithm>

namespace {

// ====== Current dump: confirmed game fields ======
static constexpr uintptr_t kGameFacadeCurrentMatchGameStaticField = 0x8;   // GameFacade.CurrentMatchGame
static constexpr uintptr_t kMatchGameMatchField = 0x90;                    // MatchGame.m_Match
static constexpr uintptr_t kMatchGameCameraManagerField = 0xD8;           // MatchGame.m_CameraControllerManager
static constexpr uintptr_t kMatchLocalPlayerCandidateField = 0xD8;        // JMAGGLCNGIG.MHJCLOPOBAA : Player
static constexpr uintptr_t kMatchPlayerListField = 0x158;                 // JMAGGLCNGIG.LMOIPODCHOL : List<Player>
static constexpr uintptr_t kPlayerTeamModeIDField = 0x434;                // Player.TeamModeID
static constexpr uintptr_t kPlayerRootTransformField = 0x700;             // Player.BDMMCNJOHNI : Transform

// The Player bone area is a sequence of ITransformNode fields in the dump.
// Their exact semantic names are obfuscated, so we select the highest plausible
// world-space node as a head candidate and fall back to root + fixed height.
static constexpr uintptr_t kPlayerNodeOffsets[] = {
    0x698, 0x6A0, 0x6A8, 0x6B0, 0x6B8, 0x6C0, 0x6C8, 0x6D0,
    0x6D8, 0x6E0, 0x6E8, 0x6F0, 0x6F8, 0x708, 0x710, 0x718,
    0x720, 0x728, 0x730
};

// Unity managed List<T> layout for reference/object lists.
static constexpr uintptr_t kListItemsField = 0x10;
static constexpr uintptr_t kListSizeField = 0x18;
static constexpr uintptr_t kArrayDataField = 0x20;

// Unity ITransformNode / TransformNode instance layout: field at +0x10 is the Transform.
static constexpr uintptr_t kTransformNodeTransformField = 0x10;

// UnityEngine.Object native bridge used by the existing transform reader.
static constexpr uintptr_t kUnityManagedNativePtrField = 0x10;

// Generic native Transform hierarchy layout already used by the project.
static constexpr uintptr_t kTransformMatrixField = 0x38;
static constexpr uintptr_t kTransformIndexField = 0x40;
static constexpr uintptr_t kTransformMatrixListField = 0x18;
static constexpr uintptr_t kTransformMatrixIndicesField = 0x20;

// Existing project / Unity-native camera data candidate. It is deliberately
// probed and validated instead of being blindly trusted.
static constexpr uintptr_t kCameraNativeMatrixCandidate = 0xD8;

// Legacy GameFacade type-info bootstrap retained only as a compatibility
// resolver; the actual game-object fields below are from the current dump.
static constexpr uintptr_t kLegacyGameFacadeTypeInfoRVA = 0xA4D2968;
static constexpr uintptr_t kLegacyGameFacadeStaticFieldsOffset = 0xB8;

struct Matrix4x4f { float m[16]; };

static uint64_t gCachedCamera = 0;
static uint64_t gCachedNativeCamera = 0;
static uintptr_t gCachedMatrixOffset = 0;
static bool gHasCachedMatrix = false;
static CFAbsoluteTime gLastMatrixProbe = 0.0;
static uint64_t gCachedUnityBase = 0;
static CFAbsoluteTime gLastUnityRefresh = 0.0;

static bool finitef(float v) {
    return std::isfinite(v) && std::fabs(v) < 1000000.0f;
}

static bool plausibleAddress(uint64_t p) {
    return p > 0x100000000ULL && p < 0x8000000000ULL;
}

template <typename T>
static bool readMem(uint64_t addr, T &out) {
    if (!plausibleAddress(addr)) return false;
    return _read((long)addr, &out, (int)sizeof(T));
}

static uint64_t readPtr(uint64_t addr) {
    uint64_t p = 0;
    if (!readMem(addr, p)) return 0;
    return plausibleAddress(p) ? p : 0;
}

static bool readWorldPosition(uint64_t transform, Vector3 &out) {
    if (!plausibleAddress(transform)) return false;

    const uint64_t nativeTransform = readPtr(transform + kUnityManagedNativePtrField);
    if (!nativeTransform) return false;

    const uint64_t matrix = readPtr(nativeTransform + kTransformMatrixField);
    if (!matrix) return false;

    uint64_t matrixIndexRaw = 0;
    if (!readMem(nativeTransform + kTransformIndexField, matrixIndexRaw)) return false;
    if (matrixIndexRaw > 100000) return false;
    const int32_t index = (int32_t)matrixIndexRaw;
    if (index < 0 || index > 100000) return false;

    const uint64_t matrixList = readPtr(matrix + kTransformMatrixListField);
    const uint64_t matrixIndices = readPtr(matrix + kTransformMatrixIndicesField);
    if (!matrixList || !matrixIndices) return false;

    TMatrix result{};
    if (!readMem(matrixList + sizeof(TMatrix) * (uint32_t)index, result)) return false;

    int32_t parentIndex = -1;
    if (!readMem(matrixIndices + sizeof(int32_t) * (uint32_t)index, parentIndex)) return false;

    int guard = 0;
    while (parentIndex >= 0 && guard++ < 128) {
        if (parentIndex > 100000) return false;
        TMatrix parent{};
        if (!readMem(matrixList + sizeof(TMatrix) * (uint32_t)parentIndex, parent)) return false;

        const float scaleX = result.position.x * parent.scale.x;
        const float scaleY = result.position.y * parent.scale.y;
        const float scaleZ = result.position.z * parent.scale.z;

        result.position.x = parent.position.x + scaleX
            + (scaleX * ((parent.rotation.y * parent.rotation.y * -2.0f) - (parent.rotation.z * parent.rotation.z * 2.0f)))
            + (scaleY * ((parent.rotation.w * parent.rotation.z * -2.0f) - (parent.rotation.y * parent.rotation.x * -2.0f)))
            + (scaleZ * ((parent.rotation.z * parent.rotation.x * 2.0f) - (parent.rotation.w * parent.rotation.y * -2.0f)));

        result.position.y = parent.position.y + scaleY
            + (scaleX * ((parent.rotation.x * parent.rotation.y * 2.0f) - (parent.rotation.w * parent.rotation.z * -2.0f)))
            + (scaleY * ((parent.rotation.z * parent.rotation.z * -2.0f) - (parent.rotation.x * parent.rotation.x * 2.0f)))
            + (scaleZ * ((parent.rotation.w * parent.rotation.x * -2.0f) - (parent.rotation.z * parent.rotation.y * -2.0f)));

        result.position.z = parent.position.z + scaleZ
            + (scaleX * ((parent.rotation.w * parent.rotation.y * -2.0f) - (parent.rotation.x * parent.rotation.z * 2.0f)))
            + (scaleY * ((parent.rotation.y * parent.rotation.z * 2.0f) - (parent.rotation.w * parent.rotation.x * -2.0f)))
            + (scaleZ * ((parent.rotation.x * parent.rotation.x * -2.0f) - (parent.rotation.y * parent.rotation.y * 2.0f)));

        if (!readMem(matrixIndices + sizeof(int32_t) * (uint32_t)parentIndex, parentIndex)) return false;
    }

    out = Vector3(result.position.x, result.position.y, result.position.z);
    return finitef(out.x) && finitef(out.y) && finitef(out.z);
}

static bool worldToScreen(const Matrix4x4f &m, const Vector3 &world, float width, float height, float &sx, float &sy, float &depth) {
    const float clipX = m.m[0] * world.x + m.m[4] * world.y + m.m[8]  * world.z + m.m[12];
    const float clipY = m.m[1] * world.x + m.m[5] * world.y + m.m[9]  * world.z + m.m[13];
    const float clipW = m.m[3] * world.x + m.m[7] * world.y + m.m[11] * world.z + m.m[15];

    if (!finitef(clipX) || !finitef(clipY) || !finitef(clipW) || clipW <= 0.05f) return false;

    sx = width * 0.5f + (clipX / clipW) * width * 0.5f;
    sy = height * 0.5f - (clipY / clipW) * height * 0.5f;
    depth = clipW;
    return finitef(sx) && finitef(sy) && finitef(depth);
}

static bool matrixLooksUseful(const Matrix4x4f &m, const Vector3 &anchor, float width, float height, float &scoreOut) {
    int finiteCount = 0;
    float magnitude = 0.0f;
    for (float v : m.m) {
        if (!finitef(v)) return false;
        if (std::fabs(v) < 100.0f) finiteCount++;
        magnitude += std::fabs(v);
    }
    if (finiteCount < 12 || magnitude < 0.1f || magnitude > 10000.0f) return false;

    float ax = 0, ay = 0, ad = 0;
    float hx = 0, hy = 0, hd = 0;
    Vector3 head = anchor + Vector3(0.0f, 1.65f, 0.0f);
    if (!worldToScreen(m, anchor, width, height, ax, ay, ad)) return false;
    if (!worldToScreen(m, head, width, height, hx, hy, hd)) return false;

    scoreOut = 0.0f;
    if (ax >= -width && ax <= width * 2.0f) scoreOut += 2.0f;
    if (ay >= -height && ay <= height * 2.0f) scoreOut += 2.0f;
    if (hx >= -width && hx <= width * 2.0f) scoreOut += 1.0f;
    if (hy >= -height && hy <= height * 2.0f) scoreOut += 1.0f;

    const float centerXError = std::fabs((hx - width * 0.5f) / std::max(width, 1.0f));
    const float centerYError = std::fabs((hy - height * 0.45f) / std::max(height, 1.0f));
    scoreOut += std::max(0.0f, 3.0f - centerXError * 3.0f);
    scoreOut += std::max(0.0f, 2.0f - centerYError * 2.0f);

    const float boxHeight = std::fabs(ay - hy);
    if (boxHeight > 4.0f && boxHeight < height * 1.5f) scoreOut += 3.0f;
    if (hy <= ay) scoreOut += 2.0f;
    return scoreOut >= 5.0f;
}

static bool readCandidateMatrix(uint64_t camera, const Vector3 &localAnchor, float width, float height, Matrix4x4f &out, uintptr_t &offsetOut) {
    const uint64_t native = readPtr(camera + kUnityManagedNativePtrField);
    if (!native) return false;

    // Fast path: keep using the previously validated native-camera matrix slot.
    if (gHasCachedMatrix && gCachedCamera == camera && gCachedNativeCamera == native) {
        Matrix4x4f cached{};
        if (readMem(native + gCachedMatrixOffset, cached)) {
            float score = 0.0f;
            if (matrixLooksUseful(cached, localAnchor, width, height, score)) {
                out = cached;
                offsetOut = gCachedMatrixOffset;
                return true;
            }
        }
        gHasCachedMatrix = false;
    }

    // First try the project's historically-used native-camera location.
    Matrix4x4f fixed{};
    if (readMem(native + kCameraNativeMatrixCandidate, fixed)) {
        float score = 0.0f;
        if (matrixLooksUseful(fixed, localAnchor, width, height, score)) {
            out = fixed;
            offsetOut = kCameraNativeMatrixCandidate;
            gCachedCamera = camera;
            gCachedNativeCamera = native;
            gCachedMatrixOffset = kCameraNativeMatrixCandidate;
            gHasCachedMatrix = true;
            return true;
        }
    }

    // Heuristic scan is rate-limited because this is only needed when the
    // camera layout changes or the fixed candidate fails validation.
    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    if ((now - gLastMatrixProbe) < 0.25 && gCachedCamera == camera && gCachedNativeCamera == native)
        return false;
    gLastMatrixProbe = now;

    unsigned char blob[0x600]{};
    if (!_read((long)native, blob, sizeof(blob))) return false;

    Matrix4x4f best{};
    float bestScore = -FLT_MAX;
    uintptr_t bestOffset = 0;

    for (uintptr_t off = 0x20; off + sizeof(Matrix4x4f) <= sizeof(blob); off += 4) {
        Matrix4x4f candidate{};
        std::memcpy(candidate.m, blob + off, sizeof(candidate.m));
        float score = 0.0f;
        if (!matrixLooksUseful(candidate, localAnchor, width, height, score)) continue;
        if (score > bestScore) {
            bestScore = score;
            best = candidate;
            bestOffset = off;
        }
    }

    if (bestScore < 7.0f) return false;
    out = best;
    offsetOut = bestOffset;
    gCachedCamera = camera;
    gCachedNativeCamera = native;
    gCachedMatrixOffset = bestOffset;
    gHasCachedMatrix = true;
    return true;
}

static uint64_t resolveMatchGame(uint64_t moduleBase) {
    // Compatibility bootstrap used by the existing project. Validate every hop.
    uint64_t typeInfo = readPtr(moduleBase + kLegacyGameFacadeTypeInfoRVA);
    if (!typeInfo) return 0;

    uint64_t statics = readPtr(typeInfo + kLegacyGameFacadeStaticFieldsOffset);
    if (!statics) return 0;

    uint64_t currentMatchGame = readPtr(statics + kGameFacadeCurrentMatchGameStaticField);
    return currentMatchGame;
}

static uint64_t resolveMatch(uint64_t matchGame) {
    return readPtr(matchGame + kMatchGameMatchField);
}

static uint64_t resolveCamera(uint64_t matchGame) {
    uint64_t manager = readPtr(matchGame + kMatchGameCameraManagerField);
    if (!manager) return 0;
    // CameraControllerManager.GameCamera is the first Camera field at +0x20.
    return readPtr(manager + 0x20);
}

static uint64_t resolveList(uint64_t match) {
    return readPtr(match + kMatchPlayerListField);
}

static uint64_t resolveLocalPlayer(uint64_t match) {
    return readPtr(match + kMatchLocalPlayerCandidateField);
}

static uint64_t readListPlayer(uint64_t list, int index, int count) {
    if (!list || index < 0 || index >= count) return 0;
    uint64_t items = readPtr(list + kListItemsField);
    if (!items) return 0;
    return readPtr(items + kArrayDataField + sizeof(uint64_t) * (uintptr_t)index);
}

static bool readBestHead(uint64_t player, const Vector3 &root, Vector3 &head) {
    bool found = false;
    float bestScore = -FLT_MAX;

    for (uintptr_t off : kPlayerNodeOffsets) {
        uint64_t node = readPtr(player + off);
        if (!node) continue;
        uint64_t transform = readPtr(node + kTransformNodeTransformField);
        if (!transform) continue;
        Vector3 p{};
        if (!readWorldPosition(transform, p)) continue;

        float dy = p.y - root.y;
        float dxz = std::sqrt((p.x - root.x) * (p.x - root.x) + (p.z - root.z) * (p.z - root.z));
        if (dy < 0.55f || dy > 2.8f || dxz > 1.2f) continue;

        float score = dy * 3.0f - dxz * 2.0f;
        if (score > bestScore) {
            bestScore = score;
            head = p;
            found = true;
        }
    }

    if (!found) {
        head = root + Vector3(0.0f, 1.65f, 0.0f);
    }
    return true;
}

static void status(RemoteESPFrame &f, const char *s) {
    std::snprintf(f.status, sizeof(f.status), "%s", s ? s : "");
}

}

extern "C" int RemoteESPBuildFrame(float screenWidth, float screenHeight, int teamCheck, RemoteESPFrame *outFrame) {
    RemoteESPFrame f{};
    if (!outFrame || screenWidth <= 1.0f || screenHeight <= 1.0f) return 0;

    CFAbsoluteTime now = CFAbsoluteTimeGetCurrent();
    uint64_t base = gCachedUnityBase;
    if (!base || (now - gLastUnityRefresh) >= 2.0) {
        base = GetGameModule_Base((char *)"FreeFire");
        if (!base) base = GetGameModule_Base((char *)"freefireth");
        if (base) gCachedUnityBase = base;
        else gCachedUnityBase = 0;
        gLastUnityRefresh = now;
    }
    f.unityBase = base;
    if (!base) {
        status(f, "GAME OFFLINE | UnityFramework nao encontrado");
        *outFrame = f;
        return 0;
    }

    f.connected = 1;

    uint64_t matchGame = resolveMatchGame(base);
    if (!matchGame) {
        status(f, "ONLINE | MatchGame nao resolvido");
        *outFrame = f;
        return 0;
    }

    uint64_t match = resolveMatch(matchGame);
    uint64_t localPlayer = resolveLocalPlayer(match);
    uint64_t list = resolveList(match);
    uint64_t camera = resolveCamera(matchGame);
    if (!match || !list || !camera) {
        status(f, "ONLINE | cadeia Match/List/Camera incompleta");
        *outFrame = f;
        return 0;
    }
    f.chainValid = 1;

    int count = 0;
    if (!readMem(list + kListSizeField, count) || count <= 0 || count > 128) {
        status(f, "ONLINE | List<Player> invalida ou vazia");
        *outFrame = f;
        return 0;
    }
    f.listCount = count;

    Vector3 localRoot{};
    bool haveLocalRoot = false;
    if (localPlayer) {
        uint64_t localRootTransform = readPtr(localPlayer + kPlayerRootTransformField);
        if (localRootTransform) haveLocalRoot = readWorldPosition(localRootTransform, localRoot);
    }

    // If the candidate local pointer is stale, use the first valid player as an anchor.
    if (!haveLocalRoot) {
        for (int i = 0; i < count; ++i) {
            uint64_t p = readListPlayer(list, i, count);
            if (!p) continue;
            uint64_t rt = readPtr(p + kPlayerRootTransformField);
            if (!rt) continue;
            if (readWorldPosition(rt, localRoot)) { haveLocalRoot = true; break; }
        }
    }
    if (!haveLocalRoot) {
        status(f, "ONLINE | nenhum Transform de Player legivel");
        *outFrame = f;
        return 0;
    }

    Matrix4x4f matrix{};
    uintptr_t matrixOffset = 0;
    if (!readCandidateMatrix(camera, localRoot, screenWidth, screenHeight, matrix, matrixOffset)) {
        status(f, "ONLINE | Camera encontrada, matriz nao validada");
        *outFrame = f;
        return 0;
    }
    f.matrixValid = 1;

    unsigned int localTeam = 0;
    if (localPlayer) readMem(localPlayer + kPlayerTeamModeIDField, localTeam);

    for (int i = 0; i < count && f.targetCount < 64; ++i) {
        uint64_t player = readListPlayer(list, i, count);
        if (!player || player == localPlayer) continue;

        unsigned int team = 0;
        readMem(player + kPlayerTeamModeIDField, team);
        if (teamCheck && localTeam != 0 && team != 0 && team == localTeam) continue;

        uint64_t rootTransform = readPtr(player + kPlayerRootTransformField);
        if (!rootTransform) continue;

        Vector3 root{};
        if (!readWorldPosition(rootTransform, root)) continue;

        Vector3 head{};
        readBestHead(player, root, head);

        float sxRoot = 0, syRoot = 0, dRoot = 0;
        float sxHead = 0, syHead = 0, dHead = 0;
        if (!worldToScreen(matrix, root, screenWidth, screenHeight, sxRoot, syRoot, dRoot)) continue;
        if (!worldToScreen(matrix, head, screenWidth, screenHeight, sxHead, syHead, dHead)) continue;

        const float boxHeight = std::fabs(syRoot - syHead);
        if (boxHeight < 8.0f || boxHeight > screenHeight * 1.5f) continue;

        const float boxWidth = std::max(8.0f, boxHeight * 0.45f);
        const float bx = sxHead - boxWidth * 0.5f;
        const float by = std::min(syHead, syRoot);

        if (bx > screenWidth || bx + boxWidth < 0.0f || by > screenHeight || by + boxHeight < 0.0f) continue;
        if (dRoot <= 0.05f || dHead <= 0.05f) continue;

        RemoteESPBox &b = f.boxes[f.targetCount++];
        b.x = bx;
        b.y = by;
        b.width = boxWidth;
        b.height = boxHeight;
        b.distance = std::sqrt(
            (root.x - localRoot.x) * (root.x - localRoot.x) +
            (root.y - localRoot.y) * (root.y - localRoot.y) +
            (root.z - localRoot.z) * (root.z - localRoot.z));
        b.teamModeID = team;
    }

    std::snprintf(f.status, sizeof(f.status),
                  "ESP ONLINE | targets %d | list %d | matrix +0x%lX",
                  f.targetCount, f.listCount, (unsigned long)matrixOffset);

    *outFrame = f;
    return 1;
}

extern "C" int RemoteESPRendererReady(void) {
    return 1;
}
