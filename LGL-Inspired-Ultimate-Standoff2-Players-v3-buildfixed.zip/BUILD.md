# Free Fire — ESP probe

Esta revisão não inclui a antiga função de bone mapping.

O projeto é dividido em:

1. `Excalibur`: HUD/menu e desenho das linhas.
2. `tweak/ESPProbe.xm`: ponte in-process filtrada para `com.dts.freefireth`.

Os testes usam somente os RVAs/campo fornecidos na conversa.

ESP 1:
`Player::GetTransformNode 0x5735538` → `TransformNode.transform +0x10` → `Transform::get_position 0x08D6C1EC` → `Camera::get_main 0x08CFF0B4` → `Camera::WorldToScreenPoint 0x08CFE9C0`.

ESP 2:
`Player::GetTransformNode 0x5735538` → `TransformNode::get_transform 0x06B4964C` → posição/projeção.

ESP 3:
`Player::GetTransformNode 0x5735538` → `BFOONIGAIFK::get_transform 0x0581FB80` → posição/projeção.

No build, o probe é empacotado como `ESPProbeFF`.
