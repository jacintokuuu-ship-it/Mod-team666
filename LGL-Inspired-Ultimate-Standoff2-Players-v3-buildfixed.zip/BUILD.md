# Free Fire — External HUD

## Produto

Este projeto compila somente um aplicativo iOS standalone (`Excalibur`) que roda fora do Free Fire.
Não existe target de tweak, dylib injetada, MobileSubstrate, Substitute ou ElleKit no build padrão.

## Arquitetura externa

`Excalibur` → `get_pid_by_name("FreeFire")` → `task_for_pid()`/fallback Mach → `UnityFramework` via `TASK_DYLD_INFO` → `mach_vm_read_overwrite()`.

## Verificar

A função **VERIFICAR — ACESSO AO FREE FIRE** executa um teste real de: processo, `task_t`, base de `UnityFramework`, leitura do cabeçalho Mach-O e leitura dos bytes das RVAs fornecidas. O resultado aparece no toast e no cartão de status.

## ESP Line + ESP Box

A camada de desenho continua externa. A enumeração ao vivo agora percorre `UIModelSpectator.m_PlayerDic`, lê `PlayerData`, resolve o `Player` e encontra a câmera pelo encadeamento `Player + 0x690` (`FollowCamera`) → `+0x30` (`TargetCamera`). A posição usa `PlayerData.lastPosition` com fallback para o Transform raiz em `Player + 0x700`.

O projetor segue a convenção de tela do Unity e converte pixels para pontos UIKit usando o `UIScreen.scale`.

## Build

```sh
make package
```

O ambiente desta análise não possui SDK iPhoneOS/Theos para executar uma compilação real, portanto o pacote foi revisado estruturalmente e não deve ser apresentado como binário já compilado/validado em dispositivo.
