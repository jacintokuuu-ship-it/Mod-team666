# BUILD.md — External iOS 15.8

## Estado
Aplicação standalone arm64 para iOS 15.x/Theos. O código de aquisição foi convertido para **read-only**: essas primitivas de escrita/alocação/execução remota não são usadas.

## Build
```sh
make clean
make package FINALPACKAGE=1
```

O ambiente desta entrega não contém um SDK iPhoneOS/Theos utilizável, portanto este pacote **não é declarado como compilado/testado em dispositivo**.

## TrollStore
TrollStore é usado somente como mecanismo de instalação/perma-signing. A aplicação não presume que a instalação concede automaticamente task ports ou outras permissões privadas. Falhas de sandbox/entitlement/task port devem aparecer no diagnóstico.
