# Free Fire — PE de meia v5

This revision separates the two roles:

1. `Excalibur` remains the HUD/menu application.
2. `tweak/PEDeMeia.xm` is the in-process tweak that is filtered to
   `com.dts.freefireth`.

The in-process hook uses the Substrate-compatible `MSHookFunction` API provided
by the installed jailbreak hook layer (for example, ElleKit).

Hook target from the supplied dump:

`UnityEngine.Animator.GetBoneTransform(HumanBodyBones)`

RVA:

`0x08CDDFEC`

Mapping while enabled:

`Hips (0) -> Head (10)`
`Chest (8) -> Neck (9)`

Build HUD:
    make package

Build tweak (Dopamine/rootless):
    cd tweak
    THEOS_PACKAGE_SCHEME=rootless make package

The HUD sends `com.lgl.pedemeia.toggle` as a Darwin notification; the tweak
receives it and toggles its in-process behavior.

Runtime verification is still required for the exact installed Free Fire
binary. The supplied dump establishes the RVA and enum values, but it does
not by itself prove that the generated native ABI is identical on every
Free Fire build.
