# XternalZ v9 — HUD nativo + motor externo preservado

Esta revisão mantém os módulos existentes de processo, task, leitura Unity e ESP e substitui a camada de menu/interação.

## Arquitetura

```text
Global HID/AX
     |
     v
TSEventFetcher
     |
     v
UIKit UIEvent
     |
     v
HUDMainWindow -> HUDRootViewController -> MenuView (UIKit)
                                      |
                                      +-> Teste / existing read path
                                      +-> ESP state bridge

Existing engine (unchanged in purpose)
     |
     +-> tasks/pid.mm
     +-> functions/Teste.mm / Offsets.h
     +-> unity/unity.mm
     +-> overlay/ESPImGuiView.mm
     +-> hooks/CaptainHook.h (header retained)
```

## O que mudou

- `menu/menu.m` não cria mais um `MTKView` fullscreen nem usa `gMenuWindowRect` para decidir toque.
- O menu agora é uma árvore UIKit normal (`UIView`, `UIButton`, `UISwitch`, `UIScrollView`, `UIStackView`).
- O painel possui tamanho real e é o próprio alvo do `hitTest:`; áreas externas continuam passando através da `HUDMainWindow`.
- O painel pode ser arrastado pelo cabeçalho com `UIPanGestureRecognizer`.
- A orientação reposiciona/redimensiona o painel sem aplicar a antiga rotação manual da superfície fullscreen.
- `HUDApp.mm` segue a divisão de eventos do TrollSpeed: AX em versões modernas e fallback `_enqueueHIDEvent:` quando necessário.
- `TSEventFetcher.mm` foi refeito para manter um `UITouch` por `pathIdentity` e entregar cada amostra no main thread, eliminando os slots globais únicos `toRemove`/`toStationarify`.
- A checagem LaunchServices agora usa o bundle identifier real `com.xternalz.app` presente no `Info.plist`.

## O que não foi reescrito

Os arquivos de leitura e transformação permanecem como estavam em propósito e estrutura:

- `tasks/pid.mm`
- `functions/Teste.mm`
- `functions/Offsets.h`
- `unity/unity.mm`
- `overlay/ESPImGuiView.mm`

O código Dear ImGui também continua no projeto para compatibilidade, mas não é mais o host do menu principal.

## Observação sobre hooks

O ZIP original contém `hooks/CaptainHook.h`, mas a análise do código não encontrou call-sites ativos de `CHMethod`, `CHConstructor` ou `MSHookMessageEx` fora do próprio header/import legado. Portanto, esta revisão preserva o suporte/arquivo existente, mas não inventa hooks que não estavam implementados no ZIP.

## Build

O projeto continua com Theos e deployment target iOS 15.0. O ambiente de análise Linux não contém um SDK iPhoneOS/Theos configurado, então esta revisão foi validada estruturalmente (plists, referências e fontes) e não deve ser apresentada como um binário já compilado.

## Touch-routing fix

- `HUDMainWindow` delegates hit-testing to `HUDRootViewController` so the full-screen bookkeeping views cannot consume touch events outside the real interactive menu/hotspot.
- `_contentView` and `_blurView` are explicitly non-interactive.
- The global window is created with `_initWithFrame:attached:YES` and ordered to the front instead of being made the ordinary application key window.
- Synthetic touch delivery uses a main-run-loop source and refreshes the KIF HID representation after every location/phase mutation.

## Build-integrity fixes in this revision

- `HUDApp.mm` now types `AXEventHandInfoRepresentation`/`AXEventPathInfoRepresentation` explicitly before reading `pathIdentity`.
- `HUDMainApplication.mm` checks every `posix_spawn` return before using the child PID/status.
- `TSEventFetcher.mm` explicitly includes `<cstring>` for `memset`.
- `tasks/pid.mm` explicitly includes `<algorithm>` for `std::min`, releases the processor-set task array on early match, bounds the remote image count and guarantees NUL termination of remote paths.
- The native menu uses a single scroll-content stack, eliminating overlapping tab edge constraints.
- The legacy Metal/ImGui host remains in the tree but is not compiled by the active target.


## Build-integrity follow-up

The HUD input path now preserves the full AX pointer identity and serializes synthetic touch delivery on the main thread. The Objective-C test bridge uses `BOOL` so it can be imported from `.m` files, and the package metadata no longer contains the stale TrollSpeed launch-daemon executable path.
