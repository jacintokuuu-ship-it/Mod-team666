# ARCHITECTURE.md

```text
UIKit HUD/Menu
      │
      ├── toggle/state
      │
      └── Renderer (main thread)
              ▲
              │ immutable snapshot
              │
      External Reader worker
              │
              ├── process discovery
              ├── task acquisition
              ├── UnityFramework discovery
              ├── read-only validation
              └── snapshot publication
```

## Regra
O renderer nunca executa chamadas Mach pesadas. `ESPExternalReadSnapshot()` devolve o último snapshot e agenda atualização em background quando necessário.

## Limitação estrutural atual
O ZIP fornecido não contém a dump estrutural mencionada pelo projeto. Portanto a enumeração real de entidades/câmera/W2S não é declarada como confirmada. O código não executa métodos Unity remotamente como substituto.
