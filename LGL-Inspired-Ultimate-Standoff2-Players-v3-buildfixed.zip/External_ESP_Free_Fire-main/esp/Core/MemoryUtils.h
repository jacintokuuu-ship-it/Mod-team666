#ifndef MemoryUtils_h
#define MemoryUtils_h

#include <mach/mach.h>
#include <sys/sysctl.h>
#include <stdint.h>
#include <string>

#pragma mark - Remote task state

static mach_port_t get_task = MACH_PORT_NULL;
static pid_t Processpid = -1;

extern "C" kern_return_t mach_vm_region_recurse(vm_map_t                 map,
                                                mach_vm_address_t        *address,
                                                mach_vm_size_t            *size,
                                                uint32_t                 *depth,
                                                vm_region_recurse_info_t info,
                                                mach_msg_type_number_t   *infoCnt);

// The old code rejected valid arm64/arm64e user addresses above 0x1600000000.
// Keep the low-address guard, but let the kernel validate the actual mapping.
inline bool isVaildPtr(uint64_t addr) {
    return addr >= 0x100000000ULL && addr < 0x0000800000000000ULL;
}

pid_t GetGameProcesspid(const char *GameProcessName);
vm_map_offset_t GetGameModule_Base(const char *GameProcessName,
                                   const char *ModuleName = nullptr);
bool _read(uint64_t addr, void *buffer, size_t len);


template<typename T>
T ReadAddr(uint64_t address) {
    T data{};
    _read(address, reinterpret_cast<void *>(&data), sizeof(T));
    return data;
}

#endif
