#import "MemoryUtils.h"

#include <mach-o/dyld_images.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <stdio.h>

static bool ReadRemote(vm_address_t address, void *buffer, size_t len) {
    if (get_task == MACH_PORT_NULL || buffer == nullptr || len == 0) {
        return false;
    }

    mach_vm_size_t outSize = 0;
    kern_return_t kr = mach_vm_read_overwrite(
        get_task,
        (mach_vm_address_t)address,
        (mach_vm_size_t)len,
        (mach_vm_address_t)buffer,
        &outSize
    );

    return kr == KERN_SUCCESS && outSize == len;
}

static bool ReadRemoteCString(vm_address_t address, char *buffer, size_t capacity) {
    if (address == 0 || buffer == nullptr || capacity < 2) {
        return false;
    }

    for (size_t i = 0; i < capacity - 1; ++i) {
        char c = '\0';
        if (!ReadRemote(address + i, &c, sizeof(c))) {
            buffer[0] = '\0';
            return false;
        }

        buffer[i] = c;
        if (c == '\0') {
            return true;
        }
    }

    buffer[capacity - 1] = '\0';
    return true;
}

pid_t GetGameProcesspid(const char *GameProcessName) {
    if (GameProcessName == nullptr || GameProcessName[0] == '\0') {
        return -1;
    }

    size_t length = 0;
    static const int name[] = {CTL_KERN, KERN_PROC, KERN_PROC_ALL, 0};

    int err = sysctl(
        (int *)name,
        (sizeof(name) / sizeof(*name)) - 1,
        nullptr,
        &length,
        nullptr,
        0
    );

    if (err != 0) {
        return -1;
    }

    if (length == 0 || length > 64 * 1024 * 1024) {
        return -1;
    }

    struct kinfo_proc *procBuffer =
        (struct kinfo_proc *)malloc(length);

    if (procBuffer == nullptr) {
        return -1;
    }

    err = sysctl(
        (int *)name,
        (sizeof(name) / sizeof(*name)) - 1,
        procBuffer,
        &length,
        nullptr,
        0
    );

    if (err != 0) {
        free(procBuffer);
        return -1;
    }

    int count = (int)(length / sizeof(struct kinfo_proc));
    pid_t result = -1;

    for (int i = 0; i < count; ++i) {
        const char *procname = procBuffer[i].kp_proc.p_comm;

        if (procname == nullptr) {
            continue;
        }

        // Match the Free Fire process requested by the project.
        // Case-insensitive matching makes this robust to launcher/build variants.
        if (strcasecmp(procname, GameProcessName) == 0 ||
            strcasestr(procname, GameProcessName) != nullptr) {
            result = procBuffer[i].kp_proc.p_pid;
            break;
        }
    }

    free(procBuffer);
    return result;
}

static bool AttachToProcess(const char *GameProcessName) {
    pid_t pid = GetGameProcesspid(GameProcessName);

    if (pid <= 0) {
        Processpid = -1;
        return false;
    }

    // Reuse the existing task port when the PID has not changed.
    if (Processpid == pid && get_task != MACH_PORT_NULL) {
        return true;
    }

    if (get_task != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), get_task);
        get_task = MACH_PORT_NULL;
    }

    Processpid = pid;

    kern_return_t kr = task_for_pid(
        mach_task_self(),
        pid,
        &get_task
    );

    if (kr != KERN_SUCCESS || get_task == MACH_PORT_NULL) {
        get_task = MACH_PORT_NULL;
        fprintf(stderr,
                "[ExternalESP] task_for_pid(%d) failed: %s (%d)\n",
                pid,
                mach_error_string(kr),
                kr);
        return false;
    }

    fprintf(stderr,
            "[ExternalESP] attached to freefireth pid=%d\n",
            pid);

    return true;
}

vm_map_offset_t GetGameModule_Base(const char *GameProcessName,
                                   const char *ModuleName) {
    if (!AttachToProcess(GameProcessName)) {
        return 0;
    }

    task_dyld_info_data_t dyldInfo{};
    mach_msg_type_number_t count = TASK_DYLD_INFO_COUNT;

    kern_return_t kr = task_info(
        get_task,
        TASK_DYLD_INFO,
        (task_info_t)&dyldInfo,
        &count
    );

    if (kr != KERN_SUCCESS || dyldInfo.all_image_info_addr == 0) {
        fprintf(stderr,
                "[ExternalESP] TASK_DYLD_INFO failed: %s (%d)\n",
                mach_error_string(kr),
                kr);
        return 0;
    }

    dyld_all_image_infos infos{};

    if (!ReadRemote(
            (vm_address_t)dyldInfo.all_image_info_addr,
            &infos,
            sizeof(infos))) {
        fprintf(stderr, "[ExternalESP] failed reading dyld image info\n");
        return 0;
    }

    uint32_t imageCount = infos.infoArrayCount;

    // Sanity limit protects against corrupted data causing an enormous loop.
    if (imageCount == 0 || imageCount > 4096 || infos.infoArray == nullptr) {
        fprintf(stderr,
                "[ExternalESP] invalid image count: %u\n",
                imageCount);
        return 0;
    }

    size_t arrayBytes = sizeof(dyld_image_info) * (size_t)imageCount;
    dyld_image_info *images =
        (dyld_image_info *)calloc(imageCount, sizeof(dyld_image_info));

    if (images == nullptr) {
        return 0;
    }

    bool arrayOK = ReadRemote(
        (vm_address_t)infos.infoArray,
        images,
        arrayBytes
    );

    if (!arrayOK) {
        free(images);
        fprintf(stderr, "[ExternalESP] failed reading dyld image array\n");
        return 0;
    }

    vm_map_offset_t fallbackBase = 0;
    const char *wantedModule = ModuleName;

    for (uint32_t i = 0; i < imageCount; ++i) {
        if (images[i].imageLoadAddress == nullptr ||
            images[i].imageFilePath == nullptr) {
            continue;
        }

        char path[1024] = {0};
        if (!ReadRemoteCString(
                (vm_address_t)images[i].imageFilePath,
                path,
                sizeof(path))) {
            continue;
        }

        if (wantedModule != nullptr &&
            wantedModule[0] != '\0' &&
            strcasestr(path, wantedModule) != nullptr) {
            vm_map_offset_t base =
                (vm_map_offset_t)images[i].imageLoadAddress;

            fprintf(stderr,
                    "[ExternalESP] %s base = 0x%llx\n",
                    wantedModule,
                    (unsigned long long)base);

            free(images);
            return base;
        }

        // Fallback: the main executable for freefireth.
        if (strcasestr(path, GameProcessName) != nullptr) {
            fallbackBase =
                (vm_map_offset_t)images[i].imageLoadAddress;
        }
    }

    free(images);

    if (fallbackBase != 0) {
        fprintf(stderr,
                "[ExternalESP] fallback %s base = 0x%llx\n",
                GameProcessName,
                (unsigned long long)fallbackBase);
    } else {
        fprintf(stderr,
                "[ExternalESP] module not found: %s\n",
                wantedModule ? wantedModule : "(main executable)");
    }

    return fallbackBase;
}

bool _read(uint64_t addr, void *buffer, size_t len) {
    if (!isVaildPtr(addr) || buffer == nullptr || len == 0) {
        return false;
    }

    return ReadRemote((vm_address_t)addr, buffer, len);
}
