#import "esp.h"

#define sWidth  [UIScreen mainScreen].bounds.size.width
#define sHeight [UIScreen mainScreen].bounds.size.height

@interface ESP_View ()
@property (nonatomic, strong) NSMutableArray<CALayer *> *layers;
@property (nonatomic, strong) CADisplayLink *displayLink;
@property (nonatomic, strong) CADisplayLink *displayLinkDATA;
@property (nonatomic, strong) NSArray<NSValue *> *boxesData;
@end

static uint64_t Module_Base = 0;
static CFTimeInterval LastModuleLookup = 0;

static void ClearESPBoxes(ESP_View *view) {
    view.boxes = @[];
}

@implementation ESP_View

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.layers = [NSMutableArray array];
        self.backgroundColor = [UIColor clearColor];
        self.opaque = NO;
        self.userInteractionEnabled = NO;

        // Do not resolve the game module only once here. The HUD can be
        // launched before Free Fire, so resolution is retried while running.
        Module_Base = 0;
        LastModuleLookup = 0;

        self.displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(updateBoxes)];
        [self.displayLink addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];

        self.displayLinkDATA = [CADisplayLink displayLinkWithTarget:self selector:@selector(update_data)];
        self.displayLinkDATA.preferredFramesPerSecond = 30;
        [self.displayLinkDATA addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    if (self.superview) {
        self.frame = self.superview.bounds;
    }
    [self updateBoxes];
}

- (void)setBoxes:(NSArray<NSValue *> *)boxes
{
    _boxesData = [boxes copy];
    [self updateBoxes];
}

- (void)updateBoxes {
    if (!self.window) return;

    NSUInteger count = self.boxesData.count;

    while (self.layers.count < count)
    {
        CALayer *layer = [CALayer layer];
        layer.borderColor = [UIColor colorWithRed:1 green:0 blue:0 alpha:0.8].CGColor;
        layer.borderWidth = 2.0;
        layer.cornerRadius = 3.0;
        [self.layer addSublayer:layer];
        [self.layers addObject:layer];
    }

    for (NSUInteger i = 0; i < self.layers.count; i++)
    {
        CALayer *layer = self.layers[i];

        if (i < count)
        {
            ESPBox box;
            [self.boxesData[i] getValue:&box];
            layer.hidden = NO;

            [CATransaction begin];
            [CATransaction setDisableActions:YES];
            layer.frame = CGRectMake(box.pos.x, box.pos.y, box.width, box.height);
            [CATransaction commit];
        }
        else
        {
            layer.hidden = YES;
        }
    }
}

- (void)dealloc {
    [self.displayLink invalidate];
    [self.displayLinkDATA invalidate];
    self.displayLink = nil;
    self.displayLinkDATA = nil;
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)update_data
{
    if (!self.window) return;

    CGSize size = self.bounds.size;
    if (size.width <= 1.0 || size.height <= 1.0) {
        ClearESPBoxes(self);
        return;
    }

    // The original project cached the module base during init. If the game
    // was not running yet, the cache stayed invalid forever. Retry instead.
    CFTimeInterval now = CACurrentMediaTime();
    if (!isVaildPtr(Module_Base) ||
        Module_Base == 0) {
        if (now - LastModuleLookup >= 0.50) {
            LastModuleLookup = now;

            // The gameplay offsets in this project are for UnityFramework,
            // while Free Fire remains the target process.
            Module_Base = (uint64_t)GetGameModule_Base(
                "freefireth",
                "UnityFramework"
            );

            if (!isVaildPtr(Module_Base)) {
                ClearESPBoxes(self);
                return;
            }

            NSLog(@"[ExternalESP] Free Fire found, UnityFramework = 0x%llx",
                  (unsigned long long)Module_Base);
        }
        else {
            ClearESPBoxes(self);
            return;
        }
    }

    uint64_t matchGame = getMatchGame(Module_Base);
    if (!isVaildPtr(matchGame)) {
        ClearESPBoxes(self);
        return;
    }

    uint64_t camera = CameraMain(matchGame);
    if (!isVaildPtr(camera)) {
        ClearESPBoxes(self);
        return;
    }

    uint64_t match = getMatch(matchGame);
    if (!isVaildPtr(match)) {
        ClearESPBoxes(self);
        return;
    }

    uint64_t myPawnObject = getLocalPlayer(match);
    if (!isVaildPtr(myPawnObject)) {
        ClearESPBoxes(self);
        return;
    }

    uint64_t mainCameraTransform =
        ReadAddr<uint64_t>(myPawnObject + 0x2B0);

    if (!isVaildPtr(mainCameraTransform)) {
        ClearESPBoxes(self);
        return;
    }

    Vector3 myLocation = getPositionExt(mainCameraTransform);

    uint64_t player = ReadAddr<uint64_t>(match + 0xC8);
    if (!isVaildPtr(player)) {
        ClearESPBoxes(self);
        return;
    }

    uint64_t tValue = ReadAddr<uint64_t>(player + 0x28);
    if (!isVaildPtr(tValue)) {
        ClearESPBoxes(self);
        return;
    }

    int countValue = ReadAddr<int>(tValue + 0x18);

    // Refuse obviously corrupt collections.
    if (countValue <= 0 || countValue > 256) {
        ClearESPBoxes(self);
        return;
    }

    float *matrix = GetViewMatrix(camera);
    if (matrix == nullptr) {
        ClearESPBoxes(self);
        return;
    }

    NSMutableArray<NSValue *> *boxesMutable =
        [NSMutableArray arrayWithCapacity:MIN((NSInteger)countValue, 32)];

    int countObject = 0;

    for (int i = 0; i < countValue; i++) {
        uint64_t PawnObject =
            ReadAddr<uint64_t>(tValue + 0x20 + 8ULL * (uint64_t)i);

        if (!isVaildPtr(PawnObject)) continue;

        if (isLocalTeamMate(myPawnObject, PawnObject)) continue;

        NSString *Name = GetNickName(PawnObject);
        if (Name.length == 0) continue;

        int CurHP = get_CurHP(PawnObject);
        int MaxHP = get_MaxHP(PawnObject);

        // Keep these reads alive for the existing logic / future rendering.
        (void)CurHP;
        (void)MaxHP;

        uint64_t headNode = getHead(PawnObject);
        uint64_t toeNode = getRightToeNode(PawnObject);

        if (!isVaildPtr(headNode) || !isVaildPtr(toeNode)) continue;

        Vector3 HeadLocation = getPositionExt(headNode);
        HeadLocation.y += 0.2f;

        Vector3 RightToePos = getPositionExt(toeNode);

        Vector3 w2sHeadLocation =
            WorldToScreen(HeadLocation, matrix, sWidth, sHeight);
        Vector3 w2sRightToePos =
            WorldToScreen(RightToePos, matrix, sWidth, sHeight);

        float dis = Vector3::Distance(myLocation, HeadLocation);
        if (dis <= 0.0f || dis > 220.0f) continue;

        float boxHeight = fabsf(w2sHeadLocation.y - w2sRightToePos.y);
        if (boxHeight < 8.0f || boxHeight > sHeight * 1.5f) continue;

        float boxWidth = boxHeight * 0.5f;
        float x = w2sHeadLocation.x - boxWidth * 0.5f;
        float y = MIN(w2sHeadLocation.y, w2sRightToePos.y);

        // Avoid putting invalid geometry into Core Animation.
        if (!isfinite(x) || !isfinite(y) ||
            !isfinite(boxWidth) || !isfinite(boxHeight)) {
            continue;
        }

        if (x > sWidth || x + boxWidth < 0 ||
            y > sHeight || y + boxHeight < 0) {
            continue;
        }

        ESPBox espBox;
        espBox.pos.x = x;
        espBox.pos.y = y;
        espBox.width = boxWidth;
        espBox.height = boxHeight;

        NSValue *val =
            [NSValue valueWithBytes:&espBox objCType:@encode(ESPBox)];

        [boxesMutable addObject:val];
        countObject++;
    }

    NSLog(@"[ExternalESP] Players: %d | boxes: %lu",
          countObject,
          (unsigned long)boxesMutable.count);

    self.boxes = boxesMutable;
}

@end
