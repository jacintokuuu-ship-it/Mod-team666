# ESP externo — 3 testes com offsets confiáveis

Esta revisão usa somente os RVAs/offsets confirmados nos arquivos enviados nesta conversa. A cadeia antiga de `PlayerManager`, campos `+0x98/+0xB0/+0x44`, matrizes antigas e equivalentes foi removida do caminho ativo.

## Os 3 testes

**ESP 1**
`Player::GetTransformNode 0x5735538` → `ITransformNode::get_transform 0x890EFE4` → `Transform::get_position 0x8D6C1EC` → `Camera::get_main 0x8CFF0B4` → `Camera::WorldToScreenPoint 0x8CFE9C0`

**ESP 2**
`Player::GetTransformNode 0x5735538` → `TransformNode::get_transform 0x6B4964C` → `Transform::get_position 0x8D6C1EC` → mesma projeção confirmada.

**ESP 3**
`Player::GetTransformNode 0x5735538` → `BFOONIGAIFK::get_transform 0x581FB80` → `Transform::get_position 0x8D6C1EC` → mesma projeção confirmada.

O HUD (`Excalibur`) desenha a linha a partir do centro inferior da tela. O componente que observa os métodos dentro do jogo publica apenas as coordenadas resultantes para o HUD por memória compartilhada POSIX.

## Como testar

1. Compile e instale o `Excalibur`.
2. Compile/instale o tweak `PEDeMeiaFF` com o mesmo alvo do jogo.
3. Abra o menu e use **ESP 1**, depois **ESP 2**, depois **ESP 3**.
4. O cartão `ESP STATUS` mostra contadores separados para `node`, `T1/T2/T3`, `pos`, `cam`, `W2S` e a máscara dos hooks.

Uma linha só é desenhada quando há posição válida e projeção com profundidade positiva. A conversão vertical Unity → UIKit é feita como `altura - y`.

## O que permanece deliberadamente pendente

Não são usados offsets não confirmados para `local player`, filtro de time, getter de `Entity.Position`, herança completa de `Player` ou argumento `string` de `GetTransformNode`. Eles ficam fora do caminho de teste justamente para não reintroduzir dados antigos.

## Build GitHub Actions

O workflow foi preparado para gerar o app e também o pacote do tweak. O ambiente do workflow instala Theos + iPhoneOS 15.6 SDK antes dos dois builds.
