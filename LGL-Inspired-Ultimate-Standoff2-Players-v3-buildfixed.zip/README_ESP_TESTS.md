# ESP 1/2/3 — teste por alavanca

O projeto não possui mais a função PE de meia.

Cada teste tem sua própria alavanca no menu nativo. Apenas uma rota pode ficar ativa por vez.

## ESP 1
Player::GetTransformNode `0x5735538` → campo `TransformNode.transform +0x10` → `Transform::get_position 0x8D6C1EC` → `Camera::get_main 0x8CFF0B4` → `Camera::WorldToScreenPoint 0x8CFE9C0`.

Este substitui o teste anterior que dependia de `ITransformNode::get_transform`.

## ESP 2
Player::GetTransformNode `0x5735538` → `TransformNode::get_transform 0x6B4964C` → posição/projeção confirmadas acima.

## ESP 3
Player::GetTransformNode `0x5735538` → `BFOONIGAIFK::get_transform 0x581FB80` → posição/projeção confirmadas acima.

Nenhum PlayerManager antigo, matriz antiga ou offset de player antigo é utilizado.


## Player count — AERO mechanism

The current dump exposes a much stronger semantic route than the previous
synthetic zero-count diagnostic:

```text
GameFacade.get_UIModelSpectator()
        RVA 0x5933D60
              |
              v
UIModelSpectator*              (resolved from the remote getter code)
              |
           +0x30
              |
              v
m_PlayerDic : Dictionary<BEADLMGGGGL, PlayerData>
              |
           +0x20
              |
              v
Dictionary.Count  -> JOGADORES
```

The dump places `m_UIModelSpectator` in `GameFacade` at static field offset
`0x320`, exposes `get_UIModelSpectator()`, and places `m_PlayerDic` at
`UIModelSpectator +0x30`. It also exposes `UIModelSpectator.GetPlayerCount()`
at RVA `0x48F8C34`.

The external reader does not invoke target-process code. It reads the getter
machine code conservatively to recover the returned object pointer, then
reads the backing dictionary and its `Count` field. A JMAG collection fallback
is retained only as a diagnostic when the UIModelSpectator route cannot be
resolved.

This means the project can now display a live player-count candidate instead
of the previous hard-coded `0` snapshot.
