# ESP 1/2/3 — teste por alavanca

O projeto não possui mais a função PE de meia.

Cada teste tem sua própria alavanca no menu nativo. Apenas uma rota pode ficar ativa por vez.

## ESP 1
A rota externa ativa usa `GameFacade.get_UIModelSpectator 0x5933D60` → `GetLivePlayerByTeamIdAndPlayerIndex 0x48F86B8` → `Player.GetAttackableCenterWS 0x56300E8` → `Camera.get_main 0x8CFF0B4` → `Camera.WorldToScreenPoint 0x8CFE9C0`.

A cadeia `GetTransformNode` continua retida como caminho de referência e diagnóstico, sem ser usada como atalho inventado.

Este substitui o teste anterior que dependia de `ITransformNode::get_transform`.

## ESP 2/3
Mantidos no header de offsets como rotas alternativas de investigação. A rota funcional ativa não depende deles.

Nenhum PlayerManager antigo, matriz antiga ou offset de player antigo é utilizado.
