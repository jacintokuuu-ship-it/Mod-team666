# Free Fire target

- Process: `FreeFire`
- Bundle identifier: `com.dts.freefireth`
- Main image: `UnityFramework` for the Animator hook
- PE de meia hook: `UnityEngine.Animator.GetBoneTransform(HumanBodyBones)`
- RVA: `0x08CDDFEC`

Legacy player-count offsets from the old target are not used by the PE de meia
implementation.
