# Free Fire target — external mode

- Process: `FreeFire`
- Bundle identifier: `com.dts.freefireth`
- Main image used for the supplied Unity RVAs: `UnityFramework`

The project remains external-only. The RVAs are treated as addresses inside `UnityFramework`. The live ESP reader uses the existing `task_for_pid`/Mach task path to create a transient collector thread, call the supplied getters, copy a compact screen-space snapshot back, and terminate that thread. No persistent hook or injected dylib is installed.
