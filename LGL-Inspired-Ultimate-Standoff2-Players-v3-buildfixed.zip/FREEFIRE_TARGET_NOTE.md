# Free Fire target update

The runtime process/image identification was changed from Standoff 2 to:

- Process: `FreeFire`
- Bundle identifier: `com.dts.freefireth`
- Main executable/image: `FreeFire`

The supplied source did not include a Free Fire dump containing the PlayerManager/
player-count structures or verified Free Fire offsets. Therefore the legacy
player-count offsets were not fabricated or numerically changed. A real
Free Fire player-count implementation requires the matching Free Fire dump
and offsets.
