# PROJETINpai External HUD v6

This build treats the project as a TrollStore-installed external HUD, not as a normal foreground app.

## Architecture
- Controller process launches a dedicated `-hud` process.
- HUD process is spawned with the existing TrollStore persona/root entitlement path enabled.
- HUD registers its window with `SBSAccessibilityWindowHostingController`, following the global-HUD pattern used by TrollSpeed/AssistiveTouch-style TrollStore projects.
- Window level is kept above ordinary application windows.
- No `TSEventFetcher`, artificial `UITouch`, IOHID replay, or global touch interception is used.
- The menu's actual hit region is the only interactive region; outside it the overlay returns `nil` so the foreground application receives the touch.

## Important limitation
The hosting mechanism is a privileged system overlay path, but iOS can still place certain system-owned surfaces (lock screen, Control Center, notifications, keyboards, protected UI) above third-party HUDs.

## Sources studied
- Lessica/TrollSpeed: privileged HUD process + AssistiveTouch-style entitlements/hosting model.
- leminlimez/Helium: TrollStore global widget/HUD model and iOS 15 testing.
- silentninjabee/iOS-ImGui-ModMenu-Template: ImGui + Metal + Theos menu architecture.
- joeyjurjens/iOS-Mod-Menu-Template-for-Theos: reusable menu control patterns.

The project keeps its original ESP/ImGui/functions/unity modules; this revision changes the external HUD and input plumbing rather than replacing those modules.
