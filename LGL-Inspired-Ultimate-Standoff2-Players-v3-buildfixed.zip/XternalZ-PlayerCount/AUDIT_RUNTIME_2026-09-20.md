

## Final static checks

- `audit_project.sh`: PASS
- `verify_player_count.sh`: PASS
- `scripts/verify_sdk_contract.sh`: PASS
- Bash syntax: PASS
- C++17 syntax for `Offsets.h`, `ESPExternalShared.h`, and `Vector3.h`: PASS
- `menu/menu.m` no longer assigns `CGColorRef` to `UIColor *`.
- No active `setObject:forKey:inDomain:` call remains.
- No active source uses the three legacy event files.
