#!/bin/bash
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT_DIR"

if grep -REn --include='*.m' --include='*.mm' --include='*.h' --include='*.pch' \
  'setObject:@YES[[:space:]]+forKey:@"[^"]+"[[:space:]]+inDomain:' . >/tmp/xz_sdk_contract_bad 2>/dev/null; then
    echo "ERROR: unsupported private NSUserDefaults UIKit logging call(s):"
    cat /tmp/xz_sdk_contract_bad
    rm -f /tmp/xz_sdk_contract_bad
    exit 1
fi
rm -f /tmp/xz_sdk_contract_bad
echo "SDK contract: PASS"
