#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
python3 - "$ROOT_DIR" <<'PY'
import re, sys
from pathlib import Path
root = Path(sys.argv[1])
call = re.compile(r'\]\s*setObject:@YES\s+forKey:@"[^"]+"\s+inDomain:@"com\.apple\.UIKit"\s*;')
bad = []
for p in root.rglob("*"):
    if p.is_file() and p.suffix in {".m", ".mm", ".h", ".pch"}:
        s = p.read_text(encoding="utf-8", errors="ignore")
        # Remove comments so documentation doesn't trigger the guard.
        s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
        s = re.sub(r'//.*', '', s)
        if call.search(s):
            bad.append(str(p.relative_to(root)))
if bad:
    print("ERROR: unsupported private NSUserDefaults UIKit logging call(s):")
    for p in bad:
        print("  " + p)
    raise SystemExit(1)
print("SDK contract: PASS")
PY
