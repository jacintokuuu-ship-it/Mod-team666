#import "menu.h"
#import "../include/HUDBridge.h"
#import <QuartzCore/QuartzCore.h>
#include <math.h>

static UIColor *MakterAccentColor(void)
{
    if (@available(iOS 13.0, *)) return [UIColor systemOrangeColor];
    return [UIColor colorWithRed:1.0 green:0.42 blue:0.08 alpha:1.0];
}

static CGFloat MakterClamp(CGFloat value, CGFloat minValue, CGFloat maxValue)
{
    if (maxValue < minValue) {
        CGFloat tmp = minValue;
        minValue = maxValue;
        maxValue = tmp;
    }
    return MIN(MAX(value, minValue), maxValue);
}

@interface MenuView () <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIVisualEffectView *materialView;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UIView *statusDot;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIView *functionRow;
@property (nonatomic, strong) UISwitch *playerCountSwitch;
@property (nonatomic, strong) UILabel *playerCountStatusLabel;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) UIPanGestureRecognizer *headerPanGesture;
@property (nonatomic, assign) CGPoint panStartCenter;
@property (nonatomic, assign) BOOL hasUserPosition;
@property (nonatomic, assign) UIInterfaceOrientation currentOrientation;
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, assign) NSInteger directTouchPointerId;
@property (nonatomic, assign) CGPoint directTouchStartPoint;
@property (nonatomic, assign) CGPoint directTouchStartCenter;
@property (nonatomic, assign) CGPoint directTouchStartContentOffset;
@property (nonatomic, assign) BOOL directTouchDragging;
@property (nonatomic, assign) NSInteger directTouchMode;
@end

enum {
    kDirectTouchNone = 0,
    kDirectTouchHeaderDrag = 1,
    kDirectTouchClose = 2,
    kDirectTouchContent = 3
};

@implementation MenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (!self) return nil;

    _currentOrientation = UIInterfaceOrientationPortrait;
    _directTouchPointerId = -1;
    _directTouchMode = kDirectTouchNone;
    _directTouchDragging = NO;

    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.clipsToBounds = NO;
    self.userInteractionEnabled = YES;
    self.multipleTouchEnabled = YES;

    if (@available(iOS 13.0, *)) {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:
                         [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]];
    } else {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:nil];
        _materialView.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.98];
    }
    _materialView.translatesAutoresizingMaskIntoConstraints = NO;
    _materialView.layer.cornerRadius = 18.0;
    _materialView.clipsToBounds = YES;
    [self addSubview:_materialView];

    UIView *border = [[UIView alloc] init];
    border.translatesAutoresizingMaskIntoConstraints = NO;
    border.userInteractionEnabled = NO;
    border.backgroundColor = UIColor.clearColor;
    border.layer.cornerRadius = 18.0;
    border.layer.borderWidth = 0.8;
    border.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.14].CGColor;
    [_materialView.contentView addSubview:border];

    _headerView = [[UIView alloc] init];
    _headerView.translatesAutoresizingMaskIntoConstraints = NO;
    [_materialView.contentView addSubview:_headerView];

    _titleLabel = [[UILabel alloc] init];
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLabel.text = @"PLAYER COUNT LAB";
    _titleLabel.textColor = UIColor.whiteColor;
    _titleLabel.font = [UIFont systemFontOfSize:16.5 weight:UIFontWeightBold];
    [_headerView addSubview:_titleLabel];

    _subtitleLabel = [[UILabel alloc] init];
    _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _subtitleLabel.text = @"6 ROTAS DE DIAGNOSTICO EXTERNO";
    _subtitleLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.48];
    _subtitleLabel.font = [UIFont systemFontOfSize:8.0 weight:UIFontWeightSemibold];
    [_headerView addSubview:_subtitleLabel];

    _statusDot = [[UIView alloc] init];
    _statusDot.translatesAutoresizingMaskIntoConstraints = NO;
    _statusDot.layer.cornerRadius = 4.0;
    [_headerView addSubview:_statusDot];

    _statusLabel = [[UILabel alloc] init];
    _statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _statusLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.58];
    _statusLabel.font = [UIFont systemFontOfSize:8.0 weight:UIFontWeightSemibold];
    [_headerView addSubview:_statusLabel];

    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _closeButton.translatesAutoresizingMaskIntoConstraints = NO;
    _closeButton.tintColor = UIColor.whiteColor;
    _closeButton.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.08];
    _closeButton.layer.cornerRadius = 15.0;
    [_closeButton setTitle:@"−" forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:20.0 weight:UIFontWeightMedium];
    [_closeButton addTarget:self action:@selector(closePressed:) forControlEvents:UIControlEventTouchUpInside];
    [_headerView addSubview:_closeButton];

    _scrollView = [[UIScrollView alloc] init];
    _scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.delaysContentTouches = NO;
    [_materialView.contentView addSubview:_scrollView];

    UIView *content = [[UIView alloc] init];
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [_scrollView addSubview:content];

    UILabel *section = [[UILabel alloc] init];
    section.translatesAutoresizingMaskIntoConstraints = NO;
    section.text = @"LEITOR DE JOGADORES";
    section.textColor = MakterAccentColor();
    section.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightBold];
    [content addSubview:section];

    _functionRow = [[UIView alloc] init];
    _functionRow.translatesAutoresizingMaskIntoConstraints = NO;
    _functionRow.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    _functionRow.layer.cornerRadius = 13.0;
    [content addSubview:_functionRow];

    UILabel *functionTitle = [[UILabel alloc] init];
    functionTitle.translatesAutoresizingMaskIntoConstraints = NO;
    functionTitle.text = @"DIAGNOSTICO — 6 METODOS";
    functionTitle.textColor = UIColor.whiteColor;
    functionTitle.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightSemibold];
    [_functionRow addSubview:functionTitle];

    UILabel *functionSubtitle = [[UILabel alloc] init];
    functionSubtitle.translatesAutoresizingMaskIntoConstraints = NO;
    functionSubtitle.text = @"Todos executados em paralelo a cada leitura";
    functionSubtitle.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.50];
    functionSubtitle.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightRegular];
    [_functionRow addSubview:functionSubtitle];

    _playerCountSwitch = [[UISwitch alloc] init];
    _playerCountSwitch.translatesAutoresizingMaskIntoConstraints = NO;
    _playerCountSwitch.onTintColor = MakterAccentColor();
    _playerCountSwitch.accessibilityLabel = @"Ativar seis metodos de contagem";
    [_playerCountSwitch addTarget:self action:@selector(playerCountSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [_functionRow addSubview:_playerCountSwitch];

    UIView *diagnosticCard = [[UIView alloc] init];
    diagnosticCard.translatesAutoresizingMaskIntoConstraints = NO;
    diagnosticCard.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.045];
    diagnosticCard.layer.cornerRadius = 13.0;
    [content addSubview:diagnosticCard];

    UILabel *diagTitle = [[UILabel alloc] init];
    diagTitle.translatesAutoresizingMaskIntoConstraints = NO;
    diagTitle.text = @"RESULTADO DAS 6 ROTAS";
    diagTitle.textColor = UIColor.whiteColor;
    diagTitle.font = [UIFont systemFontOfSize:11.5 weight:UIFontWeightSemibold];
    [diagnosticCard addSubview:diagTitle];

    UILabel *diagSubtitle = [[UILabel alloc] init];
    diagSubtitle.translatesAutoresizingMaskIntoConstraints = NO;
    diagSubtitle.text = @"C1 campo • C2 dicionario • C3/C4 UIModelMatch • C5/C6 Match";
    diagSubtitle.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.45];
    diagSubtitle.font = [UIFont systemFontOfSize:7.6 weight:UIFontWeightRegular];
    diagSubtitle.numberOfLines = 2;
    [diagnosticCard addSubview:diagSubtitle];

    _playerCountStatusLabel = [[UILabel alloc] init];
    _playerCountStatusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _playerCountStatusLabel.text = @"Contador desligado";
    _playerCountStatusLabel.textColor = UIColor.whiteColor;
    _playerCountStatusLabel.font = [UIFont monospacedSystemFontOfSize:8.0 weight:UIFontWeightMedium];
    _playerCountStatusLabel.numberOfLines = 0;
    _playerCountStatusLabel.lineBreakMode = NSLineBreakByCharWrapping;
    [diagnosticCard addSubview:_playerCountStatusLabel];

    _hintLabel = [[UILabel alloc] init];
    _hintLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _hintLabel.text = @"Ative para comparar os seis caminhos sem selecionar nenhum automaticamente.";
    _hintLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.46];
    _hintLabel.font = [UIFont systemFontOfSize:8.0 weight:UIFontWeightRegular];
    _hintLabel.numberOfLines = 3;
    [content addSubview:_hintLabel];

    [NSLayoutConstraint activateConstraints:@[
        [_materialView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_materialView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_materialView.topAnchor constraintEqualToAnchor:self.topAnchor],
        [_materialView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],

        [border.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [border.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [border.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [border.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [_headerView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_headerView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_headerView.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [_headerView.heightAnchor constraintEqualToConstant:58.0],

        [_titleLabel.leadingAnchor constraintEqualToAnchor:_headerView.leadingAnchor constant:15.0],
        [_titleLabel.topAnchor constraintEqualToAnchor:_headerView.topAnchor constant:9.0],
        [_titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:_closeButton.leadingAnchor constant:-8.0],
        [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_titleLabel.leadingAnchor],
        [_subtitleLabel.topAnchor constraintEqualToAnchor:_titleLabel.bottomAnchor constant:2.0],

        [_statusDot.leadingAnchor constraintEqualToAnchor:_subtitleLabel.trailingAnchor constant:7.0],
        [_statusDot.centerYAnchor constraintEqualToAnchor:_subtitleLabel.centerYAnchor],
        [_statusDot.widthAnchor constraintEqualToConstant:8.0],
        [_statusDot.heightAnchor constraintEqualToConstant:8.0],
        [_statusLabel.leadingAnchor constraintEqualToAnchor:_statusDot.trailingAnchor constant:4.0],
        [_statusLabel.centerYAnchor constraintEqualToAnchor:_subtitleLabel.centerYAnchor],
        [_statusLabel.trailingAnchor constraintLessThanOrEqualToAnchor:_closeButton.leadingAnchor constant:-8.0],

        [_closeButton.trailingAnchor constraintEqualToAnchor:_headerView.trailingAnchor constant:-11.0],
        [_closeButton.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_closeButton.widthAnchor constraintEqualToConstant:30.0],
        [_closeButton.heightAnchor constraintEqualToConstant:30.0],

        [_scrollView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [_scrollView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [_scrollView.topAnchor constraintEqualToAnchor:_headerView.bottomAnchor constant:2.0],
        [_scrollView.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [content.leadingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.leadingAnchor],
        [content.trailingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.trailingAnchor],
        [content.topAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.topAnchor],
        [content.bottomAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.bottomAnchor],
        [content.widthAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.widthAnchor],

        [section.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:13.0],
        [section.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-13.0],
        [section.topAnchor constraintEqualToAnchor:content.topAnchor constant:10.0],
        [section.heightAnchor constraintEqualToConstant:14.0],

        [_functionRow.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:10.0],
        [_functionRow.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-10.0],
        [_functionRow.topAnchor constraintEqualToAnchor:section.bottomAnchor constant:5.0],
        [_functionRow.heightAnchor constraintEqualToConstant:62.0],

        [functionTitle.leadingAnchor constraintEqualToAnchor:_functionRow.leadingAnchor constant:12.0],
        [functionTitle.topAnchor constraintEqualToAnchor:_functionRow.topAnchor constant:9.0],
        [functionTitle.trailingAnchor constraintLessThanOrEqualToAnchor:_playerCountSwitch.leadingAnchor constant:-8.0],
        [functionSubtitle.leadingAnchor constraintEqualToAnchor:functionTitle.leadingAnchor],
        [functionSubtitle.topAnchor constraintEqualToAnchor:functionTitle.bottomAnchor constant:2.0],
        [functionSubtitle.trailingAnchor constraintLessThanOrEqualToAnchor:_playerCountSwitch.leadingAnchor constant:-8.0],
        [_playerCountSwitch.trailingAnchor constraintEqualToAnchor:_functionRow.trailingAnchor constant:-10.0],
        [_playerCountSwitch.centerYAnchor constraintEqualToAnchor:_functionRow.centerYAnchor],

        [diagnosticCard.leadingAnchor constraintEqualToAnchor:_functionRow.leadingAnchor],
        [diagnosticCard.trailingAnchor constraintEqualToAnchor:_functionRow.trailingAnchor],
        [diagnosticCard.topAnchor constraintEqualToAnchor:_functionRow.bottomAnchor constant:8.0],
        [diagnosticCard.heightAnchor constraintEqualToConstant:250.0],

        [diagTitle.leadingAnchor constraintEqualToAnchor:diagnosticCard.leadingAnchor constant:12.0],
        [diagTitle.trailingAnchor constraintEqualToAnchor:diagnosticCard.trailingAnchor constant:-12.0],
        [diagTitle.topAnchor constraintEqualToAnchor:diagnosticCard.topAnchor constant:10.0],
        [diagSubtitle.leadingAnchor constraintEqualToAnchor:diagTitle.leadingAnchor],
        [diagSubtitle.trailingAnchor constraintEqualToAnchor:diagTitle.trailingAnchor],
        [diagSubtitle.topAnchor constraintEqualToAnchor:diagTitle.bottomAnchor constant:3.0],
        [diagSubtitle.heightAnchor constraintEqualToConstant:24.0],

        [_playerCountStatusLabel.leadingAnchor constraintEqualToAnchor:diagTitle.leadingAnchor],
        [_playerCountStatusLabel.trailingAnchor constraintEqualToAnchor:diagTitle.trailingAnchor],
        [_playerCountStatusLabel.topAnchor constraintEqualToAnchor:diagSubtitle.bottomAnchor constant:8.0],
        [_playerCountStatusLabel.bottomAnchor constraintLessThanOrEqualToAnchor:diagnosticCard.bottomAnchor constant:-9.0],

        [_hintLabel.leadingAnchor constraintEqualToAnchor:_functionRow.leadingAnchor],
        [_hintLabel.trailingAnchor constraintEqualToAnchor:_functionRow.trailingAnchor],
        [_hintLabel.topAnchor constraintEqualToAnchor:diagnosticCard.bottomAnchor constant:7.0],
        [_hintLabel.bottomAnchor constraintEqualToAnchor:content.bottomAnchor constant:-10.0]
    ]];

    _headerPanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleHeaderPan:)];
    _headerPanGesture.minimumNumberOfTouches = 1;
    _headerPanGesture.maximumNumberOfTouches = 1;
    _headerPanGesture.cancelsTouchesInView = NO;
    _headerPanGesture.delegate = self;
    [_headerView addGestureRecognizer:_headerPanGesture];

    self.alpha = 1.0;
    self.hidden = NO;
    [self updateFunctionPresentation];

    _refreshTimer = [NSTimer scheduledTimerWithTimeInterval:0.65
                                                     target:self
                                                   selector:@selector(refresh)
                                                   userInfo:nil
                                                    repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_refreshTimer forMode:NSRunLoopCommonModes];
    return self;
}

- (void)dealloc
{
    [_refreshTimer invalidate];
}

- (void)playerCountSwitchChanged:(UISwitch *)sender
{
    HUDSetPlayerCountEnabled(sender.isOn);
    if (sender.isOn) {
        _hintLabel.text = @"As seis rotas sao executadas em paralelo. Compare C1..C6 durante lobby e partida.";
    } else {
        _hintLabel.text = @"As rotas foram pausadas e o estado externo foi resetado.";
    }
    [self updateFunctionPresentation];
}

- (void)refresh
{
    if (_playerCountStatusLabel) {
        const char *status = HUDPlayerCountStatus();
        if (status && *status) {
            _playerCountStatusLabel.text = [NSString stringWithUTF8String:status];
        }
    }
    [self updateFunctionPresentation];
}

- (void)updateFunctionPresentation
{
    if (HUDPlayerCountEnabled()) {
        _statusLabel.text = @"6 ROTAS ATIVAS";
        _statusDot.backgroundColor = MakterAccentColor();
    } else {
        _statusLabel.text = @"PAUSADO";
        _statusDot.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.26];
    }
}

- (void)closePressed:(UIButton *)sender
{
    (void)sender;
    if (self.closeHandler) self.closeHandler();
    else [self hideMenu];
}

- (void)hideMenu
{
    self.userInteractionEnabled = NO;
    [UIView animateWithDuration:0.16 animations:^{
        self.alpha = 0.0;
        self.transform = CGAffineTransformMakeScale(0.97, 0.97);
    } completion:^(__unused BOOL finished) {
        self.hidden = YES;
    }];
}

- (void)showMenu
{
    self.hidden = NO;
    self.userInteractionEnabled = YES;
    self.alpha = 1.0;
    self.transform = CGAffineTransformIdentity;
    [self refresh];
}

- (void)centerMenu
{
    UIView *host = self.superview;
    if (!host) return;
    _hasUserPosition = NO;
    [self updateForOrientation:_currentOrientation];
}

- (void)updateForOrientation:(UIInterfaceOrientation)orientation
{
    if (orientation == UIInterfaceOrientationUnknown) orientation = UIInterfaceOrientationPortrait;
    _currentOrientation = orientation;

    UIView *host = self.superview;
    if (!host) return;

    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    safe = CGRectInset(safe, 8.0, 8.0);

    BOOL landscape = UIInterfaceOrientationIsLandscape(orientation);
    CGFloat desiredWidth = landscape ? 320.0 : 300.0;
    CGFloat desiredHeight = landscape ? 300.0 : 350.0;
    CGFloat availableWidth = MAX(CGRectGetWidth(safe), 1.0);
    CGFloat availableHeight = MAX(CGRectGetHeight(safe), 1.0);

    CGFloat width = MIN(desiredWidth, availableWidth);
    CGFloat height = MIN(desiredHeight, availableHeight);
    if (availableWidth >= 290.0) width = MAX(290.0, width);
    if (availableHeight >= 260.0) height = MAX(260.0, height);

    self.transform = CGAffineTransformIdentity;
    self.bounds = CGRectMake(0, 0, width, height);

    if (!_hasUserPosition) {
        self.center = CGPointMake(CGRectGetMidX(safe), CGRectGetMidY(safe));
        _hasUserPosition = YES;
    } else {
        self.center = [self clampedCenter:self.center inRect:safe];
    }

    self.layer.cornerRadius = 18.0;
    self.layer.shadowColor = UIColor.blackColor.CGColor;
    self.layer.shadowOpacity = 0.32;
    self.layer.shadowRadius = 22.0;
    self.layer.shadowOffset = CGSizeMake(0, 10);
    self.layer.shadowPath = [UIBezierPath bezierPathWithRoundedRect:self.bounds cornerRadius:18.0].CGPath;
}

- (CGPoint)clampedCenter:(CGPoint)center inRect:(CGRect)safe
{
    CGFloat halfW = CGRectGetWidth(self.bounds) * 0.5;
    CGFloat halfH = CGRectGetHeight(self.bounds) * 0.5;
    CGFloat minX = CGRectGetMinX(safe) + halfW;
    CGFloat maxX = CGRectGetMaxX(safe) - halfW;
    CGFloat minY = CGRectGetMinY(safe) + halfH;
    CGFloat maxY = CGRectGetMaxY(safe) - halfH;
    center.x = MakterClamp(center.x, minX, maxX);
    center.y = MakterClamp(center.y, minY, maxY);
    return center;
}

- (void)handleHeaderPan:(UIPanGestureRecognizer *)gesture
{
    UIView *host = self.superview;
    if (!host) return;
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
        return;
    }
    if (gesture.state != UIGestureRecognizerStateChanged && gesture.state != UIGestureRecognizerStateEnded) return;

    CGPoint translation = [gesture translationInView:host];
    CGPoint center = CGPointMake(_panStartCenter.x + translation.x, _panStartCenter.y + translation.y);
    CGRect safe = host.bounds;
    if (@available(iOS 11.0, *)) safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
    safe = CGRectInset(safe, 8.0, 8.0);

    self.transform = CGAffineTransformIdentity;
    self.center = [self clampedCenter:center inRect:safe];
    _hasUserPosition = YES;
    if (gesture.state == UIGestureRecognizerStateEnded) [gesture setTranslation:CGPointZero inView:host];
}

#pragma mark - Deterministic HUD touch router

- (CGPoint)localPointForHUDWindowPoint:(CGPoint)point
{
    UIWindow *window = self.window;
    if (window) return [self convertPoint:point fromView:window];
    if (self.superview) return [self convertPoint:point fromView:self.superview];
    return point;
}

- (BOOL)directPoint:(CGPoint)point insideView:(UIView *)view
{
    if (!view || view.hidden || view.alpha <= 0.01) return NO;
    CGPoint local = [view convertPoint:point fromView:self];
    return CGRectContainsPoint(view.bounds, local);
}

- (void)activateContentAtPoint:(CGPoint)local
{
    CGPoint rowPoint = [_functionRow convertPoint:local fromView:self];
    if (CGRectContainsPoint(_functionRow.bounds, rowPoint)) {
        _playerCountSwitch.on = !_playerCountSwitch.isOn;
        [self playerCountSwitchChanged:_playerCountSwitch];
    }
}

- (BOOL)handleHUDTouchAtWindowPoint:(CGPoint)point
                              phase:(UITouchPhase)phase
                          pointerId:(NSInteger)pointerId
{
    if (pointerId <= 0) return NO;
    CGPoint local = [self localPointForHUDWindowPoint:point];

    if (phase == UITouchPhaseBegan) {
        if (self.hidden || self.alpha <= 0.01 || !self.userInteractionEnabled) return NO;
        if (_directTouchPointerId != -1) return NO;

        _directTouchPointerId = pointerId;
        _directTouchStartPoint = local;
        _directTouchStartCenter = self.center;
        _directTouchStartContentOffset = _scrollView.contentOffset;
        _directTouchDragging = NO;
        _directTouchMode = kDirectTouchNone;

        CGPoint closePoint = [_closeButton convertPoint:local fromView:self];
        CGPoint headerPoint = [_headerView convertPoint:local fromView:self];
        if (CGRectContainsPoint(_closeButton.bounds, closePoint)) _directTouchMode = kDirectTouchClose;
        else if (CGRectContainsPoint(_headerView.bounds, headerPoint)) _directTouchMode = kDirectTouchHeaderDrag;
        else if ([self directPoint:local insideView:_scrollView]) _directTouchMode = kDirectTouchContent;

        return CGRectContainsPoint(self.bounds, local);
    }

    if (_directTouchPointerId != pointerId) return NO;

    CGPoint delta = CGPointMake(local.x - _directTouchStartPoint.x, local.y - _directTouchStartPoint.y);
    CGFloat distance = hypot(delta.x, delta.y);

    if (phase == UITouchPhaseMoved || phase == UITouchPhaseStationary) {
        if (_directTouchMode == kDirectTouchHeaderDrag) {
            if (distance > 2.0) _directTouchDragging = YES;
            if (_directTouchDragging) {
                UIView *host = self.superview;
                if (host) {
                    CGRect safe = host.bounds;
                    if (@available(iOS 11.0, *)) safe = UIEdgeInsetsInsetRect(safe, host.safeAreaInsets);
                    safe = CGRectInset(safe, 8.0, 8.0);
                    CGPoint desired = CGPointMake(_directTouchStartCenter.x + delta.x,
                                                  _directTouchStartCenter.y + delta.y);
                    self.center = [self clampedCenter:desired inRect:safe];
                    _hasUserPosition = YES;
                }
            }
            return YES;
        }

        if (_directTouchMode == kDirectTouchContent && distance > 4.0) {
            _directTouchDragging = YES;
            CGPoint offset = _directTouchStartContentOffset;
            offset.y -= delta.y;
            CGFloat maxOffset = MAX(0.0, _scrollView.contentSize.height - _scrollView.bounds.size.height);
            offset.y = MakterClamp(offset.y, 0.0, maxOffset);
            _scrollView.contentOffset = offset;
            return YES;
        }
        return YES;
    }

    if (phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled) {
        BOOL tap = (distance <= 10.0 && !_directTouchDragging);
        NSInteger mode = _directTouchMode;
        CGPoint start = _directTouchStartPoint;

        _directTouchPointerId = -1;
        _directTouchMode = kDirectTouchNone;
        _directTouchDragging = NO;

        if (phase == UITouchPhaseEnded && tap) {
            if (mode == kDirectTouchClose) [self closePressed:_closeButton];
            else if (mode == kDirectTouchContent) [self activateContentAtPoint:start];
        }
        return YES;
    }
    return YES;
}

- (BOOL)hitTestAllowsHUD
{
    return !self.hidden && self.alpha > 0.01 && self.userInteractionEnabled;
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (![self hitTestAllowsHUD]) return nil;
    return [super hitTest:point withEvent:event];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
        shouldReceiveTouch:(UITouch *)touch
{
    if (gestureRecognizer == _headerPanGesture) {
        UIView *view = touch.view;
        while (view && view != _headerView) {
            if ([view isKindOfClass:[UIControl class]]) return NO;
            view = view.superview;
        }
    }
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer
    shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}

@end
