# Player-count Lab — 6 routes

This revision replaces the old menu presentation with a diagnostic lab dedicated to player-count resolution.

The menu executes six independent external read paths and displays all results at once. No candidate is silently treated as authoritative.

C1: UIModelSpectator + 0xC4 (`m_RemainingPlayerCount`)
C2: UIModelSpectator + 0x30 (`m_PlayerDic`) -> Dictionary.Count
C3: UIModelMatch + 0x368 (`m_RemainingPlayerCount`)
C4: UIModelMatch + 0x1F0 (`m_PlayerDataList`) -> List.Count
C5: CurrentMatchGame + 0x90 (`m_Match`) + 0x128 -> Dictionary.Count
C6: CurrentMatchGame + 0x90 (`m_Match`) + 0x130 -> Dictionary.Count

`GameFacade.IsMatchStarted` at 0x209 is displayed as context so lobby values such as a stale `1` are not interpreted as a confirmed in-match count.

The dumped method RVAs are retained in `functions/Offsets.h` as version anchors. They are not invoked from the external reader.
