# Player Count — implementação

A função usa somente anchors presentes no MEGA_ESTUDO_FREEFIRE_DUMP:

- `GameFacade.m_UIModelSpectator` static offset: `0x320`
- `UIModelSpectator.m_PlayerDic`: `0x30`
- `UIModelSpectator.m_RemainingPlayerCount`: `0xC4`
- `UIModelSpectator.GetPlayerCount()`: RVA `0x48F8C34`
- `GameFacade.get_UIModelSpectator()`: RVA `0x5933D60`

## Método

O contador não chama o método remoto e não usa hook/injeção para essa função. Como este é um leitor externo, o código primeiro localiza o `UnityFramework` e varre os segmentos de dados não-`__TEXT` procurando o ponteiro do storage estático do `GameFacade`. Para cada candidato, lê `storage + 0x320` e valida se o resultado se comporta como um `UIModelSpectator` real:

1. `+0x00` parece ser ponteiro de classe;
2. `+0x30` é um ponteiro de dicionário legível;
3. `+0x80` é um booleano válido;
4. `+0xC4` é um contador não-negativo dentro de uma faixa de sanidade.

Depois disso, a função lê **somente** `UIModelSpectator + 0xC4`. O contador é consultado a cada 350 ms quando o switch está ligado. Quando o valor muda, o HUD mostra um toast como `Jogadores na partida: 47`.

## Onde alterar em uma próxima versão

Os offsets ficam todos em `functions/Offsets.h`. Não altere offsets espalhados pelo código. Para uma nova versão do jogo, substitua apenas os anchors ali, mantendo o nome semântico de cada constante.

## Importante sobre atualização de versão do Free Fire

Um dump confirma offset/RVA, mas não confirma sozinho ABI, static-storage runtime ou que o dump corresponde ao binário instalado. Por isso o resolver valida a instância em runtime antes de aceitar o valor.

## Switch

A UI está em `menu/menu.m`. O switch chama `HUDSetPlayerCountEnabled(BOOL)` e o status é obtido por `HUDPlayerCountStatus()`.

## Frequência de leitura

Com o switch ligado, a leitura ocorre aproximadamente a cada 350 ms em uma fila de background; a interface apenas exibe o valor em cache.
