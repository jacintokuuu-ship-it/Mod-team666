#pragma once
#include <stdint.h>

/*
 * Dump-only references used by the six player-count diagnostic routes.
 * RVAs are retained as evidence/diagnostic anchors; the external reader does
 * not execute target-process methods. It reads object fields and collection
 * state instead.
 */
namespace FreeFireOffsets {
    // GameFacade static fields
    static constexpr uintptr_t GameFacadeCurrentGameStaticOffset          = 0x000;
    static constexpr uintptr_t GameFacadeCurrentMatchGameStaticOffset     = 0x008;
    static constexpr uintptr_t GameFacadeIsMatchStartedStaticOffset       = 0x209;
    static constexpr uintptr_t GameFacadeUIModelMatchStaticOffset         = 0x318;
    static constexpr uintptr_t GameFacadeUIModelSpectatorStaticOffset     = 0x320;

    // UIModelSpectator
    static constexpr uintptr_t UIModelSpectatorPlayerDicOffset             = 0x30;
    static constexpr uintptr_t UIModelSpectatorHasPlayerDeadOffset         = 0x80;
    static constexpr uintptr_t UIModelSpectatorRemainingPlayerCountOffset  = 0xC4;
    static constexpr uintptr_t UIModelSpectatorTeamPlayerDicOffset         = 0x28;
    static constexpr uintptr_t UIModelSpectatorInBattleTeamsOffset         = 0x128;
    static constexpr uintptr_t UIModelSpectatorGetRemainPlayerRVA           = 0x048F3474;
    static constexpr uintptr_t UIModelSpectatorGetPlayerCountRVA            = 0x048F8C34;
    static constexpr uintptr_t UIModelSpectatorOnAlivePlayerCountChangedRVA = 0x048F56A4;

    // UIModelMatch
    static constexpr uintptr_t UIModelMatchPlayerDataListOffset             = 0x1F0;
    static constexpr uintptr_t UIModelMatchRemainingPlayerCountOffset       = 0x368;
    static constexpr uintptr_t UIModelMatchRemainingPlayerCountMaxOffset    = 0x364;
    static constexpr uintptr_t UIModelMatchMLocalTeamPlayerIDsOffset        = 0x1C0;
    static constexpr uintptr_t UIModelMatchMOppoTeamPlayerIDsOffset         = 0x1C8;
    static constexpr uintptr_t UIModelMatchStartMatchRVA                     = 0x046C145C;
    static constexpr uintptr_t UIModelMatchGetRemainingPlayerCountRVA       = 0x046C4B7C;
    static constexpr uintptr_t UIModelMatchOnAlivePlayerCountChangedRVA     = 0x046CBD80;
    static constexpr uintptr_t GameFacadeGetUIModelMatchRVA                  = 0x0592ED30;
    static constexpr uintptr_t GameFacadeGetUIModelSpectatorRVA              = 0x05933D60;

    // MatchGame -> JMAGGLCNGIG (dump shows two Player dictionaries)
    static constexpr uintptr_t MatchGameMatchObjectOffset                   = 0x90;
    static constexpr uintptr_t MatchObjectPlayerDictionaryAOffset            = 0x128;
    static constexpr uintptr_t MatchObjectPlayerDictionaryBOffset            = 0x130;

    // Methods kept as dump anchors for comparison during diagnostics.
    static constexpr uintptr_t UIModelSpectatorGetPlayerByTeamStrictRVA      = 0x048F8818;
    static constexpr uintptr_t UIModelSpectatorGetLivePlayerByTeamIndexRVA   = 0x048F86B8;
    static constexpr uintptr_t UIModelSpectatorGetFirstLivePlayerByTeamRVA   = 0x048F84D4;
    static constexpr uintptr_t UIModelSpectatorGetPlayerListFromTeamRVA      = 0x048F85F4;

    // Legacy ESP diagnostics still compiled by the application. They are not exposed in the menu.
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA = 0x048F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA   = 0x048F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA            = 0x048F84D4;
    static constexpr uintptr_t GetPlayerCountRVA                         = 0x048F8C34;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA                = 0x048F85F4;
    static constexpr uintptr_t PlayerGetTransformNodeRVA                 = 0x05735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA             = 0x0890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA              = 0x06B4964C;
    static constexpr uintptr_t BFOONIGAIFKGetTransformRVA                = 0x0581FB80;
    static constexpr uintptr_t EntityGetTransformNodeRVA                 = 0x06B4B418;
    static constexpr uintptr_t LEntityGetTransformNodeRVA                = 0x06AF1F24;
    static constexpr uintptr_t TransformNodeTransformOffset              = 0x10;
    static constexpr uintptr_t BFOONIGAIFKTransformOffset                = 0x10;
    static constexpr uintptr_t EntityCachedTransformOffset               = 0x58;
    static constexpr uintptr_t TransformGetPositionRVA                   = 0x08D6C1EC;
    static constexpr uintptr_t CameraGetMainRVA                          = 0x08CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA               = 0x08CFE9C0;
    static constexpr uintptr_t CameraWorldToScreenPointEyeRVA            = 0x08CFE5C0;
    static constexpr uintptr_t CameraWorldToViewportPointRVA              = 0x08CFEA34;
    static constexpr uintptr_t CameraGetWorldToCameraMatrixRVA            = 0x08CFE220;
    static constexpr uintptr_t CameraGetProjectionMatrixRVA               = 0x08CFE3C8;
    static constexpr uintptr_t AnimatorGetBoneTransformRVA                = 0x08CDDFEC;
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA        = 0x08CDE404;
    static constexpr int HumanBoneHips  = 0;
    static constexpr int HumanBoneChest = 8;
    static constexpr int HumanBoneNeck  = 9;
    static constexpr int HumanBoneHead  = 10;
}
