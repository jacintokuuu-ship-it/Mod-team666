#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct FFPlayerCountSnapshot {
    int32_t count;
    uint64_t unityBase;
    uint64_t staticFields;
    uint64_t uiModelSpectator;
    uint32_t valid;
    uint32_t changed;
    char message[256];
} FFPlayerCountSnapshot;

int FFPlayerCountRead(FFPlayerCountSnapshot *out);
void FFPlayerCountReset(void);

#ifdef __cplusplus
}
#endif
