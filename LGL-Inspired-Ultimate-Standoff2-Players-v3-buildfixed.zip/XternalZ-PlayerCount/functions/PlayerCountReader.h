#pragma once

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define FF_PLAYER_COUNT_CANDIDATE_COUNT 6
#define FF_PLAYER_COUNT_LABEL_LEN 64
#define FF_PLAYER_COUNT_DETAIL_LEN 160

typedef struct FFPlayerCountCandidate {
    int32_t value;
    uint32_t valid;
    char label[FF_PLAYER_COUNT_LABEL_LEN];
    char detail[FF_PLAYER_COUNT_DETAIL_LEN];
} FFPlayerCountCandidate;

typedef struct FFPlayerCountSnapshot {
    int32_t count;                 /* kept for compatibility; no auto-selected value */
    uint64_t unityBase;
    uint64_t staticFields;
    uint64_t uiModelSpectator;
    uint64_t uiModelMatch;
    uint64_t currentMatchGame;
    uint64_t matchObject;
    uint32_t valid;
    uint32_t changed;
    uint32_t matchStarted;
    uint32_t validCandidateCount;
    FFPlayerCountCandidate candidates[FF_PLAYER_COUNT_CANDIDATE_COUNT];
    char message[512];
} FFPlayerCountSnapshot;

int FFPlayerCountRead(FFPlayerCountSnapshot *out);
void FFPlayerCountReset(void);
void FFPlayerCountDiagnosticText(char *out, uint32_t capacity);

#ifdef __cplusplus
}
#endif
