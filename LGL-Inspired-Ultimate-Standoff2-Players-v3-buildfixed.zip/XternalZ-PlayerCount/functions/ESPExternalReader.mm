#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <atomic>

namespace {
static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static std::atomic<int> gMode{0};

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
}

static bool ReadRemote(task_t task, mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !out || size == 0)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, address, size,
                                               (mach_vm_address_t)out, &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool ReadRVA(task_t task, mach_vm_address_t base, uintptr_t rva)
{
    uint32_t bytes = 0;
    return ReadRemote(task, base + (mach_vm_address_t)rva, &bytes, sizeof(bytes));
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}
}

extern "C" int ESPExternalSetMode(int mode)
{
    if (mode < 0 || mode > 1) mode = 0;
    gMode.store(mode, std::memory_order_release);
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();
    s.rvaTestCount = 10;

    CloseTask();

    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
            if (out) *out = s;
        return 0;
    }

    s.processFound = 1;
    s.processPID = pid;

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        BuildFailure(s, "FALHOU: FreeFire PID %d encontrado; task nao abriu: %s",
                     pid, get_task_last_error());
            if (out) *out = s;
        return 0;
    }
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        BuildFailure(s, "FALHOU: task OK, UnityFramework nao localizado | PID %d", pid);
            if (out) *out = s;
        return 0;
    }
    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    uint32_t magic = 0;
    if (!ReadRemote(gTask, gUnityBase, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        BuildFailure(s, "FALHOU: UnityFramework 0x%llX, cabecalho Mach-O nao legivel",
                     (unsigned long long)gUnityBase);
            if (out) *out = s;
        return 0;
    }
    s.machoReadable = 1;

    const uintptr_t rvas[] = {
        FreeFireOffsets::GetPlayerByTeamIdAndPlayerIndexStrictRVA,
        FreeFireOffsets::GetLivePlayerByTeamIdAndPlayerIndexRVA,
        FreeFireOffsets::GetPlayerCountRVA,
        FreeFireOffsets::GetPlayerListFromTeamIdRVA,
        FreeFireOffsets::PlayerGetTransformNodeRVA,
        FreeFireOffsets::TransformGetPositionRVA,
        FreeFireOffsets::CameraGetMainRVA,
        FreeFireOffsets::CameraWorldToScreenPointRVA,
        FreeFireOffsets::AnimatorGetBoneTransformRVA,
        FreeFireOffsets::AnimatorGetBoneTransformInternalRVA,
    };

    s.rvaTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
    for (uint32_t i = 0; i < s.rvaTestCount; ++i) {
        if (ReadRVA(gTask, gUnityBase, rvas[i]))
            ++s.rvaReadableCount;
    }

    if (s.rvaReadableCount != s.rvaTestCount) {
        BuildFailure(s, "PARCIAL: FreeFire OK | PID %d | task OK | Unity 0x%llX | Mach-O OK | RVAs legiveis %u/%u",
                     pid, (unsigned long long)gUnityBase,
                     s.rvaReadableCount, s.rvaTestCount);
            if (out) *out = s;
        return 0;
    }

    snprintf(s.message, sizeof(s.message),
             "OK: FreeFire lido externamente | PID %d | task OK | UnityFramework 0x%llX | Mach-O OK | RVAs legiveis %u/%u",
             pid, (unsigned long long)gUnityBase,
             s.rvaReadableCount, s.rvaTestCount);

    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    if (!ESPExternalVerify(&s)) {
        if (out) *out = s;
        return 0;
    }

    /*
     * External transport is now real: task_for_pid + mach_vm_read_overwrite.
     * Live entity enumeration is deliberately not fabricated here. The target
     * slots remain empty until a PlayerManager/list chain from the same dump is
     * wired into this out-of-process reader.
     */
    // This snapshot intentionally does not claim a live entity count.
    // Player count is provided by PlayerCountReader.
    s.count = 0;
    if (out) *out = s;
    return 1;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[768];
    ESPExternalSnapshot s{};
    ESPExternalVerify(&s);
    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: sem diagnostico");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1024];
    ESPExternalSnapshot s{};
    const int ok = ESPExternalVerify(&s);

    if (!ok) {
        snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: diagnostico externo");
        return text;
    }

    snprintf(text, sizeof(text),
             "EXTERNAL CHECK\nFreeFire: OK | PID: %d\n"
             "task: OK | UnityFramework: 0x%llX\n"
             "Mach-O: OK | RVAs legiveis: %u/%u\n"
             "ESP diagnostico: %u target(s)",
             s.processPID,
             (unsigned long long)s.unityBase,
             s.rvaReadableCount,
             s.rvaTestCount,
             s.count);
    return text;
}
