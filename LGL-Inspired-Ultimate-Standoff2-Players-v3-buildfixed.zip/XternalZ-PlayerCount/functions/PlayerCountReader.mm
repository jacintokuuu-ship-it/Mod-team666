#import "PlayerCountReader.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <atomic>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <vector>
#include <mutex>

namespace {

static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static mach_vm_address_t gStaticFields = 0;
static mach_vm_address_t gSpectator = 0;
static mach_vm_address_t gMatchModel = 0;
static mach_vm_address_t gCurrentMatchGame = 0;
static mach_vm_address_t gMatchObject = 0;
static std::atomic<int32_t> gLastSignature{-1};
static std::mutex gReaderMutex;
static std::mutex gTextMutex;
static char gDiagnosticText[2048] = "Aguardando diagnostico das 6 rotas...";

static void CopyText(char *dst, size_t cap, const char *src)
{
    if (!dst || cap == 0) return;
    if (!src) src = "";
    snprintf(dst, cap, "%s", src);
}

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
    gStaticFields = 0;
    gSpectator = 0;
    gMatchModel = 0;
    gCurrentMatchGame = 0;
    gMatchObject = 0;
}

template <typename T>
static bool ReadRemote(mach_vm_address_t address, T *out)
{
    if (gTask == MACH_PORT_NULL || address == 0 || out == nullptr)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(gTask, address, sizeof(T),
                                               (mach_vm_address_t)out, &copied);
    return kr == KERN_SUCCESS && copied == sizeof(T);
}

static bool ReadRemoteBytes(mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (gTask == MACH_PORT_NULL || address == 0 || out == nullptr || size == 0)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(gTask, address, size,
                                               (mach_vm_address_t)out, &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool IsLikelyPointer(uint64_t value)
{
    return value >= 0x100000000ull && (value & 0x7ull) == 0;
}

struct SegmentRange {
    mach_vm_address_t start;
    mach_vm_size_t size;
};

static bool ReadMachODataSegments(std::vector<SegmentRange> &out)
{
    out.clear();

    mach_header_64 header{};
    if (!ReadRemoteBytes(gUnityBase, &header, sizeof(header)))
        return false;
    if (header.magic != MH_MAGIC_64)
        return false;
    if (header.ncmds == 0 || header.ncmds > 1024)
        return false;

    const mach_vm_size_t commandsSize = (mach_vm_size_t)header.sizeofcmds;
    if (commandsSize == 0 || commandsSize > (4ull * 1024ull * 1024ull))
        return false;

    std::vector<uint8_t> commands((size_t)commandsSize);
    if (!ReadRemoteBytes(gUnityBase + sizeof(mach_header_64), commands.data(), commandsSize))
        return false;

    size_t cursor = 0;
    for (uint32_t i = 0; i < header.ncmds; ++i) {
        if (cursor + sizeof(load_command) > commands.size()) return false;
        const load_command *lc = reinterpret_cast<const load_command *>(commands.data() + cursor);
        if (lc->cmdsize < sizeof(load_command) || cursor + lc->cmdsize > commands.size()) return false;

        if (lc->cmd == LC_SEGMENT_64 && lc->cmdsize >= sizeof(segment_command_64)) {
            const segment_command_64 *seg = reinterpret_cast<const segment_command_64 *>(lc);
            char name[17] = {0};
            memcpy(name, seg->segname, 16);
            const bool dataSegment = (strncmp(name, "__DATA", 6) == 0) ||
                                     (strncmp(name, "__AUTH", 6) == 0);
            if (dataSegment && (seg->initprot & VM_PROT_READ) != 0 && seg->vmsize != 0 &&
                seg->vmsize <= (128ull * 1024ull * 1024ull)) {
                out.push_back({gUnityBase + seg->vmaddr, (mach_vm_size_t)seg->vmsize});
            }
        }
        cursor += lc->cmdsize;
    }
    return !out.empty();
}

static bool ValidateObject(uint64_t object)
{
    if (!IsLikelyPointer(object)) return false;
    uint64_t klass = 0;
    return ReadRemote(object + 0x00, &klass) && IsLikelyPointer(klass);
}

static bool ReadBoolField(uint64_t object, uintptr_t offset, uint32_t *out)
{
    uint8_t v = 0;
    if (!ReadRemote(object + offset, &v) || v > 1) return false;
    if (out) *out = v;
    return true;
}

static bool ReadDictionaryCount(uint64_t dictionary, int32_t *out)
{
    if (!IsLikelyPointer(dictionary)) return false;

    uint64_t klass = 0;
    uint64_t buckets = 0;
    uint64_t entries = 0;
    int32_t count = -1;
    if (!ReadRemote(dictionary + 0x00, &klass) ||
        !ReadRemote(dictionary + 0x10, &buckets) ||
        !ReadRemote(dictionary + 0x18, &entries) ||
        !ReadRemote(dictionary + 0x20, &count)) {
        return false;
    }

    if (!IsLikelyPointer(klass)) return false;
    if (!IsLikelyPointer(buckets) && buckets != 0) return false;
    if (!IsLikelyPointer(entries) && entries != 0) return false;
    if (count < 0 || count > 512) return false;

    if (out) *out = count;
    return true;
}

static bool ReadListCount(uint64_t list, int32_t *out)
{
    if (!IsLikelyPointer(list)) return false;

    uint64_t klass = 0;
    uint64_t items = 0;
    int32_t size = -1;
    if (!ReadRemote(list + 0x00, &klass) ||
        !ReadRemote(list + 0x10, &items) ||
        !ReadRemote(list + 0x18, &size)) {
        return false;
    }

    if (!IsLikelyPointer(klass)) return false;
    if (!IsLikelyPointer(items) && items != 0) return false;
    if (size < 0 || size > 512) return false;

    if (out) *out = size;
    return true;
}

static bool ValidateSpectator(uint64_t spectator)
{
    if (!ValidateObject(spectator)) return false;

    uint64_t playerDic = 0;
    uint8_t hasPlayerDead = 0;
    int32_t remaining = -1;
    if (!ReadRemote(spectator + FreeFireOffsets::UIModelSpectatorPlayerDicOffset, &playerDic) ||
        !ReadRemote(spectator + FreeFireOffsets::UIModelSpectatorHasPlayerDeadOffset, &hasPlayerDead) ||
        !ReadRemote(spectator + FreeFireOffsets::UIModelSpectatorRemainingPlayerCountOffset, &remaining)) {
        return false;
    }

    if (!IsLikelyPointer(playerDic) || hasPlayerDead > 1) return false;
    if (remaining < 0 || remaining > 512) return false;
    return true;
}

static bool ValidateMatchModel(uint64_t match)
{
    return ValidateObject(match);
}

static bool ResolveStaticFields(void)
{
    std::vector<SegmentRange> segments;
    if (!ReadMachODataSegments(segments)) return false;

    const mach_vm_size_t kChunk = 0x8000;
    const mach_vm_size_t kMaxScanPerSegment = 32ull * 1024ull * 1024ull;

    for (const SegmentRange &segment : segments) {
        const mach_vm_size_t scanSize = std::min(segment.size, kMaxScanPerSegment);
        for (mach_vm_size_t offset = 0; offset < scanSize; offset += kChunk) {
            const mach_vm_size_t len = std::min(kChunk, scanSize - offset);
            std::vector<uint8_t> chunk((size_t)len);
            if (!ReadRemoteBytes(segment.start + offset, chunk.data(), len)) continue;

            for (mach_vm_size_t p = 0; p + sizeof(uint64_t) <= len; p += sizeof(uint64_t)) {
                uint64_t candidate = 0;
                memcpy(&candidate, chunk.data() + p, sizeof(candidate));
                if (!IsLikelyPointer(candidate)) continue;

                uint64_t spectator = 0;
                uint64_t match = 0;
                uint64_t currentMatchGame = 0;
                uint32_t matchStarted = 0;

                if (!ReadRemote(candidate + FreeFireOffsets::GameFacadeUIModelSpectatorStaticOffset, &spectator) ||
                    !ReadRemote(candidate + FreeFireOffsets::GameFacadeUIModelMatchStaticOffset, &match) ||
                    !ReadRemote(candidate + FreeFireOffsets::GameFacadeCurrentMatchGameStaticOffset, &currentMatchGame)) {
                    continue;
                }

                if (!ValidateSpectator(spectator) || !ValidateMatchModel(match)) continue;
                if (!ReadBoolField(candidate, FreeFireOffsets::GameFacadeIsMatchStartedStaticOffset, &matchStarted)) continue;

                gStaticFields = candidate;
                gSpectator = spectator;
                gMatchModel = match;
                gCurrentMatchGame = currentMatchGame;
                gMatchObject = 0;
                return true;
            }
        }
    }
    return false;
}

static bool EnsureTarget(void)
{
    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) return false;

    if (gTask != MACH_PORT_NULL) {
        uint32_t started = 0;
        if (gStaticFields && ReadBoolField(gStaticFields, FreeFireOffsets::GameFacadeIsMatchStartedStaticOffset, &started)) {
            return true;
        }
        CloseTask();
    }

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) return false;

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) { CloseTask(); return false; }

    uint32_t magic = 0;
    if (!ReadRemote(gUnityBase, &magic) || magic != MH_MAGIC_64) { CloseTask(); return false; }

    if (!ResolveStaticFields()) { CloseTask(); return false; }
    return true;
}

static int ReadCandidate1(int32_t *value, char *detail, size_t cap)
{
    int32_t v = -1;
    if (!ReadRemote(gSpectator + FreeFireOffsets::UIModelSpectatorRemainingPlayerCountOffset, &v) || v < 0 || v > 512) return 0;
    if (value) *value = v;
    snprintf(detail, cap, "UIModelSpectator + 0x%llX", (unsigned long long)FreeFireOffsets::UIModelSpectatorRemainingPlayerCountOffset);
    return 1;
}

static int ReadCandidate2(int32_t *value, char *detail, size_t cap)
{
    uint64_t dict = 0;
    int32_t count = -1;
    if (!ReadRemote(gSpectator + FreeFireOffsets::UIModelSpectatorPlayerDicOffset, &dict) ||
        !ReadDictionaryCount(dict, &count)) return 0;
    if (value) *value = count;
    snprintf(detail, cap, "Spectator + 0x%llX -> Dictionary.Count", (unsigned long long)FreeFireOffsets::UIModelSpectatorPlayerDicOffset);
    return 1;
}

static int ReadCandidate3(int32_t *value, char *detail, size_t cap)
{
    int32_t v = -1;
    if (!ReadRemote(gMatchModel + FreeFireOffsets::UIModelMatchRemainingPlayerCountOffset, &v) || v < 0 || v > 512) return 0;
    if (value) *value = v;
    snprintf(detail, cap, "UIModelMatch + 0x%llX", (unsigned long long)FreeFireOffsets::UIModelMatchRemainingPlayerCountOffset);
    return 1;
}

static int ReadCandidate4(int32_t *value, char *detail, size_t cap)
{
    uint64_t list = 0;
    int32_t count = -1;
    if (!ReadRemote(gMatchModel + FreeFireOffsets::UIModelMatchPlayerDataListOffset, &list) ||
        !ReadListCount(list, &count)) return 0;
    if (value) *value = count;
    snprintf(detail, cap, "UIModelMatch + 0x%llX -> List.Count", (unsigned long long)FreeFireOffsets::UIModelMatchPlayerDataListOffset);
    return 1;
}

static int ReadCandidate5(int32_t *value, char *detail, size_t cap)
{
    if (!IsLikelyPointer(gCurrentMatchGame)) return 0;
    uint64_t match = 0;
    uint64_t dictionary = 0;
    int32_t count = -1;
    if (!ReadRemote(gCurrentMatchGame + FreeFireOffsets::MatchGameMatchObjectOffset, &match) ||
        !IsLikelyPointer(match) ||
        !ReadRemote(match + FreeFireOffsets::MatchObjectPlayerDictionaryAOffset, &dictionary) ||
        !ReadDictionaryCount(dictionary, &count)) return 0;
    if (value) *value = count;
    snprintf(detail, cap, "CurrentMatchGame + 0x%llX -> Match + 0x%llX -> Dictionary.Count",
             (unsigned long long)FreeFireOffsets::MatchGameMatchObjectOffset,
             (unsigned long long)FreeFireOffsets::MatchObjectPlayerDictionaryAOffset);
    return 1;
}

static int ReadCandidate6(int32_t *value, char *detail, size_t cap)
{
    if (!IsLikelyPointer(gCurrentMatchGame)) return 0;
    uint64_t match = 0;
    uint64_t dictionary = 0;
    int32_t count = -1;
    if (!ReadRemote(gCurrentMatchGame + FreeFireOffsets::MatchGameMatchObjectOffset, &match) ||
        !IsLikelyPointer(match) ||
        !ReadRemote(match + FreeFireOffsets::MatchObjectPlayerDictionaryBOffset, &dictionary) ||
        !ReadDictionaryCount(dictionary, &count)) return 0;
    if (value) *value = count;
    snprintf(detail, cap, "CurrentMatchGame + 0x%llX -> Match + 0x%llX -> Dictionary.Count",
             (unsigned long long)FreeFireOffsets::MatchGameMatchObjectOffset,
             (unsigned long long)FreeFireOffsets::MatchObjectPlayerDictionaryBOffset);
    return 1;
}

static int32_t MakeSignature(const FFPlayerCountSnapshot &s)
{
    int32_t signature = 17;
    for (uint32_t i = 0; i < FF_PLAYER_COUNT_CANDIDATE_COUNT; ++i) {
        signature = signature * 31 + (s.candidates[i].valid ? s.candidates[i].value : -1);
    }
    signature = signature * 31 + (int32_t)s.matchStarted;
    return signature;
}

static void BuildDiagnostic(const FFPlayerCountSnapshot &s)
{
    char text[2048] = {0};
    int used = snprintf(text, sizeof(text), "MatchStarted=%u | validas=%u/6\n",
                        s.matchStarted, s.validCandidateCount);
    for (uint32_t i = 0; i < FF_PLAYER_COUNT_CANDIDATE_COUNT && used > 0 && used < (int)sizeof(text); ++i) {
        const FFPlayerCountCandidate &c = s.candidates[i];
        used += snprintf(text + used, sizeof(text) - (size_t)used,
                         "C%u %s: %s%d | %s\n",
                         i + 1,
                         c.label,
                         c.valid ? "OK=" : "FAIL ",
                         c.valid ? c.value : 0,
                         c.detail);
    }
    if (used > 0 && used < (int)sizeof(text)) {
        snprintf(text + used, sizeof(text) - (size_t)used,
                 "Base=0x%llX | Spectator=0x%llX | Match=0x%llX\nMatchGame=0x%llX | MatchObj=0x%llX",
                 (unsigned long long)s.unityBase,
                 (unsigned long long)s.uiModelSpectator,
                 (unsigned long long)s.uiModelMatch,
                 (unsigned long long)s.currentMatchGame,
                 (unsigned long long)s.matchObject);
    }

    std::lock_guard<std::mutex> lock(gTextMutex);
    CopyText(gDiagnosticText, sizeof(gDiagnosticText), text);
}

} // namespace

extern "C" void FFPlayerCountReset(void)
{
    std::lock_guard<std::mutex> lock(gReaderMutex);
    CloseTask();
    gLastSignature.store(-1, std::memory_order_release);
    std::lock_guard<std::mutex> textLock(gTextMutex);
    CopyText(gDiagnosticText, sizeof(gDiagnosticText), "Contador desligado");
}

extern "C" int FFPlayerCountRead(FFPlayerCountSnapshot *out)
{
    std::lock_guard<std::mutex> lock(gReaderMutex);
    FFPlayerCountSnapshot s{};
    s.count = -1;

    if (!EnsureTarget()) {
        CopyText(s.message, sizeof(s.message), "Free Fire/UnityFramework/GameFacade indisponivel");
        std::lock_guard<std::mutex> textLock(gTextMutex);
        CopyText(gDiagnosticText, sizeof(gDiagnosticText), s.message);
        if (out) *out = s;
        return 0;
    }

    s.unityBase = gUnityBase;
    s.staticFields = gStaticFields;
    s.uiModelSpectator = gSpectator;
    s.uiModelMatch = gMatchModel;
    s.currentMatchGame = gCurrentMatchGame;

    uint32_t started = 0;
    if (!ReadBoolField(gStaticFields, FreeFireOffsets::GameFacadeIsMatchStartedStaticOffset, &started)) {
        CopyText(s.message, sizeof(s.message), "GameFacade encontrado, mas IsMatchStarted nao pode ser lido");
        if (out) *out = s;
        return 0;
    }
    s.matchStarted = started;

    if (IsLikelyPointer(gCurrentMatchGame)) {
        (void)ReadRemote(gCurrentMatchGame + FreeFireOffsets::MatchGameMatchObjectOffset, &s.matchObject);
    }
    gMatchObject = s.matchObject;

    const char *labels[FF_PLAYER_COUNT_CANDIDATE_COUNT] = {
        "C1 Spectator.Remaining",
        "C2 Spectator.Dictionary",
        "C3 Match.Remaining",
        "C4 Match.PlayerDataList",
        "C5 MatchGame.DictionaryA",
        "C6 MatchGame.DictionaryB"
    };

    int (*readers[FF_PLAYER_COUNT_CANDIDATE_COUNT])(int32_t *, char *, size_t) = {
        ReadCandidate1, ReadCandidate2, ReadCandidate3,
        ReadCandidate4, ReadCandidate5, ReadCandidate6
    };

    for (uint32_t i = 0; i < FF_PLAYER_COUNT_CANDIDATE_COUNT; ++i) {
        FFPlayerCountCandidate &c = s.candidates[i];
        CopyText(c.label, sizeof(c.label), labels[i]);
        c.value = -1;
        c.valid = 0;
        if (readers[i](&c.value, c.detail, sizeof(c.detail))) {
            c.valid = 1;
            ++s.validCandidateCount;
        } else {
            CopyText(c.detail, sizeof(c.detail), "leitura/estrutura invalida nesta rota");
        }
    }

    // Scene transitions can recreate the UI models. If every route failed while
    // the static GameFacade storage is still readable, force one fresh resolution.
    if (s.validCandidateCount == 0) {
        CloseTask();
        if (EnsureTarget()) {
            s.unityBase = gUnityBase;
            s.staticFields = gStaticFields;
            s.uiModelSpectator = gSpectator;
            s.uiModelMatch = gMatchModel;
            s.currentMatchGame = gCurrentMatchGame;
            s.matchStarted = 0;
            (void)ReadBoolField(gStaticFields, FreeFireOffsets::GameFacadeIsMatchStartedStaticOffset, &s.matchStarted);
            if (IsLikelyPointer(gCurrentMatchGame)) {
                (void)ReadRemote(gCurrentMatchGame + FreeFireOffsets::MatchGameMatchObjectOffset, &s.matchObject);
            }
            s.validCandidateCount = 0;
            for (uint32_t i = 0; i < FF_PLAYER_COUNT_CANDIDATE_COUNT; ++i) {
                FFPlayerCountCandidate &c = s.candidates[i];
                c.value = -1;
                c.valid = 0;
                if (readers[i](&c.value, c.detail, sizeof(c.detail))) {
                    c.valid = 1;
                    ++s.validCandidateCount;
                } else {
                    CopyText(c.detail, sizeof(c.detail), "leitura/estrutura invalida nesta rota");
                }
            }
        }
    }

    s.valid = s.validCandidateCount > 0 ? 1u : 0u;
    const int32_t signature = MakeSignature(s);
    const int32_t previous = gLastSignature.exchange(signature, std::memory_order_acq_rel);
    s.changed = (previous >= 0 && previous != signature) ? 1u : 0u;

    snprintf(s.message, sizeof(s.message),
             "6 rotas executadas | MatchStarted=%u | validas=%u/6",
             s.matchStarted, s.validCandidateCount);
    BuildDiagnostic(s);

    if (out) *out = s;
    return s.valid ? 1 : 0;
}

extern "C" void FFPlayerCountDiagnosticText(char *out, uint32_t capacity)
{
    if (!out || capacity == 0) return;
    std::lock_guard<std::mutex> lock(gTextMutex);
    snprintf(out, capacity, "%s", gDiagnosticText);
}
