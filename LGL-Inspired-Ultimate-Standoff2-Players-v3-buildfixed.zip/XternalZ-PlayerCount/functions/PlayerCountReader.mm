#import "PlayerCountReader.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <atomic>
#include <stdio.h>
#include <string.h>
#include <algorithm>
#include <vector>

namespace {

static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static mach_vm_address_t gStaticFields = 0;
static mach_vm_address_t gSpectator = 0;
static std::atomic<int32_t> gLastCount{-1};
static std::atomic<uint64_t> gLastUnityBase{0};
static std::atomic<uint32_t> gResolveGeneration{0};

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
    gStaticFields = 0;
    gSpectator = 0;
}

template <typename T>
static bool ReadRemote(mach_vm_address_t address, T *out)
{
    if (gTask == MACH_PORT_NULL || address == 0 || out == nullptr)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(gTask,
                                               address,
                                               sizeof(T),
                                               (mach_vm_address_t)out,
                                               &copied);
    return kr == KERN_SUCCESS && copied == sizeof(T);
}

static bool ReadRemoteBytes(mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (gTask == MACH_PORT_NULL || address == 0 || out == nullptr || size == 0)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(gTask,
                                               address,
                                               size,
                                               (mach_vm_address_t)out,
                                               &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool IsLikelyPointer(uint64_t value)
{
    // arm64 user-space pointers are naturally aligned and far above the null page.
    return value >= 0x100000000ull && (value & 0x7ull) == 0;
}

struct SegmentRange {
    mach_vm_address_t start;
    mach_vm_size_t size;
};

static bool ReadMachODataSegments(std::vector<SegmentRange> &out)
{
    out.clear();

    mach_header_64 header{};
    if (!ReadRemoteBytes(gUnityBase, &header, sizeof(header)))
        return false;
    if (header.magic != MH_MAGIC_64)
        return false;

    if (header.ncmds == 0 || header.ncmds > 1024)
        return false;

    const mach_vm_size_t commandsSize = (mach_vm_size_t)header.sizeofcmds;
    if (commandsSize == 0 || commandsSize > (4ull * 1024ull * 1024ull))
        return false;

    std::vector<uint8_t> commands((size_t)commandsSize);
    if (!ReadRemoteBytes(gUnityBase + sizeof(mach_header_64), commands.data(), commandsSize))
        return false;

    size_t cursor = 0;
    for (uint32_t i = 0; i < header.ncmds; ++i) {
        if (cursor + sizeof(load_command) > commands.size())
            return false;

        const load_command *lc = reinterpret_cast<const load_command *>(commands.data() + cursor);
        if (lc->cmdsize < sizeof(load_command) || cursor + lc->cmdsize > commands.size())
            return false;

        if (lc->cmd == LC_SEGMENT_64 && lc->cmdsize >= sizeof(segment_command_64)) {
            const segment_command_64 *seg = reinterpret_cast<const segment_command_64 *>(lc);
            if ((seg->initprot & VM_PROT_READ) != 0 &&
                seg->vmsize != 0 &&
                seg->vmsize <= (128ull * 1024ull * 1024ull)) {
                // StaticFields globals are normally kept in writable data. __DATA_CONST
                // is also included because some linker configurations place pointer
                // tables there. __TEXT is intentionally excluded from this scan.
                char name[17] = {0};
                memcpy(name, seg->segname, 16);
                const bool dataSegment = (strncmp(name, "__DATA", 6) == 0) ||
                                         (strncmp(name, "__AUTH", 6) == 0);
                if (dataSegment) {
                    mach_vm_address_t start = gUnityBase + seg->vmaddr;
                    out.push_back({start, (mach_vm_size_t)seg->vmsize});
                }
            }
        }

        cursor += lc->cmdsize;
    }

    return !out.empty();
}

static bool ValidateDictionaryPointer(uint64_t dictionary)
{
    if (!IsLikelyPointer(dictionary))
        return false;

    // Unity/IL2CPP Dictionary objects contain backing arrays shortly after the
    // object header. We only require a few safe pointer-shaped fields; this is a
    // sanity check, not a guessed offset used as game data.
    uint64_t klass = 0;
    uint64_t buckets = 0;
    uint64_t entries = 0;
    if (!ReadRemote(dictionary + 0x00, &klass))
        return false;
    if (!ReadRemote(dictionary + 0x10, &buckets))
        return false;
    if (!ReadRemote(dictionary + 0x18, &entries))
        return false;

    return IsLikelyPointer(klass) &&
           (IsLikelyPointer(buckets) || IsLikelyPointer(entries) || (buckets == 0 && entries == 0));
}

static bool ValidateSpectator(uint64_t spectator, int32_t *remainingOut)
{
    if (!IsLikelyPointer(spectator))
        return false;

    uint64_t klass = 0;
    uint64_t playerDic = 0;
    uint8_t hasPlayerDead = 0;
    int32_t remaining = -1;
    uint64_t deadOrderList = 0;
    uint64_t playerHudOperateDic = 0;
    uint64_t inBattleTeams = 0;

    if (!ReadRemote(spectator + 0x00, &klass) ||
        !ReadRemote(spectator + FreeFireOffsets::UIModelSpectatorPlayerDicOffset, &playerDic) ||
        !ReadRemote(spectator + FreeFireOffsets::UIModelSpectatorHasPlayerDeadOffset, &hasPlayerDead) ||
        !ReadRemote(spectator + FreeFireOffsets::UIModelSpectatorRemainingPlayerCountOffset, &remaining) ||
        !ReadRemote(spectator + 0xA8, &deadOrderList) ||
        !ReadRemote(spectator + 0x40, &playerHudOperateDic) ||
        !ReadRemote(spectator + 0x128, &inBattleTeams)) {
        return false;
    }

    if (!IsLikelyPointer(klass) || !IsLikelyPointer(playerDic))
        return false;
    if (remaining < 0 || remaining > 1024)
        return false;
    if (hasPlayerDead > 1)
        return false;
    if (!ValidateDictionaryPointer(playerDic))
        return false;

    // These optional collections strengthen the identity of UIModelSpectator when
    // present, but can legitimately be null during transitions, so they are not required.
    (void)deadOrderList;
    (void)playerHudOperateDic;
    (void)inBattleTeams;

    if (remainingOut)
        *remainingOut = remaining;
    return true;
}

static bool ResolveStaticFieldsPointer(uint64_t *staticFieldsOut, uint64_t *spectatorOut, int32_t *countOut)
{
    std::vector<SegmentRange> segments;
    if (!ReadMachODataSegments(segments))
        return false;

    const mach_vm_size_t kChunk = 0x8000;
    const mach_vm_size_t kMaxScanPerSegment = 32ull * 1024ull * 1024ull;

    for (const SegmentRange &segment : segments) {
        const mach_vm_size_t scanSize = std::min(segment.size, kMaxScanPerSegment);
        for (mach_vm_size_t offset = 0; offset < scanSize; offset += kChunk) {
            const mach_vm_size_t len = std::min(kChunk, scanSize - offset);
            std::vector<uint8_t> chunk((size_t)len);
            if (!ReadRemoteBytes(segment.start + offset, chunk.data(), len))
                continue;

            for (mach_vm_size_t p = 0; p + sizeof(uint64_t) <= len; p += sizeof(uint64_t)) {
                uint64_t candidateStaticFields = 0;
                memcpy(&candidateStaticFields, chunk.data() + p, sizeof(candidateStaticFields));
                if (!IsLikelyPointer(candidateStaticFields))
                    continue;

                uint64_t candidateSpectator = 0;
                if (!ReadRemote(candidateStaticFields + FreeFireOffsets::GameFacadeUIModelSpectatorStaticOffset,
                                &candidateSpectator))
                    continue;

                int32_t count = -1;
                if (!ValidateSpectator(candidateSpectator, &count))
                    continue;

                *staticFieldsOut = candidateStaticFields;
                *spectatorOut = candidateSpectator;
                *countOut = count;
                return true;
            }
        }
    }

    return false;
}

static bool EnsureTarget(void)
{
    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0)
        return false;

    if (gTask != MACH_PORT_NULL) {
        int32_t probe = -1;
        if (gSpectator && ValidateSpectator(gSpectator, &probe))
            return true;
        CloseTask();
    }

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL)
        return false;

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase)
        return false;

    uint32_t machoMagic = 0;
    if (!ReadRemote(gUnityBase, &machoMagic) || machoMagic != MH_MAGIC_64)
        return false;

    uint64_t staticFields = 0;
    uint64_t spectator = 0;
    int32_t count = -1;
    if (!ResolveStaticFieldsPointer(&staticFields, &spectator, &count))
        return false;

    gStaticFields = staticFields;
    gSpectator = spectator;
    gLastUnityBase.store(gUnityBase, std::memory_order_release);
    gResolveGeneration.fetch_add(1, std::memory_order_acq_rel);
    (void)count;
    return true;
}

} // namespace

extern "C" void FFPlayerCountReset(void)
{
    CloseTask();
    gLastCount.store(-1, std::memory_order_release);
    gLastUnityBase.store(0, std::memory_order_release);
}

extern "C" int FFPlayerCountRead(FFPlayerCountSnapshot *out)
{
    FFPlayerCountSnapshot snapshot{};
    snapshot.count = -1;

    if (!EnsureTarget()) {
        snprintf(snapshot.message, sizeof(snapshot.message),
                 "Free Fire/UnityFramework/UIModelSpectator indisponivel");
        if (out) *out = snapshot;
        return 0;
    }

    int32_t count = -1;
    if (!ValidateSpectator(gSpectator, &count)) {
        // One forced re-resolution handles scene transitions and object recreation.
        CloseTask();
        if (!EnsureTarget() || !ValidateSpectator(gSpectator, &count)) {
            snprintf(snapshot.message, sizeof(snapshot.message),
                     "UIModelSpectator encontrado anteriormente, mas ficou invalido");
            if (out) *out = snapshot;
            return 0;
        }
    }

    const int32_t previous = gLastCount.exchange(count, std::memory_order_acq_rel);
    snapshot.count = count;
    snapshot.unityBase = gUnityBase;
    snapshot.staticFields = gStaticFields;
    snapshot.uiModelSpectator = gSpectator;
    snapshot.valid = 1;
    snapshot.changed = (previous >= 0 && previous != count) ? 1u : 0u;
    snprintf(snapshot.message, sizeof(snapshot.message),
             "OK: UIModelSpectator +0x%X | remaining=%d",
             (unsigned)FreeFireOffsets::UIModelSpectatorRemainingPlayerCountOffset,
             count);

    if (out) *out = snapshot;
    return 1;
}
