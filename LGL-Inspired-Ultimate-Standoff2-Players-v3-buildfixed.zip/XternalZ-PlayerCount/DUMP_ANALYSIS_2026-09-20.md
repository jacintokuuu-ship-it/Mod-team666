# Dump analysis — player-count diagnostic

Source analyzed: `dump (2).cs` supplied in this conversation.

## Confirmed GameFacade layout

From `GameFacade` (TypeDefIndex 12376):

- `CurrentGame` = `0x0`
- `CurrentMatchGame` = `0x8`
- `IsMatchStarted` = `0x209`
- `UIModelMatch` = `0x318`
- `UIModelSpectator` = `0x320`

Confirmed properties/method anchors:

- `GameFacade.get_UIModelMatch()` = RVA `0x592ED30`
- `GameFacade.get_UIModelSpectator()` = RVA `0x5933D60`

The external reader does not execute these methods; their RVAs remain as dump evidence and version anchors.

## Confirmed UIModelSpectator layout

`UIModelSpectator` (TypeDefIndex 25184):

- `m_TeamPlayerDic` = `0x28`
- `m_PlayerDic` = `0x30`
- `PlayerHudOperateDic` = `0x40`
- `HasPlayerDead` = `0x80`
- `m_DeadOrderList` = `0xA8`
- `m_RemainingPlayerCount` = `0xC4`
- `m_InBattleTeams` = `0x128`

Relevant method anchors:

- `get_RemainPlayer()` = `0x48F3474`
- `StartMatch()` = `0x48F36A4`
- `OnAddPlayer(Player)` = `0x48F3A44`
- `OnDelPlayer(...)` = `0x48F4E68`
- `OnAlivePlayerCountChanged(int)` = `0x48F56A4`
- `GetPlayerCount()` = `0x48F8C34`

This explains why `+0xC4` is a legitimate field, but does not by itself prove that the object being read is the live instance used by the current match.

## Confirmed UIModelMatch layout

`UIModelMatch` (TypeDefIndex 24622):

- `m_LocalTeamPlayerIDs` = `0x1C0`
- `m_OppoTeamPlayerIDs` = `0x1C8`
- `m_TeamPlayerDic` = `0x1E0`
- `m_PlayerDataList` = `0x1F0`
- `m_RemainingPlayerCount_max` = `0x364`
- `m_RemainingPlayerCount` = `0x368`

Relevant method anchors:

- `StartMatch()` = `0x46C145C`
- `get_RemainingPlayerCountMax()` = `0x46C4B24`
- `get_RemainingPlayerCount()` = `0x46C4B7C`
- `OnAlivePlayerCountChanged(int)` = `0x46CBD80`

This is a second independent count model and is now included in the six-route test suite.

## Confirmed MatchGame -> Match object chain

`MatchGame` (TypeDefIndex 12385):

- `m_Match` = `0x90`

`m_Match` points to `JMAGGLCNGIG` (TypeDefIndex 32046). That object contains multiple player dictionaries, including:

- `NOLEDCGOJKC` = `0x128` → `Dictionary<BEADLMGGGGL, Player>`
- `NJCGFLANJLH` = `0x130` → `Dictionary<BEADLMGGGGL, Player>`
- `GOFLDILNLBA` = `0x140` → `Dictionary<BEADLMGGGGL, Player>`
- `KAENAIKJLDD` = `0x150` → `Dictionary<BEADLMGGGGL, Player>`

The six-route implementation deliberately tests two of these dictionary chains first (`0x128` and `0x130`) because they are direct `Dictionary<..., Player>` fields in the dump.

## Six routes implemented

### C1 — Spectator field
`GameFacade static fields -> UIModelSpectator (0x320) -> m_RemainingPlayerCount (0xC4)`

### C2 — Spectator dictionary
`GameFacade static fields -> UIModelSpectator (0x320) -> m_PlayerDic (0x30) -> Dictionary.Count`

### C3 — Match-model field
`GameFacade static fields -> UIModelMatch (0x318) -> m_RemainingPlayerCount (0x368)`

### C4 — Match-model player list
`GameFacade static fields -> UIModelMatch (0x318) -> m_PlayerDataList (0x1F0) -> List.Count`

### C5 — Match object dictionary A
`GameFacade static fields -> CurrentMatchGame (0x8) -> m_Match (0x90) -> player dictionary (0x128) -> Dictionary.Count`

### C6 — Match object dictionary B
`GameFacade static fields -> CurrentMatchGame (0x8) -> m_Match (0x90) -> player dictionary (0x130) -> Dictionary.Count`

## Runtime interpretation

The menu no longer contains the previous ESP/verification cards. It contains only the six-route player-count lab.

The program does not silently promote one candidate to “the” correct value. During testing it reports `MatchStarted` plus C1..C6 simultaneously so that a live match can be compared against the visible in-game player total.

If C3/C4 agree while C1/C2 stay fixed at 0–1, the likely fault is the old spectator instance/field path. If C5/C6 agree with the visible count, the MatchGame path is the stronger candidate. If all six disagree, the next step is object-chain identification rather than changing offsets at random.

## Important external-reader limitation

The dump contains method RVAs, but this project is an external Mach VM reader. It does not inject or execute arbitrary target-process methods from those RVAs. Therefore C1..C6 use object fields and collection state rather than pretending that an RVA is callable externally.
