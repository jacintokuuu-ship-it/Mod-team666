#!/bin/bash
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

fail=0
check() {
  local label="$1"
  shift
  if "$@"; then
    printf '[PASS] %s\n' "$label"
  else
    printf '[FAIL] %s\n' "$label"
    fail=1
  fi
}

# 1. Active source graph
source_block="$(awk '/^EXCALIBUR_ALL_SOURCES :=/{flag=1;next}/^$/{if(flag) exit}flag' Makefile)"
! grep -F '$(wildcard' Makefile >/dev/null
for bad in TSEventFetcher.mm IOHIDEvent+KIF.m UITouch-KIFAdditions.m; do
  ! printf '%s\n' "$source_block" | grep -F "$bad" >/dev/null
done
printf '[PASS] source graph is explicit and excludes legacy event files\n'

# 2. Every active source exists
while IFS= read -r src; do
  [ -z "$src" ] && continue
  test -f "$src" || { echo "[FAIL] missing source: $src"; fail=1; }
done < <(printf '%s\n' "$source_block" | sed 's/\\//g' | tr '\\' ' ' | tr -s ' ' | grep -E '(^| )([A-Za-z0-9_+./-]+\.(m|mm|cpp))$' || true)

# 3. Known SDK blockers
if grep -REn --include='*.m' --include='*.mm' --include='*.h' --include='*.pch'   'setObject:@YES[[:space:]]+forKey:@"[^"]+"[[:space:]]+inDomain:' . >/tmp/xz_sdk_bad 2>/dev/null; then
  echo '[FAIL] unsupported NSUserDefaults inDomain selector remains'
  cat /tmp/xz_sdk_bad
  fail=1
else
  echo '[PASS] unsupported NSUserDefaults selector absent from code'
fi

if grep -REn --include='*.m' --include='*.mm' 'backgroundColor[[:space:]]*=[^;]*\.CGColor' . >/tmp/xz_cg_bad 2>/dev/null; then
  echo '[FAIL] CGColor assigned to UIColor backgroundColor'
  cat /tmp/xz_cg_bad
  fail=1
else
  echo '[PASS] UIColor/CGColor assignment audit'
fi

# 4. C++/ImGui guards
! grep -REn --include='*.mm' '\bImClamp\b' imgui functions overlay objc_base 2>/dev/null
! grep -REn --include='ImGuiDrawView.mm' '\bImVec2[^\n]*\+' imgui 2>/dev/null
grep -F '#include <algorithm>' imgui/ImGuiDrawView.mm >/dev/null
printf '[PASS] ImGui clamp/vector guards\n'

# 5. Build contract
grep -F 'TARGET := iphone:clang:15.6:15.0' Makefile >/dev/null
grep -F 'ARCHS := arm64' Makefile >/dev/null
grep -F 'Excalibur_CCFLAGS += -std=c++17' Makefile >/dev/null
grep -F 'Excalibur_OBJCCFLAGS += -std=c++17' Makefile >/dev/null
printf '[PASS] Theos target/toolchain flags\n'

# 6. PCH notification definitions
grep -F 'NOTIFY_LAUNCHED_HUD' hud-prefix.pch >/dev/null
! grep -F -- '-DNOTIFY_' Makefile >/dev/null
printf '[PASS] notification definitions\n'

# 7. Bundle manifests agree
python3 -S -c '
import plistlib
from pathlib import Path
a=plistlib.loads(Path("Resources/Info.plist").read_bytes())
b=plistlib.loads(Path("layout/Applications/Excalibur.app/Info.plist").read_bytes())
keys=("CFBundleExecutable","CFBundleIdentifier","CFBundleVersion","CFBundleShortVersionString","CFBundlePackageType","NSPrincipalClass")
assert all(a.get(k)==b.get(k) for k in keys)
assert b["CFBundleExecutable"]=="Excalibur"
assert b["CFBundlePackageType"]=="APPL"
print("[PASS] Info.plist manifests agree")
'

# 8. Executable packaging inputs
test -f layout/Applications/Excalibur.app/Info.plist
test -f Resources/Info.plist
test -f Resources/icon.png
test -f Resources/fogo.png
printf '[PASS] packaging resources\n'

# 9. Runtime safety checks in player-count reader
grep -F 'std::mutex gReaderMutex' functions/PlayerCountReader.mm >/dev/null
grep -F 'std::lock_guard<std::mutex> lock(gReaderMutex);' functions/PlayerCountReader.mm >/dev/null
grep -F 'CloseTask();' functions/PlayerCountReader.mm >/dev/null
printf '[PASS] player-count task lifecycle/threading guards\n'

rm -f /tmp/xz_sdk_bad /tmp/xz_cg_bad
exit "$fail"
