#!/bin/bash
set -Eeuo pipefail

echo '[1/7] literal source graph'
grep -F 'EXCALIBUR_ALL_SOURCES :=' Makefile >/dev/null
grep -F '$(wildcard' Makefile && { echo 'wildcard forbidden'; exit 1; } || true
SOURCE_BLOCK=$(awk '/^EXCALIBUR_ALL_SOURCES :=/{flag=1;next}/^$/{if(flag) exit}flag' Makefile)
for bad in TSEventFetcher.mm IOHIDEvent+KIF.m UITouch-KIFAdditions.m; do
  ! printf '%s\n' "$SOURCE_BLOCK" | grep -F "$bad" >/dev/null || { echo "legacy source in active graph: $bad"; exit 1; }
done

echo '[2/7] exact player anchors'
grep -F 'GameFacadeUIModelSpectatorStaticOffset      = 0x320' functions/Offsets.h >/dev/null
grep -F 'UIModelSpectatorRemainingPlayerCountOffset   = 0xC4' functions/Offsets.h >/dev/null
grep -F 'UIModelSpectatorGetPlayerCountRVA             = 0x048F8C34' functions/Offsets.h >/dev/null

echo '[3/7] notify definitions are in PCH'
grep -F 'NOTIFY_LAUNCHED_HUD' hud-prefix.pch >/dev/null
! grep -F -- '-DNOTIFY_' Makefile >/dev/null

echo '[4/7] player count switch bridge'
grep -F 'HUDSetPlayerCountEnabled' include/HUDBridge.h menu/menu.m objc_base/HUDMainApplication.mm >/dev/null

echo '[5/7] no orphan CaptainHook include in active ImGui source'
! grep -F '#import "../hooks/CaptainHook.h"' imgui/ImGuiDrawView.mm >/dev/null

echo '[6/7] plist'
plutil -lint Resources/Info.plist >/dev/null

echo '[7/7] source files in graph exist'
for src in objc_base/HUDApp.mm objc_base/HUDMainApplication.mm objc_base/MainApplication.mm objc_base/UIView+SecureView.m menu/menu.m overlay/ESPImGuiView.mm tasks/pid.mm functions/ESPExternalReader.mm functions/PlayerCountReader.mm; do
  test -f "$src" || { echo "missing graph source: $src"; exit 1; }
done
echo 'PASS'
