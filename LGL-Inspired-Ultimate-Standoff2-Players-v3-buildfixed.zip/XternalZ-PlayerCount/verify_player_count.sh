#!/bin/bash
set -Eeuo pipefail

echo '[1/7] literal source graph'
grep -F 'EXCALIBUR_ALL_SOURCES :=' Makefile >/dev/null
grep -F '$(wildcard' Makefile && { echo 'wildcard forbidden'; exit 1; } || true
SOURCE_BLOCK=$(awk '/^EXCALIBUR_ALL_SOURCES :=/{flag=1;next}/^$/{if(flag) exit}flag' Makefile)
for bad in TSEventFetcher.mm IOHIDEvent+KIF.m UITouch-KIFAdditions.m; do
  ! printf '%s\n' "$SOURCE_BLOCK" | grep -F "$bad" >/dev/null || { echo "legacy source in active graph: $bad"; exit 1; }
done

echo '[2/7] six diagnostic routes and dump anchors'
for needle in \
  'GameFacadeUIModelSpectatorStaticOffset     = 0x320' \
  'GameFacadeUIModelMatchStaticOffset         = 0x318' \
  'GameFacadeIsMatchStartedStaticOffset       = 0x209' \
  'UIModelSpectatorRemainingPlayerCountOffset  = 0xC4' \
  'UIModelMatchRemainingPlayerCountOffset       = 0x368' \
  'UIModelMatchPlayerDataListOffset             = 0x1F0' \
  'MatchObjectPlayerDictionaryAOffset            = 0x128' \
  'MatchObjectPlayerDictionaryBOffset            = 0x130' \
  'UIModelSpectatorGetPlayerCountRVA            = 0x048F8C34' \
  'UIModelSpectatorGetRemainPlayerRVA            = 0x048F3474' \
  'UIModelMatchGetRemainingPlayerCountRVA       = 0x046C4B7C'; do
  grep -F "$needle" functions/Offsets.h >/dev/null || { echo "missing anchor: $needle"; exit 1; }
done
grep -F 'FF_PLAYER_COUNT_CANDIDATE_COUNT 6' functions/PlayerCountReader.h >/dev/null
grep -F 'ReadCandidate6' functions/PlayerCountReader.mm >/dev/null

echo '[3/7] notify definitions are in PCH'
grep -F 'NOTIFY_LAUNCHED_HUD' hud-prefix.pch >/dev/null
! grep -F -- '-DNOTIFY_' Makefile >/dev/null

echo '[4/7] player count switch bridge'
grep -F 'HUDSetPlayerCountEnabled' include/HUDBridge.h menu/menu.m objc_base/HUDMainApplication.mm >/dev/null

echo '[5/7] no orphan CaptainHook include in active ImGui source'
! grep -F '#import "../hooks/CaptainHook.h"' imgui/ImGuiDrawView.mm >/dev/null

echo '[6/7] plist'
plutil -lint Resources/Info.plist >/dev/null

echo '[7/7] source files in graph exist'
for src in objc_base/HUDApp.mm objc_base/HUDMainApplication.mm objc_base/MainApplication.mm objc_base/UIView+SecureView.m menu/menu.m overlay/ESPImGuiView.mm tasks/pid.mm functions/ESPExternalReader.mm functions/PlayerCountReader.mm; do
  test -f "$src" || { echo "missing graph source: $src"; exit 1; }
done
echo 'PASS'
