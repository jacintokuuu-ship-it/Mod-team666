# XternalZ — Player Count build

## Build

Target: `iphone:clang:15.6:15.0`, `arm64`, C++17/Objective-C++17.

Run on the macOS/Theos runner:

```sh
chmod +x verify_player_count.sh
./verify_player_count.sh
make clean || true
make all SDKVERSION=15.6 messages=yes
```

The build's `after-stage` rule validates `Payload/Excalibur.app/Info.plist` before creating `packages/Excalibur.tipa`.

## Function

Enable `JOGADORES NA PARTIDA` in the HUD switch. The external reader resolves the `GameFacade` static-fields pointer, obtains `UIModelSpectator` with the dump-confirmed `0x320` field offset, validates the object, and reads `m_RemainingPlayerCount` at `0xC4` every 350 ms.

The function does not execute the remote getter or inject a hook. A changed count produces a toast with the new value.

## Updating offsets

Edit only `functions/Offsets.h`. The current confirmed anchors are:

- `GameFacadeUIModelSpectatorStaticOffset = 0x320`
- `UIModelSpectatorPlayerDicOffset = 0x30`
- `UIModelSpectatorHasPlayerDeadOffset = 0x80`
- `UIModelSpectatorRemainingPlayerCountOffset = 0xC4`
- `UIModelSpectatorGetPlayerCountRVA = 0x48F8C34`
- `GameFacadeGetUIModelSpectatorRVA = 0x5933D60`

If a future dump changes the object layout itself, update the reader validation offsets only after confirming those fields in the new dump. Do not add guessed offsets to unrelated files.
