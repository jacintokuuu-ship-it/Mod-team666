# Runtime / packaging privilege matrix

## TrollStore

The current official TrollStore README documents permanent IPA installation with preserved arbitrary entitlements, plus root-helper support. It also explicitly notes limitations: TrollStore does not provide true platformization, cannot spawn a launch daemon solely through that mechanism, and cannot inject a tweak into a system process.

For iOS 16+, some sensitive entitlements (including `get-task-allow`, `task_for_pid-allow`, and `com.apple.system-task-ports`) can require Developer Mode; some code-signing/debugging entitlements are specifically blocked on affected devices.

## This project

The existing `ent.plist` already requests a very large set of private entitlements, including:
- global/accessibility HUD hosting
- system task ports / task-for-pid related access
- no-sandbox / no-container
- AppDataContainers
- persona management
- platform-application

No new entitlement was added by the menu/touch repair.

## Jailbreak / Theos

For rootless jailbreak packaging, Theos documents `THEOS_PACKAGE_SCHEME=rootless`; it changes the install prefix to `/var/jb` and adjusts rpaths/package architecture accordingly. The current Makefile remains compatible with an explicit rootless build invocation; the generated IPA remains a separate app bundle.

## Scope boundary

The menu/UI work does not invent new game manipulation primitives or claim that TrollStore alone makes every private entitlement effective. Existing process/task/Unity/ESP modules remain preserved and are the source of their actual runtime behavior.
