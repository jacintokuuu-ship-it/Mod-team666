# Deterministic HUD touch architecture

The HUD input path now has two layers:

1. `HUDRouteTouch(...)` runs first on the main queue and owns only the visible
   menu rectangle while open, or the minimized reopen hotspot while closed.
2. The existing `TSEventFetcher` synthetic UIKit path remains the fallback for
   touches that are not consumed by the HUD.

Menu behavior:
- header (except minimize button): drag
- minimize: tap to hide
- tab strip: tap to switch pages
- content area: tap controls; vertical movement scrolls
- outside the menu: not consumed

The direct router prevents duplicate control activation by returning before
`TSEventFetcher` handles a consumed menu/hotspot touch.
