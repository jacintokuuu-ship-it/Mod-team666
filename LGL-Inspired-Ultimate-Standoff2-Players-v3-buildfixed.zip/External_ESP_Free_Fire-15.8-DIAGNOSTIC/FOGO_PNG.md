# Assete do menu

Use o arquivo PNG com o nome exato:

`fogo.png`

Coloque-o em:

`Resources/fogo.png`

O mesmo `fogo.png` é usado como:
- ícone/botão flutuante do menu quando minimizado;
- ícone principal do aplicativo/IPA (`CFBundleIconFile`).

A versão entregue já contém um arquivo `Resources/fogo.png` como placeholder para não quebrar o build.
Quando você tiver a arte definitiva, basta substituir esse arquivo mantendo o mesmo nome e formato PNG.
