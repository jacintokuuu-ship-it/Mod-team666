# LGL Inspired — Free Fire External HUD

Esta revisão reproduz a arquitetura externa do XternalZ: aplicativo separado, acesso ao processo por `task_t`/Mach VM e desenho do HUD fora do Free Fire.

## Verificar

O botão **VERIFICAR — ACESSO AO FREE FIRE** mostra um toast com diagnóstico objetivo: processo encontrado, task aberta, `UnityFramework`, cabeçalho Mach-O e quantidade de RVAs legíveis.

## Sem injetor

O build padrão não contém tweak, dylib injetada nem hook interno.

## Estado do ESP Line

A infraestrutura de desenho está preparada, porém a enumeração de entidades live ainda não é simulada. Para mostrar linhas sobre jogadores reais é necessário ligar a cadeia externa de jogadores ao snapshot.


## 2026-09-21 — external transport audit

This revision does not claim that TrollStore/iOS 15.8.8 automatically grants access to another process. The runtime diagnostic now records effective UID/GID, TASK_BASIC_INFO availability, readable/executable region counts, and whether each configured RVA lands in an RX region. This distinguishes memory accessibility from semantic RVA validity.

The project remains external: it does not inject a dylib into the target process. Entity enumeration is intentionally reported as unavailable until a verified, version-matched entity chain is supplied.
