MAKTER BR 2.3.0 — Orientation
Base: ateq.zip.

The orientation pipeline now follows the TrollSpeed reference architecture:
FBSOrientationObserver -> HUDRootViewController -> root-view bounds swap + one transform.
The UIWindow itself is not rotated. Menu, hotspot and ESP do not add a second rotation.
Touch coordinates continue through UIKit's window->view conversion, so hit-testing and
dragging use the same transformed coordinate space as the visible controls.
