# External-only build contract

- Product type: standalone iOS application / external HUD.
- Theos target: `APPLICATION_NAME := Excalibur`.
- Output: `Excalibur.ipa` / staged `Excalibur.app`.
- No tweak target is built.
- No DynamicLibraries `.dylib` is copied into the application payload by the default build.
- `hooks/CaptainHook.h` is retained only as legacy source/reference and is not used as an in-process hook.
- The memory path is out-of-process: process lookup → Mach task → remote reads.
