# LGL Inspired — External-only architecture

The active target is a standalone HUD application. It does not inject a dylib into Free Fire.

```text
LGL HUD (separate process)
        |
        +--> get_pid_by_name("FreeFire")
        |
        +--> task_for_pid() / Mach fallback
        |
        +--> TASK_DYLD_INFO -> UnityFramework base
        |
        +--> mach_vm_read_overwrite()
        |
        +--> external snapshot / drawing
        v
Free Fire process
```

## Active modules

- `tasks/pid.mm`: process lookup, task acquisition and remote image discovery.
- `functions/ESPExternalReader.mm`: external verification and remote-read snapshot backend.
- `functions/Offsets.h`: Free Fire RVAs supplied by the user.
- `overlay/ESPImGuiView.mm`: transparent overlay/drawing surface.
- `objc_base/HUDMainApplication.mm`: HUD lifecycle, drawing and toast.
- `menu/menu.m`: native controls, including **VERIFICAR**.

## Explicitly not present in the active build

- injected `.dylib` payload
- MobileSubstrate/Substitute/ElleKit tweak target
- TCP/SHM probe transport


## External verification

The **VERIFICAR — ACESSO AO FREE FIRE** control performs an actual out-of-process check:

1. find the `FreeFire` process;
2. obtain its `task_t`;
3. find the `UnityFramework` load address;
4. read the remote Mach-O header;
5. read four bytes at the supplied Free Fire RVAs.

The result is displayed as a toast and in the status card.

## Current ESP state

The drawing pipeline is external, but live player enumeration is intentionally not faked. The current snapshot therefore reports zero targets until the exact player-list/LocalPlayer chain from the same game build is wired into the external reader.
