#pragma once

#include <stdint.h>

#define ESP_EXTERNAL_MAGIC          0x45585431u /* EXT1 */
#define ESP_EXTERNAL_VERSION        3u
#define ESP_EXTERNAL_MAX_TARGETS    64u

/* Target coordinates are normalized Unity viewport coordinates:
 * x/y in [0,1], origin at bottom-left. The HUD converts them to its own
 * point-space and draws the final 2D rectangle.
 */
typedef struct ESPExternalTarget {
    uint64_t player;
    float x;
    float y;
    float z;
    float depth;
    float boxTop;
    float boxBottom;
    float boxWidthRatio;
    uint32_t teamIndex;
    uint32_t flags;
    uint32_t valid;
} ESPExternalTarget;

typedef struct ESPExternalSnapshot {
    uint32_t magic;
    uint32_t version;

    uint32_t processFound;
    uint32_t taskOpened;
    uint32_t unityFound;
    uint32_t machoReadable;

    uint32_t rvaReadableCount;
    uint32_t rvaTestCount;

    int32_t processPID;
    uint64_t task;
    uint64_t unityBase;
    uint64_t lastCheckNanos;

    uint32_t lastError;
    uint32_t effectiveUID;
    uint32_t effectiveGID;
    uint32_t taskBasicInfoOK;
    uint32_t readableRegionCount;
    uint32_t executableRegionCount;
    uint32_t rvaExecutableCount;

    uint32_t liveChainOK;
    uint32_t playerListOK;
    uint32_t cameraOK;
    uint32_t projectionOK;
    uint32_t localPlayerOK;
    uint32_t localTeamOK;

    uint64_t match;
    uint64_t playerList;
    uint64_t cameraManager;
    uint64_t camera;
    uint64_t localPlayer;

    uint32_t rawPlayerCount;
    uint32_t acceptedPlayerCount;
    uint32_t projectedPlayerCount;
    uint32_t count;

    ESPExternalTarget targets[ESP_EXTERNAL_MAX_TARGETS];
    char message[512];
} ESPExternalSnapshot;

#ifdef __cplusplus
extern "C" {
#endif

int ESPExternalSetMode(int mode);
int ESPExternalGetMode(void);
int ESPExternalVerify(ESPExternalSnapshot *out);
int ESPExternalReadSnapshot(ESPExternalSnapshot *out);
int ESPExternalCopyCachedSnapshot(ESPExternalSnapshot *out);
const char *ESPExternalStatusText(void);
const char *ESPExternalDiagnosticText(void);

#ifdef __cplusplus
}
#endif
