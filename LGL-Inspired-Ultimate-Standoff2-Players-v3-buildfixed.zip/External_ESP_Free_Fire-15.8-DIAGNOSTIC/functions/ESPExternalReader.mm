#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach/arm/thread_status.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <cmath>
#include <cstddef>
#include <algorithm>
#include <atomic>
#include <mutex>
#include <vector>

namespace {

// ============================================================================
// Process state
// ============================================================================

static task_t gTask = MACH_PORT_NULL;
static vm_address_t gUnityBase = 0;
static pid_t gTargetPID = -1;
static std::atomic<int> gMode{0};
static std::mutex gStateMutex;

static ESPExternalSnapshot gCachedSnapshot{};
static uint64_t gCachedSnapshotNanos = 0;
static bool gCachedSnapshotValid = false;

// ============================================================================
// Remote ARM64 execution page
//
// The game exposes the exact getters we need in the dump, but an external
// process cannot invoke those C# / Unity methods as ordinary local calls.
// This tiny ARM64 trampoline executes one of the verified target methods in a
// short-lived remote thread, stores only its return value in a remote RW page,
// and the external process reads that result back with vm_read_overwrite.
//
// The helper is deliberately limited to read-only getters and projection.
// No game memory is written except the temporary helper pages owned by this
// external task.
// ============================================================================

struct RemotePage {
    vm_address_t code = 0;
    vm_address_t data = 0;
    task_t task = MACH_PORT_NULL;
    pid_t pid = -1;
};

static RemotePage gRemotePage;

// Forward declarations used by the remote trampoline section.
static uint64_t NowNanos(void);
static bool ReadRemote(task_t task, vm_address_t address, void *out, vm_size_t size);

static constexpr vm_size_t kRemoteCodeSize = 0x1000;
static constexpr vm_size_t kRemoteDataSize = 0x8000;
static constexpr vm_address_t kCtxU64       = 0x000;
static constexpr vm_address_t kResultU64    = 0x100;
static constexpr vm_address_t kDoneU64      = 0x108;
static constexpr vm_address_t kCtxBatch     = 0x1000;
static constexpr vm_address_t kPlayers      = 0x1200;
static constexpr vm_address_t kBatchResults = 0x1600;
static constexpr vm_address_t kCtxProject   = 0x2000;
static constexpr vm_address_t kProjectInput = 0x2100;
static constexpr vm_address_t kProjectOut   = 0x2A00;
static constexpr vm_address_t kRemoteStack  = 0x7000;

/* Generated from real arm64 assembly; each array is copied verbatim into the
 * remote executable page. They contain no local absolute addresses. */
static const uint32_t kCallU64Code[] = {
    0xA9BF7BFD, 0x910003FD, 0xAA0003F3, 0xF9400270,
    0xF9400660, 0xD63F0200, 0xF9400A71, 0xF9000220,
    0x52800020, 0xF9400E71, 0xB9000220, 0x14000000
};

static const uint32_t kCallVecCode[] = {
    0xA9BF7BFD, 0x910003FD, 0xAA0003F3, 0xF9400270,
    0xF9400660, 0xD63F0200, 0xF9400A71, 0xBD000220,
    0xBD000621, 0xBD000A22, 0x52800020, 0xF9400E71,
    0xB9000220, 0x14000000
};

static const uint32_t kCallF32Code[] = {
    0xA9BF7BFD, 0x910003FD, 0xAA0003F3, 0xF9400270,
    0xF9400660, 0xD63F0200, 0xF9400A71, 0xBD000220,
    0x52800020, 0xF9400E71, 0xB9000220, 0x14000000
};

static const uint32_t kProbePlayersCode[] = {
    0xA9BF7BFD, 0x910003FD, 0xAA0003F3, 0xB9400276,
    0xF9400674, 0xF9400A75, 0xF9400E78, 0xF9401279,
    0xF940167A, 0xF940227B, 0x2A1F03F7, 0x6B1602FF,
    0x5400042A, 0xD37DF2FC, 0xF87C6A80, 0xB40002C0,
    0xEB1B001F, 0x54000280, 0xD37BEAFC, 0x8B1C02BC,
    0xD63F0300, 0xBD000380, 0xBD000781, 0xBD000B82,
    0xF8777A80, 0xD63F0320, 0xBD000F80, 0xF8777A80,
    0xD63F0340, 0xB9001380, 0xF8777A80, 0xF9401A78,
    0xD63F0300, 0xB9001780, 0x52800020, 0xB9001B80,
    0x14000005, 0xD37BEAFC, 0x8B1C02BC, 0x2A1F03E0,
    0xB9001B80, 0x110006F7, 0xF9400E78, 0x6B1602FF,
    0x54FFFBEB, 0x52800020, 0xB9004A60, 0x14000000
};

static const uint32_t kProjectPointsCode[] = {
    0xA9BF7BFD, 0x910003FD, 0xAA0003F3, 0xB9400276,
    0xF9400674, 0xF9400A75, 0xF9400E78, 0xF940127B,
    0x2A1F03F7, 0x6B1602FF, 0x540003EA, 0xD37DF2FC,
    0x8B17139C, 0x8B1C029C, 0xBD400380, 0xBD400781,
    0xBD400B82, 0xAA1B03E0, 0xD63F0300, 0xD37BEAFC,
    0x8B1C02BC, 0xBD000380, 0xBD000781, 0xBD000B82,
    0xD37DF2FC, 0x8B17139C, 0x8B1C029C, 0xBD400F80,
    0xBD401381, 0xBD401782, 0xAA1B03E0, 0xD63F0300,
    0xD37BEAFC, 0x8B1C02BC, 0xBD000F80, 0xBD001381,
    0xBD001782, 0x52800020, 0xB9001B80, 0x110006F7,
    0x17FFFFE1, 0x52800020, 0xB9002A60, 0x14000000
};

struct RemoteBatchContext {
    uint32_t count;
    uint32_t reserved;
    uint64_t players;
    uint64_t results;
    uint64_t centerFn;
    uint64_t radiusFn;
    uint64_t teamFn;
    uint64_t deadFn;
    uint64_t reserved2;
    uint64_t localPlayer;
    uint32_t done;
    uint32_t reserved3;
};

struct RemoteProjectContext {
    uint32_t count;
    uint32_t reserved;
    uint64_t points;
    uint64_t results;
    uint64_t viewportFn;
    uint64_t camera;
    uint32_t done;
    uint32_t reserved2;
};

struct RemotePlayerResult {
    float x;
    float y;
    float z;
    float radius;
    int32_t team;
    uint32_t dead;
    uint32_t valid;
    uint32_t reserved;
};

struct RemoteProjectionResult {
    float x0;
    float y0;
    float z0;
    float x1;
    float y1;
    float z1;
    uint32_t valid;
    uint32_t reserved;
};

static_assert(sizeof(RemotePlayerResult) == 0x20, "remote player ABI changed");
static_assert(offsetof(RemoteBatchContext, done) == 0x48, "batch done offset changed");
static_assert(offsetof(RemoteProjectContext, done) == 0x28, "projection done offset changed");
static_assert(sizeof(RemoteProjectionResult) == 0x20, "remote projection ABI changed");

static void ResetRemotePageLocked()
{
    if (gRemotePage.task != MACH_PORT_NULL && gRemotePage.pid == gTargetPID) {
        if (gRemotePage.code)
            vm_deallocate(gRemotePage.task, gRemotePage.code, kRemoteCodeSize);
        if (gRemotePage.data)
            vm_deallocate(gRemotePage.task, gRemotePage.data, kRemoteDataSize);
    }
    gRemotePage = {};
}

static bool WriteRemote(task_t task, vm_address_t address, const void *data, vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !data || size == 0)
        return false;

    kern_return_t kr = vm_write(task,
                                address,
                                (vm_offset_t)(uintptr_t)data,
                                (mach_msg_type_number_t)size);
    return kr == KERN_SUCCESS;
}

static bool EnsureRemotePageLocked()
{
    if (gTask == MACH_PORT_NULL || gTargetPID <= 0)
        return false;

    if (gRemotePage.code && gRemotePage.data &&
        gRemotePage.task == gTask && gRemotePage.pid == gTargetPID) {
        return true;
    }

    ResetRemotePageLocked();

    vm_address_t code = 0;
    vm_address_t data = 0;

    if (vm_allocate(gTask, &code, kRemoteCodeSize, VM_FLAGS_ANYWHERE) != KERN_SUCCESS)
        return false;
    if (vm_allocate(gTask, &data, kRemoteDataSize, VM_FLAGS_ANYWHERE) != KERN_SUCCESS) {
        vm_deallocate(gTask, code, kRemoteCodeSize);
        return false;
    }

    const struct {
        vm_address_t offset;
        const uint32_t *code;
        size_t words;
    } blocks[] = {
        {0x000, kCallU64Code, sizeof(kCallU64Code) / sizeof(kCallU64Code[0])},
        {0x100, kCallVecCode, sizeof(kCallVecCode) / sizeof(kCallVecCode[0])},
        {0x200, kCallF32Code, sizeof(kCallF32Code) / sizeof(kCallF32Code[0])},
        {0x400, kProbePlayersCode, sizeof(kProbePlayersCode) / sizeof(kProbePlayersCode[0])},
        {0x600, kProjectPointsCode, sizeof(kProjectPointsCode) / sizeof(kProjectPointsCode[0])}
    };

    bool writeOK = true;
    for (const auto &block : blocks) {
        if (!WriteRemote(gTask,
                         (vm_address_t)(code + block.offset),
                         block.code,
                         (vm_size_t)(block.words * sizeof(uint32_t)))) {
            writeOK = false;
            break;
        }
    }

    if (!writeOK) {
        vm_deallocate(gTask, code, kRemoteCodeSize);
        vm_deallocate(gTask, data, kRemoteDataSize);
        return false;
    }

    // The remote helper must remain writable for context/results but executable
    // code is isolated in a separate RX page.
    if (vm_protect(gTask, code, kRemoteCodeSize, FALSE,
                        VM_PROT_READ | VM_PROT_EXECUTE) != KERN_SUCCESS) {
        vm_deallocate(gTask, code, kRemoteCodeSize);
        vm_deallocate(gTask, data, kRemoteDataSize);
        return false;
    }

    gRemotePage.code = code;
    gRemotePage.data = data;
    gRemotePage.task = gTask;
    gRemotePage.pid = gTargetPID;
    return true;
}

static bool RunRemoteStubLocked(vm_address_t codeOffset,
                                vm_address_t contextOffset,
                                vm_address_t doneOffset,
                                uint32_t timeoutMs)
{
    if (!EnsureRemotePageLocked())
        return false;

    const vm_address_t code = (vm_address_t)(gRemotePage.code + codeOffset);
    const vm_address_t context = (vm_address_t)(gRemotePage.data + contextOffset);
    const vm_address_t doneAddress = (vm_address_t)(gRemotePage.data + doneOffset);

    uint32_t zero = 0;
    if (!WriteRemote(gTask, doneAddress, &zero, sizeof(zero)))
        return false;

    arm_thread_state64_t state{};
#if defined(__DARWIN_OPAQUE_ARM_THREAD_STATE64) && __DARWIN_OPAQUE_ARM_THREAD_STATE64
    state.__opaque_pc = (void *)(uintptr_t)code;
    state.__opaque_sp = (void *)(uintptr_t)(gRemotePage.data + kRemoteStack + 0xFF0);
    state.__opaque_x[0] = (uint64_t)context;
    state.__opaque_x[1] = 0;
    state.__opaque_x[2] = 0;
    state.__opaque_x[3] = 0;
#else
    state.__pc = (uint64_t)code;
    state.__sp = (uint64_t)(gRemotePage.data + kRemoteStack + 0xFF0);
    state.__x[0] = (uint64_t)context;
    state.__x[1] = 0;
    state.__x[2] = 0;
    state.__x[3] = 0;
#endif

    thread_act_t remoteThread = MACH_PORT_NULL;
    mach_msg_type_number_t count = ARM_THREAD_STATE64_COUNT;
    kern_return_t kr = thread_create_running(gTask,
                                             ARM_THREAD_STATE64,
                                             (thread_state_t)&state,
                                             count,
                                             &remoteThread);
    if (kr != KERN_SUCCESS || remoteThread == MACH_PORT_NULL)
        return false;

    bool completed = false;
    const uint64_t deadline = NowNanos() + (uint64_t)timeoutMs * 1000000ull;

    while (NowNanos() < deadline) {
        uint32_t done = 0;
        if (ReadRemote(gTask, doneAddress, &done, sizeof(done)) && done == 1) {
            completed = true;
            break;
        }
        usleep(1000);
    }

    // The stub deliberately parks in a tight branch after completing its work;
    // terminating only that temporary helper thread leaves the game threads
    // untouched.
    thread_terminate(remoteThread);
    mach_port_deallocate(mach_task_self(), remoteThread);

    return completed;
}

static bool RemoteCallU64Locked(uintptr_t rva, uint64_t arg, uint64_t &out)
{
    out = 0;
    if (!EnsureRemotePageLocked())
        return false;

    struct Context {
        uint64_t function;
        uint64_t arg;
        uint64_t result;
        uint64_t done;
    };

    Context ctx{};
    ctx.function = gUnityBase + (vm_address_t)rva;
    ctx.arg = arg;
    ctx.result = gRemotePage.data + kResultU64;
    ctx.done = gRemotePage.data + kDoneU64;

    if (!WriteRemote(gTask, gRemotePage.data + kCtxU64, &ctx, sizeof(ctx)))
        return false;

    if (!RunRemoteStubLocked(0x000, kCtxU64, kDoneU64, 120))
        return false;

    return ReadRemote(gTask, gRemotePage.data + kResultU64, &out, sizeof(out));
}

static bool RemoteCallVecLocked(uintptr_t rva, uint64_t arg, float out[3])
{
    if (!out || !EnsureRemotePageLocked())
        return false;

    struct Context {
        uint64_t function;
        uint64_t arg;
        uint64_t result;
        uint64_t done;
    };

    Context ctx{};
    ctx.function = gUnityBase + (vm_address_t)rva;
    ctx.arg = arg;
    ctx.result = gRemotePage.data + kResultU64;
    ctx.done = gRemotePage.data + kDoneU64;

    if (!WriteRemote(gTask, gRemotePage.data + kCtxU64, &ctx, sizeof(ctx)))
        return false;

    if (!RunRemoteStubLocked(0x100, kCtxU64, kDoneU64, 120))
        return false;

    return ReadRemote(gTask, gRemotePage.data + kResultU64, out, sizeof(float) * 3);
}

static bool RemoteCallF32Locked(uintptr_t rva, uint64_t arg, float &out)
{
    out = 0.0f;
    if (!EnsureRemotePageLocked())
        return false;

    struct Context {
        uint64_t function;
        uint64_t arg;
        uint64_t result;
        uint64_t done;
    };

    Context ctx{};
    ctx.function = gUnityBase + (vm_address_t)rva;
    ctx.arg = arg;
    ctx.result = gRemotePage.data + kResultU64;
    ctx.done = gRemotePage.data + kDoneU64;

    if (!WriteRemote(gTask, gRemotePage.data + kCtxU64, &ctx, sizeof(ctx)))
        return false;

    if (!RunRemoteStubLocked(0x200, kCtxU64, kDoneU64, 120))
        return false;

    return ReadRemote(gTask, gRemotePage.data + kResultU64, &out, sizeof(out));
}

static bool RemoteProbePlayersLocked(const std::vector<uint64_t> &players,
                                     uintptr_t centerRVA,
                                     uintptr_t radiusRVA,
                                     uintptr_t teamRVA,
                                     uintptr_t deadRVA,
                                     uint64_t localPlayer,
                                     std::vector<RemotePlayerResult> &out)
{
    out.assign(players.size(), {});
    if (players.empty() || !EnsureRemotePageLocked())
        return true;

    const size_t count = std::min(players.size(), (size_t)ESP_EXTERNAL_MAX_TARGETS);
    if (!WriteRemote(gTask,
                     gRemotePage.data + kPlayers,
                     players.data(),
                     (vm_size_t)(count * sizeof(uint64_t)))) {
        return false;
    }

    RemoteBatchContext ctx{};
    ctx.count = (uint32_t)count;
    ctx.players = gRemotePage.data + kPlayers;
    ctx.results = gRemotePage.data + kBatchResults;
    ctx.centerFn = gUnityBase + (vm_address_t)centerRVA;
    ctx.radiusFn = gUnityBase + (vm_address_t)radiusRVA;
    ctx.teamFn = gUnityBase + (vm_address_t)teamRVA;
    ctx.deadFn = gUnityBase + (vm_address_t)deadRVA;
    ctx.localPlayer = localPlayer;
    ctx.done = 0;

    if (!WriteRemote(gTask, gRemotePage.data + kCtxBatch, &ctx, sizeof(ctx)))
        return false;

    std::vector<RemotePlayerResult> remote(count);
    memset(remote.data(), 0, remote.size() * sizeof(RemotePlayerResult));
    if (!WriteRemote(gTask,
                     gRemotePage.data + kBatchResults,
                     remote.data(),
                     (vm_size_t)(remote.size() * sizeof(RemotePlayerResult)))) {
        return false;
    }

    if (!RunRemoteStubLocked(0x400, kCtxBatch,
                             kCtxBatch + offsetof(RemoteBatchContext, done),
                             180)) {
        return false;
    }

    if (!ReadRemote(gTask,
                    gRemotePage.data + kBatchResults,
                    remote.data(),
                    (vm_size_t)(remote.size() * sizeof(RemotePlayerResult)))) {
        return false;
    }

    out = remote;
    return true;
}

static bool RemoteProjectPlayersLocked(uint64_t camera,
                                       uintptr_t projectionRVA,
                                       const std::vector<float> &points,
                                       std::vector<RemoteProjectionResult> &out)
{
    out.assign(points.size() / 6u, {});
    if (points.empty() || !EnsureRemotePageLocked())
        return true;

    const size_t count = std::min(points.size() / 6u, (size_t)ESP_EXTERNAL_MAX_TARGETS);
    if (!WriteRemote(gTask,
                     gRemotePage.data + kProjectInput,
                     points.data(),
                     (vm_size_t)(count * 6u * sizeof(float)))) {
        return false;
    }

    RemoteProjectContext ctx{};
    ctx.count = (uint32_t)count;
    ctx.points = gRemotePage.data + kProjectInput;
    ctx.results = gRemotePage.data + kProjectOut;
    ctx.viewportFn = gUnityBase + (vm_address_t)projectionRVA;
    ctx.camera = camera;
    ctx.done = 0;

    if (!WriteRemote(gTask, gRemotePage.data + kCtxProject, &ctx, sizeof(ctx)))
        return false;

    std::vector<RemoteProjectionResult> remote(count);
    memset(remote.data(), 0, remote.size() * sizeof(RemoteProjectionResult));
    if (!WriteRemote(gTask,
                     gRemotePage.data + kProjectOut,
                     remote.data(),
                     (vm_size_t)(remote.size() * sizeof(RemoteProjectionResult)))) {
        return false;
    }

    if (!RunRemoteStubLocked(0x600, kCtxProject,
                             kCtxProject + offsetof(RemoteProjectContext, done),
                             220)) {
        return false;
    }

    if (!ReadRemote(gTask,
                    gRemotePage.data + kProjectOut,
                    remote.data(),
                    (vm_size_t)(remote.size() * sizeof(RemoteProjectionResult)))) {
        return false;
    }

    out = remote;
    return true;
}

// ============================================================================
// Generic external memory helpers
// ============================================================================

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}

static void CloseTaskLocked(void)
{
    ResetRemotePageLocked();

    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }

    gUnityBase = 0;
    gTargetPID = -1;
    gCachedSnapshotValid = false;
    gCachedSnapshotNanos = 0;
}

static bool ReadRemote(task_t task, vm_address_t address, void *out, vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !out || size == 0)
        return false;

    vm_size_t copied = 0;
    kern_return_t kr = vm_read_overwrite(task,
                                         address,
                                         size,
                                         (vm_address_t)out,
                                         &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool AddressIsReadable(task_t task, vm_address_t address, vm_size_t requestedSize = 1)
{
    if (task == MACH_PORT_NULL || address == 0 || requestedSize == 0)
        return false;

    vm_address_t region = address;
    vm_size_t regionSize = 0;
    uint32_t depth = 0;
    vm_region_submap_info_data_64_t info{};
    mach_msg_type_number_t infoCount = VM_REGION_SUBMAP_INFO_COUNT_64;
    kern_return_t kr = vm_region_recurse_64(task,
                                            &region,
                                            &regionSize,
                                            &depth,
                                            (vm_region_recurse_info_t)&info,
                                            &infoCount);
    if (kr != KERN_SUCCESS || regionSize == 0)
        return false;

    if ((info.protection & VM_PROT_READ) == 0)
        return false;

    return address >= region && requestedSize <= (region + regionSize - address);
}

static bool ReadRemoteU64(vm_address_t address, uint64_t &out)
{
    return AddressIsReadable(gTask, address, sizeof(out)) &&
           ReadRemote(gTask, address, &out, sizeof(out));
}

static bool ReadRemoteI32(vm_address_t address, int32_t &out)
{
    return AddressIsReadable(gTask, address, sizeof(out)) &&
           ReadRemote(gTask, address, &out, sizeof(out));
}

static bool ReadIL2CPPList(uint64_t list, std::vector<uint64_t> &players)
{
    players.clear();
    if (!list || !AddressIsReadable(gTask, (vm_address_t)list, 0x20))
        return false;

    uint64_t items = 0;
    int32_t size = 0;
    if (!ReadRemoteU64((vm_address_t)(list + FreeFireOffsets::Il2CppListItemsOffset), items) ||
        !ReadRemoteI32((vm_address_t)(list + FreeFireOffsets::Il2CppListSizeOffset), size)) {
        return false;
    }

    if (size <= 0) {
        return true;
    }

    const uint32_t count = std::min<uint32_t>((uint32_t)size, FreeFireOffsets::MaxPlayersRead);
    if (!items || !AddressIsReadable(gTask,
                                     (vm_address_t)(items + FreeFireOffsets::Il2CppArrayDataOffset),
                                     (vm_size_t)count * sizeof(uint64_t))) {
        return false;
    }

    players.resize(count);
    if (!ReadRemote(gTask,
                    (vm_address_t)(items + FreeFireOffsets::Il2CppArrayDataOffset),
                    players.data(),
                    (vm_size_t)count * sizeof(uint64_t))) {
        players.clear();
        return false;
    }

    return true;
}

static bool VerifyMachHeaderLocked(ESPExternalSnapshot &s)
{
    uint32_t magic = 0;
    if (!ReadRemote(gTask, gUnityBase, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        BuildFailure(s,
                     "FALHOU: UnityFramework 0x%llX, cabecalho Mach-O nao legivel",
                     (unsigned long long)gUnityBase);
        return false;
    }
    s.machoReadable = 1;
    return true;
}

static bool OpenTargetLocked(ESPExternalSnapshot &s, bool forceRefresh = false)
{
    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
        return false;
    }

    s.processFound = 1;
    s.processPID = pid;

    if (!forceRefresh && gTask != MACH_PORT_NULL && gUnityBase != 0 && gTargetPID == pid) {
        s.taskOpened = 1;
        s.task = (uint64_t)gTask;
        s.unityFound = 1;
        s.unityBase = (uint64_t)gUnityBase;
        if (VerifyMachHeaderLocked(s))
            return true;

        // The PID can survive a UnityFramework remap or a process restart.
        // Drop the stale task/base pair and reacquire it once.
        CloseTaskLocked();
        s.taskOpened = 0;
        s.unityFound = 0;
        s.unityBase = 0;
        s.message[0] = '\0';
    }

    CloseTaskLocked();

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        BuildFailure(s,
                     "FALHOU: FreeFire PID %d encontrado; task nao abriu: %s",
                     pid,
                     get_task_last_error());
        return false;
    }

    gTargetPID = pid;
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        BuildFailure(s, "FALHOU: task OK, UnityFramework nao localizado | PID %d", pid);
        CloseTaskLocked();
        return false;
    }

    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    return VerifyMachHeaderLocked(s);
}

static void ProbeTaskRegionsLocked(task_t task, ESPExternalSnapshot &s)
{
    if (task == MACH_PORT_NULL) return;

    vm_address_t address = 0;
    uint32_t depth = 0;
    const vm_address_t maxAddress = 0x0000800000000000ULL;

    while (address < maxAddress && s.readableRegionCount < 4096) {
        vm_size_t regionSize = 0;
        vm_region_submap_info_data_64_t info{};
        mach_msg_type_number_t infoCount = VM_REGION_SUBMAP_INFO_COUNT_64;
        vm_address_t regionAddress = address;
        kern_return_t kr = vm_region_recurse_64(task,
                                                 &regionAddress,
                                                 &regionSize,
                                                 &depth,
                                                 (vm_region_recurse_info_t)&info,
                                                 &infoCount);
        if (kr != KERN_SUCCESS || regionSize == 0) break;

        const bool readable = (info.protection & VM_PROT_READ) != 0;
        const bool executable = (info.protection & VM_PROT_EXECUTE) != 0;
        if (readable) ++s.readableRegionCount;
        if (executable) ++s.executableRegionCount;

        address = regionAddress + regionSize;
        if (address <= regionAddress) break;
    }
}

static bool AddressIsExecutable(task_t task, vm_address_t address)
{
    if (task == MACH_PORT_NULL || address == 0) return false;
    vm_address_t region = address;
    vm_size_t size = 0;
    uint32_t depth = 0;
    vm_region_submap_info_data_64_t info{};
    mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
    kern_return_t kr = vm_region_recurse_64(task,
                                            &region,
                                            &size,
                                            &depth,
                                            (vm_region_recurse_info_t)&info,
                                            &count);
    return kr == KERN_SUCCESS && size != 0 &&
           (info.protection & VM_PROT_READ) &&
           (info.protection & VM_PROT_EXECUTE);
}

static void ProbeTaskBasicInfoLocked(task_t task, ESPExternalSnapshot &s)
{
    if (task == MACH_PORT_NULL) return;
    mach_task_basic_info_data_t info{};
    mach_msg_type_number_t count = MACH_TASK_BASIC_INFO_COUNT;
    if (task_info(task,
                  MACH_TASK_BASIC_INFO,
                  reinterpret_cast<task_info_t>(&info),
                  &count) == KERN_SUCCESS) {
        s.taskBasicInfoOK = 1;
    }
}

static bool ReadPlayerListFromMatchLocked(uint64_t match,
                                          uint64_t &list,
                                          std::vector<uint64_t> &players)
{
    list = 0;
    players.clear();
    if (!match)
        return false;

    // Primary: exact List<Player> getter from the dump.
    uint64_t returnedList = 0;
    if (RemoteCallU64Locked(FreeFireOffsets::JMAGGLCNGIGListPlayersRVA,
                             match,
                             returnedList) && returnedList &&
        ReadIL2CPPList(returnedList, players)) {
        list = returnedList;
        return true;
    }

    // Fallback: confirmed JMAGGLCNGIG List<Player> fields.
    const uintptr_t candidates[] = {
        FreeFireOffsets::JMAGGLCNGIGPlayerListField0,
        FreeFireOffsets::JMAGGLCNGIGPlayerListField1
    };

    for (uintptr_t field : candidates) {
        uint64_t candidate = 0;
        if (!ReadRemoteU64((vm_address_t)(match + field), candidate) || !candidate)
            continue;
        if (ReadIL2CPPList(candidate, players)) {
            list = candidate;
            return true;
        }
    }

    return false;
}

static bool ResolveCameraLocked(uint64_t &manager, uint64_t &camera)
{
    manager = 0;
    camera = 0;

    uint64_t cm = 0;
    if (RemoteCallU64Locked(FreeFireOffsets::GameFacadeCurrentCameraControllerManagerRVA,
                            0,
                            cm) && cm) {
        manager = cm;

        uint64_t cam = 0;
        if (RemoteCallU64Locked(FreeFireOffsets::CameraControllerManagerGetGameCameraRVA,
                                cm,
                                cam) && cam) {
            camera = cam;
            return true;
        }

        // The manager's Camera fields are confirmed at +0x20/+0x28 in the dump.
        const uintptr_t fields[] = {0x20u, 0x28u};
        for (uintptr_t field : fields) {
            if (ReadRemoteU64((vm_address_t)(cm + field), cam) && cam) {
                camera = cam;
                return true;
            }
        }
    }

    // Final fallback: Unity's static main camera getter.
    uint64_t mainCamera = 0;
    if (RemoteCallU64Locked(FreeFireOffsets::CameraGetMainRVA, 0, mainCamera) && mainCamera) {
        camera = mainCamera;
        return true;
    }

    return false;
}

static bool ResolveLocalPlayerLocked(uint64_t &localPlayer, int32_t &localTeam, bool &localTeamOK)
{
    localPlayer = 0;
    localTeam = -1;
    localTeamOK = false;

    uint64_t local = 0;
    if (!RemoteCallU64Locked(FreeFireOffsets::GameFacadeGetLocalPlayerOrObServerRVA,
                             0,
                             local) || !local) {
        // Secondary route from the dump.
        (void)RemoteCallU64Locked(FreeFireOffsets::GameFacadeCurrentLocalPawnRVA,
                                  0,
                                  local);
    }

    if (!local)
        return false;

    localPlayer = local;

    uint64_t teamValue = 0;
    if (RemoteCallU64Locked(FreeFireOffsets::PlayerGetTeamIndexRVA,
                            localPlayer,
                            teamValue)) {
        localTeam = (int32_t)(uint32_t)teamValue;
        localTeamOK = true;
    }

    return true;
}

static bool IsFinite3(const float *v)
{
    return v && std::isfinite(v[0]) && std::isfinite(v[1]) && std::isfinite(v[2]);
}

static void ClearTargets(ESPExternalSnapshot &s)
{
    for (uint32_t i = 0; i < ESP_EXTERNAL_MAX_TARGETS; ++i)
        s.targets[i] = {};
    s.count = 0;
}

static bool RemoteReadPlayerTransformPositionLocked(uint64_t player, float out[3])
{
    if (!player || !out)
        return false;

    uint64_t transform = 0;

    // Fast path: Entity.m_CachedTransform is a confirmed +0x58 field.
    if (!ReadRemoteU64((vm_address_t)(player + FreeFireOffsets::EntityCachedTransformOffset), transform) ||
        !transform) {
        (void)RemoteCallU64Locked(FreeFireOffsets::EntityGetCachedTransformRVA, player, transform);
    }

    if (!transform)
        return false;

    return RemoteCallVecLocked(FreeFireOffsets::TransformGetPositionRVA, transform, out) &&
           IsFinite3(out);
}

static bool BuildTransformFallbackPlayersLocked(const std::vector<uint64_t> &players,
                                                uint64_t localPlayer,
                                                std::vector<RemotePlayerResult> &out)
{
    out.assign(players.size(), {});
    bool any = false;

    for (size_t i = 0; i < players.size(); ++i) {
        const uint64_t player = players[i];
        if (!player || player == localPlayer)
            continue;

        RemotePlayerResult result{};
        if (!RemoteReadPlayerTransformPositionLocked(player, &result.x))
            continue;

        // The exact radius getter is retained; a sane geometric fallback keeps
        // the common Box usable when a transient call fails.
        float radius = FreeFireOffsets::BoxFallbackRadius;
        (void)RemoteCallF32Locked(FreeFireOffsets::PlayerGetAttackableRadiusRVA, player, radius);
        if (!std::isfinite(radius) || radius <= 0.01f)
            radius = FreeFireOffsets::BoxFallbackRadius;

        uint64_t teamValue = 0;
        if (RemoteCallU64Locked(FreeFireOffsets::PlayerGetTeamIndexRVA, player, teamValue))
            result.team = (int32_t)(uint32_t)teamValue;
        else
            result.team = -1;

        uint64_t deadValue = 0;
        if (RemoteCallU64Locked(FreeFireOffsets::AttackableEntityGetIsDeadRVA, player, deadValue))
            result.dead = deadValue ? 1u : 0u;

        result.radius = radius;
        result.valid = 1u;
        out[i] = result;
        any = true;
    }

    return any;
}

static bool BuildLiveSnapshotLocked(ESPExternalSnapshot &s)
{
    ClearTargets(s);

    if (!OpenTargetLocked(s, false))
        return false;

    uint64_t match = 0;
    if (!RemoteCallU64Locked(FreeFireOffsets::GameFacadeCurrentMatchRVA, 0, match) || !match) {
        BuildFailure(s, "FALHOU: CurrentMatch() nao retornou objeto");
        return false;
    }
    s.match = match;

    uint64_t playerList = 0;
    std::vector<uint64_t> players;
    if (!ReadPlayerListFromMatchLocked(match, playerList, players)) {
        BuildFailure(s,
                     "FALHOU: CurrentMatch OK, mas List<Player> nao foi lida | Match 0x%llX",
                     (unsigned long long)match);
        return false;
    }

    s.playerList = playerList;
    s.playerListOK = 1;
    s.rawPlayerCount = (uint32_t)players.size();

    uint64_t cameraManager = 0;
    uint64_t camera = 0;
    if (!ResolveCameraLocked(cameraManager, camera) || !camera) {
        BuildFailure(s, "PARCIAL: players OK, camera nao resolvida");
        s.liveChainOK = 1;
        return false;
    }
    s.cameraManager = cameraManager;
    s.camera = camera;
    s.cameraOK = 1;

    uint64_t localPlayer = 0;
    int32_t localTeam = -1;
    bool localTeamOK = false;
    ResolveLocalPlayerLocked(localPlayer, localTeam, localTeamOK);
    s.localPlayer = localPlayer;
    s.localPlayerOK = localPlayer ? 1u : 0u;
    s.localTeamOK = localTeamOK ? 1u : 0u;

    std::vector<RemotePlayerResult> probe;
    if (!RemoteProbePlayersLocked(players,
                                  FreeFireOffsets::PlayerGetAttackableCenterWSRVA,
                                  FreeFireOffsets::PlayerGetAttackableRadiusRVA,
                                  FreeFireOffsets::PlayerGetTeamIndexRVA,
                                  FreeFireOffsets::AttackableEntityGetIsDeadRVA,
                                  localPlayer,
                                  probe)) {
        // Fallback 1: Entity.get_Position(), exposed directly by the dump.
        // If that whole batch path is unavailable, fall back again to the
        // confirmed m_CachedTransform -> Transform.get_position chain.
        if (!RemoteProbePlayersLocked(players,
                                      FreeFireOffsets::EntityGetPositionRVA,
                                      FreeFireOffsets::PlayerGetAttackableRadiusRVA,
                                      FreeFireOffsets::PlayerGetTeamIndexRVA,
                                      FreeFireOffsets::AttackableEntityGetIsDeadRVA,
                                      localPlayer,
                                      probe) &&
            !BuildTransformFallbackPlayersLocked(players, localPlayer, probe)) {
            BuildFailure(s, "PARCIAL: lista OK, nenhum caminho de posicao remota respondeu");
            return false;
        }
    } else {
        // If the primary center getter returned without a usable sample, try
        // the confirmed Transform chain before declaring that there are no
        // drawable players.
        size_t usable = 0;
        for (const RemotePlayerResult &r : probe) {
            if (r.valid && IsFinite3(&r.x) && std::isfinite(r.radius) && r.radius > 0.01f)
                ++usable;
        }
        if (usable == 0 && !players.empty()) {
            std::vector<RemotePlayerResult> transformProbe;
            if (BuildTransformFallbackPlayersLocked(players, localPlayer, transformProbe))
                probe.swap(transformProbe);
        }
    }

    struct BoxCandidate {
        uint64_t player;
        float center[3];
        float radius;
        int32_t team;
    };

    std::vector<BoxCandidate> candidates;
    candidates.reserve(ESP_EXTERNAL_MAX_TARGETS);

    for (size_t i = 0; i < players.size() && i < probe.size(); ++i) {
        const uint64_t player = players[i];
        const RemotePlayerResult &r = probe[i];
        if (!player || !r.valid)
            continue;
        if (r.dead != 0)
            continue;
        if (!IsFinite3(&r.x))
            continue;
        if (!std::isfinite(r.radius) || r.radius <= 0.0f)
            continue;

        // Local player is already rejected inside the remote probe; team
        // filtering remains external and only uses the verified getter.
        if (localTeamOK && r.team == localTeam)
            continue;

        BoxCandidate c{};
        c.player = player;
        c.center[0] = r.x;
        c.center[1] = r.y;
        c.center[2] = r.z;
        c.radius = r.radius;
        c.team = r.team;
        candidates.push_back(c);

        if (candidates.size() >= ESP_EXTERNAL_MAX_TARGETS)
            break;
    }

    s.acceptedPlayerCount = (uint32_t)candidates.size();
    s.liveChainOK = 1;

    if (candidates.empty()) {
        snprintf(s.message, sizeof(s.message),
                 "OK: match/list/camera ativos | players=%u | alvos=0",
                 s.rawPlayerCount);
        return true;
    }

    // Each candidate supplies a bottom and top world point. The Unity camera
    // then projects both into normalized viewport coordinates.
    std::vector<float> points;
    points.reserve(candidates.size() * 6u);
    for (const BoxCandidate &c : candidates) {
        const float halfHeight = std::max(FreeFireOffsets::BoxFallbackRadius,
                                          c.radius * FreeFireOffsets::BoxHalfHeightRadiusMultiplier);
        const float bx = c.center[0];
        const float bz = c.center[2];
        points.push_back(bx);
        points.push_back(c.center[1] - halfHeight);
        points.push_back(bz);
        points.push_back(bx);
        points.push_back(c.center[1] + halfHeight);
        points.push_back(bz);
    }

    std::vector<RemoteProjectionResult> projected;
    if (!RemoteProjectPlayersLocked(camera,
                                    FreeFireOffsets::CameraWorldToViewportPointRVA,
                                    points,
                                    projected)) {
        // Fallback 2: WorldToScreenPoint + exact Camera.pixelWidth/pixelHeight.
        // This keeps the external pipeline independent of Unity's viewport
        // helper while still producing the normalized coordinates the HUD uses.
        if (!RemoteProjectPlayersLocked(camera,
                                        FreeFireOffsets::CameraWorldToScreenPointRVA,
                                        points,
                                        projected)) {
            BuildFailure(s,
                         "PARCIAL: players=%u | camera OK | projecao Unity falhou",
                         s.rawPlayerCount);
            return false;
        }

        uint64_t pixelWidthValue = 0;
        uint64_t pixelHeightValue = 0;
        if (!RemoteCallU64Locked(FreeFireOffsets::CameraGetPixelWidthRVA,
                                 camera,
                                 pixelWidthValue) ||
            !RemoteCallU64Locked(FreeFireOffsets::CameraGetPixelHeightRVA,
                                 camera,
                                 pixelHeightValue) ||
            pixelWidthValue == 0 || pixelHeightValue == 0) {
            BuildFailure(s,
                         "PARCIAL: WorldToScreen OK, mas pixelWidth/pixelHeight nao foram lidos");
            return false;
        }

        const float pixelWidth = (float)(uint32_t)pixelWidthValue;
        const float pixelHeight = (float)(uint32_t)pixelHeightValue;
        for (RemoteProjectionResult &p : projected) {
            p.x0 /= pixelWidth;
            p.y0 /= pixelHeight;
            p.x1 /= pixelWidth;
            p.y1 /= pixelHeight;
        }
    }

    s.projectionOK = 1;

    for (size_t i = 0; i < candidates.size() && i < projected.size(); ++i) {
        const BoxCandidate &c = candidates[i];
        const RemoteProjectionResult &p = projected[i];
        if (!p.valid)
            continue;

        // Derive the box center from the same two projected vertical points to
        // keep the HUD independent from device pixel density.
        const float centerX = (p.x0 + p.x1) * 0.5f;
        const float topViewport = std::max(p.y0, p.y1);
        const float bottomViewport = std::min(p.y0, p.y1);

        if (!std::isfinite(centerX) || !std::isfinite(topViewport) ||
            !std::isfinite(bottomViewport) || !std::isfinite(p.z0) ||
            !std::isfinite(p.z1)) {
            continue;
        }

        const float depth = std::min(p.z0, p.z1);
        if (depth <= 0.01f)
            continue;

        // Viewport points outside [0,1] are allowed slightly so the box can be
        // clipped naturally by UIKit instead of popping at the edge.
        if (centerX < -0.15f || centerX > 1.15f ||
            topViewport < -0.20f || bottomViewport > 1.20f)
            continue;

        ESPExternalTarget &target = s.targets[s.count];
        target.player = c.player;
        target.x = centerX;
        target.y = (topViewport + bottomViewport) * 0.5f;
        target.z = depth;
        target.depth = depth;
        target.boxTop = topViewport;
        target.boxBottom = bottomViewport;
        target.boxWidthRatio = FreeFireOffsets::BoxWidthToHeight;
        target.teamIndex = (uint32_t)std::max(0, c.team);
        target.flags = 0x1u; // projected
        target.valid = 1u;

        s.count++;
        if (s.count >= ESP_EXTERNAL_MAX_TARGETS)
            break;
    }

    s.projectedPlayerCount = s.count;
    snprintf(s.message, sizeof(s.message),
             "OK: ESP BOX externo | players=%u | aceitos=%u | projetados=%u | camera=0x%llX",
             s.rawPlayerCount,
             s.acceptedPlayerCount,
             s.projectedPlayerCount,
             (unsigned long long)s.camera);
    return true;
}

static void FillVerifyRVAsLocked(ESPExternalSnapshot &s)
{
    const uintptr_t rvas[] = {
        FreeFireOffsets::GameFacadeCurrentMatchRVA,
        FreeFireOffsets::JMAGGLCNGIGListPlayersRVA,
        FreeFireOffsets::PlayerGetAttackableCenterWSRVA,
        FreeFireOffsets::PlayerGetAttackableRadiusRVA,
        FreeFireOffsets::AttackableEntityGetIsDeadRVA,
        FreeFireOffsets::EntityGetPositionRVA,
        FreeFireOffsets::EntityGetCachedTransformRVA,
        FreeFireOffsets::PlayerGetTeamIndexRVA,
        FreeFireOffsets::GameFacadeCurrentCameraControllerManagerRVA,
        FreeFireOffsets::CameraControllerManagerGetGameCameraRVA,
        FreeFireOffsets::CameraWorldToViewportPointRVA,
        FreeFireOffsets::CameraWorldToScreenPointRVA,
        FreeFireOffsets::CameraGetPixelWidthRVA,
        FreeFireOffsets::CameraGetPixelHeightRVA,
        FreeFireOffsets::TransformGetPositionRVA
    };

    s.rvaTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
    s.rvaReadableCount = 0;
    s.rvaExecutableCount = 0;

    for (uint32_t i = 0; i < s.rvaTestCount; ++i) {
        uint32_t bytes = 0;
        if (ReadRemote(gTask,
                       gUnityBase + (vm_address_t)rvas[i],
                       &bytes,
                       sizeof(bytes))) {
            ++s.rvaReadableCount;
        }
        if (AddressIsExecutable(gTask,
                                gUnityBase + (vm_address_t)rvas[i])) {
            ++s.rvaExecutableCount;
        }
    }
}

} // namespace

extern "C" int ESPExternalSetMode(int mode)
{
    if (mode < 0 || mode > 1)
        mode = 0;

    std::lock_guard<std::mutex> lock(gStateMutex);
    gMode.store(mode, std::memory_order_release);
    if (mode == 0)
        CloseTaskLocked();
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    std::lock_guard<std::mutex> lock(gStateMutex);

    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();
    s.effectiveUID = (uint32_t)geteuid();
    s.effectiveGID = (uint32_t)getegid();

    if (!OpenTargetLocked(s, true)) {
        if (out) *out = s;
        return 0;
    }

    ProbeTaskBasicInfoLocked(gTask, s);
    ProbeTaskRegionsLocked(gTask, s);
    FillVerifyRVAsLocked(s);

    const bool allRVAs = (s.rvaReadableCount == s.rvaTestCount);
    if (!allRVAs) {
        BuildFailure(s,
                     "PARCIAL: FreeFire OK | PID %d | task OK | Unity 0x%llX | Mach-O OK | RVAs legiveis %u/%u",
                     s.processPID,
                     (unsigned long long)s.unityBase,
                     s.rvaReadableCount,
                     s.rvaTestCount);
        if (out) *out = s;
        return 0;
    }

    snprintf(s.message, sizeof(s.message),
             "OK: task externo | PID %d | uid/euid %u/%u | UnityFramework 0x%llX | Mach-O OK | RVAs R %u/%u | RX %u/%u | regioes R/RX %u/%u",
             s.processPID,
             s.effectiveUID,
             s.effectiveGID,
             (unsigned long long)s.unityBase,
             s.rvaReadableCount,
             s.rvaTestCount,
             s.rvaExecutableCount,
             s.rvaTestCount,
             s.readableRegionCount,
             s.executableRegionCount);

    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    if (!out)
        return 0;

    std::lock_guard<std::mutex> lock(gStateMutex);

    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    if (gMode.load(std::memory_order_acquire) == 0) {
        snprintf(s.message, sizeof(s.message), "ESP BOX desligado");
        *out = s;
        return 0;
    }

    const uint64_t now = s.lastCheckNanos;
    if (gCachedSnapshotValid && (now - gCachedSnapshotNanos) < FreeFireOffsets::SnapshotCacheNanos) {
        *out = gCachedSnapshot;
        return 1;
    }

    const bool built = BuildLiveSnapshotLocked(s);
    if (!built && s.message[0] == '\0')
        BuildFailure(s, "FALHOU: snapshot externo sem diagnostico");

    // Preserve the latest usable state during a transient remote-call failure.
    if (!built && gCachedSnapshotValid && (now - gCachedSnapshotNanos) < 250000000ull) {
        ESPExternalSnapshot stale = gCachedSnapshot;
        strlcpy(stale.message, s.message[0] ? s.message : "snapshot anterior", sizeof(stale.message));
        stale.lastCheckNanos = now;
        *out = stale;
        return 1;
    }

    gCachedSnapshot = s;
    gCachedSnapshotNanos = now;
    gCachedSnapshotValid = true;

    *out = s;
    return built ? 1 : 0;
}

extern "C" int ESPExternalCopyCachedSnapshot(ESPExternalSnapshot *out)
{
    if (!out)
        return 0;

    std::lock_guard<std::mutex> lock(gStateMutex);
    if (!gCachedSnapshotValid) {
        *out = {};
        return 0;
    }

    *out = gCachedSnapshot;
    return 1;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[768];
    ESPExternalSnapshot s{};
    if (ESPExternalReadSnapshot(&s) && s.message[0]) {
        snprintf(text, sizeof(text), "%s", s.message);
        return text;
    }

    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: sem diagnostico");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1400];
    std::lock_guard<std::mutex> lock(gStateMutex);

    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    const bool verifyOK = OpenTargetLocked(s, false);
    if (!verifyOK) {
        snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: diagnostico externo");
        return text;
    }

    ProbeTaskBasicInfoLocked(gTask, s);
    FillVerifyRVAsLocked(s);

    // Do not invoke the live remote-call pipeline from the menu refresh path.
    // The ESP worker updates gCachedSnapshot; the UI only consumes that cache.
    const ESPExternalSnapshot &state = gCachedSnapshotValid ? gCachedSnapshot : s;

    snprintf(text,
             sizeof(text),
             "EXTERNAL ESP BOX\n"
             "FreeFire: OK | PID: %d | UID/EUID: %u/%u\n"
             "task: %s | UnityFramework: 0x%llX\n"
             "Mach-O: %s | RVAs R: %u/%u | RX: %u/%u\n"
             "match: 0x%llX | list: 0x%llX | players: %u\n"
             "camera: 0x%llX | chain: %s | projection: %s\n"
             "aceitos: %u | projetados: %u\n"
             "%s",
             state.processPID,
             state.effectiveUID,
             state.effectiveGID,
             state.taskBasicInfoOK ? "OK" : "FAIL",
             (unsigned long long)state.unityBase,
             state.machoReadable ? "OK" : "FAIL",
             state.rvaReadableCount,
             state.rvaTestCount,
             state.rvaExecutableCount,
             state.rvaTestCount,
             (unsigned long long)state.match,
             (unsigned long long)state.playerList,
             state.rawPlayerCount,
             (unsigned long long)state.camera,
             state.liveChainOK ? "OK" : "FAIL",
             state.projectionOK ? "OK" : "FAIL",
             state.acceptedPlayerCount,
             state.projectedPlayerCount,
             state.message[0] ? state.message : "sem mensagem");

    return text;
}
