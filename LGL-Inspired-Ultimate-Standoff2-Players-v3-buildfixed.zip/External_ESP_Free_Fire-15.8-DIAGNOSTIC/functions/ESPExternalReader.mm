#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <Foundation/Foundation.h>
#include <stdarg.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <atomic>
#include <unistd.h>
#include <mach/mach_vm.h>
#include <mach/task_info.h>

namespace {
static task_t gTask = MACH_PORT_NULL;
static mach_vm_address_t gUnityBase = 0;
static std::atomic<int> gMode{0};

static uint64_t NowNanos(void)
{
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void CloseTask(void)
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
}

static bool ReadRemote(task_t task, mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (task == MACH_PORT_NULL || address == 0 || !out || size == 0)
        return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(task, address, size,
                                               (mach_vm_address_t)out, &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool ReadRVA(task_t task, mach_vm_address_t base, uintptr_t rva)
{
    uint32_t bytes = 0;
    return ReadRemote(task, base + (mach_vm_address_t)rva, &bytes, sizeof(bytes));
}


static void ProbeTaskRegions(task_t task, ESPExternalSnapshot &s)
{
    if (task == MACH_PORT_NULL) return;

    mach_vm_address_t address = 0;
    uint32_t depth = 0;
    const mach_vm_address_t maxAddress = 0x0000800000000000ULL;

    while (address < maxAddress && s.readableRegionCount < 4096) {
        mach_vm_size_t regionSize = 0;
        vm_region_submap_info_data_64_t info{};
        mach_msg_type_number_t infoCount = VM_REGION_SUBMAP_INFO_COUNT_64;
        mach_vm_address_t regionAddress = address;
        kern_return_t kr = mach_vm_region_recurse(task, &regionAddress, &regionSize,
                                                   &depth,
                                                   (vm_region_recurse_info_t)&info,
                                                   &infoCount);
        if (kr != KERN_SUCCESS || regionSize == 0) break;

        const bool readable = (info.protection & VM_PROT_READ) != 0;
        const bool executable = (info.protection & VM_PROT_EXECUTE) != 0;
        if (readable) ++s.readableRegionCount;
        if (executable) ++s.executableRegionCount;

        address = regionAddress + regionSize;
        if (address <= regionAddress) break;
    }
}

static bool AddressIsExecutable(task_t task, mach_vm_address_t address)
{
    if (task == MACH_PORT_NULL || address == 0) return false;
    mach_vm_address_t region = address;
    mach_vm_size_t size = 0;
    uint32_t depth = 0;
    vm_region_submap_info_data_64_t info{};
    mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
    kern_return_t kr = mach_vm_region_recurse(task, &region, &size, &depth,
                                               (vm_region_recurse_info_t)&info,
                                               &count);
    return kr == KERN_SUCCESS && size != 0 &&
           (info.protection & VM_PROT_READ) &&
           (info.protection & VM_PROT_EXECUTE);
}

static void ProbeTaskBasicInfo(task_t task, ESPExternalSnapshot &s)
{
    if (task == MACH_PORT_NULL) return;
    mach_task_basic_info_data_t info{};
    mach_msg_type_number_t count = MACH_TASK_BASIC_INFO_COUNT;
    if (task_info(task, MACH_TASK_BASIC_INFO,
                  reinterpret_cast<task_info_t>(&info), &count) == KERN_SUCCESS) {
        s.taskBasicInfoOK = 1;
    }
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}
}

extern "C" int ESPExternalSetMode(int mode)
{
    if (mode < 0 || mode > 1) mode = 0;
    gMode.store(mode, std::memory_order_release);
    return mode;
}

extern "C" int ESPExternalGetMode(void)
{
    return gMode.load(std::memory_order_acquire);
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();
    s.rvaTestCount = 10;
    s.effectiveUID = (uint32_t)geteuid();
    s.effectiveGID = (uint32_t)getegid();

    CloseTask();

    const pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        BuildFailure(s, "FALHOU: processo FreeFire nao encontrado");
            if (out) *out = s;
        return 0;
    }

    s.processFound = 1;
    s.processPID = pid;

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        BuildFailure(s, "FALHOU: FreeFire PID %d encontrado; task nao abriu: %s",
                     pid, get_task_last_error());
            if (out) *out = s;
        return 0;
    }
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;
    ProbeTaskBasicInfo(gTask, s);
    ProbeTaskRegions(gTask, s);

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        BuildFailure(s, "FALHOU: task OK, UnityFramework nao localizado | PID %d", pid);
            if (out) *out = s;
        return 0;
    }
    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    uint32_t magic = 0;
    if (!ReadRemote(gTask, gUnityBase, &magic, sizeof(magic)) || magic != MH_MAGIC_64) {
        BuildFailure(s, "FALHOU: UnityFramework 0x%llX, cabecalho Mach-O nao legivel",
                     (unsigned long long)gUnityBase);
            if (out) *out = s;
        return 0;
    }
    s.machoReadable = 1;

    const uintptr_t rvas[] = {
        FreeFireOffsets::GetPlayerByTeamIdAndPlayerIndexStrictRVA,
        FreeFireOffsets::GetLivePlayerByTeamIdAndPlayerIndexRVA,
        FreeFireOffsets::GetPlayerCountRVA,
        FreeFireOffsets::GetPlayerListFromTeamIdRVA,
        FreeFireOffsets::PlayerGetTransformNodeRVA,
        FreeFireOffsets::TransformGetPositionRVA,
        FreeFireOffsets::CameraGetMainRVA,
        FreeFireOffsets::CameraWorldToScreenPointRVA,
        FreeFireOffsets::AnimatorGetBoneTransformRVA,
        FreeFireOffsets::AnimatorGetBoneTransformInternalRVA,
    };

    s.rvaTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
    for (uint32_t i = 0; i < s.rvaTestCount; ++i) {
        if (ReadRVA(gTask, gUnityBase, rvas[i]))
            ++s.rvaReadableCount;
        if (AddressIsExecutable(gTask, gUnityBase + (mach_vm_address_t)rvas[i]))
            ++s.rvaExecutableCount;
    }

    if (s.rvaReadableCount != s.rvaTestCount) {
        BuildFailure(s, "PARCIAL: FreeFire OK | PID %d | task OK | Unity 0x%llX | Mach-O OK | RVAs legiveis %u/%u",
                     pid, (unsigned long long)gUnityBase,
                     s.rvaReadableCount, s.rvaTestCount);
            if (out) *out = s;
        return 0;
    }

    snprintf(s.message, sizeof(s.message),
             "OK: task externo | PID %d | uid/euid %u/%u | UnityFramework 0x%llX | Mach-O OK | RVAs legiveis %u/%u | executaveis %u/%u | regioes R/X %u/%u",
             pid, s.effectiveUID, s.effectiveGID, (unsigned long long)gUnityBase,
             s.rvaReadableCount, s.rvaTestCount, s.rvaExecutableCount, s.rvaTestCount,
             s.readableRegionCount, s.executableRegionCount);

    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    if (!ESPExternalVerify(&s)) {
        if (out) *out = s;
        return 0;
    }

    /*
     * External transport is now real: task_for_pid + mach_vm_read_overwrite.
     * Live entity enumeration is deliberately not fabricated here. The target
     * slots remain empty until a PlayerManager/list chain from the same dump is
     * wired into this out-of-process reader.
     */
    s.count = 0;
    if (out) *out = s;
    return 1;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[768];
    ESPExternalSnapshot s{};
    ESPExternalVerify(&s);
    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: sem diagnostico");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void)
{
    static char text[1024];
    ESPExternalSnapshot s{};
    const int ok = ESPExternalVerify(&s);

    if (!ok) {
        snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "FALHOU: diagnostico externo");
        return text;
    }

    snprintf(text, sizeof(text),
             "EXTERNAL CHECK\nFreeFire: OK | PID: %d | euid: %u | egid: %u\n"
             "task: OK | task_info: %s\n"
             "UnityFramework: 0x%llX\n"
             "Mach-O: OK | RVAs R: %u/%u | RX: %u/%u\n"
             "regions R: %u | RX: %u\n"
             "ESP targets: %u (entity chain nao implementada)",
             s.processPID, s.effectiveUID, s.effectiveGID,
             s.taskBasicInfoOK ? "OK" : "FAIL",
             (unsigned long long)s.unityBase,
             s.rvaReadableCount,
             s.rvaTestCount,
             s.rvaExecutableCount,
             s.rvaTestCount,
             s.readableRegionCount,
             s.executableRegionCount,
             s.count);
    return text;
}
