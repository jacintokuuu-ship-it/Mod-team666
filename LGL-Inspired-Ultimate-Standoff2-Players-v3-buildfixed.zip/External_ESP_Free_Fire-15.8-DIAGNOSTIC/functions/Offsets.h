#pragma once
#include <stdint.h>

/*
 * Free Fire external-reference RVAs supplied by the user's dump (2).cs.
 * Keep this file limited to values that are actually used by the external
 * reader. No semantic field offset is invented here.
 */
namespace FreeFireOffsets {
    // ---------------------------------------------------------------------
    // Match / player enumeration
    // ---------------------------------------------------------------------
    static constexpr uintptr_t GameFacadeCurrentMatchRVA                    = 0x0591B898;
    static constexpr uintptr_t GameFacadeCurrentLocalPawnRVA                = 0x0591BC58;
    static constexpr uintptr_t GameFacadeGetLocalPlayerOrObServerRVA       = 0x05919628;
    static constexpr uintptr_t GameFacadeCurrentCameraControllerManagerRVA  = 0x05927F58;
    static constexpr uintptr_t GameFacadeIsLocalTeammateRVA                 = 0x0591C5B4;

    static constexpr uintptr_t JMAGGLCNGIGListPlayersRVA                    = 0x0599916C;
    static constexpr uintptr_t JMAGGLCNGIGDictionaryPlayersRVA              = 0x05999114;
    static constexpr uintptr_t JMAGGLCNGIGHashSetPlayersRVA                 = 0x0599930C;
    static constexpr uintptr_t JMAGGLCNGIGSecondaryPlayerListRVA            = 0x05999484;

    // Confirmed JMAGGLCNGIG managed fields.
    static constexpr uintptr_t JMAGGLCNGIGPlayerListField0                  = 0x158;
    static constexpr uintptr_t JMAGGLCNGIGPlayerListField1                  = 0x160;

    // List<T> managed layout (IL2CPP): _items / _size.
    static constexpr uintptr_t Il2CppListItemsOffset                        = 0x10;
    static constexpr uintptr_t Il2CppListSizeOffset                         = 0x18;
    static constexpr uintptr_t Il2CppArrayDataOffset                        = 0x20;

    // ---------------------------------------------------------------------
    // Player / entity
    // ---------------------------------------------------------------------
    static constexpr uintptr_t PlayerGetTransformNodeRVA                     = 0x05735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA                = 0x0890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA                  = 0x06B4964C;
    static constexpr uintptr_t BFOONIGAIFKGetTransformRVA                    = 0x0581FB80;
    static constexpr uintptr_t EntityGetTransformNodeRVA                     = 0x06B4B418;
    static constexpr uintptr_t LEntityGetTransformNodeRVA                    = 0x06AF1F24;
    static constexpr uintptr_t TransformNodeTransformOffset                  = 0x10;
    static constexpr uintptr_t BFOONIGAIFKTransformOffset                    = 0x10;
    static constexpr uintptr_t EntityCachedTransformOffset                   = 0x58;
    static constexpr uintptr_t TransformGetPositionRVA                       = 0x08D6C1EC;

    static constexpr uintptr_t EntityGetPositionRVA                          = 0x06B49D04;
    static constexpr uintptr_t EntityGetCachedTransformRVA                    = 0x06B49C14;
    static constexpr uintptr_t AttackableEntityGetIsDeadRVA                   = 0x058C44AC;
    static constexpr uintptr_t AttackableEntityGetAttackableCenterWSRVA       = 0x058C458C;
    static constexpr uintptr_t AttackableEntityGetAttackableRadiusRVA         = 0x058C4600;
    static constexpr uintptr_t AttackableEntityGetHitDamagePosRVA             = 0x058C4668;
    static constexpr uintptr_t AttackableEntityIsVisibleRVA                   = 0x058C493C;

    static constexpr uintptr_t PlayerGetAttackableCenterWSRVA                 = 0x056300E8;
    static constexpr uintptr_t PlayerGetAttackableRadiusRVA                   = 0x0563080C;
    static constexpr uintptr_t PlayerGetPlayerIDRVA                           = 0x055FE154;
    static constexpr uintptr_t PlayerGetTeamIndexRVA                          = 0x05630DB8;
    static constexpr uintptr_t PlayerGetCurHPRVA                              = 0x056AA7C8;
    static constexpr uintptr_t PlayerGetMaxHPRVA                              = 0x05613110;

    // ---------------------------------------------------------------------
    // Camera / projection
    // ---------------------------------------------------------------------
    static constexpr uintptr_t CameraControllerManagerGetGameCameraRVA        = 0x058DD930;
    static constexpr uintptr_t CameraGetMainRVA                               = 0x08CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA                    = 0x08CFE9C0;
    static constexpr uintptr_t CameraWorldToScreenPointEyeRVA                 = 0x08CFE5C0;
    static constexpr uintptr_t CameraWorldToViewportPointRVA                  = 0x08CFEA34;
    static constexpr uintptr_t CameraGetPixelWidthRVA                         = 0x08CFDF50;
    static constexpr uintptr_t CameraGetPixelHeightRVA                        = 0x08CFDFA0;
    static constexpr uintptr_t CameraGetWorldToCameraMatrixRVA                = 0x08CFE220;
    static constexpr uintptr_t CameraGetProjectionMatrixRVA                   = 0x08CFE3C8;

    // ---------------------------------------------------------------------
    // Retained references from the dump/project. They are not required for
    // the simple Box pipeline but remain here so older code still resolves.
    // ---------------------------------------------------------------------
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA       = 0x048F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA         = 0x048F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA                 = 0x048F84D4;
    static constexpr uintptr_t GetPlayerCountRVA                              = 0x048F8C34;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA                     = 0x048F85F4;

    static constexpr uintptr_t IsSameTeam0RVA                                 = 0x00025401;
    static constexpr uintptr_t IsSameTeam1RVA                                 = 0x00025402;

    static constexpr uintptr_t AnimatorGetBoneTransformRVA                    = 0x08CDDFEC;
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA            = 0x08CDE404;
    static constexpr int HumanBoneHips  = 0;
    static constexpr int HumanBoneChest = 8;
    static constexpr int HumanBoneNeck  = 9;
    static constexpr int HumanBoneHead  = 10;

    // Box tuning. These are renderer heuristics, not game memory offsets.
    static constexpr float BoxHalfHeightRadiusMultiplier                    = 2.05f;
    static constexpr float BoxWidthToHeight                                  = 0.42f;
    static constexpr float BoxFallbackRadius                                 = 0.45f;
    static constexpr uint32_t MaxPlayersRead                                 = 64u;
    static constexpr uint64_t SnapshotCacheNanos                              = 50000000ull; // 50 ms
}
