#import "unity.h"

/*
 * Legacy direct-memory transform/matrix code was intentionally removed.
 * The active ESP path is now driven by the trusted in-process probe and the
 * exact Unity methods listed in functions/Offsets.h.
 */
