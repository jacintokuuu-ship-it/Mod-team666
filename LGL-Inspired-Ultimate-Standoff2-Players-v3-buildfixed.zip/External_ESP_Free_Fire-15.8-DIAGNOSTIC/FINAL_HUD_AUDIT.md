# XternalZ 1.9.1 — Final HUD Runtime Audit

## Scope

This pass was limited to HUD interaction, orientation, runtime stability, and build hygiene. Existing project directories for process/task/Unity/overlay/function modules remain in the tree.

## Confirmed problems addressed

### 1. Landscape geometry was applied to subviews instead of the window

The previous implementation manually rotated `_contentView` while `MenuView` remained a sibling in the root view hierarchy. This allowed the underlying HUD to become landscape while the menu stayed visually portrait.

The final version delegates rotation to `UIAutoRotatingWindow` via its private `updateForOrientation:` path and then lays out the root hierarchy again.

### 2. Initial orientation could be skipped

The controller started in portrait and returned early when the first observer update happened to match that state.

The final version starts with `UIInterfaceOrientationUnknown`, reads `FBSOrientationObserver.activeInterfaceOrientation`, and forces an initial orientation application.

### 3. Dragging the OPEN hotspot was not supported

The hotspot previously had only a tap recognizer. A finger movement therefore cancelled the tap without moving the hotspot.

The final version adds a one-finger pan recognizer and makes the tap recognizer wait for the pan to fail. A stationary touch opens the menu; an actual drag moves the hotspot.

### 4. Menu header pan could steal normal controls

The header pan is now a proper gesture-delegate participant. It refuses touches whose view hierarchy contains a `UIControl`, preserving normal button/control behavior.

### 5. Synthetic touch path had drifted from the proven reference

The final `TSEventFetcher` uses fixed pointer slots, a living-touch collection, a `CFRunLoopSource`, and deferred cleanup/stationarization. `HUDApp` decodes AX HID events, performs its hit-test on the main queue, and feeds the event into that run-loop source.

This structure is directly aligned with the public TrollSpeed source architecture:
- `HUDApp.mm`
- `TSEventFetcher.mm`
- `UIAutoRotatingWindow.h`
- `UIApplicationRotationFollowingController.h`

## Reference research

Public references consulted during the audit:

- TrollSpeed repository:
  https://github.com/Lessica/TrollSpeed
- TrollSpeed `HUDApp.mm`:
  https://raw.githubusercontent.com/Lessica/TrollSpeed/main/sources/HUDApp.mm
- TrollSpeed `TSEventFetcher.mm`:
  https://raw.githubusercontent.com/Lessica/TrollSpeed/main/sources/TSEventFetcher.mm
- TrollSpeed `HUDMainApplication.mm`:
  https://raw.githubusercontent.com/Lessica/TrollSpeed/main/sources/HUDMainApplication.mm
- TrollSpeed `HUDMainApplicationDelegate.mm`:
  https://raw.githubusercontent.com/Lessica/TrollSpeed/main/sources/HUDMainApplicationDelegate.mm
- TrollSpeed `UIAutoRotatingWindow.h`:
  https://raw.githubusercontent.com/Lessica/TrollSpeed/main/headers/UIAutoRotatingWindow.h
- TrollSpeed `UIApplicationRotationFollowingController.h`:
  https://raw.githubusercontent.com/Lessica/TrollSpeed/main/headers/UIApplicationRotationFollowingController.h
- UIDaemon `MagicAppApplication.xm`:
  https://raw.githubusercontent.com/limneos/UIDaemon/master/MagicAppApplication.xm

TrollSpeed's README explicitly describes its global HUD as a separate privileged HUD process and credits UIDaemon and KIF among the implementation references.

## Source integrity

Preserved source directories include:

- `hooks/`
- `tasks/`
- `unity/`
- `functions/`
- `overlay/`
- `menu/`
- `objc_base/`

The legacy ImGui implementation remains in the source tree, while the active target continues to use the native UIKit menu path.

## Validation

Performed locally on the supplied source archive:

- ZIP extraction and full source-tree inspection.
- All plist files parsed successfully.
- Objective-C/Objective-C++ brace-balance checks passed for edited files.
- No `makeKeyAndVisible` call remains in the active HUD delegate.
- No accidental `attached:NO` HUD constructor remains.
- The corrected `orderFront:` declaration remains local to the private UIKit interface.
- The final touch source contains no scene-dependent `initTouch` pool creation during `+load`; slots are created lazily from the real HUD window.
- The package contains the expected source and resource files.

The modified archive was statically validated locally; a real Theos/iPhoneOS 15.6 arm64 build was not executed in this Linux environment because the Apple SDK/Theos toolchain is not installed here. The supplied GitHub Actions environment remains the authoritative compile test.

## Build notes

The GitHub `Node 20` deprecation message is unrelated to Objective-C compilation. The artifact-upload message reporting no `.theos` files is a consequence of the compiler terminating before those paths were produced.
