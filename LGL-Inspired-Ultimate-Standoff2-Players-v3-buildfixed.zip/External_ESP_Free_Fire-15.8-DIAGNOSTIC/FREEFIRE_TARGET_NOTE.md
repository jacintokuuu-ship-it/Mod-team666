# Free Fire target — external mode

- Process: `FreeFire`
- Bundle identifier: `com.dts.freefireth`
- Main image used for the supplied Unity RVAs: `UnityFramework`

The project is external-only. The RVAs are treated as addresses of code/data inside the target process and are only read for diagnostics; the external application does not call those methods through an injected hook.
