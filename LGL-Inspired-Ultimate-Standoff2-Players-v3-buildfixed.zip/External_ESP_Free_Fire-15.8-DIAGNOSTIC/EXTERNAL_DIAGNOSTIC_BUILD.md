# Free Fire — external verification

The old synthetic `Players(test)` diagnostic has been removed.

The current diagnostic performs real external operations: process discovery, Mach task acquisition, `UnityFramework` discovery, Mach-O header read, and byte reads at the supplied Free Fire RVAs.

Example success message:

```text
OK: FreeFire lido externamente | PID 1234 | task OK | UnityFramework 0x... | Mach-O OK | RVAs legiveis 10/10
```

Failure messages identify the stage that failed (`FreeFire` not found, `task` not opened, `UnityFramework` not found, Mach-O unreadable, or partial RVA reads).
