# External ESP Engine — status

## What this revision changes

- Keeps the application external: no dylib injection, no hook path, no memory writes.
- Replaces the "open task + read 4 bytes + count=0" backend with:
  - cached task/UnityFramework attachment;
  - readable-region map;
  - guarded `mach_vm_read_overwrite` reads;
  - bulk reads for candidate regions and player lists;
  - runtime discovery of `JMAGGLCNGIG` through its dump-confirmed `List<Player>` fields (`+0x158`, `+0x160`);
  - player-list enumeration with runtime pointer scoring;
  - local-player/team heuristic using the dump-confirmed `PlayerID` field (`+0x338`);
  - MatchGame discovery through the dump-confirmed `m_Match +0x90` relationship;
  - reference-derived camera and Transform memory walks, validated before use;
  - external World-to-Screen math;
  - snapshot population for Line and Box;
  - Box only advertises itself when an observed projected body span exists; the engine no longer fabricates a width from a single point.
  - renderer support for Line, Box, or both.

## Confidence boundaries

The supplied study explicitly confirms:
- `JMAGGLCNGIG` and its `List<Player>` fields at `+0x158` and `+0x160`;
- `MatchGame.m_Match` at `+0x90`;
- `PlayerID` at `+0x338`;
- the Player ITransformNode fields around `+0x698..+0x730`;
- `TransformNode.transform` at `+0x10`;
- Unity Camera/Transform semantic RVAs.

The study does **not** confirm the physical native memory layout required to read a Unity `Transform` world position or camera matrix without invoking Unity methods. Therefore this revision deliberately imports the *method* from the uploaded working external project, but marks its native Transform/Camera field walk as reference-derived and validates it at runtime.

A successful `mach_vm_read_overwrite` of an RVA is still only a readability test; it is not proof that the method itself is callable or that a returned value is semantically correct.

## Expected runtime states

1. `EXTERNAL CHECK`: task/Unity/RVA access works, discovery incomplete.
2. `JMAG FOUND`: player manager and list candidates are found.
3. `CAMERA FOUND`: MatchGame/camera matrix validates.
4. `ESP READY`: real player pointers are enumerated and screen geometry is being produced.
5. `geometry=0`: backend is attached but the reference-derived Transform/Camera layout did not validate on that build; no synthetic targets are generated.

## Build limitation

The supplied environment did not include the iPhoneOS/Theos SDK needed for a real device build, so this source package is structurally revised but not presented as a device-verified binary.

The application target was widened to `arm64 arm64e` to mirror the uploaded reference project while keeping the existing iOS 15 deployment target; this is a compatibility choice, not proof of a successful device build.
