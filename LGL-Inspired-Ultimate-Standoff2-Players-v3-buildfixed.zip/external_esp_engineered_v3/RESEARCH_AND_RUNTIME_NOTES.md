# Research and runtime notes — external ESP

## iOS memory transport

The reader remains read-only and uses `mach_vm_read_overwrite` for target-process memory reads. The code also enumerates readable VM regions with `mach_vm_region_recurse` before bulk reads, so invalid/unmapped ranges are rejected before attempting the copy.

Apple documentation:
- https://developer.apple.com/documentation/kernel/1402127-mach_vm_read_overwrite
- https://developer.apple.com/documentation/kernel/mach/mach_vm

## TrollStore / entitlements

TrollStore can preserve arbitrary entitlements when it installs an IPA, but the TrollStore project explicitly treats several task/debugger-related entitlements as restricted on iOS 16+ and can require Developer Mode. TrollStore also documents three banned code-signing entitlements on iOS 15+ A12+ (`com.apple.private.cs.debugger`, `dynamic-codesigning`, `com.apple.private.skip-library-validation`) that are not a safe assumption for a normal TrollStore app.

References:
- https://github.com/opa334/TrollStore/blob/main/README.md
- https://github.com/opa334/TrollStore/blob/main/RootHelper/main.m

## Theos / rootless

Theos rootless uses `/var/jb/` and `THEOS_PACKAGE_SCHEME=rootless`. The reference application itself is an app target rather than a tweak dylib, so the project keeps the external-reader architecture and does not add a substrate injection path.

Reference:
- https://theos.dev/docs/rootless

## Architecture

The Makefile now targets both `arm64` and `arm64e` while retaining the existing iOS 15 deployment target. This mirrors the uploaded reference project's architecture range without assuming that the local build host has the corresponding iPhoneOS SDK/toolchain.

## Runtime validation boundary

The supplied dump confirms the semantic IL2CPP relationships (JMAGGLCNGIG collections, MatchGame.m_Match, Player fields, Camera/Transform method RVAs), but it does not by itself prove the physical native memory layout of Unity's Transform and camera data. The imported Transform/camera walk is therefore runtime-validated reference logic, not a dump-guaranteed offset set.

The engine never marks ESP active merely because an RVA is readable. The meaningful runtime success state is a nonzero snapshot with valid target projections.
