# ESP external — freeze/stutter fix

## What changed

- `ESPExternalReadSnapshot()` is now a cache read only; it never opens the target task, enumerates VM regions, scans memory, or walks player transforms on the UI thread.
- `ESPExternalVerify()` is also cache-only, preventing diagnostic/menu calls from triggering remote scans.
- Added a detached background C++ worker running at 12.5 Hz while ESP is enabled.
- JMAG discovery is incremental: two 512 KiB readable/writable chunks per worker tick instead of a full process-wide sweep in one call.
- MatchGame/camera reverse lookup uses the same incremental budget.
- The task/UnityFramework attachment is cached for the lifetime of the observed PID instead of being forcibly torn down every 2 seconds.
- Camera matrix refresh remains cheap (16 floats) once its pointer has been discovered.
- Failed player-list reads are tolerated for three worker ticks before invalidating the runtime chain and restarting discovery.
- Viewport dimensions are atomic so the UI and worker can update/read them without a data race.

## Rendering behavior

`HUDMainApplication` continues to render from `ESPExternalSnapshot`, but it consumes the most recent complete snapshot. A slow or failed memory-read cycle can no longer block `viewDidLayoutSubviews`.

## Verification boundary

This change addresses execution scheduling and memory-read pressure only. It does not claim that the supplied offsets/transform layout are valid for every Free Fire build.
