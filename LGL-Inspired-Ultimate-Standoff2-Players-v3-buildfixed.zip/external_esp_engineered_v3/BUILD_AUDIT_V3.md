# Build audit — v3

- Source tree derived from the supplied `external funcional(2).zip`.
- Reference architecture studied from the supplied TrollStore/FF project.
- `Makefile` architecture widened to `arm64 arm64e`.
- External reader remains read-only; no `mach_vm_write` path was added.
- Backend syntax-checked with Clang using local stubs for the unavailable iPhoneOS SDK/Mach headers.
- The full iPhoneOS/Theos device build was NOT run in this environment.
- End-to-end ESP success still requires runtime validation on the target build/device.
