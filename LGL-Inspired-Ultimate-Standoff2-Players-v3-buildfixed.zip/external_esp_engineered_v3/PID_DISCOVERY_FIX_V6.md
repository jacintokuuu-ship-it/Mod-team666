# V6 — PID discovery fix

Esta versão preserva o pipeline externo existente e corrige apenas a etapa que estava falhando antes de `task_for_pid`.

## Mudanças

- mantém `proc_listallpids` + `proc_name` do projeto externo anterior;
- adiciona fallback por `proc_pidpath`;
- comparação case-insensitive;
- ignora PID 0;
- mantém aliases de nome (`FreeFire`, `freefire`, `Free Fire`, `Garena Free Fire`);
- mensagem de falha agora identifica explicitamente que a falha ocorreu na descoberta do processo;
- não faz varredura de memória para descobrir o PID.

## Limitação honesta

Isto corrige a etapa PID/task discovery. Não é uma prova de ESP LINE end-to-end em um dispositivo real: a própria auditoria da dump registra que a resolução runtime de JMAG, enumeração de players e aquisição de posição/projeção ainda precisam ser validadas no processo em execução.
