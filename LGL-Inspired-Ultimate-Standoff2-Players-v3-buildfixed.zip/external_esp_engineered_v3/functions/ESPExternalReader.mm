#import "ESPExternalShared.h"
#import "Offsets.h"
#import "ExternalMemory.h"
#import "../tasks/pid.h"

#include <Foundation/Foundation.h>
#include <UIKit/UIKit.h>
#include <mach/mach.h>
#include <mach-o/loader.h>
#include <atomic>
#include <cmath>
#include <cfloat>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <limits>
#include <mutex>
#include <thread>
#include <chrono>
#include <unordered_map>
#include <vector>
#include <algorithm>
#include <ctime>
#include <cstdarg>

namespace {

struct Vec3 {
    float x, y, z;
};

struct Vec4 {
    float x, y, z, w;
};

struct Quaternion {
    float x, y, z, w;
};

struct TMatrix {
    Vec4 position;
    Quaternion rotation;
    Vec4 scale;
};

struct PlayerIDLayout {
    uint32_t value;
    uint32_t id;
    uint8_t teamID;
    uint8_t shortID;
    uint8_t pad[6];
    uint64_t idMask;
};

struct ListInfo {
    uint64_t list = 0;
    uint64_t items = 0;
    uint32_t size = 0;
};

struct Candidate {
    uint64_t manager = 0;
    uint64_t list = 0;
    uint32_t listCount = 0;
    uintptr_t listFieldOffset = 0;
    uint32_t score = 0;
};


static task_t gTask = MACH_PORT_NULL;
static pid_t gPID = -1;
static mach_vm_address_t gUnityBase = 0;
static std::atomic<int> gMode{0};
static std::mutex gMutex;
static ExternalMemoryReader gMem;
static uint64_t gLastRegionRefreshNanos = 0;
static Candidate gCandidate{};
static uint64_t gMatchGame = 0;
static uint64_t gCameraMain = 0;
static float gCameraMatrix[16]{};
static bool gCameraMatrixValid = false;
static std::atomic<float> gViewportW{0.0f};
static std::atomic<float> gViewportH{0.0f};
static uint32_t gDiscoveryScore = 0;
static uint32_t gObservedPlayers = 0;
static char gDiscoveryMessage[256] = "aguardando descoberta";

// The renderer must never perform process-wide discovery. All expensive
// external reads run on a dedicated background worker and publish a complete
// immutable snapshot for the UI thread to consume.
static std::mutex gPublishedMutex;
static ESPExternalSnapshot gPublishedSnapshot{};
static std::atomic<bool> gWorkerStarted{false};
static uint64_t gNextJMAGScanNanos = 0;
static uint64_t gNextMatchScanNanos = 0;
static uint32_t gEnumerationFailures = 0;

struct DiscoveryScanState {
    bool active = false;
    size_t regionIndex = 0;
    mach_vm_address_t cursor = 0;
    uint64_t needle = 0;
    Candidate best{};
};

static DiscoveryScanState gJMAGScan{};
static DiscoveryScanState gMatchScan{};

static uint64_t NowNanos() {
    struct timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static bool IsFinite(float v) {
    return std::isfinite(v);
}

static bool IsPlausiblePointer(uint64_t p) {
    return p >= 0x100000000ull &&
           p <= 0x00007FFFFFFFFFFFULL &&
           (p & 0x7ULL) == 0;
}

static void CloseTaskLocked() {
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gPID = -1;
    gUnityBase = 0;
    gMem.Reset();
    gLastRegionRefreshNanos = 0;
    gCandidate = Candidate{};
    gMatchGame = 0;
    gCameraMain = 0;
    gCameraMatrixValid = false;
    gDiscoveryScore = 0;
    gObservedPlayers = 0;
    gJMAGScan = DiscoveryScanState{};
    gMatchScan = DiscoveryScanState{};
    snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage), "desconectado");
}

static bool ReadBytes(uint64_t address, void *out, size_t size) {
    if (!gMem.IsReadable(address, size)) {
        uint64_t now = NowNanos();
        if (now - gLastRegionRefreshNanos > 500000000ULL) {
            if (!gMem.RefreshRegions()) return false;
            gLastRegionRefreshNanos = now;
        }
    }
    return gMem.Read(address, out, size);
}

template <typename T>
static bool ReadValue(uint64_t address, T &out) {
    return ReadBytes(address, &out, sizeof(T));
}

static bool ReadPointer(uint64_t address, uint64_t &out) {
    out = 0;
    if (!ReadValue(address, out)) return false;
    return IsPlausiblePointer(out);
}

static bool ValidateList(uint64_t listObject, ListInfo &out) {
    out = ListInfo{};
    if (!IsPlausiblePointer(listObject)) return false;

    uint64_t items = 0;
    uint32_t size = 0;
    if (!ReadValue(listObject + 0x10, items)) return false;
    if (!ReadValue(listObject + 0x18, size)) return false;

    if (size > 128) return false;
    if (size > 0 && !IsPlausiblePointer(items)) return false;
    if (!gMem.IsReadable(listObject, 0x28)) return false;

    if (size > 0) {
        uint64_t first = 0;
        if (!ReadValue(items + 0x20, first)) return false;
        if (first != 0 && !IsPlausiblePointer(first)) return false;
        if (!gMem.IsReadable(items + 0x18, 0x20)) return false;
    }

    out.list = listObject;
    out.items = items;
    out.size = size;
    return true;
}

static uint32_t ScorePlayerLike(uint64_t player) {
    if (!IsPlausiblePointer(player)) return 0;
    uint32_t score = 0;

    PlayerIDLayout pid{};
    if (ReadValue(player + FreeFireOffsets::PlayerIDOffset, pid)) {
        if (pid.teamID <= 32) score += 2;
        if (pid.value != 0 || pid.id != 0) score += 1;
    }

    uint64_t cam = 0;
    if (ReadPointer(player + FreeFireOffsets::MainCameraTransformOffset, cam)) {
        score += 1;
    }

    uint64_t node = 0;
    if (ReadPointer(player + FreeFireOffsets::PlayerNodeOffsets[0], node)) score += 1;
    if (ReadPointer(player + FreeFireOffsets::PlayerNodeOffsets[1], node)) score += 1;

    return score;
}

static bool ReadJMAGCandidateFromOwner(uint64_t owner,
                                       uintptr_t listField,
                                       Candidate &out) {
    if (!IsPlausiblePointer(owner)) return false;

    uint8_t block[0x190]{};
    if (!ReadBytes(owner, block, sizeof(block))) return false;

    for (uintptr_t off : {FreeFireOffsets::JMAG_List0,
                          FreeFireOffsets::JMAG_List1}) {
        if (off >= sizeof(block) - sizeof(uint64_t)) continue;
        uint64_t listPtr = 0;
        memcpy(&listPtr, block + off, sizeof(listPtr));
        if (!IsPlausiblePointer(listPtr)) continue;

        ListInfo li{};
        if (!ValidateList(listPtr, li)) continue;

        uint32_t score = 3;
        if (off == listField) score += 3;

        uint32_t playerScore = 0;
        if (li.size > 0) {
            uint64_t items[8]{};
            uint32_t take = std::min<uint32_t>(li.size, 8);
            if (ReadBytes(li.items + 0x20, items, sizeof(uint64_t) * take)) {
                for (uint32_t i = 0; i < take; ++i) {
                    playerScore = std::max(playerScore, ScorePlayerLike(items[i]));
                }
            }
        }
        score += playerScore;

        if (score > out.score) {
            out.manager = owner;
            out.list = listPtr;
            out.listCount = li.size;
            out.listFieldOffset = off;
            out.score = score;
        }
    }

    return out.manager != 0;
}

static void BeginJMAGScan() {
    gJMAGScan = DiscoveryScanState{};
    gJMAGScan.active = true;
    gJMAGScan.regionIndex = 0;
    gJMAGScan.cursor = 0;
}

// Incremental scan: process only two 512 KiB chunks per worker tick. This is
// deliberately slower than a one-shot heap scan but prevents a large burst of
// mach_vm_read_overwrite calls from stalling the game while a match is loading.
static bool AdvanceJMAGScan(Candidate &out, uint32_t maxChunks) {
    if (!gJMAGScan.active) return false;

    const std::vector<ExternalMemoryReader::Region> regions = gMem.regions();
    const size_t chunkSize = 512 * 1024;
    uint32_t chunks = 0;

    while (gJMAGScan.regionIndex < regions.size() && chunks < maxChunks) {
        const auto &region = regions[gJMAGScan.regionIndex];
        if ((region.protection & VM_PROT_WRITE) == 0 || region.size < 0x200) {
            gJMAGScan.regionIndex++;
            gJMAGScan.cursor = 0;
            continue;
        }

        if (gJMAGScan.cursor < region.start || gJMAGScan.cursor >= region.start + region.size) {
            gJMAGScan.cursor = region.start;
        }

        mach_vm_address_t remaining = region.start + region.size - gJMAGScan.cursor;
        size_t take = (size_t)std::min<mach_vm_size_t>(chunkSize, remaining);
        if (take < 0x20) {
            gJMAGScan.regionIndex++;
            gJMAGScan.cursor = 0;
            continue;
        }

        std::vector<uint8_t> buf(take);
        if (ReadBytes(gJMAGScan.cursor, buf.data(), take)) {
            const mach_vm_address_t base = gJMAGScan.cursor;
            for (size_t i = 0; i + 0x20 <= take; i += 8) {
                uint64_t items = 0;
                uint32_t size = 0;
                memcpy(&items, buf.data() + i + 0x10, sizeof(items));
                memcpy(&size, buf.data() + i + 0x18, sizeof(size));
                if (size == 0 || size > 128) continue;
                if (!IsPlausiblePointer(items)) continue;

                const uint64_t listAddr = base + i;
                for (uintptr_t off : {FreeFireOffsets::JMAG_List0,
                                      FreeFireOffsets::JMAG_List1}) {
                    if (listAddr < off) continue;
                    uint64_t owner = listAddr - off;
                    if (owner < region.start || owner + 0x190 > region.start + region.size) continue;

                    Candidate candidate{};
                    if (!ReadJMAGCandidateFromOwner(owner, off, candidate)) continue;
                    if (candidate.score > gJMAGScan.best.score) {
                        gJMAGScan.best = candidate;
                    }

                    if (candidate.score >= 8 && candidate.listCount >= 1) {
                        out = candidate;
                        gJMAGScan.active = false;
                        return true;
                    }
                }
            }
        }

        gJMAGScan.cursor += take;
        chunks++;
        if (gJMAGScan.cursor >= region.start + region.size) {
            gJMAGScan.regionIndex++;
            gJMAGScan.cursor = 0;
        }
    }

    if (gJMAGScan.regionIndex >= regions.size()) {
        gJMAGScan.active = false;
        if (gJMAGScan.best.manager != 0 && gJMAGScan.best.score >= 6) {
            out = gJMAGScan.best;
            return true;
        }
        return false;
    }

    return false;
}

static void BeginMatchScan(uint64_t jmag) {
    gMatchScan = DiscoveryScanState{};
    gMatchScan.active = true;
    gMatchScan.regionIndex = 0;
    gMatchScan.cursor = 0;
    gMatchScan.needle = jmag;
}

static bool AdvanceMatchScan(uint64_t jmag, uint64_t &matchGameOut, uint32_t maxChunks) {
    if (!gMatchScan.active || gMatchScan.needle != jmag) return false;

    const std::vector<ExternalMemoryReader::Region> regions = gMem.regions();
    const size_t chunkSize = 512 * 1024;
    uint32_t chunks = 0;

    while (gMatchScan.regionIndex < regions.size() && chunks < maxChunks) {
        const auto &region = regions[gMatchScan.regionIndex];
        if ((region.protection & VM_PROT_WRITE) == 0 || region.size < 0x100) {
            gMatchScan.regionIndex++;
            gMatchScan.cursor = 0;
            continue;
        }

        if (gMatchScan.cursor < region.start || gMatchScan.cursor >= region.start + region.size) {
            gMatchScan.cursor = region.start;
        }

        mach_vm_address_t remaining = region.start + region.size - gMatchScan.cursor;
        size_t take = (size_t)std::min<mach_vm_size_t>(chunkSize, remaining);
        if (take < sizeof(uint64_t)) {
            gMatchScan.regionIndex++;
            gMatchScan.cursor = 0;
            continue;
        }

        std::vector<uint8_t> buf(take);
        if (ReadBytes(gMatchScan.cursor, buf.data(), take)) {
            const mach_vm_address_t base = gMatchScan.cursor;
            for (size_t i = 0; i + sizeof(uint64_t) <= take; i += 8) {
                uint64_t value = 0;
                memcpy(&value, buf.data() + i, sizeof(value));
                if (value != jmag) continue;

                if (base + i < FreeFireOffsets::MatchGameMatchOffset) continue;
                uint64_t matchGame = base + i - FreeFireOffsets::MatchGameMatchOffset;

                uint64_t cameraMgr = 0;
                if (!ReadPointer(matchGame + FreeFireOffsets::MatchGameCameraManager, cameraMgr)) continue;
                uint64_t cameraMain = 0;
                if (!ReadPointer(cameraMgr + FreeFireOffsets::CameraManagerMain, cameraMain)) continue;

                matchGameOut = matchGame;
                gCameraMain = cameraMain;
                gMatchScan.active = false;
                return true;
            }
        }

        gMatchScan.cursor += take;
        chunks++;
        if (gMatchScan.cursor >= region.start + region.size) {
            gMatchScan.regionIndex++;
            gMatchScan.cursor = 0;
        }
    }

    if (gMatchScan.regionIndex >= regions.size()) {
        gMatchScan.active = false;
    }
    return false;
}

static bool ReadCameraMatrix(uint64_t cameraMain, float out[16]) {
    uint64_t v1 = 0;
    if (!ReadPointer(cameraMain + FreeFireOffsets::CameraMainImpl, v1)) return false;

    if (!ReadBytes(v1 + FreeFireOffsets::CameraMatrixBase, out, sizeof(float) * 16))
        return false;

    int finiteCount = 0;
    float maxAbs = 0.0f;
    for (int i = 0; i < 16; ++i) {
        if (IsFinite(out[i])) finiteCount++;
        maxAbs = std::max(maxAbs, std::fabs(out[i]));
    }

    return finiteCount == 16 && maxAbs < 100000.0f;
}

static bool ReadTransformWorld(uint64_t transformObject, Vec3 &out) {
    out = Vec3{0,0,0};

    if (!IsPlausiblePointer(transformObject)) return false;

    uint64_t matrix = 0;
    uint64_t index64 = 0;
    if (!ReadPointer(transformObject + FreeFireOffsets::TransformAccessMatrix, matrix))
        return false;
    if (!ReadValue(transformObject + FreeFireOffsets::TransformAccessIndex, index64))
        return false;

    if (index64 > 200000) return false;

    uint64_t matrixList = 0;
    uint64_t matrixIndices = 0;
    if (!ReadPointer(matrix + FreeFireOffsets::TransformAccessMatrixList, matrixList))
        return false;
    if (!ReadPointer(matrix + FreeFireOffsets::TransformAccessMatrixIndices, matrixIndices))
        return false;

    uint32_t index = (uint32_t)index64;
    TMatrix resultMatrix{};
    if (!ReadValue(matrixList + (uint64_t)sizeof(TMatrix) * index, resultMatrix))
        return false;

    Vec3 result{resultMatrix.position.x,
                resultMatrix.position.y,
                resultMatrix.position.z};

    int32_t transformIndex = -1;
    if (!ReadValue(matrixIndices + sizeof(int32_t) * index, transformIndex))
        return false;

    uint32_t guard = 0;
    while (transformIndex >= 0 && guard++ < 64) {
        TMatrix parent{};
        if (!ReadValue(matrixList + (uint64_t)sizeof(TMatrix) * (uint32_t)transformIndex,
                       parent))
            return false;

        Vec3 scale{
            result.x * parent.scale.x,
            result.y * parent.scale.y,
            result.z * parent.scale.z
        };

        const float rx = parent.rotation.x;
        const float ry = parent.rotation.y;
        const float rz = parent.rotation.z;
        const float rw = parent.rotation.w;

        result.x = parent.position.x + scale.x +
                   (scale.x * ((ry * ry * -2.0f) - (rz * rz * 2.0f))) +
                   (scale.y * ((rw * rz * -2.0f) - (ry * rx * -2.0f))) +
                   (scale.z * ((rz * rx * 2.0f) - (rw * ry * -2.0f)));

        result.y = parent.position.y + scale.y +
                   (scale.x * ((rx * ry * 2.0f) - (rw * rz * -2.0f))) +
                   (scale.y * ((rz * rz * -2.0f) - (rx * rx * 2.0f))) +
                   (scale.z * ((rw * rx * 2.0f) - (rz * ry * -2.0f)));

        result.z = parent.position.z + scale.z +
                   (scale.x * ((rw * ry * -2.0f) - (rx * rz * -2.0f))) +
                   (scale.y * ((ry * rz * 2.0f) - (rw * rx * -2.0f))) +
                   (scale.z * ((rx * rx * -2.0f) - (ry * ry * 2.0f)));

        if (!ReadValue(matrixIndices + sizeof(int32_t) * (uint32_t)transformIndex,
                       transformIndex)) {
            return false;
        }
    }

    if (!IsFinite(result.x) || !IsFinite(result.y) || !IsFinite(result.z))
        return false;

    if (std::fabs(result.x) > 100000.0f ||
        std::fabs(result.y) > 100000.0f ||
        std::fabs(result.z) > 100000.0f)
        return false;

    out = result;
    return true;
}

static bool WorldToScreen(const Vec3 &obj, float &x, float &y, float &depth) {
    const float viewportW = gViewportW.load(std::memory_order_acquire);
    const float viewportH = gViewportH.load(std::memory_order_acquire);
    if (!gCameraMatrixValid || viewportW <= 1.0f || viewportH <= 1.0f)
        return false;

    const float *m = gCameraMatrix;
    float w = m[3] * obj.x + m[7] * obj.y + m[11] * obj.z + m[15];
    if (!IsFinite(w)) return false;
    if (w < 0.05f) return false;

    x = (viewportW * 0.5f) +
        (m[0] * obj.x + m[4] * obj.y + m[8] * obj.z + m[12]) /
        w * (viewportW * 0.5f);

    y = (viewportH * 0.5f) -
        (m[1] * obj.x + m[5] * obj.y + m[9] * obj.z + m[13]) /
        w * (viewportH * 0.5f);

    depth = w;
    return IsFinite(x) && IsFinite(y) &&
           x > -0.25f * viewportW && x < 1.25f * viewportW &&
           y > -0.25f * viewportH && y < 1.25f * viewportH;
}


/*
 * First-pass body discovery:
 * - read all known ITransformNode pointers from the Player block;
 * - reconstruct positions using the reference external transform walk;
 * - project valid nodes;
 * - choose the highest and lowest screen points to form the box.
 */
static bool BuildPlayerScreenGeometry(uint64_t player,
                                      float &centerX,
                                      float &centerY,
                                      float &depth,
                                      float &left,
                                      float &top,
                                      float &right,
                                      float &bottom,
                                      float &worldY,
                                      float &distanceHint) {
    uint8_t playerBlock[0xA0]{};
    if (!ReadBytes(player + 0x690, playerBlock, sizeof(playerBlock)))
        return false;

    struct ScreenPoint {
        float x, y, depth, wy;
    };
    ScreenPoint points[FreeFireOffsets::PlayerNodeOffsetCount]{};
    uint32_t pointCount = 0;

    for (uint32_t i = 0; i < FreeFireOffsets::PlayerNodeOffsetCount; ++i) {
        uintptr_t absoluteOffset = FreeFireOffsets::PlayerNodeOffsets[i];
        if (absoluteOffset < 0x690) continue;
        size_t local = absoluteOffset - 0x690;
        if (local + sizeof(uint64_t) > sizeof(playerBlock)) continue;

        uint64_t node = 0;
        memcpy(&node, playerBlock + local, sizeof(node));
        if (!IsPlausiblePointer(node)) continue;

        uint64_t transform = 0;
        if (!ReadPointer(node + FreeFireOffsets::TransformNodeTransformOffset, transform))
            continue;

        Vec3 world{};
        if (!ReadTransformWorld(transform, world))
            continue;

        float sx=0, sy=0, sd=0;
        if (!WorldToScreen(world, sx, sy, sd))
            continue;

        points[pointCount++] = ScreenPoint{sx, sy, sd, world.y};
        if (pointCount >= FreeFireOffsets::PlayerNodeOffsetCount)
            break;
    }

    if (pointCount == 0) return false;

    left = points[0].x;
    right = points[0].x;
    top = points[0].y;
    bottom = points[0].y;

    float bestDepth = points[0].depth;
    centerX = points[0].x;
    centerY = points[0].y;
    worldY = points[0].wy;

    for (uint32_t i = 1; i < pointCount; ++i) {
        left = std::min(left, points[i].x);
        right = std::max(right, points[i].x);
        top = std::min(top, points[i].y);
        bottom = std::max(bottom, points[i].y);

        if (points[i].depth < bestDepth) {
            bestDepth = points[i].depth;
            centerX = points[i].x;
            centerY = points[i].y;
            worldY = points[i].wy;
        }
    }

    // Never synthesize a box from a single projected point. A line may still
    // use the point, while the box renderer will require a real observed span.
    float h = std::fabs(bottom - top);
    const float viewportH = gViewportH.load(std::memory_order_acquire);
    if (h > viewportH * 0.95f) return false;

    float cx = (left + right) * 0.5f;
    float cy = (top + bottom) * 0.5f;
    centerX = cx;
    centerY = cy;
    depth = bestDepth;

    // Distance is optional; if the camera transform path is unavailable,
    // leave it unknown rather than inventing it.
    distanceHint = -1.0f;
    return true;
}

static bool EnumeratePlayers(std::vector<uint64_t> &players, ListInfo &listInfo) {
    players.clear();
    if (gCandidate.manager == 0) return false;

    uint64_t chosenList = 0;
    for (uintptr_t off : {FreeFireOffsets::JMAG_List0,
                          FreeFireOffsets::JMAG_List1}) {
        uint64_t listPtr = 0;
        if (!ReadPointer(gCandidate.manager + off, listPtr)) continue;
        ListInfo li{};
        if (!ValidateList(listPtr, li)) continue;
        if (li.size == 0) continue;
        if (chosenList == 0 || li.size > listInfo.size) {
            chosenList = listPtr;
            listInfo = li;
        }
    }

    if (!chosenList || listInfo.size == 0) return false;

    const uint32_t count = std::min<uint32_t>(listInfo.size, ESP_EXTERNAL_MAX_TARGETS * 2u);
    std::vector<uint64_t> raw(count, 0);
    if (!ReadBytes(listInfo.items + 0x20, raw.data(), sizeof(uint64_t) * count))
        return false;

    for (uint32_t i = 0; i < count; ++i) {
        if (!IsPlausiblePointer(raw[i])) continue;
        if (ScorePlayerLike(raw[i]) < 2) continue;
        players.push_back(raw[i]);
        if (players.size() >= ESP_EXTERNAL_MAX_TARGETS * 2u) break;
    }

    gObservedPlayers = (uint32_t)players.size();
    return !players.empty();
}

static bool SelectLocalPlayer(const std::vector<uint64_t> &players, uint64_t &localPlayer) {
    localPlayer = 0;
    uint32_t best = 0;

    for (uint64_t p : players) {
        uint32_t score = ScorePlayerLike(p);
        uint64_t cam = 0;
        if (ReadPointer(p + FreeFireOffsets::MainCameraTransformOffset, cam)) {
            score += 4;
        }
        if (score > best) {
            best = score;
            localPlayer = p;
        }
    }

    return localPlayer != 0;
}

static bool EnsureAttached(ESPExternalSnapshot &s) {
    std::lock_guard<std::mutex> lock(gMutex);

    pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        CloseTaskLocked();
        snprintf(s.message, sizeof(s.message), "FALHOU: FreeFire nao encontrado (proc_name/proc_pidpath)");
        return false;
    }

    const uint64_t now = NowNanos();
    // Keep the task/base cached for the lifetime of the observed PID. The old
    // implementation forcibly detached every 2 seconds, which retriggered the
    // expensive discovery scans while entering a match.
    if (gTask != MACH_PORT_NULL && gPID == pid && gUnityBase != 0) {
        s.processFound = 1;
        s.processPID = pid;
        s.taskOpened = 1;
        s.task = (uint64_t)gTask;
        s.unityFound = 1;
        s.unityBase = (uint64_t)gUnityBase;
        return true;
    }

    CloseTaskLocked();

    gPID = pid;
    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        snprintf(s.message, sizeof(s.message),
                 "FALHOU: PID %d encontrado, task indisponivel: %s",
                 pid, get_task_last_error());
        return false;
    }

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        snprintf(s.message, sizeof(s.message),
                 "FALHOU: UnityFramework nao localizado | PID %d", pid);
        CloseTaskLocked();
        return false;
    }

    gMem.Attach(gTask, gUnityBase);
    if (!gMem.RefreshRegions()) {
        snprintf(s.message, sizeof(s.message),
                 "FALHOU: task abriu, mas mapa de memoria nao foi enumerado");
        return false;
    }
    gLastRegionRefreshNanos = now;

    s.processFound = 1;
    s.processPID = pid;
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;
    s.unityFound = 1;
    s.unityBase = (uint64_t)gUnityBase;

    return true;
}

static void BuildFailure(ESPExternalSnapshot &s, const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(s.message, sizeof(s.message), fmt, ap);
    va_end(ap);
}

static void PopulateStatus(ESPExternalSnapshot &s) {
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.processPID = gPID;
    s.task = (uint64_t)gTask;
    s.unityBase = (uint64_t)gUnityBase;
    s.jmagInstance = gCandidate.manager;
    s.playerCollection = gCandidate.list;
    s.matchGame = gMatchGame;
    s.cameraMain = gCameraMain;
    s.discoveryScore = gDiscoveryScore;
    s.playerCountObserved = gObservedPlayers;
    s.viewportWidth = gViewportW.load(std::memory_order_acquire);
    s.viewportHeight = gViewportH.load(std::memory_order_acquire);
}

} // namespace

static void PublishSnapshot(const ESPExternalSnapshot &snapshot) {
    std::lock_guard<std::mutex> lock(gPublishedMutex);
    gPublishedSnapshot = snapshot;
}

static ESPExternalSnapshot LoadPublishedSnapshot() {
    std::lock_guard<std::mutex> lock(gPublishedMutex);
    ESPExternalSnapshot snapshot = gPublishedSnapshot;
    return snapshot;
}

static bool CheckMachOAndRvas(ESPExternalSnapshot &s) {
    uint32_t machoMagic = 0;
    if (!ReadValue(gUnityBase, machoMagic) || machoMagic != MH_MAGIC_64) {
        BuildFailure(s, "FALHOU: UnityFramework 0x%llX ilegivel ou nao e Mach-O 64",
                     (unsigned long long)gUnityBase);
        return false;
    }
    s.machoReadable = 1;

    const uintptr_t rvas[] = {
        FreeFireOffsets::PlayerGetTransformNodeRVA,
        FreeFireOffsets::TransformGetPositionRVA,
        FreeFireOffsets::CameraGetMainRVA,
        FreeFireOffsets::CameraWorldToScreenPointRVA,
        FreeFireOffsets::AnimatorGetBoneTransformRVA,
        FreeFireOffsets::AnimatorGetBoneTransformInternalRVA,
        FreeFireOffsets::GetPlayerCountRVA,
        FreeFireOffsets::GetPlayerListFromTeamIdRVA
    };
    s.rvaTestCount = (uint32_t)(sizeof(rvas) / sizeof(rvas[0]));
    s.rvaReadableCount = 0;
    for (uintptr_t rva : rvas) {
        uint32_t bytes = 0;
        if (ReadValue(gUnityBase + rva, bytes)) {
            s.rvaReadableCount++;
        }
    }
    return true;
}

static void WorkerTick() {
    const int mode = gMode.load(std::memory_order_acquire);

    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();

    if (mode == 0) {
        // No process scan while ESP is disabled. Preserve the last attachment
        // metadata but publish an empty target set to clear the overlay.
        PopulateStatus(s);
        s.count = 0;
        snprintf(s.message, sizeof(s.message), "ESP desligado");
        PublishSnapshot(s);
        return;
    }

    if (!EnsureAttached(s)) {
        s.count = 0;
        PublishSnapshot(s);
        return;
    }

    if (!CheckMachOAndRvas(s)) {
        s.count = 0;
        PublishSnapshot(s);
        return;
    }

    const uint64_t now = NowNanos();

    // Discovery cadence is deliberately slow. The external reader must not
    // continuously sweep the target process while a match is loading.
    // One bounded chunk is enough per cadence interval; normal camera/player
    // reads continue independently once the chain is resolved.
    static uint64_t nextDiscoveryWorkNanos = 0;
    const bool discoveryDue = now >= nextDiscoveryWorkNanos;

    // Discovery is incremental: only two 512 KiB remote-memory chunks are
    // processed per 80 ms tick. There is no one-shot heap sweep anymore.
    if (gCandidate.manager == 0) {
        if (!gJMAGScan.active && now >= gNextJMAGScanNanos) {
            BeginJMAGScan();
            snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                     "iniciando descoberta incremental de JMAG");
        }

        if (gJMAGScan.active && discoveryDue) {
            nextDiscoveryWorkNanos = now + 500000000ULL;
            Candidate discovered{};
            if (AdvanceJMAGScan(discovered, 1)) {
                gCandidate = discovered;
                gDiscoveryScore = discovered.score;
                gEnumerationFailures = 0;
                gNextMatchScanNanos = now;
                snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                         "JMAG 0x%llX | field +0x%llX | count %u | score %u",
                         (unsigned long long)discovered.manager,
                         (unsigned long long)discovered.listFieldOffset,
                         discovered.listCount,
                         discovered.score);
            } else if (!gJMAGScan.active) {
                gNextJMAGScanNanos = NowNanos() + 8000000000ULL;
                if (gJMAGScan.best.manager == 0) {
                    snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                             "JMAG nao encontrado; nova tentativa em 8s");
                }
            }
        }
    }

    if (gCandidate.manager != 0 && !gCameraMatrixValid) {
        if (!gMatchScan.active && now >= gNextMatchScanNanos) {
            BeginMatchScan(gCandidate.manager);
            snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                     "JMAG resolvido; localizando MatchGame/camera incrementalmente");
        }

        if (gMatchScan.active && discoveryDue) {
            nextDiscoveryWorkNanos = now + 500000000ULL;
            uint64_t matchGame = 0;
            if (AdvanceMatchScan(gCandidate.manager, matchGame, 1)) {
                float m[16]{};
                if (ReadCameraMatrix(gCameraMain, m)) {
                    memcpy(gCameraMatrix, m, sizeof(gCameraMatrix));
                    gCameraMatrixValid = true;
                    gMatchGame = matchGame;
                    snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                             "JMAG 0x%llX | MatchGame 0x%llX | Camera 0x%llX",
                             (unsigned long long)gCandidate.manager,
                             (unsigned long long)matchGame,
                             (unsigned long long)gCameraMain);
                } else {
                    gNextMatchScanNanos = NowNanos() + 1000000000ULL;
                    snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                             "MatchGame encontrado, mas matriz camera nao validou");
                }
            } else if (!gMatchScan.active) {
                gNextMatchScanNanos = NowNanos() + 3000000000ULL;
                snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                         "MatchGame/camera nao encontrados; nova tentativa em 3s");
            }
        }
    }

    // Once the camera pointer is known, refresh only the 16-float matrix each
    // tick. This keeps the hot path small while tracking camera movement.
    if (gCameraMatrixValid) {
        float matrix[16]{};
        if (ReadCameraMatrix(gCameraMain, matrix)) {
            memcpy(gCameraMatrix, matrix, sizeof(gCameraMatrix));
        } else {
            gCameraMatrixValid = false;
            gNextMatchScanNanos = now + 1000000000ULL;
            snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                     "camera invalida; aguardando nova resolucao");
        }
    }

    PopulateStatus(s);

    if (!gCandidate.manager || !gCameraMatrixValid) {
        s.count = 0;
        snprintf(s.message, sizeof(s.message),
                 "DISCOVERY EM BACKGROUND | %s", gDiscoveryMessage);
        PublishSnapshot(s);
        return;
    }

    std::vector<uint64_t> players;
    ListInfo listInfo{};
    if (!EnumeratePlayers(players, listInfo)) {
        if (++gEnumerationFailures >= 3) {
            gCandidate = Candidate{};
            gMatchGame = 0;
            gCameraMain = 0;
            gCameraMatrixValid = false;
            gDiscoveryScore = 0;
            gEnumerationFailures = 0;
            gJMAGScan = DiscoveryScanState{};
            gMatchScan = DiscoveryScanState{};
            gNextJMAGScanNanos = now + 1500000000ULL;
            gNextMatchScanNanos = now + 1500000000ULL;
            snprintf(gDiscoveryMessage, sizeof(gDiscoveryMessage),
                     "lista invalida; reiniciando descoberta");
        }
        s.count = 0;
        snprintf(s.message, sizeof(s.message),
                 "lista/player chain instavel; mantendo cache");
        PublishSnapshot(s);
        return;
    }
    gEnumerationFailures = 0;

    uint64_t localPlayer = 0;
    SelectLocalPlayer(players, localPlayer);

    PlayerIDLayout localPID{};
    uint8_t localTeam = 0;
    if (localPlayer && ReadValue(localPlayer + FreeFireOffsets::PlayerIDOffset, localPID)) {
        localTeam = localPID.teamID;
    }

    const bool wantLine = (mode & 1) != 0;
    const bool wantBox  = (mode & 2) != 0;
    uint32_t count = 0;

    // Keep the worker hot path bounded. 64 raw players is already above the
    // external target cap and avoids pathological list sizes dominating a tick.
    const uint32_t maxPlayersThisTick = std::min<uint32_t>(
        (uint32_t)players.size(), ESP_EXTERNAL_MAX_TARGETS);

    for (uint32_t i = 0; i < maxPlayersThisTick; ++i) {
        uint64_t player = players[i];
        if (count >= ESP_EXTERNAL_MAX_TARGETS) break;
        if (player == localPlayer) continue;

        PlayerIDLayout pid{};
        if (!ReadValue(player + FreeFireOffsets::PlayerIDOffset, pid)) continue;
        if (pid.teamID == localTeam && localPlayer != 0) continue;

        float cx=0, cy=0, depth=0;
        float left=0, top=0, right=0, bottom=0;
        float wy=0, distanceHint=-1;

        if (!BuildPlayerScreenGeometry(player, cx, cy, depth,
                                       left, top, right, bottom,
                                       wy, distanceHint)) {
            continue;
        }

        ESPExternalTarget &t = s.targets[count];
        t.player = player;
        t.x = cx;
        t.y = cy;
        t.z = wy;
        t.depth = depth;
        t.boxLeft = left;
        t.boxTop = top;
        t.boxRight = right;
        t.boxBottom = bottom;
        t.distance = distanceHint;
        t.team = pid.teamID;
        t.valid = 1;
        const bool observedBox = (right - left) >= 2.0f && (bottom - top) >= 2.0f;
        t.flags = (wantLine ? ESP_TARGET_FLAG_LINE : 0) |
                  ((wantBox && observedBox) ? ESP_TARGET_FLAG_BOX : 0);
        count++;
    }

    s.count = count;
    PopulateStatus(s);

    if (count == 0) {
        snprintf(s.message, sizeof(s.message),
                 "Discovery OK | JMAG=0x%llX | players=%u | camera=0x%llX | geometry=0",
                 (unsigned long long)gCandidate.manager,
                 gObservedPlayers,
                 (unsigned long long)gCameraMain);
    } else {
        snprintf(s.message, sizeof(s.message),
                 "ESP READY | %u targets | JMAG=0x%llX | camera=0x%llX",
                 count,
                 (unsigned long long)gCandidate.manager,
                 (unsigned long long)gCameraMain);
    }

    PublishSnapshot(s);
}

static void StartWorkerIfNeeded() {
    bool expected = false;
    if (!gWorkerStarted.compare_exchange_strong(expected, true,
                                                std::memory_order_acq_rel)) {
        return;
    }

    std::thread([] {
        for (;;) {
            WorkerTick();
            // 12.5 Hz acquisition. The UI can render at 60 Hz using the last
            // complete snapshot and therefore never waits for memory reads.
            const int sleepMs = (gMode.load(std::memory_order_acquire) == 0) ? 250 : 80;
            std::this_thread::sleep_for(std::chrono::milliseconds(sleepMs));
        }
    }).detach();
}

extern "C" int ESPExternalSetMode(int mode) {
    if (mode < 0 || mode > 3) mode = 0;
    gMode.store(mode, std::memory_order_release);
    if (mode != 0) StartWorkerIfNeeded();
    return mode;
}

extern "C" int ESPExternalGetMode(void) {
    return gMode.load(std::memory_order_acquire);
}

extern "C" void ESPExternalSetViewport(float width, float height) {
    if (width > 1.0f && height > 1.0f && std::isfinite(width) && std::isfinite(height)) {
        gViewportW.store(width, std::memory_order_release);
        gViewportH.store(height, std::memory_order_release);
        if (gMode.load(std::memory_order_acquire) != 0) StartWorkerIfNeeded();
    }
}

extern "C" int ESPExternalVerify(ESPExternalSnapshot *out) {
    // Verification is now a zero-blocking cache read. The old implementation
    // attached/scanned synchronously and was called from UI paths.
    if (gMode.load(std::memory_order_acquire) != 0) StartWorkerIfNeeded();

    ESPExternalSnapshot s = LoadPublishedSnapshot();
    if (s.magic != ESP_EXTERNAL_MAGIC || s.version != ESP_EXTERNAL_VERSION) {
        s = ESPExternalSnapshot{};
        s.magic = ESP_EXTERNAL_MAGIC;
        s.version = ESP_EXTERNAL_VERSION;
        s.lastCheckNanos = NowNanos();
        s.viewportWidth = gViewportW.load(std::memory_order_acquire);
        s.viewportHeight = gViewportH.load(std::memory_order_acquire);
        snprintf(s.message, sizeof(s.message), "worker aguardando inicializacao");
    }
    if (out) *out = s;
    return 1;
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out) {
    // Critical property: called from viewDidLayoutSubviews, so this function
    // must never attach, enumerate regions, scan the process, or walk transforms.
    if (gMode.load(std::memory_order_acquire) != 0) StartWorkerIfNeeded();

    ESPExternalSnapshot s = LoadPublishedSnapshot();
    if (s.magic != ESP_EXTERNAL_MAGIC || s.version != ESP_EXTERNAL_VERSION) {
        s = ESPExternalSnapshot{};
        s.magic = ESP_EXTERNAL_MAGIC;
        s.version = ESP_EXTERNAL_VERSION;
        s.viewportWidth = gViewportW.load(std::memory_order_acquire);
        s.viewportHeight = gViewportH.load(std::memory_order_acquire);
        snprintf(s.message, sizeof(s.message), "aguardando snapshot externo");
    }
    if (out) *out = s;
    return 1;
}

extern "C" const char *ESPExternalStatusText(void) {
    static char text[1024];
    ESPExternalSnapshot s{};
    ESPExternalVerify(&s);
    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "aguardando");
    return text;
}

extern "C" const char *ESPExternalDiagnosticText(void) {
    static char text[1536];
    ESPExternalSnapshot s{};
    ESPExternalVerify(&s);

    snprintf(text, sizeof(text),
             "EXTERNAL ENGINE (ASYNC)\n"
             "FreeFire: %s | PID: %d\n"
             "task: %s | Unity: 0x%llX\n"
             "Mach-O: %s | RVAs: %u/%u\n"
             "JMAG: 0x%llX | collection: 0x%llX | score: %u\n"
             "MatchGame: 0x%llX | Camera: 0x%llX\n"
             "Players: %u | Snapshot: %u\n"
             "Worker: ativo | 12.5 Hz | Discovery: %s",
             s.processFound ? "OK" : "FAIL",
             s.processPID,
             s.taskOpened ? "OK" : "FAIL",
             (unsigned long long)s.unityBase,
             s.machoReadable ? "OK" : "FAIL",
             s.rvaReadableCount,
             s.rvaTestCount,
             (unsigned long long)s.jmagInstance,
             (unsigned long long)s.playerCollection,
             s.discoveryScore,
             (unsigned long long)s.matchGame,
             (unsigned long long)s.cameraMain,
             s.playerCountObserved,
             s.count,
             s.message);
    return text;
}
