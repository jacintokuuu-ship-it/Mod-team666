#pragma once

#include <mach/mach.h>
#include <mach/mach_types.h>
#include <mach/vm_map.h>
#include <mach/vm_region.h>

// iPhoneOS 15.6 SDK ships a deliberately unsupported <mach/mach_vm.h>.
// Declare the 64-bit Mach VM entry points locally instead of including it.
extern "C" {
    kern_return_t mach_vm_read_overwrite(vm_map_t target_task,
                                         mach_vm_address_t address,
                                         mach_vm_size_t size,
                                         mach_vm_address_t data,
                                         mach_vm_size_t *outsize);
    kern_return_t mach_vm_region_recurse(vm_map_t map,
                                         mach_vm_address_t *address,
                                         mach_vm_size_t *size,
                                         uint32_t *depth,
                                         vm_region_recurse_info_t info,
                                         mach_msg_type_number_t *infoCnt);
}
#include <stdint.h>
#include <stddef.h>
#include <vector>

class ExternalMemoryReader {
public:
    struct Region {
        mach_vm_address_t start;
        mach_vm_size_t size;
        vm_prot_t protection;
        vm_prot_t maxProtection;
    };

    ExternalMemoryReader();
    ~ExternalMemoryReader();

    void Attach(task_t task, mach_vm_address_t unityBase);
    void Reset();

    task_t task() const { return m_task; }
    mach_vm_address_t unityBase() const { return m_unityBase; }

    bool RefreshRegions();
    bool IsReadable(mach_vm_address_t address, mach_vm_size_t size) const;
    bool Read(mach_vm_address_t address, void *out, mach_vm_size_t size) const;

    template <typename T>
    bool ReadValue(mach_vm_address_t address, T &out) const {
        return Read(address, &out, sizeof(T));
    }

    template <typename T>
    T ReadOrZero(mach_vm_address_t address) const {
        T value{};
        ReadValue(address, value);
        return value;
    }

    const std::vector<Region> &regions() const { return m_regions; }

private:
    task_t m_task;
    mach_vm_address_t m_unityBase;
    std::vector<Region> m_regions;

    bool FindRegion(mach_vm_address_t address, mach_vm_size_t size, Region &out) const;
};
