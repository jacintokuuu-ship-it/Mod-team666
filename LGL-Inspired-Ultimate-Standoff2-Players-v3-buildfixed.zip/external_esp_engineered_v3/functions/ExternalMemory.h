#pragma once

#include <mach/mach.h>
#include <mach/mach_vm.h>
#include <stdint.h>
#include <stddef.h>
#include <vector>

class ExternalMemoryReader {
public:
    struct Region {
        mach_vm_address_t start;
        mach_vm_size_t size;
        vm_prot_t protection;
        vm_prot_t maxProtection;
    };

    ExternalMemoryReader();
    ~ExternalMemoryReader();

    void Attach(task_t task, mach_vm_address_t unityBase);
    void Reset();

    task_t task() const { return m_task; }
    mach_vm_address_t unityBase() const { return m_unityBase; }

    bool RefreshRegions();
    bool IsReadable(mach_vm_address_t address, mach_vm_size_t size) const;
    bool Read(mach_vm_address_t address, void *out, mach_vm_size_t size) const;

    template <typename T>
    bool ReadValue(mach_vm_address_t address, T &out) const {
        return Read(address, &out, sizeof(T));
    }

    template <typename T>
    T ReadOrZero(mach_vm_address_t address) const {
        T value{};
        ReadValue(address, value);
        return value;
    }

    const std::vector<Region> &regions() const { return m_regions; }

private:
    task_t m_task;
    mach_vm_address_t m_unityBase;
    std::vector<Region> m_regions;

    bool FindRegion(mach_vm_address_t address, mach_vm_size_t size, Region &out) const;
};
