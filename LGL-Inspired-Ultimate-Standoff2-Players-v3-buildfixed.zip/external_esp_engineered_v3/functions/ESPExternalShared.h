#pragma once

#include <stdint.h>

#define ESP_EXTERNAL_MAGIC   0x45585431u /* EXT1 */
#define ESP_EXTERNAL_VERSION 3u
#define ESP_EXTERNAL_MAX_TARGETS 64u

enum ESPExternalTargetFlags : uint32_t {
    ESP_TARGET_FLAG_LINE = 1u << 0,
    ESP_TARGET_FLAG_BOX  = 1u << 1,
    ESP_TARGET_FLAG_LOCAL = 1u << 2,
};

typedef struct ESPExternalTarget {
    uint64_t player;
    float x;          // Unity screen X (bottom-left origin)
    float y;          // Unity screen Y (bottom-left origin)
    float z;          // World-space Y when available
    float depth;      // Projection depth
    float boxLeft;
    float boxTop;
    float boxRight;
    float boxBottom;
    float distance;
    uint32_t team;
    uint32_t valid;
    uint32_t flags;
} ESPExternalTarget;

typedef struct ESPExternalSnapshot {
    uint32_t magic;
    uint32_t version;
    uint32_t processFound;
    uint32_t taskOpened;
    uint32_t unityFound;
    uint32_t machoReadable;
    uint32_t rvaReadableCount;
    uint32_t rvaTestCount;
    int32_t processPID;
    uint64_t task;
    uint64_t unityBase;
    uint64_t jmagInstance;
    uint64_t playerCollection;
    uint64_t matchGame;
    uint64_t cameraMain;
    uint64_t lastCheckNanos;
    uint32_t lastError;
    uint32_t count;
    uint32_t discoveryScore;
    uint32_t playerCountObserved;
    float viewportWidth;
    float viewportHeight;
    ESPExternalTarget targets[ESP_EXTERNAL_MAX_TARGETS];
    char message[512];
} ESPExternalSnapshot;

#ifdef __cplusplus
extern "C" {
#endif

int ESPExternalSetMode(int mode); /* bit 0 = line, bit 1 = box */
int ESPExternalGetMode(void);
void ESPExternalSetViewport(float width, float height);
int ESPExternalVerify(ESPExternalSnapshot *out);
int ESPExternalReadSnapshot(ESPExternalSnapshot *out);
const char *ESPExternalStatusText(void);
const char *ESPExternalDiagnosticText(void);

#ifdef __cplusplus
}
#endif
