#pragma once
#include <stdint.h>

/*
 * Free Fire / IL2CPP external reference profile.
 *
 * Important:
 * - Values marked "dump-confirmed" are present in the supplied dump study.
 * - Values marked "reference-derived" reproduce the memory-walk technique
 *   from the uploaded TrollStore project. They are intentionally validated
 *   at runtime before use and are NOT treated as guaranteed for every build.
 */
namespace FreeFireOffsets {
    // [dump-confirmed] JMAGGLCNGIG Player collections.
    static constexpr uintptr_t JMAG_Dict0 = 0x128;
    static constexpr uintptr_t JMAG_Dict1 = 0x130;
    static constexpr uintptr_t JMAG_Dict2 = 0x140;
    static constexpr uintptr_t JMAG_Dict3 = 0x148;
    static constexpr uintptr_t JMAG_Dict4 = 0x150;
    static constexpr uintptr_t JMAG_List0 = 0x158;
    static constexpr uintptr_t JMAG_List1 = 0x160;

    // [dump-confirmed] MatchGame -> JMAGGLCNGIG.
    static constexpr uintptr_t MatchGameMatchOffset = 0x90;

    // [dump-confirmed] Player fields.
    static constexpr uintptr_t PlayerIDOffset = 0x338;
    static constexpr uintptr_t MainCameraTransformOffset = 0x3E8;
    static constexpr uintptr_t IPRIDataPoolOffset = 0x68;

    // [dump-confirmed] ITransformNode fields seen on Player.
    static constexpr uintptr_t PlayerNodeOffsets[] = {
        0x698, 0x6A0, 0x6A8, 0x6B0, 0x6B8, 0x6C0, 0x6C8,
        0x6D0, 0x6D8, 0x6E0, 0x6E8, 0x6F0, 0x6F8, 0x700,
        0x708, 0x710, 0x718, 0x720, 0x728, 0x730
    };
    static constexpr uint32_t PlayerNodeOffsetCount =
        sizeof(PlayerNodeOffsets) / sizeof(PlayerNodeOffsets[0]);

    // [dump-confirmed] ITransformNode/TransformNode.
    static constexpr uintptr_t TransformNodeTransformOffset = 0x10;

    // [reference-derived] Unity native Transform access layout used by the
    // uploaded working external project. Runtime sanity checks are mandatory.
    static constexpr uintptr_t TransformAccessMatrix = 0x38;
    static constexpr uintptr_t TransformAccessIndex = 0x40;
    static constexpr uintptr_t TransformAccessMatrixList = 0x18;
    static constexpr uintptr_t TransformAccessMatrixIndices = 0x20;

    // [reference-derived] MatchGame -> camera manager -> camera main -> matrix.
    static constexpr uintptr_t MatchGameCameraManager = 0xD8;
    static constexpr uintptr_t CameraManagerMain = 0x18;
    static constexpr uintptr_t CameraMainImpl = 0x10;
    static constexpr uintptr_t CameraMatrixBase = 0xD8;

    // [dump-confirmed] semantic APIs; retained as diagnostics/reference only.
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA = 0x048F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA   = 0x048F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA            = 0x048F84D4;
    static constexpr uintptr_t GetPlayerCountRVA                         = 0x048F8C34;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA                = 0x048F85F4;

    static constexpr uintptr_t PlayerGetTransformNodeRVA                 = 0x05735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA             = 0x0890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA              = 0x06B4964C;
    static constexpr uintptr_t TransformGetPositionRVA                   = 0x08D6C1EC;

    static constexpr uintptr_t CameraGetMainRVA                          = 0x08CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA               = 0x08CFE9C0;
    static constexpr uintptr_t CameraWorldToViewportPointRVA             = 0x08CFEA34;
    static constexpr uintptr_t CameraGetWorldToCameraMatrixRVA            = 0x08CFE220;
    static constexpr uintptr_t CameraGetProjectionMatrixRVA               = 0x08CFE3C8;

    static constexpr uintptr_t AnimatorGetBoneTransformRVA               = 0x08CDDFEC;
    static constexpr uintptr_t AnimatorGetBoneTransformInternalRVA       = 0x08CDE404;
}
