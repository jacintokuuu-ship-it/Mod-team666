#import "ExternalMemory.h"

#include <algorithm>
#include <mach/mach.h>
#include <mach/vm_region.h>

ExternalMemoryReader::ExternalMemoryReader()
: m_task(MACH_PORT_NULL), m_unityBase(0) {}

ExternalMemoryReader::~ExternalMemoryReader() {
    Reset();
}

void ExternalMemoryReader::Attach(task_t task, mach_vm_address_t unityBase) {
    m_task = task;
    m_unityBase = unityBase;
    m_regions.clear();
}

void ExternalMemoryReader::Reset() {
    m_task = MACH_PORT_NULL;
    m_unityBase = 0;
    m_regions.clear();
}

bool ExternalMemoryReader::FindRegion(mach_vm_address_t address,
                                      mach_vm_size_t size,
                                      Region &out) const {
    if (size == 0) return false;
    for (const Region &r : m_regions) {
        if (address < r.start) continue;
        mach_vm_address_t end = address + size;
        if (end < address) return false;
        if (end <= r.start + r.size) {
            out = r;
            return true;
        }
    }
    return false;
}

bool ExternalMemoryReader::RefreshRegions() {
    m_regions.clear();
    if (m_task == MACH_PORT_NULL) return false;

    mach_vm_address_t address = 0;
    mach_vm_size_t size = 0;
    uint32_t depth = 0;

    for (;;) {
        vm_region_submap_info_data_64_t info{};
        mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;

        kern_return_t kr = mach_vm_region_recurse(
            m_task, &address, &size, &depth,
            reinterpret_cast<vm_region_recurse_info_t>(&info), &count);

        if (kr != KERN_SUCCESS) break;

        if (info.is_submap) {
            depth++;
            continue;
        }

        if ((info.protection & VM_PROT_READ) != 0 && size >= 0x1000) {
            Region r{address, size, info.protection, info.max_protection};
            m_regions.push_back(r);
        }

        address += size;
        depth = 0;
    }

    std::sort(m_regions.begin(), m_regions.end(),
              [](const Region &a, const Region &b) { return a.start < b.start; });

    return !m_regions.empty();
}

bool ExternalMemoryReader::IsReadable(mach_vm_address_t address,
                                       mach_vm_size_t size) const {
    Region r{};
    return FindRegion(address, size, r) &&
           (r.protection & VM_PROT_READ) != 0;
}

bool ExternalMemoryReader::Read(mach_vm_address_t address,
                                void *out,
                                mach_vm_size_t size) const {
    if (m_task == MACH_PORT_NULL || !out || size == 0) return false;

    if (!IsReadable(address, size)) return false;

    mach_vm_size_t copied = 0;
    kern_return_t kr = mach_vm_read_overwrite(
        m_task,
        address,
        size,
        reinterpret_cast<mach_vm_address_t>(out),
        &copied);

    if (kr == KERN_SUCCESS && copied == size) return true;

    return false;
}
