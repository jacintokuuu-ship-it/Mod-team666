#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface HUDMainWindow : UIWindow
@property (nonatomic, weak, nullable) UIView *interactiveRootView;
@end

NS_ASSUME_NONNULL_END
