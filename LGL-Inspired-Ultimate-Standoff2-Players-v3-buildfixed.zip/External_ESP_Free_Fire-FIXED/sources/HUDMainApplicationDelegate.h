//
//  HUDMainApplicationDelegate.h
//  TrollSpeed
//
//  Created by Lessica on 2024/1/24.
//

#import <UIKit/UIKit.h>
#import "HUDMainWindow.h"

@interface HUDMainApplicationDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) HUDMainWindow *window;
@end