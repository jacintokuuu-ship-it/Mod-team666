#import "HUDMainWindow.h"

@implementation HUDMainWindow

+ (BOOL)_isSystemWindow { return YES; }
- (BOOL)_isWindowServerHostingManaged { return NO; }
- (BOOL)_isSecure { return YES; }
- (BOOL)_shouldCreateContextAsSecure { return YES; }

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    UIView *interactiveRoot = self.interactiveRootView;
    if (!interactiveRoot || interactiveRoot.hidden || interactiveRoot.alpha <= 0.01) {
        return nil;
    }

    CGPoint localPoint = [interactiveRoot convertPoint:point fromView:self];
    if (![interactiveRoot pointInside:localPoint withEvent:event]) {
        return nil;
    }

    UIView *hit = [interactiveRoot hitTest:localPoint withEvent:event];
    return (hit == interactiveRoot) ? nil : hit;
}

@end
