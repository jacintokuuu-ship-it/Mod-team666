#import <UIKit/UIKit.h>
#import <objc/runtime.h>

#import "HUDMainApplicationDelegate.h"
#import "HUDMainWindow.h"
#import "SBSAccessibilityWindowHostingController.h"
#import "UIWindow+Private.h"
#import "../esp/drawing_view/esp.h"
#import "UIView+SecureView.h"

@interface HUDLandscapeContainerViewController : UIViewController
@end

@interface HUDMenuHostView : UIView
@property (nonatomic, strong) UIView *panelView;
@property (nonatomic, strong) UIButton *toggleButton;
@end

@implementation HUDMenuHostView

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if ([self.panelView pointInside:[self.panelView convertPoint:point fromView:self] withEvent:event]) {
        return YES;
    }
    if ([self.toggleButton pointInside:[self.toggleButton convertPoint:point fromView:self] withEvent:event]) {
        return YES;
    }
    return NO;
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    UIView *hit = [super hitTest:point withEvent:event];
    return (hit == self) ? nil : hit;
}

@end

@implementation HUDLandscapeContainerViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = UIColor.clearColor;
    self.view.opaque = NO;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskLandscape;
}

- (BOOL)shouldAutorotate
{
    return YES;
}

- (UIInterfaceOrientation)preferredInterfaceOrientationForPresentation
{
    return UIInterfaceOrientationLandscapeRight;
}

@end

static UIButton *HUDMakeMenuButton(NSString *title, CGRect frame)
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.frame = frame;
    button.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.10];
    button.layer.cornerRadius = 10.0;
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.08].CGColor;
    button.tintColor = UIColor.whiteColor;
    [button setTitle:title forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:15.0 weight:UIFontWeightSemibold];
    return button;
}

static UILabel *HUDMakeLabel(NSString *text, CGRect frame, CGFloat fontSize, UIFontWeight weight)
{
    UILabel *label = [[UILabel alloc] initWithFrame:frame];
    label.text = text;
    label.textColor = UIColor.whiteColor;
    label.font = [UIFont systemFontOfSize:fontSize weight:weight];
    label.backgroundColor = UIColor.clearColor;
    label.numberOfLines = 1;
    return label;
}

@implementation HUDMainApplicationDelegate {
    SBSAccessibilityWindowHostingController *_windowHostingController;
    HUDMenuHostView *_menuHost;
    ESP_View *_espView;
    BOOL _menuVisible;
}

- (instancetype)init
{
    return [super init];
}

- (UIInterfaceOrientation)currentInterfaceOrientation
{
    UIApplication *application = UIApplication.sharedApplication;

    if (@available(iOS 13.0, *)) {
        for (UIScene *scene in application.connectedScenes) {
            if (![scene isKindOfClass:UIWindowScene.class]) continue;
            UIWindowScene *windowScene = (UIWindowScene *)scene;
            if (windowScene.activationState != UISceneActivationStateForegroundActive &&
                windowScene.activationState != UISceneActivationStateForegroundInactive) continue;
            UIInterfaceOrientation orientation = windowScene.interfaceOrientation;
            if (orientation != UIInterfaceOrientationUnknown) return orientation;
        }
    }

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-declarations"
    UIInterfaceOrientation statusBarOrientation = application.statusBarOrientation;
#pragma clang diagnostic pop
    if (statusBarOrientation != UIInterfaceOrientationUnknown) return statusBarOrientation;

    UIDeviceOrientation deviceOrientation = UIDevice.currentDevice.orientation;
    if (UIDeviceOrientationIsLandscape(deviceOrientation)) {
        return deviceOrientation == UIDeviceOrientationLandscapeLeft
            ? UIInterfaceOrientationLandscapeRight
            : UIInterfaceOrientationLandscapeLeft;
    }
    return UIInterfaceOrientationLandscapeRight;
}

- (void)positionMenuHostAnimated:(BOOL)animated
{
    if (!_menuHost || !self.window) return;

    CGRect bounds = self.window.bounds;
    CGFloat margin = 20.0;
    CGFloat triggerSize = 52.0;
    CGFloat panelWidth = 286.0;
    CGFloat panelHeight = 176.0;
    CGFloat hostWidth = _menuVisible ? panelWidth : triggerSize;
    CGFloat hostHeight = _menuVisible ? panelHeight : triggerSize;

    CGFloat x = CGRectGetWidth(bounds) - panelWidth - margin;
    CGFloat y = margin + 14.0;
    if (!_menuVisible) {
        x = CGRectGetWidth(bounds) - triggerSize - margin;
        y = margin + 14.0;
    }

    CGRect target = CGRectMake(MAX(margin, x), MAX(margin, y), hostWidth, hostHeight);
    void (^changes)(void) = ^{
        _menuHost.frame = target;
        if (_menuVisible) {
            _menuHost.toggleButton.frame = CGRectMake(panelWidth - 46.0, 8.0, 34.0, 34.0);
            _menuHost.panelView.frame = CGRectMake(0, 0, panelWidth, panelHeight);
        } else {
            _menuHost.toggleButton.frame = CGRectMake(0, 0, triggerSize, triggerSize);
            _menuHost.panelView.frame = CGRectZero;
        }
    };

    if (animated) {
        [UIView animateWithDuration:0.18 animations:changes];
    } else {
        changes();
    }
}

- (void)toggleMenu
{
    _menuVisible = !_menuVisible;
    [_menuHost.toggleButton setTitle:(_menuVisible ? @"×" : @"☰") forState:UIControlStateNormal];
    [self positionMenuHostAnimated:YES];
    self.window.interactiveRootView = _menuHost;
}

- (void)setupMenu
{
    _menuVisible = YES;
    _menuHost = [[HUDMenuHostView alloc] initWithFrame:CGRectZero];
    _menuHost.backgroundColor = UIColor.clearColor;
    _menuHost.userInteractionEnabled = YES;

    UIView *panel = [[UIView alloc] initWithFrame:CGRectZero];
    panel.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.88];
    panel.layer.cornerRadius = 16.0;
    panel.layer.borderWidth = 1.0;
    panel.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.12].CGColor;
    panel.layer.shadowColor = UIColor.blackColor.CGColor;
    panel.layer.shadowOpacity = 0.30;
    panel.layer.shadowRadius = 18.0;
    panel.layer.shadowOffset = CGSizeMake(0, 8);
    _menuHost.panelView = panel;
    [_menuHost addSubview:panel];

    UILabel *title = HUDMakeLabel(@"FREE FIRE  •  EXTERNAL", CGRectMake(16, 12, 240, 22), 16.0, UIFontWeightBold);
    [panel addSubview:title];

    UILabel *status = HUDMakeLabel(@"TrollStore HUD  •  active", CGRectMake(16, 38, 240, 18), 11.5, UIFontWeightMedium);
    status.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.62];
    [panel addSubview:status];

    UIButton *espButton = HUDMakeMenuButton(@"ESP BOX   ON", CGRectMake(16, 70, 124, 42));
    [panel addSubview:espButton];
    [espButton addTarget:self action:@selector(toggleESP:) forControlEvents:UIControlEventTouchUpInside];

    UIButton *hideButton = HUDMakeMenuButton(@"MINIMIZE", CGRectMake(146, 70, 124, 42));
    [panel addSubview:hideButton];
    [hideButton addTarget:self action:@selector(toggleMenu) forControlEvents:UIControlEventTouchUpInside];

    UIButton *testButton = HUDMakeMenuButton(@"TEST TOUCH", CGRectMake(16, 120, 254, 38));
    [panel addSubview:testButton];
    [testButton addTarget:self action:@selector(testTouch:) forControlEvents:UIControlEventTouchUpInside];

    UIButton *toggle = [UIButton buttonWithType:UIButtonTypeSystem];
    toggle.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.88];
    toggle.layer.cornerRadius = 17.0;
    toggle.layer.borderWidth = 1.0;
    toggle.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.14].CGColor;
    toggle.tintColor = UIColor.whiteColor;
    toggle.titleLabel.font = [UIFont systemFontOfSize:21.0 weight:UIFontWeightBold];
    [toggle setTitle:@"×" forState:UIControlStateNormal];
    [toggle addTarget:self action:@selector(toggleMenu) forControlEvents:UIControlEventTouchUpInside];
    _menuHost.toggleButton = toggle;
    [_menuHost addSubview:toggle];

    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleMenuPan:)];
    [title addGestureRecognizer:pan];
    title.userInteractionEnabled = YES;

    UIView *rootView = self.window.rootViewController.view;
    [rootView addSubview:_menuHost];
    [self positionMenuHostAnimated:NO];
    self.window.interactiveRootView = _menuHost;
}

- (void)toggleESP:(UIButton *)sender
{
    sender.selected = !sender.selected;
    _espView.renderEnabled = !sender.selected;
    [sender setTitle:(_espView.renderEnabled ? @"ESP BOX   ON" : @"ESP BOX   OFF") forState:UIControlStateNormal];
    [_espView setNeedsDisplay];
}

- (void)testTouch:(UIButton *)sender
{
    NSString *oldTitle = sender.titleLabel.text;
    [sender setTitle:@"TOUCH RECEIVED ✓" forState:UIControlStateNormal];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if (sender.superview) [sender setTitle:oldTitle forState:UIControlStateNormal];
    });
}

- (void)handleMenuPan:(UIPanGestureRecognizer *)gesture
{
    CGPoint delta = [gesture translationInView:self.window.rootViewController.view];
    if (gesture.state == UIGestureRecognizerStateChanged) {
        CGRect frame = _menuHost.frame;
        frame.origin.x += delta.x;
        frame.origin.y += delta.y;

        CGSize boundsSize = self.window.bounds.size;
        CGFloat maxX = MAX(0.0, boundsSize.width - frame.size.width);
        CGFloat maxY = MAX(0.0, boundsSize.height - frame.size.height);
        frame.origin.x = MIN(MAX(0.0, frame.origin.x), maxX);
        frame.origin.y = MIN(MAX(0.0, frame.origin.y), maxY);
        _menuHost.frame = frame;
        [gesture setTranslation:CGPointZero inView:self.window.rootViewController.view];
    }
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary<UIApplicationLaunchOptionsKey, id> *)launchOptions
{
    HUDLandscapeContainerViewController *container = [[HUDLandscapeContainerViewController alloc] init];

    _espView = [[ESP_View alloc] initWithFrame:CGRectZero];
    _espView.translatesAutoresizingMaskIntoConstraints = NO;
    _espView.backgroundColor = UIColor.clearColor;
    _espView.userInteractionEnabled = NO;
    [_espView hideViewFromCapture:NO];

    UIView *containerView = container.view;
    [containerView addSubview:_espView];
    [NSLayoutConstraint activateConstraints:@[
        [_espView.leadingAnchor constraintEqualToAnchor:containerView.leadingAnchor],
        [_espView.trailingAnchor constraintEqualToAnchor:containerView.trailingAnchor],
        [_espView.topAnchor constraintEqualToAnchor:containerView.topAnchor],
        [_espView.bottomAnchor constraintEqualToAnchor:containerView.bottomAnchor]
    ]];

    self.window = [[HUDMainWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.backgroundColor = UIColor.clearColor;
    self.window.opaque = NO;
    self.window.rootViewController = container;
    self.window.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.window.windowLevel = 10000010.0;

    [self.window makeKeyAndVisible];
    [containerView setNeedsLayout];
    [containerView layoutIfNeeded];
    _espView.frame = containerView.bounds;

    [self setupMenu];

    UIInterfaceOrientation curOrientation = [self currentInterfaceOrientation];
    SEL setOrientSel = NSSelectorFromString(@"_setInterfaceOrientation:");
    if ([self.window respondsToSelector:setOrientSel]) {
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
        NSMethodSignature *sig = [self.window methodSignatureForSelector:setOrientSel];
        if (sig) {
            NSInvocation *inv = [NSInvocation invocationWithMethodSignature:sig];
            [inv setSelector:setOrientSel];
            [inv setTarget:self.window];
            NSInteger orientVal = (NSInteger)curOrientation;
            [inv setArgument:&orientVal atIndex:2];
            [inv invoke];
        }
#pragma clang diagnostic pop
    }

    _windowHostingController = [[objc_getClass("SBSAccessibilityWindowHostingController") alloc] init];
    unsigned int contextId = [self.window _contextId];
    double windowLevel = self.window.windowLevel;

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Warc-performSelector-leaks"
    NSMethodSignature *signature = [NSMethodSignature signatureWithObjCTypes:"v@:Id"];
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    [invocation setTarget:_windowHostingController];
    [invocation setSelector:NSSelectorFromString(@"registerWindowWithContextID:atLevel:")];
    [invocation setArgument:&contextId atIndex:2];
    [invocation setArgument:&windowLevel atIndex:3];
    [invocation invoke];
#pragma clang diagnostic pop

    return YES;
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    [self.window setHidden:NO];
    [self.window makeKeyAndVisible];
}

@end
