#import "NexusOverlayWindow.h"
#import "NexusOverlayRootView.h"

@implementation NexusOverlayWindow

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self nexusCommonInit];
    }
    return self;
}

- (instancetype)initWithWindowScene:(UIWindowScene *)windowScene API_AVAILABLE(ios(13.0))
{
    self = [super initWithWindowScene:windowScene];
    if (self) {
        [self nexusCommonInit];
    }
    return self;
}

- (void)nexusCommonInit
{
    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.alpha = 1.0;
    self.userInteractionEnabled = YES;
    self.multipleTouchEnabled = YES;
    self.windowLevel = UIWindowLevelAlert + 1.0;
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if (self.hidden || self.alpha <= 0.01 || !self.userInteractionEnabled) return NO;
    UIView *root = self.rootViewController.view;
    if (!root || root.hidden || root.alpha <= 0.01) return NO;
    CGPoint local = [root convertPoint:point fromView:self];
    return [root pointInside:local withEvent:event];
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (![self pointInside:point withEvent:event]) return nil;
    UIView *root = self.rootViewController.view;
    CGPoint local = [root convertPoint:point fromView:self];
    return [root hitTest:local withEvent:event];
}

- (BOOL)canBecomeKeyWindow
{
    return NO;
}

@end
