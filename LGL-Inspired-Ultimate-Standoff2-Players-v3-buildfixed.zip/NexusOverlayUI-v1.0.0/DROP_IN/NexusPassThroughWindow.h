#import <UIKit/UIKit.h>

@interface NexusOverlayWindow : UIWindow
@end
