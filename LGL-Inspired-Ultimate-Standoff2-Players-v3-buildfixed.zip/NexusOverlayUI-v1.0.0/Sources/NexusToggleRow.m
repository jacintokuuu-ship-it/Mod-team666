#import "NexusToggleRow.h"
#import "NexusTheme.h"
#import <QuartzCore/QuartzCore.h>

@implementation NexusToggleRow {
    UILabel *_titleLabel;
    UILabel *_subtitleLabel;
    UIView *_trackView;
    UIView *_glowView;
    UIView *_thumbView;
}

- (instancetype)initWithTitle:(NSString *)title subtitle:(NSString *)subtitle featureKey:(NSString *)featureKey
{
    self = [super initWithFrame:CGRectZero];
    if (self) {
        _featureKey = [featureKey copy];
        self.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.028];
        self.layer.cornerRadius = 14.0;
        self.layer.borderWidth = 1.0;
        self.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.08].CGColor;
        self.userInteractionEnabled = YES;
        self.accessibilityTraits = UIAccessibilityTraitButton;

        _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _titleLabel.text = title;
        _titleLabel.font = [UIFont systemFontOfSize:14.0 weight:UIFontWeightSemibold];
        _titleLabel.textColor = [UIColor colorWithWhite:0.94 alpha:1.0];
        _titleLabel.userInteractionEnabled = NO;
        [self addSubview:_titleLabel];

        _subtitleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _subtitleLabel.text = subtitle;
        _subtitleLabel.font = [UIFont monospacedSystemFontOfSize:9.0 weight:UIFontWeightRegular];
        _subtitleLabel.textColor = [NexusTheme mutedTextColor];
        _subtitleLabel.userInteractionEnabled = NO;
        [self addSubview:_subtitleLabel];

        _trackView = [[UIView alloc] initWithFrame:CGRectZero];
        _trackView.userInteractionEnabled = NO;
        _trackView.layer.cornerRadius = 15.0;
        _trackView.layer.borderWidth = 1.0;
        _trackView.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.12].CGColor;
        [self addSubview:_trackView];

        _glowView = [[UIView alloc] initWithFrame:CGRectZero];
        _glowView.userInteractionEnabled = NO;
        _glowView.layer.cornerRadius = 15.0;
        _glowView.alpha = 0.0;
        _glowView.layer.shadowOffset = CGSizeZero;
        _glowView.layer.shadowRadius = 12.0;
        [self addSubview:_glowView];

        _thumbView = [[UIView alloc] initWithFrame:CGRectZero];
        _thumbView.userInteractionEnabled = NO;
        _thumbView.layer.cornerRadius = 11.0;
        _thumbView.layer.shadowColor = [UIColor blackColor].CGColor;
        _thumbView.layer.shadowOpacity = 0.40;
        _thumbView.layer.shadowRadius = 4.0;
        _thumbView.layer.shadowOffset = CGSizeMake(0.0, 2.0);
        [_trackView addSubview:_thumbView];

        [self addTarget:self action:@selector(didActivate:) forControlEvents:UIControlEventTouchUpInside];
        [self setOn:NO animated:NO];
    }
    return self;
}

- (void)didActivate:(__unused id)sender
{
    [self setOn:!self.on animated:YES];
    [self sendActionsForControlEvents:UIControlEventValueChanged];
}

- (void)setHighlighted:(BOOL)highlighted
{
    [super setHighlighted:highlighted];
    [UIView animateWithDuration:0.08 animations:^{
        self.transform = highlighted ? CGAffineTransformMakeScale(0.985, 0.985) : CGAffineTransformIdentity;
    }];
}

- (void)setOn:(BOOL)on animated:(BOOL)animated
{
    _on = on;
    self.accessibilityValue = on ? @"On" : @"Off";
    self.accessibilityTraits = UIAccessibilityTraitButton | (on ? UIAccessibilityTraitSelected : 0);

    void (^changes)(void) = ^{
        UIColor *trackColor = on ? [NexusTheme greenColor] : [UIColor colorWithWhite:1.0 alpha:0.07];
        UIColor *glowColor = on ? [NexusTheme greenColor] : [UIColor clearColor];
        self->_trackView.backgroundColor = on ? [trackColor colorWithAlphaComponent:0.20] : trackColor;
        self->_trackView.layer.borderColor = [trackColor colorWithAlphaComponent:on ? 0.68 : 0.12].CGColor;
        self->_glowView.backgroundColor = [glowColor colorWithAlphaComponent:0.12];
        self->_glowView.layer.shadowColor = glowColor.CGColor;
        self->_glowView.alpha = on ? 1.0 : 0.0;
        self->_thumbView.backgroundColor = on ? [UIColor colorWithWhite:0.98 alpha:1.0] : [UIColor colorWithWhite:0.82 alpha:1.0];
        CGFloat travel = CGRectGetWidth(self->_trackView.bounds) - 24.0;
        CGFloat x = on ? travel : 0.0;
        self->_thumbView.frame = CGRectMake(2.0 + x, 4.0, 22.0, 22.0);
    };

    if (animated) {
        [UIView animateWithDuration:0.18 delay:0.0 options:UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionCurveEaseOut animations:changes completion:nil];
    } else {
        changes();
    }
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat w = CGRectGetWidth(self.bounds);
    _titleLabel.frame = CGRectMake(14.0, 9.0, MAX(80.0, w - 96.0), 19.0);
    _subtitleLabel.frame = CGRectMake(14.0, 29.0, MAX(80.0, w - 96.0), 15.0);
    CGRect track = CGRectMake(w - 62.0, 10.0, 54.0, 30.0);
    _trackView.frame = track;
    _trackView.layer.cornerRadius = 15.0;
    _glowView.frame = CGRectInset(track, 0.0, 0.0);
    _glowView.layer.cornerRadius = 15.0;
    CGFloat travel = CGRectGetWidth(track) - 24.0;
    CGFloat x = _on ? travel : 0.0;
    _thumbView.frame = CGRectMake(2.0 + x, 4.0, 22.0, 22.0);
}

@end
