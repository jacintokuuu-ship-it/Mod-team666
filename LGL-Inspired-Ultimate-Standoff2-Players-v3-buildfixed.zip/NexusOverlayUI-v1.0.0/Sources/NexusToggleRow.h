#import <UIKit/UIKit.h>

@interface NexusToggleRow : UIControl
@property (nonatomic, copy, readonly) NSString *featureKey;
@property (nonatomic, assign, readonly, getter=isOn) BOOL on;
- (instancetype)initWithTitle:(NSString *)title subtitle:(NSString *)subtitle featureKey:(NSString *)featureKey;
- (void)setOn:(BOOL)on animated:(BOOL)animated;
@end
