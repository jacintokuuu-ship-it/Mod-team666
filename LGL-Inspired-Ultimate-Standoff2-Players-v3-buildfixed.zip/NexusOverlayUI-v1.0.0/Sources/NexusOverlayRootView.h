#import <UIKit/UIKit.h>
#import "NexusFuturisticPanelView.h"

@interface NexusOverlayRootView : UIView <NexusFuturisticPanelViewDelegate>
@property (nonatomic, strong, readonly) NexusFuturisticPanelView *panel;
@property (nonatomic, strong, readonly) UIControl *launcher;
@property (nonatomic, assign, readonly, getter=isPanelVisible) BOOL panelVisible;
- (void)togglePanel;
- (void)showPanelAnimated:(BOOL)animated;
- (void)showLauncherAnimated:(BOOL)animated;
- (void)setInteractiveScreenFrame:(CGRect)frame;
@end
