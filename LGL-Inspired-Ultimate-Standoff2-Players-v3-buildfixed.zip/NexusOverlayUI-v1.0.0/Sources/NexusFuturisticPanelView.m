#import "NexusFuturisticPanelView.h"
#import "NexusToggleRow.h"
#import "NexusTheme.h"

@interface NexusFuturisticPanelView () <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIVisualEffectView *blurView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UISegmentedControl *tabs;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UIStackView *stackView;
@property (nonatomic, strong) NSMutableDictionary<NSString *, NexusToggleRow *> *rows;
@property (nonatomic, strong) UIButton *minimizeButton;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIView *dragRegion;
@end

@implementation NexusFuturisticPanelView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        _rows = [NSMutableDictionary dictionary];
        self.backgroundColor = UIColor.clearColor;
        self.userInteractionEnabled = YES;
        self.layer.cornerRadius = 22.0;
        self.layer.shadowColor = [NexusTheme cyanColor].CGColor;
        self.layer.shadowOpacity = 0.30;
        self.layer.shadowRadius = 20.0;
        self.layer.shadowOffset = CGSizeZero;

        UIBlurEffect *effect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemUltraThinMaterialDark];
        _blurView = [[UIVisualEffectView alloc] initWithEffect:effect];
        _blurView.userInteractionEnabled = YES;
        _blurView.layer.cornerRadius = 22.0;
        _blurView.clipsToBounds = YES;
        [self addSubview:_blurView];

        UIView *border = [[UIView alloc] initWithFrame:CGRectZero];
        border.userInteractionEnabled = NO;
        border.layer.cornerRadius = 22.0;
        border.layer.borderWidth = 1.0;
        border.layer.borderColor = [NexusTheme lineColor].CGColor;
        border.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [_blurView.contentView addSubview:border];

        UIView *accent = [[UIView alloc] initWithFrame:CGRectZero];
        accent.userInteractionEnabled = NO;
        accent.backgroundColor = [NexusTheme cyanColor];
        accent.layer.shadowColor = [NexusTheme cyanColor].CGColor;
        accent.layer.shadowOpacity = 0.90;
        accent.layer.shadowRadius = 9.0;
        accent.layer.shadowOffset = CGSizeZero;
        accent.tag = 1001;
        [_blurView.contentView addSubview:accent];

        _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _titleLabel.text = @"NEXUS // OVERLAY";
        _titleLabel.font = [UIFont systemFontOfSize:18.0 weight:UIFontWeightHeavy];
        _titleLabel.textColor = [UIColor whiteColor];
        _titleLabel.userInteractionEnabled = NO;
        [_blurView.contentView addSubview:_titleLabel];

        _statusLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _statusLabel.text = @"INPUT LINK  /  ONLINE";
        _statusLabel.font = [UIFont monospacedSystemFontOfSize:9.0 weight:UIFontWeightBold];
        _statusLabel.textColor = [NexusTheme greenColor];
        _statusLabel.userInteractionEnabled = NO;
        [_blurView.contentView addSubview:_statusLabel];

        _minimizeButton = [self iconButtonWithTitle:@"—" action:@selector(minimizePressed:)];
        _closeButton = [self iconButtonWithTitle:@"×" action:@selector(closePressed:)];
        _minimizeButton.accessibilityLabel = @"Minimize overlay";
        _closeButton.accessibilityLabel = @"Close overlay";
        [_blurView.contentView addSubview:_minimizeButton];
        [_blurView.contentView addSubview:_closeButton];

        _tabs = [[UISegmentedControl alloc] initWithItems:@[@"CORE", @"VISUAL", @"SYSTEM"]];
        _tabs.selectedSegmentIndex = 0;
        _tabs.selectedSegmentTintColor = [[NexusTheme cyanColor] colorWithAlphaComponent:0.24];
        _tabs.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.045];
        [_tabs setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor colorWithWhite:0.60 alpha:1.0], NSFontAttributeName:[UIFont monospacedSystemFontOfSize:9.0 weight:UIFontWeightBold]} forState:UIControlStateNormal];
        [_tabs setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor], NSFontAttributeName:[UIFont monospacedSystemFontOfSize:9.0 weight:UIFontWeightBold]} forState:UIControlStateSelected];
        [_tabs addTarget:self action:@selector(tabChanged:) forControlEvents:UIControlEventValueChanged];
        [_blurView.contentView addSubview:_tabs];

        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectZero];
        _scrollView.showsVerticalScrollIndicator = NO;
        _scrollView.delaysContentTouches = NO;
        _scrollView.canCancelContentTouches = YES;
        _scrollView.backgroundColor = UIColor.clearColor;
        [_blurView.contentView addSubview:_scrollView];

        _stackView = [[UIStackView alloc] initWithFrame:CGRectZero];
        _stackView.axis = UILayoutConstraintAxisVertical;
        _stackView.spacing = 8.0;
        [_scrollView addSubview:_stackView];

        for (NSArray *item in @[
            @[@"Visual grid", @"Native switch interaction", @"grid"],
            @[@"Target frame", @"Animated state indicator", @"frame"],
            @[@"Diagnostics", @"Touch routing telemetry", @"diagnostics"],
            @[@"Haptics", @"UI feedback layer", @"haptics"],
            @[@"Focus mode", @"Keep the panel compact", @"focus"],
            @[@"Status glow", @"Cybernetic accent layer", @"glow"],
            @[@"Accessibility", @"Native control semantics", @"a11y"],
            @[@"Auto layout", @"Safe-area aware panel", @"layout"]
        ]) {
            NexusToggleRow *row = [[NexusToggleRow alloc] initWithTitle:item[0] subtitle:item[1] featureKey:item[2]];
            row.translatesAutoresizingMaskIntoConstraints = NO;
            [row addTarget:self action:@selector(rowChanged:) forControlEvents:UIControlEventValueChanged];
            [row.heightAnchor constraintEqualToConstant:54.0].active = YES;
            [_stackView addArrangedSubview:row];
            _rows[item[2]] = row;
        }

        UIView *hint = [[UIView alloc] initWithFrame:CGRectZero];
        hint.backgroundColor = [[NexusTheme cyanColor] colorWithAlphaComponent:0.08];
        hint.layer.cornerRadius = 12.0;
        hint.userInteractionEnabled = NO;
        UILabel *hintText = [[UILabel alloc] initWithFrame:CGRectZero];
        hintText.text = @"TOUCH TEST  •  inside = overlay\n                       outside = background";
        hintText.numberOfLines = 2;
        hintText.font = [UIFont monospacedSystemFontOfSize:9.0 weight:UIFontWeightMedium];
        hintText.textColor = [NexusTheme cyanColor];
        hintText.frame = CGRectMake(12.0, 8.0, 220.0, 28.0);
        [hint addSubview:hintText];
        [_stackView addArrangedSubview:hint];
        [hint.heightAnchor constraintEqualToConstant:44.0].active = YES;

        _dragRegion = [[UIView alloc] initWithFrame:CGRectZero];
        _dragRegion.backgroundColor = UIColor.clearColor;
        _dragRegion.userInteractionEnabled = YES;
        _dragRegion.tag = 1002;
        [_blurView.contentView addSubview:_dragRegion];
        UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleDrag:)];
        pan.delegate = self;
        [_dragRegion addGestureRecognizer:pan];
    }
    return self;
}

- (UIButton *)iconButtonWithTitle:(NSString *)title action:(SEL)action
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.05];
    button.layer.cornerRadius = 9.0;
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = [UIColor colorWithWhite:1.0 alpha:0.08].CGColor;
    button.titleLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightBold];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [button addTarget:self action:action forControlEvents:UIControlEventTouchUpInside];
    return button;
}

- (void)rowChanged:(NexusToggleRow *)row
{
    [_statusLabel setText:row.isOn ? @"MODULE  /  ENABLED" : @"MODULE  /  DISABLED"];
    if ([self.delegate respondsToSelector:@selector(nexusPanel:didToggleKey:enabled:)]) {
        [self.delegate nexusPanel:self didToggleKey:row.featureKey enabled:row.isOn];
    }
}

- (void)tabChanged:(UISegmentedControl *)sender
{
    _statusLabel.text = sender.selectedSegmentIndex == 0 ? @"CORE  /  ONLINE" : (sender.selectedSegmentIndex == 1 ? @"VISUAL  /  ONLINE" : @"SYSTEM  /  ONLINE");
}

- (void)minimizePressed:(__unused UIButton *)sender
{
    if ([self.delegate respondsToSelector:@selector(nexusPanelDidRequestMinimize:)]) {
        [self.delegate nexusPanelDidRequestMinimize:self];
    }
}

- (void)closePressed:(__unused UIButton *)sender
{
    if ([self.delegate respondsToSelector:@selector(nexusPanelDidRequestClose:)]) {
        [self.delegate nexusPanelDidRequestClose:self];
    }
}

- (void)handleDrag:(UIPanGestureRecognizer *)gesture
{
    UIView *host = self.superview;
    if (!host || (gesture.state != UIGestureRecognizerStateChanged && gesture.state != UIGestureRecognizerStateEnded)) return;
    CGPoint delta = [gesture translationInView:host];
    CGPoint newCenter = CGPointMake(self.center.x + delta.x, self.center.y + delta.y);
    CGFloat margin = 10.0;
    CGFloat halfW = self.bounds.size.width * 0.5;
    CGFloat halfH = self.bounds.size.height * 0.5;
    newCenter.x = MIN(MAX(newCenter.x, halfW + margin), MAX(halfW + margin, host.bounds.size.width - halfW - margin));
    newCenter.y = MIN(MAX(newCenter.y, halfH + margin), MAX(halfH + margin, host.bounds.size.height - halfH - margin));
    self.center = newCenter;
    [gesture setTranslation:CGPointZero inView:host];
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    (void)gestureRecognizer;
    CGPoint point = [touch locationInView:self];
    return CGRectContainsPoint(CGRectMake(0.0, 0.0, CGRectGetWidth(self.bounds) - 92.0, 60.0), point);
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGRect b = self.bounds;
    _blurView.frame = b;
    UIView *accent = [_blurView.contentView viewWithTag:1001];
    accent.frame = CGRectMake(0.0, 0.0, 5.0, CGRectGetHeight(b));
    _dragRegion.frame = CGRectMake(0.0, 0.0, MAX(140.0, CGRectGetWidth(b) - 92.0), 64.0);
    _titleLabel.frame = CGRectMake(18.0, 10.0, MAX(140.0, CGRectGetWidth(b) - 150.0), 24.0);
    _statusLabel.frame = CGRectMake(18.0, 37.0, 150.0, 12.0);
    _minimizeButton.frame = CGRectMake(CGRectGetWidth(b) - 84.0, 13.0, 33.0, 30.0);
    _closeButton.frame = CGRectMake(CGRectGetWidth(b) - 46.0, 13.0, 33.0, 30.0);
    _tabs.frame = CGRectMake(16.0, 72.0, CGRectGetWidth(b) - 32.0, 34.0);
    _scrollView.frame = CGRectMake(16.0, 114.0, CGRectGetWidth(b) - 32.0, MAX(90.0, CGRectGetHeight(b) - 130.0));
    CGFloat width = CGRectGetWidth(_scrollView.bounds);
    CGSize fitting = [_stackView systemLayoutSizeFittingSize:CGSizeMake(width, UILayoutFittingCompressedSize.height)];
    CGFloat contentHeight = MAX(fitting.height, CGRectGetHeight(_scrollView.bounds));
    _stackView.frame = CGRectMake(0.0, 0.0, width, contentHeight);
    _scrollView.contentSize = CGSizeMake(width, fitting.height + 10.0);
}

@end
