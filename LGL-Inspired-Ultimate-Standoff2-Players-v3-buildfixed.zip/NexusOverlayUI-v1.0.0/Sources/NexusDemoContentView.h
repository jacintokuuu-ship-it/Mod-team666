#import <UIKit/UIKit.h>

@interface NexusDemoContentView : UIView
@property (nonatomic, copy, nullable) void (^onOverlayStateRequest)(NSString *message);
@end
