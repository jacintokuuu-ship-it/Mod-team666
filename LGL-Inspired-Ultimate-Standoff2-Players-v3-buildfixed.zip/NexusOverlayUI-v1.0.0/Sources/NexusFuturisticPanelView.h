#import <UIKit/UIKit.h>

@class NexusFuturisticPanelView;

@protocol NexusFuturisticPanelViewDelegate <NSObject>
- (void)nexusPanelDidRequestMinimize:(NexusFuturisticPanelView *)panel;
- (void)nexusPanelDidRequestClose:(NexusFuturisticPanelView *)panel;
- (void)nexusPanel:(NexusFuturisticPanelView *)panel didToggleKey:(NSString *)key enabled:(BOOL)enabled;
@end

@interface NexusFuturisticPanelView : UIView
@property (nonatomic, weak) id<NexusFuturisticPanelViewDelegate> delegate;
- (instancetype)initWithFrame:(CGRect)frame;
@end
