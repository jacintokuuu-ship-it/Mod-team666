#import "NexusDemoContentView.h"
#import "NexusTheme.h"

@interface NexusDemoContentView ()
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *instructionLabel;
@property (nonatomic, strong) UILabel *counterLabel;
@property (nonatomic, assign) NSInteger tapCount;
@end

@implementation NexusDemoContentView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [NexusTheme backgroundColor];
        self.userInteractionEnabled = YES;

        _titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _titleLabel.text = @"TOUCH ROUTING LAB";
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        _titleLabel.font = [UIFont monospacedSystemFontOfSize:22.0 weight:UIFontWeightHeavy];
        _titleLabel.textColor = [UIColor colorWithWhite:0.95 alpha:1.0];
        [self addSubview:_titleLabel];

        _instructionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _instructionLabel.text = @"Tap outside the cyan panel.\nThose taps belong to this background window.";
        _instructionLabel.numberOfLines = 0;
        _instructionLabel.textAlignment = NSTextAlignmentCenter;
        _instructionLabel.font = [UIFont monospacedSystemFontOfSize:12.0 weight:UIFontWeightRegular];
        _instructionLabel.textColor = [UIColor colorWithWhite:0.58 alpha:1.0];
        [self addSubview:_instructionLabel];

        _counterLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        _counterLabel.textAlignment = NSTextAlignmentCenter;
        _counterLabel.font = [UIFont monospacedSystemFontOfSize:28.0 weight:UIFontWeightBold];
        _counterLabel.textColor = [NexusTheme greenColor];
        [self addSubview:_counterLabel];
        [self updateCounter];
    }
    return self;
}

- (void)updateCounter
{
    _counterLabel.text = [NSString stringWithFormat:@"BACKGROUND TOUCHES  %ld", (long)_tapCount];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat width = CGRectGetWidth(self.bounds);
    CGFloat centerY = CGRectGetHeight(self.bounds) * 0.5;
    _titleLabel.frame = CGRectMake(16.0, centerY - 90.0, width - 32.0, 32.0);
    _instructionLabel.frame = CGRectMake(24.0, centerY - 42.0, width - 48.0, 52.0);
    _counterLabel.frame = CGRectMake(16.0, centerY + 28.0, width - 32.0, 42.0);
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    (void)touches;
    (void)event;
    _tapCount += 1;
    [self updateCounter];
    [super touchesEnded:touches withEvent:event];
}

@end
