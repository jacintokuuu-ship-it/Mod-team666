#import "NexusOverlayRootView.h"
#import "NexusTheme.h"
#import <QuartzCore/QuartzCore.h>

@interface NexusLauncherControl : UIControl
@property (nonatomic, strong) UILabel *label;
@end

@implementation NexusLauncherControl
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [NexusTheme panelColor];
        self.layer.cornerRadius = 24.0;
        self.layer.borderWidth = 1.0;
        self.layer.borderColor = [[NexusTheme cyanColor] colorWithAlphaComponent:0.72].CGColor;
        self.layer.shadowColor = [NexusTheme cyanColor].CGColor;
        self.layer.shadowOpacity = 0.60;
        self.layer.shadowRadius = 14.0;
        self.layer.shadowOffset = CGSizeZero;
        self.userInteractionEnabled = YES;
        _label = [[UILabel alloc] initWithFrame:CGRectZero];
        _label.text = @"N";
        _label.textAlignment = NSTextAlignmentCenter;
        _label.font = [UIFont monospacedSystemFontOfSize:20.0 weight:UIFontWeightHeavy];
        _label.textColor = [UIColor whiteColor];
        _label.userInteractionEnabled = NO;
        [self addSubview:_label];
    }
    return self;
}
- (void)setHighlighted:(BOOL)highlighted
{
    [super setHighlighted:highlighted];
    [UIView animateWithDuration:0.08 animations:^{
        self.transform = highlighted ? CGAffineTransformMakeScale(0.92, 0.92) : CGAffineTransformIdentity;
    }];
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    _label.frame = self.bounds;
}
@end

@implementation NexusOverlayRootView {
    NexusFuturisticPanelView *_panel;
    NexusLauncherControl *_launcher;
    BOOL _panelVisible;
    CGPoint _anchorCenter;
    BOOL _hasAnchor;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColor.clearColor;
        self.userInteractionEnabled = YES;
        self.multipleTouchEnabled = YES;
        self.clipsToBounds = NO;

        _panel = [[NexusFuturisticPanelView alloc] initWithFrame:CGRectZero];
        _panel.delegate = self;
        [self addSubview:_panel];

        _launcher = [[NexusLauncherControl alloc] initWithFrame:CGRectMake(0.0, 0.0, 68.0, 68.0)];
        [_launcher addTarget:self action:@selector(launcherPressed:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_launcher];

        _panelVisible = YES;
        _launcher.hidden = YES;
    }
    return self;
}

- (NexusFuturisticPanelView *)panel { return _panel; }
- (UIControl *)launcher { return _launcher; }
- (BOOL)isPanelVisible { return _panelVisible; }

- (UIView *)activeView
{
    return _panelVisible ? _panel : _launcher;
}

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event
{
    if (self.hidden || self.alpha <= 0.01 || !self.userInteractionEnabled) return NO;
    UIView *active = [self activeView];
    if (!active || active.hidden || active.alpha <= 0.01) return NO;
    CGPoint local = [active convertPoint:point fromView:self];
    return [active pointInside:local withEvent:event];
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    if (![self pointInside:point withEvent:event]) return nil;
    UIView *active = [self activeView];
    CGPoint local = [active convertPoint:point fromView:self];
    return [active hitTest:local withEvent:event] ?: active;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGSize panelSize = CGSizeMake(MIN(360.0, MAX(300.0, CGRectGetWidth(self.bounds) - 32.0)), 560.0);
    if (!_hasAnchor) {
        _anchorCenter = CGPointMake(CGRectGetMidX(self.bounds), CGRectGetMidY(self.bounds));
        _hasAnchor = YES;
    }
    CGFloat halfW = (_panelVisible ? panelSize.width : 68.0) * 0.5;
    CGFloat halfH = (_panelVisible ? panelSize.height : 68.0) * 0.5;
    _anchorCenter.x = MIN(MAX(_anchorCenter.x, halfW + 10.0), MAX(halfW + 10.0, CGRectGetWidth(self.bounds) - halfW - 10.0));
    _anchorCenter.y = MIN(MAX(_anchorCenter.y, halfH + 10.0), MAX(halfH + 10.0, CGRectGetHeight(self.bounds) - halfH - 10.0));

    _panel.bounds = (CGRect){CGPointZero, panelSize};
    _panel.center = _anchorCenter;
    _panel.hidden = !_panelVisible;

    _launcher.bounds = (CGRect){CGPointZero, CGSizeMake(68.0, 68.0)};
    _launcher.center = _anchorCenter;
    _launcher.hidden = _panelVisible;
}

- (void)setInteractiveScreenFrame:(CGRect)frame
{
    if (CGRectIsNull(frame) || CGRectIsEmpty(frame) || CGRectIsEmpty(self.bounds)) return;
    CGRect local = [self convertRect:frame fromView:nil];
    _anchorCenter = CGPointMake(CGRectGetMidX(local), CGRectGetMidY(local));
    _hasAnchor = YES;
    [self setNeedsLayout];
    [self layoutIfNeeded];
}

- (void)showPanelAnimated:(BOOL)animated
{
    if (!_panelVisible) {
        _anchorCenter = _launcher.center;
        _hasAnchor = YES;
    }
    _panelVisible = YES;
    [self setNeedsLayout];
    [self layoutIfNeeded];
    _panel.alpha = animated ? 0.0 : 1.0;
    _panel.transform = animated ? CGAffineTransformMakeScale(0.96, 0.96) : CGAffineTransformIdentity;
    _launcher.hidden = YES;
    _panel.hidden = NO;
    void (^changes)(void) = ^{
        self->_panel.alpha = 1.0;
        self->_panel.transform = CGAffineTransformIdentity;
    };
    if (animated) [UIView animateWithDuration:0.18 animations:changes]; else changes();
}

- (void)showLauncherAnimated:(BOOL)animated
{
    if (_panelVisible) {
        _anchorCenter = _panel.center;
        _hasAnchor = YES;
    }
    _panelVisible = NO;
    [self setNeedsLayout];
    [self layoutIfNeeded];
    _launcher.alpha = animated ? 0.0 : 1.0;
    _launcher.transform = animated ? CGAffineTransformMakeScale(0.72, 0.72) : CGAffineTransformIdentity;
    _launcher.hidden = NO;
    _panel.hidden = YES;
    void (^changes)(void) = ^{
        self->_launcher.alpha = 1.0;
        self->_launcher.transform = CGAffineTransformIdentity;
    };
    if (animated) [UIView animateWithDuration:0.18 animations:changes]; else changes();
}

- (void)togglePanel
{
    if (_panelVisible) [self showLauncherAnimated:YES]; else [self showPanelAnimated:YES];
}

- (void)launcherPressed:(__unused UIControl *)sender
{
    [self showPanelAnimated:YES];
}

- (void)nexusPanelDidRequestMinimize:(__unused NexusFuturisticPanelView *)panel
{
    [self showLauncherAnimated:YES];
}

- (void)nexusPanelDidRequestClose:(__unused NexusFuturisticPanelView *)panel
{
    [self showLauncherAnimated:YES];
}

- (void)nexusPanel:(__unused NexusFuturisticPanelView *)panel didToggleKey:(NSString *)key enabled:(BOOL)enabled
{
    (void)key;
    (void)enabled;
}

@end
