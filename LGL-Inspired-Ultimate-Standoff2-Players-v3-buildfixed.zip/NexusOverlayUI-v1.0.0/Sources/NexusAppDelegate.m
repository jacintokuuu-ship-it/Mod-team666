#import "NexusAppDelegate.h"
#import "NexusDemoContentView.h"
#import "NexusOverlayWindow.h"
#import "NexusOverlayRootView.h"

@implementation NexusAppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    (void)application;
    (void)launchOptions;
    return YES;
}

@end

@interface NexusSceneDelegate : UIResponder <UIWindowSceneDelegate>
@property (nonatomic, strong) UIWindow *backgroundWindow;
@property (nonatomic, strong) NexusOverlayWindow *overlayWindow;
@end

@implementation NexusSceneDelegate

- (void)scene:(UIScene *)scene willConnectToSession:(UISceneSession *)session options:(UISceneConnectionOptions *)connectionOptions API_AVAILABLE(ios(13.0))
{
    (void)session;
    (void)connectionOptions;
    if (![scene isKindOfClass:[UIWindowScene class]]) return;

    UIWindowScene *windowScene = (UIWindowScene *)scene;

    self.backgroundWindow = [[UIWindow alloc] initWithWindowScene:windowScene];
    UIViewController *backgroundController = [[UIViewController alloc] init];
    backgroundController.view = [[NexusDemoContentView alloc] initWithFrame:CGRectZero];
    self.backgroundWindow.rootViewController = backgroundController;

    self.overlayWindow = [[NexusOverlayWindow alloc] initWithWindowScene:windowScene];
    UIViewController *overlayController = [[UIViewController alloc] init];
    NexusOverlayRootView *root = [[NexusOverlayRootView alloc] initWithFrame:CGRectZero];
    overlayController.view = root;
    self.overlayWindow.rootViewController = overlayController;
    self.overlayWindow.windowLevel = UIWindowLevelAlert + 1.0;

    self.backgroundWindow.hidden = NO;
    [self.backgroundWindow makeKeyAndVisible];
    self.overlayWindow.hidden = NO;
}

@end
