#import <UIKit/UIKit.h>

@interface NexusAppDelegate : UIResponder <UIApplicationDelegate>
@end
