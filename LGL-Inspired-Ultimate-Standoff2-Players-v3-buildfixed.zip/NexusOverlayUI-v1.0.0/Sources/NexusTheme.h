#import <UIKit/UIKit.h>

@interface NexusTheme : NSObject
+ (UIColor *)backgroundColor;
+ (UIColor *)panelColor;
+ (UIColor *)cyanColor;
+ (UIColor *)greenColor;
+ (UIColor *)mutedTextColor;
+ (UIColor *)lineColor;
@end
