#import "NexusTheme.h"

@implementation NexusTheme
+ (UIColor *)backgroundColor { return [UIColor colorWithRed:0.015 green:0.025 blue:0.040 alpha:1.0]; }
+ (UIColor *)panelColor { return [UIColor colorWithRed:0.020 green:0.055 blue:0.075 alpha:0.94]; }
+ (UIColor *)cyanColor { return [UIColor colorWithRed:0.18 green:0.90 blue:1.0 alpha:1.0]; }
+ (UIColor *)greenColor { return [UIColor colorWithRed:0.22 green:1.0 blue:0.62 alpha:1.0]; }
+ (UIColor *)mutedTextColor { return [UIColor colorWithWhite:0.50 alpha:1.0]; }
+ (UIColor *)lineColor { return [UIColor colorWithRed:0.18 green:0.80 blue:0.92 alpha:0.25]; }
@end
