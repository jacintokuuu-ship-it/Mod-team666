# NexusOverlayUI 1.0.0

UI-only iOS overlay test harness for validating selective hit-testing and a futuristic native control surface.

## Architecture

The test app deliberately uses two real `UIWindow` instances:

1. `backgroundWindow` — receives touches outside the overlay.
2. `NexusOverlayWindow` — fullscreen, transparent, higher `windowLevel`, but returns `nil` from `hitTest:` whenever the active overlay control is not under the finger.

`NexusOverlayRootView` is also selective: only the visible panel or launcher can become the hit-test target.

This makes the behavior directly observable: tapping outside increments `BACKGROUND TOUCHES`; tapping a toggle, tab, minimize, close, launcher, or drag region is consumed by the overlay.

## Build

```sh
export THEOS=/path/to/theos
./BUILD_PRECHECK.sh
make clean
make package
```

The project is intentionally iOS-native UIKit and contains no game hooks, ESP, chams, anti-ban, stealth, or input-injection code.

## Integration principle

Do not move the real controls into a fullscreen transparent view with `userInteractionEnabled = YES` unless its `hitTest:` is selective. Keep the overlay window fullscreen, and make the root view decide which child is actually interactive.

## Verification

```sh
./BUILD_PRECHECK.sh
python3 Tests/touch_geometry_sim.py
```

The test matrix is in `Tests/touch_matrix.md`.
