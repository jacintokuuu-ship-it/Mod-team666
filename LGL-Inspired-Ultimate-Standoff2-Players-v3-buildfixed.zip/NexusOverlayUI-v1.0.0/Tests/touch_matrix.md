# Touch Matrix

| Case | Expected receiver |
|---|---|
| Panel button | Overlay window |
| Toggle row | Overlay window |
| Tab control | Overlay window |
| Header drag | Overlay window |
| Launcher | Overlay window |
| Point outside panel | Background window |
| Point outside launcher | Background window |
| Minimize then tap launcher | Overlay window |
| Close then tap launcher | Overlay window |
| Cancelled interaction | No synthetic click |

The project intentionally uses native UIKit controls instead of synthetic HID-to-ImGui input. This makes the touch path observable and deterministic.
