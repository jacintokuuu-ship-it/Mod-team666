from dataclasses import dataclass

@dataclass
class Rect:
    x: float
    y: float
    w: float
    h: float
    def contains(self, px: float, py: float) -> bool:
        return self.x <= px <= self.x + self.w and self.y <= py <= self.y + self.h

def route(point, active: Rect):
    return "overlay" if active.contains(*point) else "background"

panel = Rect(40, 220, 300, 560)
launcher = Rect(146, 420, 68, 68)

assert route((100, 300), panel) == "overlay"
assert route((10, 300), panel) == "background"
assert route((339, 779), panel) == "overlay"
assert route((341, 781), panel) == "background"
assert route((180, 450), launcher) == "overlay"
assert route((80, 120), launcher) == "background"

# Dragging only changes the child target; the overlay window remains fullscreen.
panel = Rect(520, 220, 300, 560)
assert route((600, 300), panel) == "overlay"
assert route((100, 300), panel) == "background"

print("TOUCH_GEOMETRY_SIMULATION PASS")
