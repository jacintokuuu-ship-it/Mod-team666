# NexusOverlayUI 1.0.0 — Engineering Audit

## Problem addressed

The previous architecture used a visually separate render surface plus a touch proxy and synthetic input forwarding. That made it possible for the visual panel to exist while the actual event target was elsewhere.

## New event pipeline

`WindowServer/UIKit -> NexusOverlayWindow -> NexusOverlayRootView -> active native control`

The overlay window is fullscreen so the window server can consider it as a candidate. Its `hitTest:` delegates to the root. The root only returns a hit for the visible panel or launcher; every other coordinate returns `nil`.

## Why the old small-window pattern was removed

Resizing the window itself to the panel bounds couples window-server hit testing to animated/dragged geometry. The new design keeps the window stable and moves only the interactive child. This separates window registration from UI layout.

## Native controls

Toggles are `UIControl` instances. State changes are animated locally and sent through `UIControlEventValueChanged`. No synthetic HID events and no direct mutation of an external renderer's mouse state are needed.

## Regression cases

- inside panel -> overlay
- outside panel -> background
- inside launcher -> overlay
- outside launcher -> background
- after dragging -> new panel position is interactive
- minimize -> launcher becomes interactive
- close -> launcher remains available
- diagnostics/background counter demonstrates routing

## Build limitation

Static validation is performed in the supplied environment. A real iOS arm64 compilation still requires the target machine's Theos installation and iPhoneOS SDK, which are not available in this environment.
