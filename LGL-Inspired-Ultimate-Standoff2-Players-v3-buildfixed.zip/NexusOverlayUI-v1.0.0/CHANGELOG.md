# 1.0.0

- Replaced split-window synthetic input with one fullscreen overlay `UIWindow` plus selective root hit-testing.
- Added native UIKit panel controls with animated switch tracks/thumbs.
- Added blur, glow, borders, shadows, minimize/restore, close, and drag header.
- Added a background touch counter so pass-through behavior is immediately testable.
- Added Theos Makefile and static preflight checks.
