#!/bin/sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)"
cd "$ROOT"

fail=0
check_file() { [ -f "$1" ] || { echo "FAIL: missing $1"; fail=1; }; }

for f in \
    Makefile Resources/Info.plist \
    Sources/main.m Sources/NexusAppDelegate.h Sources/NexusAppDelegate.m \
    Sources/NexusDemoContentView.h Sources/NexusDemoContentView.m \
    Sources/NexusOverlayWindow.h Sources/NexusOverlayWindow.m \
    Sources/NexusOverlayRootView.h Sources/NexusOverlayRootView.m \
    Sources/NexusFuturisticPanelView.h Sources/NexusFuturisticPanelView.m \
    Sources/NexusToggleRow.h Sources/NexusToggleRow.m \
    Sources/NexusTheme.h Sources/NexusTheme.m
 do
    check_file "$f"
done

plutil -lint Resources/Info.plist >/dev/null

python3 - <<'PY'
from pathlib import Path
files = list(Path('Sources').glob('*.m'))
headers = list(Path('Sources').glob('*.h'))
all_files = files + headers
text = '\n'.join(p.read_text() for p in all_files)
required = ['hitTest:', 'pointInside:', 'UIWindow', 'userInteractionEnabled = YES']
for needle in required:
    if needle not in text:
        raise SystemExit(f'missing architectural marker: {needle}')
for bad in ['BKSHIDEventRegisterEventCallback', 'HUDInjectImGuiTouch', 'anti-ban', 'chams', 'ESP hook', 'sendEvent:']:
    if bad in text:
        raise SystemExit(f'legacy/cheat path present in UI harness: {bad}')

# Approximate balanced delimiter scan. It intentionally ignores strings and comments.
for path in all_files:
    s = path.read_text()
    stack=[]
    pairs={')':'(',']':'[','}':'{'}
    i=0
    while i < len(s):
        if s.startswith('//',i):
            j=s.find('\n',i+2); i=len(s) if j < 0 else j+1; continue
        if s.startswith('/*',i):
            j=s.find('*/',i+2)
            if j < 0: raise SystemExit(f'unclosed comment: {path}')
            i=j+2; continue
        if s[i] in '\"\'':
            q=s[i]; i+=1
            while i < len(s):
                if s[i]=='\\': i+=2; continue
                if s[i]==q: i+=1; break
                i+=1
            continue
        c=s[i]
        if c in '([{': stack.append(c)
        elif c in pairs:
            if not stack or stack[-1] != pairs[c]:
                raise SystemExit(f'delimiter mismatch: {path}')
            stack.pop()
        i+=1
    if stack: raise SystemExit(f'unclosed delimiter: {path}: {stack[-4:]}')

print('BUILD_PRECHECK PASS')
PY
