# PRIVILEGE_MATRIX.md

## TrollStore
O TrollStore preserva entitlements presentes no IPA durante a instalação. A documentação oficial também informa que ele não fornece platformization real e não permite criar um launch daemon apenas por estar instalado via TrollStore.

## Este projeto
O build usa somente:
- `get-task-allow`
- `task_for_pid-allow`

Esses entitlements são uma tentativa explícita de habilitar o caminho `task_for_pid`; eles **não são tratados pelo código como garantia de acesso**. Se o kernel negar o task port, o diagnóstico mostra a falha.

Não são usados:
- `platform-application`
- `com.apple.private.security.no-sandbox`
- `com.apple.system-task-ports`
- launch daemon
- código executável alocado no processo-alvo
- escrita de memória no processo-alvo
- criação/controle de thread no processo-alvo

## iOS 15.8
A documentação do TrollStore lista iOS 14.0 beta 2 até 16.6.1 entre as versões suportadas, portanto iOS 15.x está dentro dessa faixa de suporte do TrollStore.
