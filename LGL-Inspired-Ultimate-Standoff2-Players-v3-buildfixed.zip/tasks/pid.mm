#import <CoreFoundation/CoreFoundation.h>
#import <Foundation/Foundation.h>
#import <mach-o/loader.h>
#import <mach-o/fat.h>
#import <mach-o/dyld.h>
#import <mach/mach.h>
#import <mach/vm_page_size.h>
#import <mach/task_info.h>
#import <mach/mach_traps.h>
#import <stdio.h>
#import <stdlib.h>
#import <libgen.h>
#import <map>
#import <deque>
#import <vector>
#import <array>
#import <string>
#import <UIKit/UIKit.h>
#include <mach-o/dyld_images.h>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#import "pid.h"
#import "../esp/helpers/libproc.h"


struct dyld_uuid_info64 {
    mach_vm_address_t    imageLoadAddress;
    uuid_t               imageUUID;
};

struct dyld_image_info64 {
    mach_vm_address_t    imageLoadAddress;
    mach_vm_address_t    imageFilePath;
    mach_vm_size_t       imageFileModDate;
};

struct dyld_all_image_infos64 {
    uint32_t version;
    uint32_t infoArrayCount;
    mach_vm_address_t infoArray;
    dyld_image_notifier  notification;
    bool                 processDetachedFromSharedRegion;
    bool libSystemInitialized;
    mach_vm_address_t            dyldImageLoadAddress;
    mach_vm_address_t            jitInfo;
    mach_vm_address_t            dyldVersion;
    mach_vm_address_t            errorMessage;
    uint64_t                    terminationFlags;
    mach_vm_address_t            coreSymbolicationShmPage;
    uint64_t                    systemOrderFlag;
    uint64_t                    uuidArrayCount;
    mach_vm_address_t            uuidArray;
    mach_vm_address_t            dyldAllImageInfosAddress;
    uint64_t                    initialImageCount;
    uint64_t                    errorKind;
    mach_vm_address_t            errorClientOfDylibPath;
    mach_vm_address_t            errorTargetDylibPath;
    mach_vm_address_t            errorSymbol;
    uint64_t                    sharedCacheSlide;
};



pid_t get_pid_by_name(const char *keyword)
{
    if (keyword == NULL || *keyword == '\0')
        return -1;

    int count = proc_listallpids(NULL, 0);
    if (count <= 0)
        return -1;

    std::vector<pid_t> pids(static_cast<size_t>(count));
    int listed = proc_listallpids(pids.data(), static_cast<int>(pids.size() * sizeof(pid_t)));
    if (listed <= 0)
        return -1;

    // The process list can change between the size query and the second call.
    // Retry once with the newly reported size instead of using a C++ VLA.
    if (listed > static_cast<int>(pids.size()))
    {
        pids.resize(static_cast<size_t>(listed));
        listed = proc_listallpids(pids.data(), static_cast<int>(pids.size() * sizeof(pid_t)));
        if (listed <= 0)
            return -1;
    }

    const size_t pidCount = std::min(static_cast<size_t>(listed), pids.size());
    for (size_t i = 0; i < pidCount; ++i)
    {
        char name[1000] = {0};
        if (proc_name(pids[i], name, sizeof(name)) <= 0)
            continue;

        if (strstr(name, keyword) != NULL)
            return pids[i];
    }

    return -1;
}

static char s_taskLastError[128] = "ok";

const char *get_task_last_error(void) { return s_taskLastError; }

task_t get_task_by_pid(pid_t pid)
{
    if (pid <= 0) {
        snprintf(s_taskLastError, sizeof(s_taskLastError), "invalid pid");
        return MACH_PORT_NULL;
    }

    task_t task = MACH_PORT_NULL;
    const kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr == KERN_SUCCESS && task != MACH_PORT_NULL) {
        snprintf(s_taskLastError, sizeof(s_taskLastError), "ok(task_for_pid)");
        return task;
    }

    snprintf(s_taskLastError,
             sizeof(s_taskLastError),
             "task_for_pid=0x%x (%s)",
             kr,
             mach_error_string(kr));
    return MACH_PORT_NULL;
}

mach_vm_address_t get_image_base_address(mach_port_t task, const char *image_name)
{
    task_dyld_info_data_t dyld_info;
    mach_msg_type_number_t count = TASK_DYLD_INFO_COUNT;
    kern_return_t kr = task_info(task, TASK_DYLD_INFO, (task_info_t)&dyld_info, &count);
    if (kr != KERN_SUCCESS)
    {
        fprintf(stderr, "task_info failed: %s\n", mach_error_string(kr));
        return 0;
    }

    struct dyld_all_image_infos64 infos;
    vm_size_t size = sizeof(infos);
    mach_msg_type_number_t read_size = 0;
    vm_offset_t read_mem = 0;

    kr = vm_read(task, (vm_address_t)dyld_info.all_image_info_addr, size, &read_mem, &read_size);
    if (kr != KERN_SUCCESS || read_size < sizeof(infos))
    {
        fprintf(stderr, "vm_read for dyld_all_image_infos64 failed: %s\n", mach_error_string(kr));
        return 0;
    }
    memcpy(&infos, (void *)read_mem, sizeof(infos));
    vm_deallocate(mach_task_self(), read_mem, read_size);

    uint32_t image_count = infos.infoArrayCount;
    mach_vm_address_t info_array_addr = infos.infoArray;
    if (image_count == 0 || image_count > 65536 || info_array_addr == 0)
        return 0;

    vm_size_t image_info_size = (vm_size_t)image_count * sizeof(struct dyld_image_info64);
    struct dyld_image_info64 *image_infos = (struct dyld_image_info64 *)malloc(image_info_size);
    if (!image_infos) return 0;

    read_mem = 0;
    read_size = 0;
    kr = vm_read(task, (vm_address_t)info_array_addr, image_info_size, &read_mem, &read_size);
    if (kr != KERN_SUCCESS || read_size < image_info_size)
    {
        fprintf(stderr, "vm_read for image infos failed: %s\n", mach_error_string(kr));
        free(image_infos);
        return 0;
    }
    memcpy(image_infos, (void *)read_mem, image_info_size);
    vm_deallocate(mach_task_self(), read_mem, read_size);

    for (uint32_t i = 0; i < image_count; ++i)
    {
        char path_buffer[PATH_MAX] = {0};
        read_mem = 0;
        read_size = 0;
        kr = vm_read(task, (vm_address_t)image_infos[i].imageFilePath, PATH_MAX, &read_mem, &read_size);
        if (kr == KERN_SUCCESS)
        {
            size_t to_copy = read_size >= PATH_MAX ? (PATH_MAX - 1) : read_size;
            memcpy(path_buffer, (void *)read_mem, to_copy);
            path_buffer[to_copy] = '\0';
            vm_deallocate(mach_task_self(), read_mem, read_size);
        }

        if (kr == KERN_SUCCESS && strstr(path_buffer, image_name))
        {
            mach_vm_address_t base = image_infos[i].imageLoadAddress;
            free(image_infos);
            return base;
        }
    }

    free(image_infos);
    return 0;
}

