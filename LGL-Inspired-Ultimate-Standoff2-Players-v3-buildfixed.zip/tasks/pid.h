#pragma once

#include <Foundation/Foundation.h>
#include <UIKit/UIKit.h>
#include <mach/mach.h>
#include <mach/vm_map.h>
#include <sys/types.h>

pid_t get_pid_by_name(const char *keyword);
task_t get_task_by_pid(pid_t pid);
const char *get_task_last_error(void);
mach_vm_address_t get_image_base_address(mach_port_t task, const char *image_name);
