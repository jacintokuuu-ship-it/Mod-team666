#import <UIKit/UIKit.h>
@interface PassthroughOverlayView:UIView
@property(nonatomic,weak)UIView *interactiveView;
@end
