#import "PassthroughOverlayView.h"
@implementation PassthroughOverlayView
- (UIView *)hitTest:(CGPoint)p withEvent:(UIEvent *)event{
 if(self.hidden||self.alpha<.01||!self.userInteractionEnabled||!self.interactiveView||self.interactiveView.hidden)return nil;
 CGPoint q=[self.interactiveView convertPoint:p fromView:self];
 if(![self.interactiveView pointInside:q withEvent:event])return nil;
 return [self.interactiveView hitTest:q withEvent:event] ?: self.interactiveView;
}
@end
