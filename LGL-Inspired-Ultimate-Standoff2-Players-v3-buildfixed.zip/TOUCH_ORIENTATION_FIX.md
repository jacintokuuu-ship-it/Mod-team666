# MAKTER BR — Correção de toque após rotação

## Sintoma
Após o HUD virar para landscape, o desenho do menu ficava correto, mas os pontos de toque não coincidiam com os controles. Botões/switches exigiam tocar fora da posição visual e o arraste do cabeçalho seguia um eixo/posição incorretos.

## Causa
O callback HID/Accessibility entrega coordenadas em espaço global da tela. O HUD, porém, aplica uma transformação de rotação à própria `UIWindow`. Em landscape, uma coordenada global não pode ser passada diretamente para:

- `UIWindow hitTest:`;
- conversão para `MenuView`;
- `UITouch initAtPoint:inWindow:onView:`;
- `UITouch setLocationInWindow:`.

Isso fazia a renderização e o hit-test usarem espaços diferentes.

## Correção aplicada

1. `MenuView` agora converte `screen/global -> UIWindow local -> MenuView local` antes de testar controles e calcular o delta de arraste.
2. O hotspot de reabertura usa a mesma conversão.
3. O fallback UIKit converte `screen/global -> UIWindow local` antes do `hitTest:`.
4. `TSEventFetcher` passou a receber explicitamente `atWindowCoordinate:` para não confundir coordenadas de tela com coordenadas locais.
5. A transformação visual da janela permanece única; os elementos filhos não recebem uma segunda rotação.

## Resultado esperado

- Portrait: hitboxes coincidem com os controles.
- Landscape: hitboxes continuam coincidindo após a rotação.
- Arrastar o cabeçalho acompanha o movimento real do dedo na tela.
- Girar novamente para portrait mantém o mesmo comportamento.
- O hotspot de abertura também acompanha a rotação.
