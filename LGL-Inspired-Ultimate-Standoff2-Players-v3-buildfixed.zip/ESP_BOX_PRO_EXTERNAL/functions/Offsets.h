#pragma once
#include <stdint.h>

// Values below come only from the dump/disassembly supplied in this project.
namespace FreeFireOffsets {
    static constexpr uintptr_t GetPlayerByTeamIdAndPlayerIndexStrictRVA = 0x48F8818;
    static constexpr uintptr_t GetLivePlayerByTeamIdAndPlayerIndexRVA   = 0x48F86B8;
    static constexpr uintptr_t GetFirtstLivePlayerByTeamIdRVA           = 0x48F84D4;
    static constexpr uintptr_t GetPlayerListFromTeamIdRVA               = 0x48F85F4;
    static constexpr uintptr_t GetPlayerCountRVA                        = 0x48F8C34;
    static constexpr uintptr_t GetNextLivePlayerRVA                     = 0x48F747C;
    static constexpr uintptr_t GetPrevLivePlayerRVA                     = 0x48F77AC;
    static constexpr uintptr_t GetTeamNextLivePlayerRVA                 = 0x48F7ADC;
    static constexpr uintptr_t GetTeamPrevLivePlayerRVA                 = 0x48F7CEC;
    static constexpr uintptr_t GetNextTeamLivePlayerRVA                 = 0x48F7EF8;
    static constexpr uintptr_t GetPrevTeamLivePlayerRVA                 = 0x48F8118;
    static constexpr uintptr_t GetRandomPlayerRVA                       = 0x48F8340;

    static constexpr uintptr_t GameFacade_UIModelSpectatorOffset        = 0x320;
    static constexpr uintptr_t GameFacadeGetterRVA                      = 0x5933D60;

    // Direct global-page reference observed in get_UIModelSpectator():
    // ADRP x20, #0xbb46000 ; ADD x20, x20, #0xa50 ; LDR x0, [x20]
    static constexpr uintptr_t GameFacadeGlobalRVA                      = 0xBB46A50;
    static constexpr uintptr_t GameFacadeToSpectatorOwnerOffset         = 0xB8;

    static constexpr uintptr_t UIModelSpectator_TeamPlayerDicOffset     = 0x28;
    static constexpr uintptr_t UIModelSpectator_PlayerDicOffset         = 0x30;
    static constexpr uintptr_t UIModelSpectator_RemainingPlayerCount    = 0xC4;

    static constexpr uintptr_t PlayerData_IdOffset                      = 0x10;
    static constexpr uintptr_t PlayerData_UserIdOffset                  = 0x28;
    static constexpr uintptr_t PlayerData_GsTeamIdOffset                = 0x34;
    static constexpr uintptr_t PlayerData_ScTeamIdOffset                = 0x35;
    static constexpr uintptr_t PlayerData_IsDeadOffset                  = 0x6C;
    static constexpr uintptr_t PlayerData_LastPositionOffset            = 0xDC;
    static constexpr uintptr_t PlayerData_PlayerOffset                  = 0x100;

    static constexpr uintptr_t PlayerGetTransformNodeRVA                = 0x5735538;
    static constexpr uintptr_t ITransformNodeGetTransformRVA             = 0x890EFE4;
    static constexpr uintptr_t TransformNodeGetTransformRVA              = 0x6B4964C;
    static constexpr uintptr_t BFOONIGAIFKGetTransformRVA                = 0x581FB80;
    static constexpr uintptr_t EntityGetTransformNodeRVA                 = 0x6B4B418;
    static constexpr uintptr_t LEntityGetTransformNodeRVA                = 0x6AF1F24;

    static constexpr uintptr_t CameraGetMainRVA                           = 0x8CFF0B4;
    static constexpr uintptr_t CameraWorldToScreenPointRVA                = 0x8CFE9C0;

    // IMPORTANT: no Transform.position getter RVA is declared here because
    // the supplied dump did not confirm a dedicated getter RVA.
}
