#pragma once
#include <stdint.h>

#define ESP_EXTERNAL_MAGIC 0x45585042u /* EXPB */
#define ESP_EXTERNAL_VERSION 3u
#define ESP_EXTERNAL_MAX_TARGETS 64u

typedef struct ESPBoxTarget {
    uint64_t player;
    uint64_t playerData;
    float worldX;
    float worldY;
    float worldZ;
    float screenX;
    float screenY;
    float screenDepth;
    float headScreenX;
    float headScreenY;
    float headDepth;
    uint32_t worldValid;
    uint32_t screenValid;
    uint32_t dead;
    uint8_t gsTeamId;
    uint8_t scTeamId;
    uint16_t reserved;
} ESPBoxTarget;

typedef struct ESPExternalSnapshot {
    uint32_t magic;
    uint32_t version;
    uint32_t processFound;
    uint32_t taskOpened;
    uint32_t unityFound;
    uint32_t machoReadable;
    uint32_t spectatorFound;
    uint32_t playerDictionaryFound;
    uint32_t playerDictionaryHeuristic;
    uint32_t playerDataCount;
    uint32_t worldPositionCount;
    uint32_t screenPositionCount;
    int32_t processPID;
    uint64_t task;
    uint64_t unityBase;
    uint64_t gameFacadeObject;
    uint64_t uiModelSpectator;
    uint64_t playerDictionary;
    uint64_t lastCheckNanos;
    uint32_t count;
    ESPBoxTarget targets[ESP_EXTERNAL_MAX_TARGETS];
    char message[768];
} ESPExternalSnapshot;

#ifdef __cplusplus
extern "C" {
#endif
int ESPExternalReadSnapshot(ESPExternalSnapshot *out);
const char *ESPExternalStatusText(void);
#ifdef __cplusplus
}
#endif
