#import "ESPExternalShared.h"
#import "Offsets.h"
#import "../tasks/pid.h"

#include <mach/mach.h>
#include <mach-o/loader.h>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <algorithm>
#include <vector>

namespace {
static task_t gTask = MACH_PORT_NULL;
static uint64_t gUnityBase = 0;

static uint64_t NowNanos()
{
    timespec ts{};
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000000000ull + (uint64_t)ts.tv_nsec;
}

static void CloseTask()
{
    if (gTask != MACH_PORT_NULL) {
        mach_port_deallocate(mach_task_self(), gTask);
        gTask = MACH_PORT_NULL;
    }
    gUnityBase = 0;
}

template <typename T>
static bool ReadRemote(uint64_t address, T *out)
{
    if (!address || !out) return false;
    vm_size_t copied = 0;
    kern_return_t kr = vm_read_overwrite(gTask,
                                         (vm_address_t)address,
                                         (vm_size_t)sizeof(T),
                                         (vm_address_t)out,
                                         &copied);
    return kr == KERN_SUCCESS && copied == sizeof(T);
}

static bool ReadBytes(uint64_t address, void *out, size_t size)
{
    if (!address || !out || !size) return false;
    vm_size_t copied = 0;
    kern_return_t kr = vm_read_overwrite(gTask,
                                         (vm_address_t)address,
                                         (vm_size_t)size,
                                         (vm_address_t)out,
                                         &copied);
    return kr == KERN_SUCCESS && copied == size;
}

static bool LooksLikePointer(uint64_t p)
{
    return p > 0x10000ull && (p % 8ull) == 0;
}

static bool ResolveUISpectator(uint64_t *facadeOut, uint64_t *spectatorOut)
{
    const uint64_t globalAddress = gUnityBase + FreeFireOffsets::GameFacadeGlobalRVA;
    uint64_t facade = 0;
    if (!ReadRemote(globalAddress, &facade) || !LooksLikePointer(facade)) return false;

    uint64_t owner = 0;
    if (!ReadRemote(facade + FreeFireOffsets::GameFacadeToSpectatorOwnerOffset, &owner) || !LooksLikePointer(owner)) {
        return false;
    }

    uint64_t spectator = 0;
    if (!ReadRemote(owner + FreeFireOffsets::GameFacade_UIModelSpectatorOffset, &spectator) || !LooksLikePointer(spectator)) {
        return false;
    }

    if (facadeOut) *facadeOut = facade;
    if (spectatorOut) *spectatorOut = spectator;
    return true;
}

// Standard IL2CPP/managed Dictionary layout is used only as a bounded heuristic:
// object field +0x18 = entries array; +0x20 = count. Entry is treated as
// {int hashCode; int next; uint64 key; pointer value} (24 bytes).
// This layout was NOT explicitly supplied in the dump, so every result is
// validated by guarded remote reads before it is accepted.
static uint32_t EnumeratePlayerDataDictionary(uint64_t dictionary,
                                                ESPBoxTarget *targets,
                                                uint32_t maxTargets,
                                                uint32_t *worldCount)
{
    if (!dictionary || !targets || !maxTargets) return 0;

    uint64_t entriesArray = 0;
    int32_t count = 0;
    if (!ReadRemote(dictionary + 0x18, &entriesArray) || !LooksLikePointer(entriesArray)) return 0;
    if (!ReadRemote(dictionary + 0x20, &count)) return 0;
    if (count <= 0 || count > 512) return 0;

    struct Entry24 { int32_t hashCode; int32_t next; uint64_t key; uint64_t value; };
    uint32_t produced = 0;
    uint32_t worlds = 0;

    for (int32_t i = 0; i < count && produced < maxTargets; ++i) {
        Entry24 entry{};
        uint64_t entryAddress = entriesArray + 0x20ull + (uint64_t)i * sizeof(Entry24);
        if (!ReadRemote(entryAddress, &entry)) continue;
        if (entry.hashCode < 0 || !LooksLikePointer(entry.value)) continue;

        ESPBoxTarget t{};
        t.playerData = entry.value;
        ReadRemote(entry.value + FreeFireOffsets::PlayerData_UserIdOffset, &t.player);
        ReadRemote(entry.value + FreeFireOffsets::PlayerData_GsTeamIdOffset, &t.gsTeamId);
        ReadRemote(entry.value + FreeFireOffsets::PlayerData_ScTeamIdOffset, &t.scTeamId);
        ReadRemote(entry.value + FreeFireOffsets::PlayerData_IsDeadOffset, &t.dead);

        float p[3] = {0,0,0};
        if (!ReadBytes(entry.value + FreeFireOffsets::PlayerData_LastPositionOffset, p, sizeof(p))) continue;
        t.worldX = p[0]; t.worldY = p[1]; t.worldZ = p[2];
        const bool finite = std::isfinite(t.worldX) && std::isfinite(t.worldY) && std::isfinite(t.worldZ);
        const float magnitude = std::sqrt(t.worldX*t.worldX + t.worldY*t.worldY + t.worldZ*t.worldZ);
        if (!finite || magnitude > 1000000.0f) continue;

        t.worldValid = 1;
        ++worlds;
        targets[produced++] = t;
    }

    if (worldCount) *worldCount = worlds;
    return produced;
}

static void ClearTargets(ESPExternalSnapshot *s)
{
    for (uint32_t i = 0; i < ESP_EXTERNAL_MAX_TARGETS; ++i) {
        s->targets[i] = ESPBoxTarget{};
    }
}
}

extern "C" int ESPExternalReadSnapshot(ESPExternalSnapshot *out)
{
    ESPExternalSnapshot s{};
    s.magic = ESP_EXTERNAL_MAGIC;
    s.version = ESP_EXTERNAL_VERSION;
    s.lastCheckNanos = NowNanos();
    ClearTargets(&s);
    CloseTask();

    pid_t pid = get_pid_by_name("FreeFire");
    if (pid <= 0) {
        snprintf(s.message, sizeof(s.message), "FreeFire nao encontrado");
        if (out) *out = s;
        return 0;
    }
    s.processFound = 1;
    s.processPID = pid;

    gTask = get_task_by_pid(pid);
    if (gTask == MACH_PORT_NULL) {
        snprintf(s.message, sizeof(s.message), "FreeFire encontrado, task falhou: %s", get_task_last_error());
        if (out) *out = s;
        return 0;
    }
    s.taskOpened = 1;
    s.task = (uint64_t)gTask;

    gUnityBase = get_image_base_address(gTask, "UnityFramework");
    if (!gUnityBase) {
        snprintf(s.message, sizeof(s.message), "UnityFramework nao localizado");
        if (out) *out = s;
        return 0;
    }
    s.unityFound = 1;
    s.unityBase = gUnityBase;

    uint32_t magic = 0;
    if (!ReadRemote(gUnityBase, &magic) || magic != MH_MAGIC_64) {
        snprintf(s.message, sizeof(s.message), "UnityFramework invalido ou ilegivel");
        if (out) *out = s;
        return 0;
    }
    s.machoReadable = 1;

    if (!ResolveUISpectator(&s.gameFacadeObject, &s.uiModelSpectator)) {
        snprintf(s.message, sizeof(s.message),
                 "Task/Unity OK, mas UIModelSpectator nao foi resolvido pelo caminho confirmado");
        if (out) *out = s;
        return 0;
    }
    s.spectatorFound = 1;

    if (!ReadRemote(s.uiModelSpectator + FreeFireOffsets::UIModelSpectator_PlayerDicOffset,
                    &s.playerDictionary) || !LooksLikePointer(s.playerDictionary)) {
        snprintf(s.message, sizeof(s.message),
                 "UIModelSpectator OK, m_PlayerDic +0x30 nao foi resolvido");
        if (out) *out = s;
        return 0;
    }
    s.playerDictionaryFound = 1;
    s.playerDictionaryHeuristic = 1;

    uint32_t worldCount = 0;
    s.count = EnumeratePlayerDataDictionary(s.playerDictionary,
                                             s.targets,
                                             ESP_EXTERNAL_MAX_TARGETS,
                                             &worldCount);
    s.playerDataCount = s.count;
    s.worldPositionCount = worldCount;

    // Screen coordinates intentionally remain invalid until a camera/matrix
    // source is confirmed. The dump confirms Camera.get_main and
    // WorldToScreenPoint RVAs, but does not establish an external callable path
    // or a direct camera-matrix memory layout.
    s.screenPositionCount = 0;

    snprintf(s.message, sizeof(s.message),
             "BOX PRO: task OK | Unity 0x%llX | spectator 0x%llX | PlayerData %u | WorldPos %u | ScreenPos %u | camera bridge pendente",
             (unsigned long long)s.unityBase,
             (unsigned long long)s.uiModelSpectator,
             s.playerDataCount,
             s.worldPositionCount,
             s.screenPositionCount);

    if (out) *out = s;
    return 1;
}

extern "C" const char *ESPExternalStatusText(void)
{
    static char text[1024];
    ESPExternalSnapshot s{};
    ESPExternalReadSnapshot(&s);
    snprintf(text, sizeof(text), "%s", s.message[0] ? s.message : "sem diagnostico");
    return text;
}
