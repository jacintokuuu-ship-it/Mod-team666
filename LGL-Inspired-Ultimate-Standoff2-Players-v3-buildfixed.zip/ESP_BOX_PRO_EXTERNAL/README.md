# ESP BOX PRO — External / Free Fire

Este pacote foi reduzido para um único recurso: **ESP BOX PRO**.

## Removido do build
- menu/ImGui
- chams
- tracers/lines
- health bar
- nickname/weapon
- modos de teste antigos
- patcher e lógica de funções não relacionadas
- arquivos legados de toque

## Cadeia usada
Os endereços de enumeração, `UIModelSpectator`, `PlayerData`, `GetTransformNode` e câmera foram transcritos somente das informações/dump fornecidos.

O leitor externo usa:
1. `task_for_pid` para obter a task.
2. `UnityFramework` para obter a base.
3. O caminho observado no getter `get_UIModelSpectator()` para tentar resolver `UIModelSpectator` sem chamar o método remotamente.
4. `UIModelSpectator + 0x30` para obter `m_PlayerDic`.
5. Um parser **heurístico** de `Dictionary` apenas para extrair `PlayerData`.
6. `PlayerData + 0xDC` (`lastPosition`) para obter uma posição 3D.
7. O renderer só desenha quando há coordenadas de tela válidas.

## O que ainda não é declarado como confirmado
A dump fornecida confirmou os RVAs de `Camera.get_main` e `Camera.WorldToScreenPoint`, mas não confirmou um caminho externo para executar esses métodos nem um layout de memória direto para a matriz de câmera. Por isso este projeto **não inventa** um getter de `Transform.position` ou uma matriz de câmera.

Assim, a etapa atual pode resolver `PlayerData`/world position, mas `screenValid` permanece 0 até o bridge de câmera ser confirmado.

## Build
Requer Theos + SDK iPhoneOS 15.6 em ambiente macOS.

```sh
make package SDKVERSION=15.6 FINALPACKAGE=1 DEBUG=0
```

Saída esperada:
`packages/ESP-Box-Pro.tipa`

Este pacote foi analisado/reescrito no container, mas **não foi compilado aqui**, pois não há ambiente macOS/Theos/iOS SDK disponível neste runtime.
