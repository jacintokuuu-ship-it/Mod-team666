#import <Foundation/Foundation.h>
#import <mach/mach.h>
#import <mach-o/dyld_images.h>
#import <mach-o/loader.h>
#import <sys/proc_info.h>
#import <libproc.h>
#include <vector>
#include <algorithm>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#import "pid.h"

struct dyld_image_info64_compat {
    mach_vm_address_t imageLoadAddress;
    mach_vm_address_t imageFilePath;
    mach_vm_size_t imageFileModDate;
};

struct dyld_all_image_infos64_compat {
    uint32_t version;
    uint32_t infoArrayCount;
    mach_vm_address_t infoArray;
    mach_vm_address_t notification;
    bool processDetachedFromSharedRegion;
    bool libSystemInitialized;
    mach_vm_address_t dyldImageLoadAddress;
    mach_vm_address_t jitInfo;
    mach_vm_address_t dyldVersion;
    mach_vm_address_t errorMessage;
    uint64_t terminationFlags;
    mach_vm_address_t coreSymbolicationShmPage;
    uint64_t systemOrderFlag;
    uint64_t uuidArrayCount;
    mach_vm_address_t uuidArray;
    mach_vm_address_t dyldAllImageInfosAddress;
    uint64_t initialImageCount;
    uint64_t errorKind;
    mach_vm_address_t errorClientOfDylibPath;
    mach_vm_address_t errorTargetDylibPath;
    mach_vm_address_t errorSymbol;
    uint64_t sharedCacheSlide;
};

static char s_last_error[256] = "ok";
const char *get_task_last_error(void) { return s_last_error; }

pid_t get_pid_by_name(const char *keyword)
{
    if (!keyword || !*keyword) return -1;
    int count = proc_listallpids(NULL, 0);
    if (count <= 0) return -1;
    std::vector<pid_t> pids((size_t)count);
    int listed = proc_listallpids(pids.data(), (int)(pids.size() * sizeof(pid_t)));
    if (listed <= 0) return -1;
    if (listed > (int)pids.size()) {
        pids.resize((size_t)listed);
        listed = proc_listallpids(pids.data(), (int)(pids.size() * sizeof(pid_t)));
        if (listed <= 0) return -1;
    }
    size_t n = std::min((size_t)listed, pids.size());
    for (size_t i = 0; i < n; ++i) {
        char name[PROC_PIDPATHINFO_MAXSIZE] = {0};
        if (proc_name(pids[i], name, sizeof(name)) <= 0) continue;
        if (strstr(name, keyword)) return pids[i];
    }
    return -1;
}

task_t get_task_by_pid(pid_t pid)
{
    task_t task = MACH_PORT_NULL;
    kern_return_t kr = task_for_pid(mach_task_self(), pid, &task);
    if (kr == KERN_SUCCESS && task != MACH_PORT_NULL) {
        snprintf(s_last_error, sizeof(s_last_error), "ok(task_for_pid)");
        return task;
    }
    snprintf(s_last_error, sizeof(s_last_error), "task_for_pid=0x%x", kr);
    return MACH_PORT_NULL;
}

uint64_t get_image_base_address(task_t task, const char *image_name)
{
    if (task == MACH_PORT_NULL || !image_name) return 0;

    task_dyld_info_data_t dyld_info{};
    mach_msg_type_number_t count = TASK_DYLD_INFO_COUNT;
    kern_return_t kr = task_info(task, TASK_DYLD_INFO, (task_info_t)&dyld_info, &count);
    if (kr != KERN_SUCCESS) return 0;

    dyld_all_image_infos64_compat infos{};
    vm_offset_t read_mem = 0;
    mach_msg_type_number_t read_size = 0;
    kr = vm_read(task, (vm_address_t)dyld_info.all_image_info_addr,
                 (vm_size_t)sizeof(infos), &read_mem, &read_size);
    if (kr != KERN_SUCCESS || read_size < sizeof(infos)) return 0;
    memcpy(&infos, (void *)read_mem, sizeof(infos));
    vm_deallocate(mach_task_self(), read_mem, read_size);

    if (!infos.infoArray || infos.infoArrayCount == 0 || infos.infoArrayCount > 65536) return 0;
    size_t bytes = (size_t)infos.infoArrayCount * sizeof(dyld_image_info64_compat);
    auto *images = (dyld_image_info64_compat *)malloc(bytes);
    if (!images) return 0;
    read_mem = 0; read_size = 0;
    kr = vm_read(task, (vm_address_t)infos.infoArray, (vm_size_t)bytes, &read_mem, &read_size);
    if (kr != KERN_SUCCESS || read_size < bytes) {
        free(images); return 0;
    }
    memcpy(images, (void *)read_mem, bytes);
    vm_deallocate(mach_task_self(), read_mem, read_size);

    uint64_t result = 0;
    for (uint32_t i = 0; i < infos.infoArrayCount; ++i) {
        char path[PATH_MAX] = {0};
        read_mem = 0; read_size = 0;
        kr = vm_read(task, (vm_address_t)images[i].imageFilePath, PATH_MAX, &read_mem, &read_size);
        if (kr == KERN_SUCCESS && read_size) {
            size_t copy = std::min((size_t)read_size, (size_t)PATH_MAX - 1);
            memcpy(path, (void *)read_mem, copy);
            path[copy] = '\0';
            vm_deallocate(mach_task_self(), read_mem, read_size);
            if (strstr(path, image_name)) {
                result = (uint64_t)images[i].imageLoadAddress;
                break;
            }
        }
    }
    free(images);
    return result;
}
