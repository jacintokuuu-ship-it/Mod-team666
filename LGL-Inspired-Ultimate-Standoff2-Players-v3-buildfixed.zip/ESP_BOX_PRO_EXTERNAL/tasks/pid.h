#pragma once
#include <mach/mach.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif
pid_t get_pid_by_name(const char *keyword);
task_t get_task_by_pid(pid_t pid);
const char *get_task_last_error(void);
uint64_t get_image_base_address(task_t task, const char *image_name);
#ifdef __cplusplus
}
#endif
