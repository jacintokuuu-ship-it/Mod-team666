#import <UIKit/UIKit.h>
#import <QuartzCore/QuartzCore.h>
#import <objc/runtime.h>
#import <CoreFoundation/CoreFoundation.h>
#include <cstring>
#import "../overlay/ESPBoxView.h"
#import "../functions/ESPExternalShared.h"

#ifdef __cplusplus
extern "C" {
#endif
void UIApplicationInstantiateSingleton(id aclass);
void UIApplicationInitialize(void);
void BKSDisplayServicesStart(void);
void GSInitialize(void);
#ifdef __cplusplus
}
#endif

@interface UIApplication (ESPPrivate)
- (void)_accessibilityInit;
- (void)__completeAndRunAsPlugin;
@end

@interface ESPBoxWindow : UIWindow
@end
@implementation ESPBoxWindow
- (BOOL)_isSystemWindow { return YES; }
- (BOOL)_isWindowServerHostingManaged { return NO; }
- (BOOL)_ignoresMouseEvents { return NO; }
- (BOOL)_wantsSceneAssociation { return NO; }
- (BOOL)_alwaysGetsContexts { return YES; }
- (BOOL)keepContextInBackground { return YES; }
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event { return nil; }
@end

@interface ESPBoxController : UIViewController
@end

@implementation ESPBoxController {
    ESPBoxView *_boxView;
    NSTimer *_timer;
    UIInterfaceOrientation _orientation;
}

- (BOOL)prefersStatusBarHidden { return YES; }
- (BOOL)shouldAutorotate { return YES; }
- (UIInterfaceOrientationMask)supportedInterfaceOrientations {
    return UIInterfaceOrientationMaskPortrait | UIInterfaceOrientationMaskLandscapeLeft | UIInterfaceOrientationMaskLandscapeRight;
}

- (void)loadView {
    _boxView = [[ESPBoxView alloc] initWithFrame:UIScreen.mainScreen.bounds];
    _boxView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    self.view = _boxView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    _orientation = UIInterfaceOrientationPortrait;
    __weak typeof(self) weakSelf = self;
    _timer = [NSTimer scheduledTimerWithTimeInterval:(1.0 / 30.0)
                                               repeats:YES
                                                 block:^(__unused NSTimer *timer) {
        __strong typeof(weakSelf) self = weakSelf;
        if (!self) return;
        ESPExternalSnapshot snapshot{};
        if (ESPExternalReadSnapshot(&snapshot)) {
            [self->_boxView applySnapshot:&snapshot];
        } else {
            [self->_boxView applySnapshot:NULL];
        }
    }];
}

- (void)dealloc {
    [_timer invalidate];
}
@end

@interface ESPBoxAppDelegate : UIResponder <UIApplicationDelegate>
@property(nonatomic, strong) ESPBoxWindow *window;
@end

@implementation ESPBoxAppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    (void)application; (void)launchOptions;
    ESPBoxController *vc = [[ESPBoxController alloc] init];
    self.window = [[ESPBoxWindow alloc] initWithFrame:UIScreen.mainScreen.bounds];
    self.window.backgroundColor = UIColor.clearColor;
    self.window.windowLevel = 10000010.0;
    self.window.rootViewController = vc;
    [self.window setHidden:NO];
    [self.window orderFront:nil];
    return YES;
}
@end

@interface ESPBoxApplication : UIApplication
@end
@implementation ESPBoxApplication
@end

static void ESPRunHUD(void)
{
    GSInitialize();
    BKSDisplayServicesStart();
    UIApplicationInitialize();
    UIApplicationInstantiateSingleton(objc_getClass("ESPBoxApplication"));
    ESPBoxAppDelegate *delegate = [[ESPBoxAppDelegate alloc] init];
    UIApplication.sharedApplication.delegate = delegate;
    [UIApplication.sharedApplication _accessibilityInit];
    [UIApplication.sharedApplication __completeAndRunAsPlugin];
    CFRunLoopRun();
}

int main(int argc, char *argv[])
{
    @autoreleasepool {
        if (argc > 1 && strcmp(argv[1], "-hud") == 0) {
            ESPRunHUD();
            return 0;
        }
        return UIApplicationMain(argc, argv, @"ESPBoxApplication", @"ESPBoxAppDelegate");
    }
}
