#import "ESPBoxView.h"
#import "../functions/ESPExternalShared.h"
#import <QuartzCore/QuartzCore.h>

@interface ESPBoxView ()
@property(nonatomic, strong) NSMutableArray<CAShapeLayer *> *boxLayers;
@end

@implementation ESPBoxView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColor.clearColor;
        self.userInteractionEnabled = NO;
        self.boxLayers = [NSMutableArray arrayWithCapacity:ESP_EXTERNAL_MAX_TARGETS];
        for (NSUInteger i = 0; i < ESP_EXTERNAL_MAX_TARGETS; ++i) {
            CAShapeLayer *layer = [CAShapeLayer layer];
            layer.fillColor = UIColor.clearColor.CGColor;
            layer.strokeColor = UIColor.whiteColor.CGColor;
            layer.lineWidth = 1.8;
            layer.hidden = YES;
            [self.layer addSublayer:layer];
            [self.boxLayers addObject:layer];
        }
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    for (CAShapeLayer *layer in self.boxLayers) layer.frame = self.bounds;
}

- (void)applySnapshot:(const ESPExternalSnapshot *)snapshot
{
    NSUInteger visible = 0;
    if (snapshot) {
        visible = MIN((NSUInteger)snapshot->count, self.boxLayers.count);
    }

    for (NSUInteger i = 0; i < self.boxLayers.count; ++i) {
        CAShapeLayer *layer = self.boxLayers[i];
        if (i >= visible) {
            layer.hidden = YES;
            layer.path = nil;
            continue;
        }

        const ESPBoxTarget *t = &snapshot->targets[i];
        if (!t->screenValid || t->screenDepth <= 0.01f || t->headDepth <= 0.01f) {
            layer.hidden = YES;
            layer.path = nil;
            continue;
        }

        CGFloat footX = t->screenX;
        CGFloat footY = t->screenY;
        CGFloat headX = t->headScreenX;
        CGFloat headY = t->headScreenY;
        CGFloat height = fabs(footY - headY);
        if (height < 8.0) height = 8.0;
        CGFloat width = height * 0.42;
        CGFloat centerX = (footX + headX) * 0.5;
        CGFloat topY = MIN(headY, footY);
        CGRect r = CGRectMake(centerX - width * 0.5, topY, width, height);
        r = CGRectIntersection(r, self.bounds);

        if (CGRectIsNull(r) || CGRectGetWidth(r) < 2.0 || CGRectGetHeight(r) < 2.0) {
            layer.hidden = YES;
            layer.path = nil;
            continue;
        }

        UIBezierPath *p = [UIBezierPath bezierPathWithRect:r];
        layer.path = p.CGPath;
        layer.hidden = t->dead ? YES : NO;
    }
}

@end
