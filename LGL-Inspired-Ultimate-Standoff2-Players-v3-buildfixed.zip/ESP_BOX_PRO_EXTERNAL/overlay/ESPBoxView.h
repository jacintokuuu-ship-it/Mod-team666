#import <UIKit/UIKit.h>

@interface ESPBoxView : UIView
- (void)applySnapshot:(const struct ESPExternalSnapshot *)snapshot;
@end
