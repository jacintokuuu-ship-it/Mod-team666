# AERO — Player Count Audit

## Dump-confirmed facts

### GameFacade
- `m_UIModelSpectator` is a static `UIModelSpectator` field at `0x320`.
- `get_UIModelSpectator()` is present at RVA `0x5933D60`.
- `CurrentMatch()` is present at RVA `0x591B898`.

### UIModelSpectator
- `m_PlayerDic` is `Dictionary<BEADLMGGGGL, PlayerData>` at `+0x30`.
- `get_PlayerDic()` is present at RVA `0x48F26F0`.
- `GetPlayerCount()` is present at RVA `0x48F8C34`.
- `OnAddPlayer` / `OnDelPlayer` methods also exist in this class, consistent with
  the dictionary being a player-facing model that is updated as players enter
  and leave.

### JMAGGLCNGIG fallback
- `MHJCLOPOBAA` is a `Player` field at `+0xD8`.
- player-related `Dictionary<...,Player>` fields exist at `+0x128`, `+0x130`,
  `+0x140`, `+0x148`, and `+0x150`.
- `List<Player>` fields exist at `+0x158`, `+0x160`, and `+0x570`.
- an `int` method `DELLEJMPCOI()` exists at RVA `0x596CD78`.
- several additional `int` methods exist nearby.

## What is actually wired

The external project now:
1. finds FreeFire;
2. gets its task;
3. locates UnityFramework;
4. resolves `GameFacade.get_UIModelSpectator()` by a conservative AArch64
   getter interpreter;
5. reads `UIModelSpectator + 0x30`;
6. reads `Dictionary.Count` at `+0x20`;
7. publishes the result as the primary `JOGADORES` value;
8. exposes JMAG list/dictionary counts as fallback diagnostics.

## Why this is preferable

The old code explicitly set `snapshot.count = 0` and therefore could never show
a live player number. The new route is based on a dump-confirmed semantic method
and the exact backing field exposed in the same class.

## Limitation

The supplied dump is metadata only. It does not contain the native method
bodies, so it cannot by itself prove the runtime implementation of every
accessor. The project therefore validates the remote getter machine code at
runtime and refuses to label an unverified collection as the primary count.

Full iOS/Theos compilation and runtime behaviour must still be confirmed by the
GitHub Actions runner and the target device.
