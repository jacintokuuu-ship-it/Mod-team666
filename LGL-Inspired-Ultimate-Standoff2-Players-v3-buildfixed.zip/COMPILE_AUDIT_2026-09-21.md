# Compile audit — 2026-09-21

## Fixed blocker
Clang with `-Werror` rejected the MOV Xd,Xm AArch64 pattern in
`functions/ESPExternalReader.mm` as `-Wtautological-bitwise-compare`.

Old:
`(insn & 0xFFE0FC1Fu) == 0xAA0003E0u`

The mask cleared bits 5..9, while the compared constant requires those bits
to be `0x1F`, so the comparison could never be true.

New:
`(insn & 0xFFE0FFE0u) == 0xAA0003E0u`

This mask ignores the variable source-register field (bits 16..20) and
destination-register field (bits 0..4), while preserving the fixed opcode
and the fixed XZR field (bits 5..9).

## Static sweep
A sweep of the C/C++/Objective-C source found no other simple
`(value & mask) == constant` comparisons where the constant sets bits
outside the mask.

The project still requires the user's macOS/Theos CI environment for a
real iOS build; this audit does not claim runtime testing.
