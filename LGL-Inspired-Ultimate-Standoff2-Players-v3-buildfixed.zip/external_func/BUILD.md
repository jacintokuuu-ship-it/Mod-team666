# Free Fire — External HUD

## Produto

Este projeto compila somente um aplicativo iOS standalone (`Excalibur`) que roda fora do Free Fire.
Não existe target de tweak, dylib injetada, MobileSubstrate, Substitute ou ElleKit no build padrão.

## Arquitetura externa

`Excalibur` → `get_pid_by_name("FreeFire")` → `task_for_pid()`/fallback Mach → `UnityFramework` via `TASK_DYLD_INFO` → `mach_vm_read_overwrite()`.

## Verificar

A função **VERIFICAR — ACESSO AO FREE FIRE** executa um teste real de: processo, `task_t`, base de `UnityFramework`, leitura do cabeçalho Mach-O e leitura dos bytes das RVAs fornecidas. O resultado aparece no toast e no cartão de status.

## ESP Line

A camada de desenho é externa e já está separada do leitor de memória. A enumeração ao vivo de jogadores ainda não é fabricada: o snapshot permanece com `0` targets até a cadeia `PlayerManager/lista/LocalPlayer` do mesmo dump ser ligada ao leitor externo.

## Build

```sh
make package
```

O ambiente desta análise não possui SDK iPhoneOS/Theos para executar uma compilação real, portanto o pacote foi revisado estruturalmente e não deve ser apresentado como binário já compilado/validado em dispositivo.


## Build 3-function
The active menu exposes only: process verification, external player-count display, and external memory-read monitor. Legacy ESP menu controls are not exposed. Player count is only as real as the external target enumeration wired into the dump; this build does not fabricate a count.
