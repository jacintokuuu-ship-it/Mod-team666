#pragma once

#include <stdint.h>

#define ESP_EXTERNAL_MAGIC   0x45585431u /* EXT1 */
#define ESP_EXTERNAL_VERSION 3u
#define ESP_EXTERNAL_MAX_TARGETS 64u

typedef struct ESPExternalTarget {
    uint64_t player;
    float x;
    float y;
    float z;
    float depth;
    uint32_t valid;
} ESPExternalTarget;

typedef struct ESPExternalSnapshot {
    uint32_t magic;
    uint32_t version;
    uint32_t processFound;
    uint32_t taskOpened;
    uint32_t unityFound;
    uint32_t machoReadable;
    uint32_t rvaReadableCount;
    uint32_t rvaTestCount;
    int32_t processPID;
    uint64_t task;
    uint64_t unityBase;
    uint64_t lastCheckNanos;
    uint32_t lastError;
    uint32_t count;
    ESPExternalTarget targets[ESP_EXTERNAL_MAX_TARGETS];
    char message[512];
} ESPExternalSnapshot;

#ifdef __cplusplus
extern "C" {
#endif

int ESPExternalSetMode(int mode);
int ESPExternalGetMode(void);
int ESPExternalVerify(ESPExternalSnapshot *out);
int ESPExternalReadSnapshot(ESPExternalSnapshot *out);
const char *ESPExternalPlayerCountText(void);
const char *ESPExternalReadMonitorText(void);
const char *ESPExternalStatusText(void);
const char *ESPExternalDiagnosticText(void);

#ifdef __cplusplus
}
#endif
