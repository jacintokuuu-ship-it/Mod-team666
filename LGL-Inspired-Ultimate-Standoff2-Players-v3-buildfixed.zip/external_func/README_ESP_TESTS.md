# ESP 1/2/3 — teste por alavanca

O projeto não possui mais a função PE de meia.

Cada teste tem sua própria alavanca no menu nativo. Apenas uma rota pode ficar ativa por vez.

## ESP 1
Player::GetTransformNode `0x5735538` → campo `TransformNode.transform +0x10` → `Transform::get_position 0x8D6C1EC` → `Camera::get_main 0x8CFF0B4` → `Camera::WorldToScreenPoint 0x8CFE9C0`.

Este substitui o teste anterior que dependia de `ITransformNode::get_transform`.

## ESP 2
Player::GetTransformNode `0x5735538` → `TransformNode::get_transform 0x6B4964C` → posição/projeção confirmadas acima.

## ESP 3
Player::GetTransformNode `0x5735538` → `BFOONIGAIFK::get_transform 0x581FB80` → posição/projeção confirmadas acima.

Nenhum PlayerManager antigo, matriz antiga ou offset de player antigo é utilizado.


## Build 3-function
The active menu exposes only: process verification, external player-count display, and external memory-read monitor. Legacy ESP menu controls are not exposed. Player count is only as real as the external target enumeration wired into the dump; this build does not fabricate a count.
