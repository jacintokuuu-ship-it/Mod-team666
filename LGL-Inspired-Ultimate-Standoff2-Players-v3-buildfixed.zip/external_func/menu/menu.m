#import "menu.h"
#import "../include/HUDBridge.h"
#import "../functions/ESPExternalShared.h"
#import <QuartzCore/QuartzCore.h>

static UIColor *MakterAccentColor(void)
{
    if (@available(iOS 13.0, *)) return [UIColor systemOrangeColor];
    return [UIColor colorWithRed:1.0 green:0.42 blue:0.08 alpha:1.0];
}

const char *ESPExternalPlayerCountText(void);
const char *ESPExternalReadMonitorText(void);
void HUDVerifyExternal(void);

@interface MenuView () <UIGestureRecognizerDelegate>
@property (nonatomic, strong) UIVisualEffectView *materialView;
@property (nonatomic, strong) UIView *headerView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *subtitleLabel;
@property (nonatomic, strong) UIView *statusDot;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *closeButton;
@property (nonatomic, strong) UIScrollView *scrollView;
@property (nonatomic, strong) UISwitch *playerCountSwitch;
@property (nonatomic, strong) UISwitch *readMonitorSwitch;
@property (nonatomic, strong) UIButton *verifyButton;
@property (nonatomic, strong) UILabel *playerCountStatusLabel;
@property (nonatomic, strong) UILabel *readMonitorStatusLabel;
@property (nonatomic, strong) UILabel *verifyStatusLabel;
@property (nonatomic, strong) UILabel *hintLabel;
@property (nonatomic, strong) UIPanGestureRecognizer *headerPanGesture;
@property (nonatomic, assign) CGPoint panStartCenter;
@property (nonatomic, assign) BOOL hasUserPosition;
@property (nonatomic, assign) UIInterfaceOrientation currentOrientation;
@property (nonatomic, strong) NSTimer *refreshTimer;
@property (nonatomic, assign) NSInteger directTouchPointerId;
@property (nonatomic, assign) CGPoint directTouchStartPoint;
@property (nonatomic, assign) CGPoint directTouchStartCenter;
@property (nonatomic, assign) CGPoint directTouchStartContentOffset;
@property (nonatomic, assign) BOOL directTouchDragging;
@property (nonatomic, assign) NSInteger directTouchMode;
@end

enum {
    kDirectTouchNone = 0,
    kDirectTouchHeaderDrag = 1,
    kDirectTouchClose = 2,
    kDirectTouchContent = 3
};

@implementation MenuView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (!self) return nil;

    _currentOrientation = UIInterfaceOrientationPortrait;
    _directTouchPointerId = -1;
    _directTouchMode = kDirectTouchNone;
    _directTouchDragging = NO;

    self.backgroundColor = UIColor.clearColor;
    self.opaque = NO;
    self.clipsToBounds = NO;
    self.userInteractionEnabled = YES;
    self.multipleTouchEnabled = YES;
    self.exclusiveTouch = NO;

    if (@available(iOS 13.0, *)) {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:
                         [UIBlurEffect effectWithStyle:UIBlurEffectStyleSystemMaterialDark]];
    } else {
        _materialView = [[UIVisualEffectView alloc] initWithEffect:nil];
        _materialView.backgroundColor = [UIColor colorWithWhite:0.06 alpha:0.98];
    }
    _materialView.translatesAutoresizingMaskIntoConstraints = NO;
    _materialView.layer.cornerRadius = 18.0;
    _materialView.clipsToBounds = YES;
    [self addSubview:_materialView];

    UIView *border = [[UIView alloc] init];
    border.translatesAutoresizingMaskIntoConstraints = NO;
    border.userInteractionEnabled = NO;
    border.backgroundColor = UIColor.clearColor;
    border.layer.cornerRadius = 18.0;
    border.layer.borderWidth = 0.8;
    border.layer.borderColor = [[UIColor whiteColor] colorWithAlphaComponent:0.14].CGColor;
    [_materialView.contentView addSubview:border];

    _headerView = [[UIView alloc] init];
    _headerView.translatesAutoresizingMaskIntoConstraints = NO;
    [_materialView.contentView addSubview:_headerView];

    _titleLabel = [[UILabel alloc] init];
    _titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _titleLabel.text = @"MAKTER";
    _titleLabel.textColor = UIColor.whiteColor;
    _titleLabel.font = [UIFont systemFontOfSize:17.0 weight:UIFontWeightBold];
    [_headerView addSubview:_titleLabel];

    _subtitleLabel = [[UILabel alloc] init];
    _subtitleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _subtitleLabel.text = @"EXTERNAL READER";
    _subtitleLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.48];
    _subtitleLabel.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightSemibold];
    [_headerView addSubview:_subtitleLabel];

    _statusDot = [[UIView alloc] init];
    _statusDot.translatesAutoresizingMaskIntoConstraints = NO;
    _statusDot.layer.cornerRadius = 4.0;
    [_headerView addSubview:_statusDot];

    _statusLabel = [[UILabel alloc] init];
    _statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _statusLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.58];
    _statusLabel.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightSemibold];
    [_headerView addSubview:_statusLabel];

    _closeButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _closeButton.translatesAutoresizingMaskIntoConstraints = NO;
    _closeButton.tintColor = UIColor.whiteColor;
    _closeButton.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.08];
    _closeButton.layer.cornerRadius = 15.0;
    [_closeButton setTitle:@"−" forState:UIControlStateNormal];
    _closeButton.titleLabel.font = [UIFont systemFontOfSize:20.0 weight:UIFontWeightMedium];
    _closeButton.accessibilityLabel = @"Minimizar menu";
    [_closeButton addTarget:self action:@selector(closePressed:) forControlEvents:UIControlEventTouchUpInside];
    [_headerView addSubview:_closeButton];

    _scrollView = [[UIScrollView alloc] init];
    _scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    _scrollView.showsVerticalScrollIndicator = NO;
    _scrollView.alwaysBounceVertical = NO;
    _scrollView.directionalLockEnabled = YES;
    _scrollView.delaysContentTouches = NO;
    _scrollView.canCancelContentTouches = YES;
    [_materialView.contentView addSubview:_scrollView];

    UIView *content = [[UIView alloc] init];
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [_scrollView addSubview:content];

    UILabel *section = [[UILabel alloc] init];
    section.translatesAutoresizingMaskIntoConstraints = NO;
    section.text = @"FUNÇÕES";
    section.textColor = MakterAccentColor();
    section.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightBold];
    [content addSubview:section];

    // 1. Player count
    UIView *playerCard = [[UIView alloc] init];
    playerCard.translatesAutoresizingMaskIntoConstraints = NO;
    playerCard.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    playerCard.layer.cornerRadius = 13.0;
    [content addSubview:playerCard];

    UILabel *playerTitle = [[UILabel alloc] init];
    playerTitle.translatesAutoresizingMaskIntoConstraints = NO;
    playerTitle.text = @"QUANTIDADE DE JOGADORES";
    playerTitle.textColor = UIColor.whiteColor;
    playerTitle.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightSemibold];
    [playerCard addSubview:playerTitle];

    UILabel *playerSubtitle = [[UILabel alloc] init];
    playerSubtitle.translatesAutoresizingMaskIntoConstraints = NO;
    playerSubtitle.text = @"Conta alvos realmente enumerados pelo leitor";
    playerSubtitle.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.50];
    playerSubtitle.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightRegular];
    [playerCard addSubview:playerSubtitle];

    _playerCountSwitch = [[UISwitch alloc] init];
    _playerCountSwitch.translatesAutoresizingMaskIntoConstraints = NO;
    _playerCountSwitch.onTintColor = MakterAccentColor();
    _playerCountSwitch.accessibilityLabel = @"Quantidade de jogadores";
    [_playerCountSwitch addTarget:self action:@selector(playerCountSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [playerCard addSubview:_playerCountSwitch];

    _playerCountStatusLabel = [[UILabel alloc] init];
    _playerCountStatusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _playerCountStatusLabel.text = @"Aguardando…";
    _playerCountStatusLabel.textColor = UIColor.whiteColor;
    _playerCountStatusLabel.font = [UIFont monospacedSystemFontOfSize:8.0 weight:UIFontWeightMedium];
    _playerCountStatusLabel.numberOfLines = 0;
    [playerCard addSubview:_playerCountStatusLabel];

    // 2. External read monitor
    UIView *readCard = [[UIView alloc] init];
    readCard.translatesAutoresizingMaskIntoConstraints = NO;
    readCard.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.055];
    readCard.layer.cornerRadius = 13.0;
    [content addSubview:readCard];

    UILabel *readTitle = [[UILabel alloc] init];
    readTitle.translatesAutoresizingMaskIntoConstraints = NO;
    readTitle.text = @"MONITOR DE LEITURA EXTERNA";
    readTitle.textColor = UIColor.whiteColor;
    readTitle.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightSemibold];
    [readCard addSubview:readTitle];

    UILabel *readSubtitle = [[UILabel alloc] init];
    readSubtitle.translatesAutoresizingMaskIntoConstraints = NO;
    readSubtitle.text = @"Prova real: task + Mach VM + memória do Unity";
    readSubtitle.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.50];
    readSubtitle.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightRegular];
    [readCard addSubview:readSubtitle];

    _readMonitorSwitch = [[UISwitch alloc] init];
    _readMonitorSwitch.translatesAutoresizingMaskIntoConstraints = NO;
    _readMonitorSwitch.onTintColor = MakterAccentColor();
    _readMonitorSwitch.accessibilityLabel = @"Monitor de leitura externa";
    [_readMonitorSwitch addTarget:self action:@selector(readMonitorSwitchChanged:) forControlEvents:UIControlEventValueChanged];
    [readCard addSubview:_readMonitorSwitch];

    _readMonitorStatusLabel = [[UILabel alloc] init];
    _readMonitorStatusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _readMonitorStatusLabel.text = @"Aguardando…";
    _readMonitorStatusLabel.textColor = UIColor.whiteColor;
    _readMonitorStatusLabel.font = [UIFont monospacedSystemFontOfSize:8.0 weight:UIFontWeightMedium];
    _readMonitorStatusLabel.numberOfLines = 0;
    [readCard addSubview:_readMonitorStatusLabel];

    // 3. Keep process verification as a standalone action.
    UIView *verifyCard = [[UIView alloc] init];
    verifyCard.translatesAutoresizingMaskIntoConstraints = NO;
    verifyCard.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.045];
    verifyCard.layer.cornerRadius = 13.0;
    [content addSubview:verifyCard];

    UILabel *verifyTitle = [[UILabel alloc] init];
    verifyTitle.translatesAutoresizingMaskIntoConstraints = NO;
    verifyTitle.text = @"VERIFICAR PROCESSO";
    verifyTitle.textColor = UIColor.whiteColor;
    verifyTitle.font = [UIFont systemFontOfSize:12.5 weight:UIFontWeightSemibold];
    [verifyCard addSubview:verifyTitle];

    UILabel *verifySubtitle = [[UILabel alloc] init];
    verifySubtitle.translatesAutoresizingMaskIntoConstraints = NO;
    verifySubtitle.text = @"Procura FreeFire e confirma o acesso externo";
    verifySubtitle.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.50];
    verifySubtitle.font = [UIFont systemFontOfSize:8.5 weight:UIFontWeightRegular];
    [verifyCard addSubview:verifySubtitle];

    _verifyButton = [UIButton buttonWithType:UIButtonTypeSystem];
    _verifyButton.translatesAutoresizingMaskIntoConstraints = NO;
    _verifyButton.tintColor = UIColor.whiteColor;
    _verifyButton.backgroundColor = MakterAccentColor();
    _verifyButton.layer.cornerRadius = 9.0;
    [_verifyButton setTitle:@"TESTAR" forState:UIControlStateNormal];
    _verifyButton.titleLabel.font = [UIFont systemFontOfSize:9.0 weight:UIFontWeightBold];
    [_verifyButton addTarget:self action:@selector(verifyPressed:) forControlEvents:UIControlEventTouchUpInside];
    [verifyCard addSubview:_verifyButton];

    _verifyStatusLabel = [[UILabel alloc] init];
    _verifyStatusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _verifyStatusLabel.text = @"Aguardando verificação…";
    _verifyStatusLabel.textColor = UIColor.whiteColor;
    _verifyStatusLabel.font = [UIFont monospacedSystemFontOfSize:8.0 weight:UIFontWeightMedium];
    _verifyStatusLabel.numberOfLines = 0;
    [verifyCard addSubview:_verifyStatusLabel];

    _hintLabel = [[UILabel alloc] init];
    _hintLabel.translatesAutoresizingMaskIntoConstraints = NO;
    _hintLabel.text = @"Somente essas funções estão ativas neste build.";
    _hintLabel.textColor = [[UIColor whiteColor] colorWithAlphaComponent:0.42];
    _hintLabel.font = [UIFont systemFontOfSize:8.0 weight:UIFontWeightRegular];
    _hintLabel.numberOfLines = 2;
    [content addSubview:_hintLabel];

    [NSLayoutConstraint activateConstraints:@[
        [_materialView.leadingAnchor constraintEqualToAnchor:self.leadingAnchor],
        [_materialView.trailingAnchor constraintEqualToAnchor:self.trailingAnchor],
        [_materialView.topAnchor constraintEqualToAnchor:self.topAnchor],
        [_materialView.bottomAnchor constraintEqualToAnchor:self.bottomAnchor],

        [border.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor],
        [border.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor],
        [border.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor],
        [border.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor],

        [_headerView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor constant:12.0],
        [_headerView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor constant:-12.0],
        [_headerView.topAnchor constraintEqualToAnchor:_materialView.contentView.topAnchor constant:10.0],
        [_headerView.heightAnchor constraintEqualToConstant:38.0],

        [_titleLabel.leadingAnchor constraintEqualToAnchor:_headerView.leadingAnchor],
        [_titleLabel.topAnchor constraintEqualToAnchor:_headerView.topAnchor],
        [_subtitleLabel.leadingAnchor constraintEqualToAnchor:_headerView.leadingAnchor],
        [_subtitleLabel.bottomAnchor constraintEqualToAnchor:_headerView.bottomAnchor],
        [_statusDot.trailingAnchor constraintEqualToAnchor:_closeButton.leadingAnchor constant:-8.0],
        [_statusDot.centerYAnchor constraintEqualToAnchor:_titleLabel.centerYAnchor],
        [_statusDot.widthAnchor constraintEqualToConstant:8.0],
        [_statusDot.heightAnchor constraintEqualToConstant:8.0],
        [_statusLabel.leadingAnchor constraintEqualToAnchor:_statusDot.trailingAnchor constant:5.0],
        [_statusLabel.centerYAnchor constraintEqualToAnchor:_statusDot.centerYAnchor],
        [_closeButton.trailingAnchor constraintEqualToAnchor:_headerView.trailingAnchor],
        [_closeButton.centerYAnchor constraintEqualToAnchor:_headerView.centerYAnchor],
        [_closeButton.widthAnchor constraintEqualToConstant:30.0],
        [_closeButton.heightAnchor constraintEqualToConstant:30.0],

        [_scrollView.leadingAnchor constraintEqualToAnchor:_materialView.contentView.leadingAnchor constant:12.0],
        [_scrollView.trailingAnchor constraintEqualToAnchor:_materialView.contentView.trailingAnchor constant:-12.0],
        [_scrollView.topAnchor constraintEqualToAnchor:_headerView.bottomAnchor constant:4.0],
        [_scrollView.bottomAnchor constraintEqualToAnchor:_materialView.contentView.bottomAnchor constant:-10.0],

        [content.leadingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.leadingAnchor],
        [content.trailingAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.trailingAnchor],
        [content.topAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.topAnchor],
        [content.bottomAnchor constraintEqualToAnchor:_scrollView.contentLayoutGuide.bottomAnchor],
        [content.widthAnchor constraintEqualToAnchor:_scrollView.frameLayoutGuide.widthAnchor],

        [section.leadingAnchor constraintEqualToAnchor:content.leadingAnchor],
        [section.trailingAnchor constraintEqualToAnchor:content.trailingAnchor],
        [section.topAnchor constraintEqualToAnchor:content.topAnchor],
        [section.heightAnchor constraintEqualToConstant:16.0],

        [playerCard.leadingAnchor constraintEqualToAnchor:content.leadingAnchor],
        [playerCard.trailingAnchor constraintEqualToAnchor:content.trailingAnchor],
        [playerCard.topAnchor constraintEqualToAnchor:section.bottomAnchor constant:6.0],
        [playerCard.heightAnchor constraintEqualToConstant:96.0],
        [playerTitle.leadingAnchor constraintEqualToAnchor:playerCard.leadingAnchor constant:12.0],
        [playerTitle.topAnchor constraintEqualToAnchor:playerCard.topAnchor constant:9.0],
        [playerTitle.trailingAnchor constraintLessThanOrEqualToAnchor:_playerCountSwitch.leadingAnchor constant:-8.0],
        [playerSubtitle.leadingAnchor constraintEqualToAnchor:playerCard.leadingAnchor constant:12.0],
        [playerSubtitle.topAnchor constraintEqualToAnchor:playerTitle.bottomAnchor constant:2.0],
        [playerSubtitle.trailingAnchor constraintLessThanOrEqualToAnchor:_playerCountSwitch.leadingAnchor constant:-8.0],
        [_playerCountSwitch.trailingAnchor constraintEqualToAnchor:playerCard.trailingAnchor constant:-10.0],
        [_playerCountSwitch.centerYAnchor constraintEqualToAnchor:playerCard.centerYAnchor],
        [_playerCountStatusLabel.leadingAnchor constraintEqualToAnchor:playerCard.leadingAnchor constant:12.0],
        [_playerCountStatusLabel.trailingAnchor constraintEqualToAnchor:playerCard.trailingAnchor constant:-12.0],
        [_playerCountStatusLabel.topAnchor constraintEqualToAnchor:playerSubtitle.bottomAnchor constant:7.0],
        [_playerCountStatusLabel.bottomAnchor constraintLessThanOrEqualToAnchor:playerCard.bottomAnchor constant:-6.0],

        [readCard.leadingAnchor constraintEqualToAnchor:content.leadingAnchor],
        [readCard.trailingAnchor constraintEqualToAnchor:content.trailingAnchor],
        [readCard.topAnchor constraintEqualToAnchor:playerCard.bottomAnchor constant:8.0],
        [readCard.heightAnchor constraintEqualToConstant:118.0],
        [readTitle.leadingAnchor constraintEqualToAnchor:readCard.leadingAnchor constant:12.0],
        [readTitle.topAnchor constraintEqualToAnchor:readCard.topAnchor constant:9.0],
        [readTitle.trailingAnchor constraintLessThanOrEqualToAnchor:_readMonitorSwitch.leadingAnchor constant:-8.0],
        [readSubtitle.leadingAnchor constraintEqualToAnchor:readCard.leadingAnchor constant:12.0],
        [readSubtitle.topAnchor constraintEqualToAnchor:readTitle.bottomAnchor constant:2.0],
        [readSubtitle.trailingAnchor constraintLessThanOrEqualToAnchor:_readMonitorSwitch.leadingAnchor constant:-8.0],
        [_readMonitorSwitch.trailingAnchor constraintEqualToAnchor:readCard.trailingAnchor constant:-10.0],
        [_readMonitorSwitch.centerYAnchor constraintEqualToAnchor:readTitle.centerYAnchor],
        [_readMonitorStatusLabel.leadingAnchor constraintEqualToAnchor:readCard.leadingAnchor constant:12.0],
        [_readMonitorStatusLabel.trailingAnchor constraintEqualToAnchor:readCard.trailingAnchor constant:-12.0],
        [_readMonitorStatusLabel.topAnchor constraintEqualToAnchor:readSubtitle.bottomAnchor constant:7.0],
        [_readMonitorStatusLabel.bottomAnchor constraintLessThanOrEqualToAnchor:readCard.bottomAnchor constant:-7.0],

        [verifyCard.leadingAnchor constraintEqualToAnchor:content.leadingAnchor],
        [verifyCard.trailingAnchor constraintEqualToAnchor:content.trailingAnchor],
        [verifyCard.topAnchor constraintEqualToAnchor:readCard.bottomAnchor constant:8.0],
        [verifyCard.heightAnchor constraintEqualToConstant:104.0],
        [verifyTitle.leadingAnchor constraintEqualToAnchor:verifyCard.leadingAnchor constant:12.0],
        [verifyTitle.topAnchor constraintEqualToAnchor:verifyCard.topAnchor constant:9.0],
        [verifyTitle.trailingAnchor constraintLessThanOrEqualToAnchor:_verifyButton.leadingAnchor constant:-8.0],
        [verifySubtitle.leadingAnchor constraintEqualToAnchor:verifyCard.leadingAnchor constant:12.0],
        [verifySubtitle.topAnchor constraintEqualToAnchor:verifyTitle.bottomAnchor constant:2.0],
        [verifySubtitle.trailingAnchor constraintLessThanOrEqualToAnchor:_verifyButton.leadingAnchor constant:-8.0],
        [_verifyButton.trailingAnchor constraintEqualToAnchor:verifyCard.trailingAnchor constant:-10.0],
        [_verifyButton.centerYAnchor constraintEqualToAnchor:verifyTitle.centerYAnchor],
        [_verifyButton.widthAnchor constraintEqualToConstant:66.0],
        [_verifyButton.heightAnchor constraintEqualToConstant:30.0],
        [_verifyStatusLabel.leadingAnchor constraintEqualToAnchor:verifyCard.leadingAnchor constant:12.0],
        [_verifyStatusLabel.trailingAnchor constraintEqualToAnchor:verifyCard.trailingAnchor constant:-12.0],
        [_verifyStatusLabel.topAnchor constraintEqualToAnchor:verifySubtitle.bottomAnchor constant:8.0],
        [_verifyStatusLabel.bottomAnchor constraintLessThanOrEqualToAnchor:verifyCard.bottomAnchor constant:-7.0],

        [_hintLabel.leadingAnchor constraintEqualToAnchor:content.leadingAnchor],
        [_hintLabel.trailingAnchor constraintEqualToAnchor:content.trailingAnchor],
        [_hintLabel.topAnchor constraintEqualToAnchor:verifyCard.bottomAnchor constant:7.0],
        [_hintLabel.bottomAnchor constraintEqualToAnchor:content.bottomAnchor constant:-10.0]
    ]];

    _headerPanGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(handleHeaderPan:)];
    _headerPanGesture.minimumNumberOfTouches = 1;
    _headerPanGesture.maximumNumberOfTouches = 1;
    _headerPanGesture.cancelsTouchesInView = NO;
    _headerPanGesture.delegate = self;
    [_headerView addGestureRecognizer:_headerPanGesture];

    self.alpha = 1.0;
    self.hidden = NO;
    [self updateFunctionPresentation];

    _refreshTimer = [NSTimer scheduledTimerWithTimeInterval:0.75
                                                     target:self
                                                   selector:@selector(refresh)
                                                   userInfo:nil
                                                    repeats:YES];
    [[NSRunLoop mainRunLoop] addTimer:_refreshTimer forMode:NSRunLoopCommonModes];
    return self;
}

- (void)dealloc
{
    [_refreshTimer invalidate];
}

- (void)playerCountSwitchChanged:(UISwitch *)sender
{
    if (sender.isOn) {
        const char *text = ESPExternalPlayerCountText();
        if (text) _playerCountStatusLabel.text = [NSString stringWithUTF8String:text];
        _hintLabel.text = @"Contagem baseada somente nos targets que o leitor externo enumerou.";
    } else {
        _playerCountStatusLabel.text = @"Desativado.";
        _hintLabel.text = @"Somente essas funções estão ativas neste build.";
    }
    [self updateFunctionPresentation];
}

- (void)readMonitorSwitchChanged:(UISwitch *)sender
{
    if (sender.isOn) {
        const char *text = ESPExternalReadMonitorText();
        if (text) _readMonitorStatusLabel.text = [NSString stringWithUTF8String:text];
        _hintLabel.text = @"O monitor executa leituras externas reais no processo alvo.";
    } else {
        _readMonitorStatusLabel.text = @"Desativado.";
        _hintLabel.text = @"Somente essas funções estão ativas neste build.";
    }
    [self updateFunctionPresentation];
}

- (void)verifyPressed:(UIButton *)sender
{
    (void)sender;
    HUDVerifyExternal();
    const char *text = ESPExternalStatusText();
    if (text) _verifyStatusLabel.text = [NSString stringWithUTF8String:text];
    _hintLabel.text = @"Verificação concluída: processo, task, UnityFramework e memória.";
    [self updateFunctionPresentation];
}

- (void)refresh
{
    if (_playerCountSwitch.isOn) {
        const char *text = ESPExternalPlayerCountText();
        if (text && _playerCountStatusLabel) _playerCountStatusLabel.text = [NSString stringWithUTF8String:text];
    }
    if (_readMonitorSwitch.isOn) {
        const char *text = ESPExternalReadMonitorText();
        if (text && _readMonitorStatusLabel) _readMonitorStatusLabel.text = [NSString stringWithUTF8String:text];
    }
    [self updateFunctionPresentation];
}

- (void)updateFunctionPresentation
{
    BOOL active = _playerCountSwitch.isOn || _readMonitorSwitch.isOn;
    _statusDot.backgroundColor = active ? [UIColor colorWithRed:1.0 green:0.55 blue:0.12 alpha:1.0]
                                         : [[UIColor whiteColor] colorWithAlphaComponent:0.26];
    _statusLabel.text = active ? @"EXTERNAL" : @"PRONTO";
}

- (void)closePressed:(UIButton *)sender
{
    (void)sender;
    if (self.closeHandler) self.closeHandler();
}

- (void)hideMenu
{
    self.hidden = YES;
    self.alpha = 0.0;
}

- (void)showMenu
{
    self.hidden = NO;
    self.alpha = 1.0;
    [self.superview bringSubviewToFront:self];
}

- (void)centerMenu
{
    UIView *host = self.superview;
    if (!host) return;
    self.center = CGPointMake(CGRectGetMidX(host.bounds), CGRectGetMidY(host.bounds));
    _hasUserPosition = NO;
}

- (void)updateForOrientation:(UIInterfaceOrientation)orientation
{
    _currentOrientation = orientation;
}

- (void)handleHeaderPan:(UIPanGestureRecognizer *)gesture
{
    UIView *host = self.superview;
    if (!host) return;
    CGPoint translation = [gesture translationInView:host];
    if (gesture.state == UIGestureRecognizerStateBegan) {
        _panStartCenter = self.center;
    } else if (gesture.state == UIGestureRecognizerStateChanged || gesture.state == UIGestureRecognizerStateEnded) {
        CGSize size = self.bounds.size;
        CGFloat x = _panStartCenter.x + translation.x;
        CGFloat y = _panStartCenter.y + translation.y;
        x = MIN(MAX(x, size.width * 0.5), host.bounds.size.width - size.width * 0.5);
        y = MIN(MAX(y, size.height * 0.5), host.bounds.size.height - size.height * 0.5);
        self.center = CGPointMake(x, y);
        _hasUserPosition = YES;
    }
}

- (BOOL)handleHUDTouchAtWindowPoint:(CGPoint)point
                              phase:(UITouchPhase)phase
                          pointerId:(NSInteger)pointerId
{
    (void)pointerId;
    if (self.hidden || self.alpha < 0.01) return NO;
    CGPoint local = [self convertPoint:point fromView:self.superview];
    BOOL inside = CGRectContainsPoint(self.bounds, local);
    if (!inside && phase == UITouchPhaseBegan) return NO;
    return inside || phase == UITouchPhaseMoved || phase == UITouchPhaseEnded || phase == UITouchPhaseCancelled;
}

@end
