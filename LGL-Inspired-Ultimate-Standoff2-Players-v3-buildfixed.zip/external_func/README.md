# LGL Inspired — Free Fire External HUD

Esta revisão reproduz a arquitetura externa do XternalZ: aplicativo separado, acesso ao processo por `task_t`/Mach VM e desenho do HUD fora do Free Fire.

## Verificar

O botão **VERIFICAR — ACESSO AO FREE FIRE** mostra um toast com diagnóstico objetivo: processo encontrado, task aberta, `UnityFramework`, cabeçalho Mach-O e quantidade de RVAs legíveis.

## Sem injetor

O build padrão não contém tweak, dylib injetada nem hook interno.

## Estado do ESP Line

A infraestrutura de desenho está preparada, porém a enumeração de entidades live ainda não é simulada. Para mostrar linhas sobre jogadores reais é necessário ligar a cadeia externa de jogadores ao snapshot.


## Build 3-function
The active menu exposes only: process verification, external player-count display, and external memory-read monitor. Legacy ESP menu controls are not exposed. Player count is only as real as the external target enumeration wired into the dump; this build does not fabricate a count.
