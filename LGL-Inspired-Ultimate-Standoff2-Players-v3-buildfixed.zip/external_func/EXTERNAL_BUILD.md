# External-only build contract

- Product type: standalone iOS application / external HUD.
- Theos target: `APPLICATION_NAME := Excalibur`.
- Output: `Excalibur.ipa` / staged `Excalibur.app`.
- No tweak target is built.
- No DynamicLibraries `.dylib` is copied into the application payload by the default build.
- `hooks/CaptainHook.h` is retained only as legacy source/reference and is not used as an in-process hook.
- The memory path is out-of-process: process lookup → Mach task → remote reads.


## Build 3-function
The active menu exposes only: process verification, external player-count display, and external memory-read monitor. Legacy ESP menu controls are not exposed. Player count is only as real as the external target enumeration wired into the dump; this build does not fabricate a count.
