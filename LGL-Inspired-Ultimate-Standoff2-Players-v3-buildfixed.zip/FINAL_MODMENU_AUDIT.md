# MAKTER Mod Menu — Final Audit

## Interaction architecture

The visible menu no longer depends on synthetic `UIEvent` delivery for its own controls.

Input ownership:
- Menu header: one-finger drag moves the panel.
- Tab strip: direct tap selects HOME / VISUAL / STYLE / SYSTEM.
- Content: direct tap activates controls; vertical movement scrolls the active page.
- Minimize: the header minus button directly hides the menu.
- Collapsed state: only the OPEN hotspot is touch-owned; tap reopens it and drag moves it.
- Outside the menu/hotspot: the existing HUD/game event path is preserved.

The direct router is pointer-ID-aware and consumes the complete touch sequence after a touch begins inside a HUD-owned control region, preventing accidental game input and duplicate activation.

## Control event semantics

The direct router dispatches:
- `UISwitch` -> toggles state and sends `UIControlEventValueChanged`
- `UISegmentedControl` -> chooses the touched segment and sends `UIControlEventValueChanged`
- buttons -> sends `UIControlEventTouchUpInside`

This avoids the previous mismatch where switches/segmented controls could receive the wrong event type.

## Existing functional modules preserved

No existing process/task/Unity/ESP source was removed. The active build still includes:
`tasks/*.mm`, `unity/*.mm`, `functions/*.mm`, and `overlay/ESPImGuiView.mm`.

Existing CaptainHook infrastructure remains in `hooks/legacy hook source (removed from build)`. No fake hook call-sites were invented.

## TrollStore / jailbreak packaging notes

The existing entitlement file was retained; no new private entitlement was added by this UI repair.

Official TrollStore documentation states that installed IPA binaries can retain arbitrary entitlements, while also documenting important limits on banned code-signing entitlements, true platformization, launch daemons, and system-process tweak injection.

For jailbreak rootless packaging, Theos documents `THEOS_PACKAGE_SCHEME=rootless`, `/var/jb` staging, rootless rpaths, and `iphoneos-arm64` package architecture.

## Validation performed

- All project plist files parsed successfully.
- Edited source delimiter balance checked.
- Menu route declaration/implementation checked.
- Root HUD route declaration/implementation checked.
- HUD bridge declaration/implementation/call checked.
- `clampCGFloat()` definition and calls checked.
- `math.h` dependencies checked.
- All menu target-action selectors have matching methods.
- No TODO/PLACEHOLDER/NOT IMPLEMENTED markers found in active menu source.
- TrollStore's three documented iOS 15 A12+ banned entitlements are not present in `ent.plist`.

## Build limitation

A real iOS/Theos build was not executed in this Linux analysis environment because Apple's Xcode/iPhoneOS SDK toolchain is not installed here. The repository's GitHub Actions workflow remains the authoritative compilation test.
