# MAKTER BR — Final Orientation / Touch Fix

## Root cause

The HUD window was visually rotated with `CGAffineTransformMakeRotation(...)`
while the AX touch position was already expressed in the active screen
coordinate space. That made the visual layer and the UIKit input coordinate
system disagree after a 90-degree rotation.

## Final design

`HUDMainWindow` no longer applies a rotation transform.

On every orientation change it:

1. Reads the screen coordinate-space bounds.
2. Builds portrait/landscape dimensions from the current screen size.
3. Resizes the HUD window to those dimensions.
4. Leaves `transform == CGAffineTransformIdentity`.

The child views therefore use normal UIKit local coordinates in both modes.

## Touch path

```text
AXEventRepresentation.location
        |
        v
current screen coordinate space
        |
        |  [HUDMainWindow convertPoint:fromView:nil]
        v
HUD window local coordinates
        |
        v
MenuView local coordinates
        |
        +--> close button
        +--> header drag
        +--> Teste switch
        +--> scroll/content
```

No manual 90/180-degree transform is applied to touch points.

## Build validation

This environment does not contain an iPhoneOS SDK or Theos toolchain, so an
arm64 iOS binary cannot be produced here. The source tree was checked for the
old window-rotation path and the new coordinate-space path is self-contained.
