# MAKTER BR 2.2.0 — final orientation/input architecture

The supplied TrollSpeed HUD project was used as the orientation reference.

- The HUD `UIWindow` remains in its stable base coordinate space.
- `HUDRootViewController.view` swaps bounds for landscape and receives one rotation transform.
- AX touch locations are forwarded unchanged to the HUD window, matching the reference event path.
- UIKit hit-testing and gesture recognition perform the coordinate conversion through the transformed root view.
- The previous deterministic direct-touch router is no longer called, eliminating its second coordinate system.
- The ESP view does not rotate independently.

This specifically targets the prior symptom where the menu visually rotated but button hitboxes and drag coordinates were displaced.
