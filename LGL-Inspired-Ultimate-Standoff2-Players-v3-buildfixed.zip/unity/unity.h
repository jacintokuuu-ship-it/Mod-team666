#pragma once

#include <mach/mach.h>
#include <stdint.h>
#include <cmath>

#include "../esp/helpers/Vector3.h"

struct ESPTMatrix {
    struct Vector4 { float x, y, z, w; } position;
    struct Vector4 rotation;
    struct Vector4 scale;
};

struct ESPMatrix4x4 {
    float m[4][4];
};

bool ESPRemoteRead(task_t task, mach_vm_address_t address, void *out, mach_vm_size_t size);

bool ESPReadTransformPosition(task_t task,
                              mach_vm_address_t transform,
                              Vector3 *outPosition);

bool ESPReadCameraMatrix(task_t task,
                         mach_vm_address_t camera,
                         ESPMatrix4x4 *outMatrix);

bool ESPWorldToScreen(const Vector3 &world,
                      const ESPMatrix4x4 &matrix,
                      float pixelWidth,
                      float pixelHeight,
                      Vector3 *outScreen);
