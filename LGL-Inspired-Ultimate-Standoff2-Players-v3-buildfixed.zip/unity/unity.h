#pragma once

/*
 * The active ESP path does not use legacy direct-memory player layouts.
 * Runtime ESP data comes from functions/ESPProbeShared.h.
 */
