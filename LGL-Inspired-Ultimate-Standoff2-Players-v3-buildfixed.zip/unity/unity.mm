#import "unity.h"
#import "../functions/Offsets.h"

#include <algorithm>
#include <cstring>

namespace {
static inline bool PlausibleAddress(mach_vm_address_t address)
{
    return address > 0x100000000ull;
}

static inline bool FiniteVector(const Vector3 &v)
{
    return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z);
}

static inline bool FiniteMatrix(const ESPMatrix4x4 &m)
{
    for (int r = 0; r < 4; ++r) {
        for (int c = 0; c < 4; ++c) {
            if (!std::isfinite(m.m[r][c])) return false;
        }
    }
    return true;
}
}

bool ESPRemoteRead(task_t task, mach_vm_address_t address, void *out, mach_vm_size_t size)
{
    if (task == MACH_PORT_NULL || !PlausibleAddress(address) || !out || size == 0)
        return false;

    vm_size_t copied = 0;
    const kern_return_t kr = vm_read_overwrite(task,
                                                (vm_address_t)address,
                                                (vm_size_t)size,
                                                (vm_address_t)out,
                                                &copied);
    return kr == KERN_SUCCESS && copied == (vm_size_t)size;
}

bool ESPReadTransformPosition(task_t task,
                              mach_vm_address_t transform,
                              Vector3 *outPosition)
{
    if (!outPosition || !PlausibleAddress(transform)) return false;

    mach_vm_address_t transObj = 0;
    if (!ESPRemoteRead(task,
                       transform + FreeFireOffsets::TransformInternalOffset,
                       &transObj,
                       sizeof(transObj)) || !PlausibleAddress(transObj)) {
        return false;
    }

    mach_vm_address_t matrix = 0;
    if (!ESPRemoteRead(task,
                       transObj + FreeFireOffsets::TransformMatrixOffset,
                       &matrix,
                       sizeof(matrix)) || !PlausibleAddress(matrix)) {
        return false;
    }

    int32_t index = -1;
    if (!ESPRemoteRead(task,
                       transObj + FreeFireOffsets::TransformIndexOffset,
                       &index,
                       sizeof(index)) || index < 0 || index > 4096) {
        return false;
    }

    mach_vm_address_t matrixList = 0;
    mach_vm_address_t matrixIndices = 0;
    if (!ESPRemoteRead(task,
                       matrix + FreeFireOffsets::TransformMatrixListOffset,
                       &matrixList,
                       sizeof(matrixList)) ||
        !ESPRemoteRead(task,
                       matrix + FreeFireOffsets::TransformMatrixIndicesOffset,
                       &matrixIndices,
                       sizeof(matrixIndices)) ||
        !PlausibleAddress(matrixList) || !PlausibleAddress(matrixIndices)) {
        return false;
    }

    ESPTMatrix resultMatrix{};
    const mach_vm_address_t resultAddress = matrixList +
        static_cast<mach_vm_address_t>(sizeof(ESPTMatrix)) * static_cast<mach_vm_address_t>(index);
    if (!ESPRemoteRead(task, resultAddress, &resultMatrix, sizeof(resultMatrix)))
        return false;

    Vector3 result(resultMatrix.position.x,
                   resultMatrix.position.y,
                   resultMatrix.position.z);
    int32_t parentIndex = -1;
    if (!ESPRemoteRead(task,
                       matrixIndices + sizeof(int32_t) * static_cast<mach_vm_address_t>(index),
                       &parentIndex,
                       sizeof(parentIndex))) {
        return false;
    }

    int guard = 0;
    while (parentIndex >= 0 && parentIndex < 4096 && guard++ < 128) {
        ESPTMatrix parent{};
        const mach_vm_address_t parentAddress = matrixList +
            static_cast<mach_vm_address_t>(sizeof(ESPTMatrix)) * static_cast<mach_vm_address_t>(parentIndex);
        if (!ESPRemoteRead(task, parentAddress, &parent, sizeof(parent)))
            return false;

        const float rotX = parent.rotation.x;
        const float rotY = parent.rotation.y;
        const float rotZ = parent.rotation.z;
        const float rotW = parent.rotation.w;

        const float scaleX = result.x * parent.scale.x;
        const float scaleY = result.y * parent.scale.y;
        const float scaleZ = result.z * parent.scale.z;

        result.x = parent.position.x + scaleX +
            (scaleX * ((rotY * rotY * -2.0f) - (rotZ * rotZ * 2.0f))) +
            (scaleY * ((rotW * rotZ * -2.0f) - (rotY * rotX * -2.0f))) +
            (scaleZ * ((rotZ * rotX * 2.0f) - (rotW * rotY * -2.0f)));

        result.y = parent.position.y + scaleY +
            (scaleX * ((rotX * rotY * 2.0f) - (rotW * rotZ * -2.0f))) +
            (scaleY * ((rotZ * rotZ * -2.0f) - (rotX * rotX * 2.0f))) +
            (scaleZ * ((rotW * rotX * -2.0f) - (rotZ * rotY * -2.0f)));

        result.z = parent.position.z + scaleZ +
            (scaleX * ((rotW * rotY * -2.0f) - (rotX * rotZ * -2.0f))) +
            (scaleY * ((rotY * rotZ * 2.0f) - (rotW * rotX * -2.0f))) +
            (scaleZ * ((rotX * rotX * -2.0f) - (rotY * rotY * 2.0f)));

        if (!ESPRemoteRead(task,
                           matrixIndices + sizeof(int32_t) * static_cast<mach_vm_address_t>(parentIndex),
                           &parentIndex,
                           sizeof(parentIndex))) {
            return false;
        }
    }

    if (!FiniteVector(result)) return false;
    *outPosition = result;
    return true;
}

bool ESPReadCameraMatrix(task_t task,
                         mach_vm_address_t camera,
                         ESPMatrix4x4 *outMatrix)
{
    if (!outMatrix || !PlausibleAddress(camera)) return false;

    mach_vm_address_t internal = 0;
    if (!ESPRemoteRead(task,
                       camera + FreeFireOffsets::CameraInternalOffset,
                       &internal,
                       sizeof(internal)) || !PlausibleAddress(internal)) {
        return false;
    }

    ESPMatrix4x4 matrix{};
    if (!ESPRemoteRead(task,
                       internal + FreeFireOffsets::CameraViewProjectionMatrixOffset,
                       &matrix,
                       sizeof(matrix)) || !FiniteMatrix(matrix)) {
        return false;
    }

    // Reject obviously uninitialized memory while allowing extreme but finite FOVs.
    const float basis = std::fabs(matrix.m[0][0]) +
                        std::fabs(matrix.m[1][1]) +
                        std::fabs(matrix.m[2][2]);
    if (!std::isfinite(basis) || basis < 0.00001f || basis > 100000.0f)
        return false;

    *outMatrix = matrix;
    return true;
}

bool ESPWorldToScreen(const Vector3 &world,
                      const ESPMatrix4x4 &matrix,
                      float pixelWidth,
                      float pixelHeight,
                      Vector3 *outScreen)
{
    if (!outScreen || pixelWidth <= 1.0f || pixelHeight <= 1.0f || !FiniteVector(world))
        return false;

    const float transX = matrix.m[0][3];
    const float transY = matrix.m[1][3];
    const float transZ = matrix.m[2][3];
    const float rightX = matrix.m[0][0];
    const float rightY = matrix.m[1][0];
    const float rightZ = matrix.m[2][0];
    const float upX = matrix.m[0][1];
    const float upY = matrix.m[1][1];
    const float upZ = matrix.m[2][1];

    const float w = transX * world.x + transY * world.y + transZ * world.z + matrix.m[3][3];
    if (!std::isfinite(w) || w < 0.01f)
        return false;

    const float screenX = rightX * world.x + rightY * world.y + rightZ * world.z + matrix.m[3][0];
    const float screenY = upX * world.x + upY * world.y + upZ * world.z + matrix.m[3][1];

    const float halfW = pixelWidth * 0.5f;
    const float halfH = pixelHeight * 0.5f;

    outScreen->x = halfW * (1.0f + screenX / w);
    outScreen->y = halfH * (1.0f - screenY / w);
    outScreen->z = w;

    return std::isfinite(outScreen->x) &&
           std::isfinite(outScreen->y) &&
           std::isfinite(outScreen->z);
}
